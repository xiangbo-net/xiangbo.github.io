# -*- coding: utf-8 -*-
"""
案例8《采购入库单生成与库存更新》核心入库程序
================================================
功能：
  ① 读取 入库核对异常清单（承接案例7）+ 送货单结构化结果 + ERP模板 + 库存台账 + 库位主数据 + 历史入库记录
  ② 筛选"核对通过且可入库"的明细（风险等级=正常）
  ③ 映射到 ERP 入库单字段（仓库/库位/物料/数量/批次/PO/供应商/入库日期）
  ④ 入库前校验：
      校验1 重复入库（同一送货单+物料+批次 已在历史入库记录中）
      校验2 库位缺失（物料默认库位不在库位主数据中）
      校验3 负库存（当前库存 - 出库 为负）
      校验4 未检验/不合格（IQC 非 OK）
  ⑤ 输出 4 个交付物到 03-output/：
      ERP入库单_可导入.xlsx（通过校验的）
      库存更新后台账.xlsx
      库存更新差异表.xlsx
      采购入库工作台账.xlsx
  ⑥ 补充输出 看板.html
"""
import os

from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# ============================================================
# ★ 可调设置区（员工提修改需求只改这里，不要动下方核心逻辑）★
# ============================================================
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BATCH_NO = '2026W31'            # 批次（可改）
PROCESSOR = '仓库助理'          # 默认处理人（可改）
IN_DATE = '2026-08-06'         # 入库日期（可改）

# 1) 行颜色（十六进制色号，不带 #，可改）
COLOR_PASS = 'E2EFDA'           # 可入库：浅绿
COLOR_PENDING = 'FFF2CC'        # 需人工确认：浅黄
COLOR_DUP = 'F8CBAD'            # 重复入库：浅橙
COLOR_REJECT = 'D9D9D9'         # 禁止入库：浅灰

# 2) 状态标签（可改）
LABEL_PASS = '可入库'
LABEL_PENDING = '需人工确认'
LABEL_DUP = '重复入库'
LABEL_LOC = '库位缺失'
LABEL_NEG = '负库存'
LABEL_REJECT = '禁止入库'

# 状态 → 填充色 映射（xlsx 与 HTML 看板共用同一套色系）
STATUS_FILL = {
    LABEL_PASS: 'E2EFDA',       # 绿
    LABEL_PENDING: 'FFF2CC',    # 黄
    LABEL_DUP: 'F8CBAD',        # 橙
    LABEL_NEG: 'F8CBAD',        # 橙（负库存同样异常）
    LABEL_LOC: 'FFF2CC',        # 黄（库位缺失需确认）
    LABEL_REJECT: 'D9D9D9',     # 灰
}
STATUS_FONT = {
    LABEL_PASS: '375623',       # 深绿字
    LABEL_PENDING: '7F6000',    # 深黄字
    LABEL_DUP: '833C00',        # 深橙字
    LABEL_NEG: '833C00',        # 深橙字
    LABEL_LOC: '7F6000',        # 深黄字
    LABEL_REJECT: '404040',     # 深灰字
}

# 3) 功能开关（True=启用 / False=关闭，可改）
ENABLE_CHECK_DUP = True        # 校验1 重复入库
ENABLE_CHECK_LOC = True        # 校验2 库位缺失
ENABLE_CHECK_NEG = True        # 校验3 负库存

# ============================================================
# 样式常量（由上方可调设置生成，一般无需改动）
# ============================================================
HEADER_FILL = PatternFill('solid', fgColor='1F4E79')
HEADER_FONT = Font(bold=True, color='FFFFFF')
FILL_OK = PatternFill('solid', fgColor=COLOR_PASS)
FILL_LOW = PatternFill('solid', fgColor=COLOR_PENDING)
FILL_MID = PatternFill('solid', fgColor=COLOR_DUP)
FILL_HIGH = PatternFill('solid', fgColor=COLOR_REJECT)
FILL_MAP = {st: PatternFill('solid', fgColor=hexc) for st, hexc in STATUS_FILL.items()}
FONT_MAP = {st: Font(color=hexc) for st, hexc in STATUS_FONT.items()}
THIN = Side(style='thin', color='B0B0B0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# ---------- 路径常量 ----------
P_ANOMALY = f'{ROOT}/01-input/入库核对异常清单.xlsx'
P_DELIVERY = f'{ROOT}/01-input/送货单OCR结构化结果.xlsx'
P_ERP = f'{ROOT}/01-input/ERP入库单模板.xlsx'
P_STOCK = f'{ROOT}/01-input/库存台账_实时库存.xlsx'
P_LOC = f'{ROOT}/01-input/库位主数据.xlsx'
P_HISTORY = f'{ROOT}/04-archive/历史入库记录.xlsx'
P_OUT_ERP = f'{ROOT}/03-output/ERP入库单_可导入.xlsx'
P_OUT_BACK = f'{ROOT}/03-output/库存更新后台账.xlsx'
P_OUT_DIFF = f'{ROOT}/03-output/库存更新差异表.xlsx'
P_OUT_WORK = f'{ROOT}/03-output/采购入库工作台账.xlsx'
P_OUT_BOARD = f'{ROOT}/03-output/入库单看板.html'
P_OUT_NOTICE = f'{ROOT}/03-output/企业微信通知草稿.txt'


def read_rows(path):
    """读取 xlsx 全部行。健壮性：文件缺失时返回空并提示（不崩溃）。"""
    if not os.path.exists(path):
        print(f'[兜底-提示] 文件不存在，按空处理: {path}')
        return [], []
    wb = load_workbook(path)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        return [], []
    return list(rows[0]), list(rows[1:])


def style_sheet(ws, widths=None):
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = BORDER
    if widths:
        for col, w in widths.items():
            ws.column_dimensions[col].width = w


def main():
    print(f'[批次] {BATCH_NO} 采购入库单生成与库存更新开始 ...')

    # 1. 加载数据
    ha, a_rows = read_rows(P_ANOMALY)
    hd, d_rows = read_rows(P_DELIVERY)
    he, e_rows = read_rows(P_ERP)
    hs, s_rows = read_rows(P_STOCK)
    hl, l_rows = read_rows(P_LOC)
    hh, h_rows = read_rows(P_HISTORY)
    print(f'[读取] 核对清单 {len(a_rows)} | 送货单 {len(d_rows)} | 库存 {len(s_rows)} | 库位 {len(l_rows)} | 历史入库 {len(h_rows)}')

    # 2. 组织数据
    delivery_map = {}   # 送货单号 -> 行字典
    for r in d_rows:
        if r and r[0]:
            delivery_map[str(r[0]).strip()] = dict(zip(hd, r))
    stock_map = {}      # 物料编码 -> (当前库存, 库位)
    for r in s_rows:
        if r and r[0]:
            # 表头: [物料编码, 物料名称, 当前库存, 单位, 库位, 最近入库日期] → 库位在第 5 列(r[4])
            stock_map[str(r[0]).strip()] = (float(r[2]) if r[2] is not None else 0,
                                            str(r[4]).strip() if len(r) > 4 and r[4] else '')
    loc_set = {str(r[0]).strip() for r in l_rows if r and r[0]}
    history_keys = set()   # (送货单号, 物料编码, 批次)
    for r in h_rows:
        if r and r[0]:
            history_keys.add((str(r[1]).strip() if len(r) > 1 and r[1] else '',
                              str(r[2]).strip() if len(r) > 2 and r[2] else '',
                              str(r[3]).strip() if len(r) > 3 and r[3] else ''))

    # 3. 筛选可入库明细
    erp_rows = []    # 可导入入库单行
    diff_rows = []   # 库存差异表
    work_rows = []   # 工作台账
    stat = {LABEL_PASS: 0, LABEL_PENDING: 0, LABEL_DUP: 0, LABEL_LOC: 0, LABEL_NEG: 0, LABEL_REJECT: 0}

    for r in a_rows:
        if not r or not r[0]:
            continue
        sd_no = str(r[0]).strip()
        supplier = str(r[1]).strip() if r[1] else ''
        po_no = str(r[2]).strip() if r[2] else ''
        mat_code = str(r[3]).strip() if r[3] else ''
        mat_name = str(r[4]).strip() if r[4] else ''
        qty = float(r[5]) if r[5] is not None else 0
        unit = str(r[6]).strip() if r[6] else ''
        risk = str(r[8]).strip() if len(r) > 8 and r[8] else ''
        action = str(r[9]).strip() if len(r) > 9 and r[9] else ''

        # 送货单补充字段（批次/送货日期）
        delivery = delivery_map.get(sd_no, {})
        batch = str(delivery.get('批次') or '').strip()
        d_date = str(delivery.get('送货日期') or '').strip()

        # 只处理"正常/可入库"的
        if action != '可入库' and risk != '正常':
            work_rows.append({
                '批次号': BATCH_NO, '送货单号': sd_no, '物料编码': mat_code, '物料名称': mat_name,
                '数量': qty, '单位': unit, '批次': batch,
                '校验结果': LABEL_REJECT, '原因': f'核对未通过（{risk}）',
                '建议动作': action, '复核状态': '不处理',
            })
            diff_rows.append({
                '送货单号': sd_no, '物料编码': mat_code, '物料名称': mat_name,
                '入库数量': qty, '入库前库存': '-', '入库后库存': '-',
                '状态': LABEL_REJECT, '说明': f'核对未通过（{risk}）',
            })
            stat[LABEL_REJECT] += 1
            continue

        # ---- 入库前校验 ----
        checks = []
        # 校验1 重复入库
        if ENABLE_CHECK_DUP and (sd_no, mat_code, batch) in history_keys:
            checks.append((LABEL_DUP, f'送货单 {sd_no} + {mat_code} + 批次 {batch} 已在历史入库记录中'))
        # 校验2 库位缺失（从库存台账取库位，检查是否在库位主数据中）
        cur_stock, loc = stock_map.get(mat_code, (0, ''))
        if ENABLE_CHECK_LOC and loc and loc not in loc_set:
            checks.append((LABEL_LOC, f'物料 {mat_code} 默认库位「{loc}」不在库位主数据中'))
        # 校验3 负库存
        if ENABLE_CHECK_NEG and (cur_stock + qty) < 0:
            checks.append((LABEL_NEG, f'入库后库存 {cur_stock}+{qty:.0f}={cur_stock+qty:.0f} 为负'))

        # 判定
        if checks:
            # 重复入库/负库存 → 禁止；库位缺失 → 需人工确认
            level = LABEL_DUP if any(c[0] == LABEL_DUP for c in checks) else (
                LABEL_NEG if any(c[0] == LABEL_NEG for c in checks) else LABEL_PENDING)
            status = LABEL_PENDING if any(c[0] == LABEL_LOC for c in checks) else '禁止入库'
            reason = '；'.join(f'{t}: {d}' for t, d in checks)
            # 库位缺失但其他没问题 → 需人工确认（可先挂起）
            if level == LABEL_PENDING:
                pass
            else:
                status = '禁止入库'
            work_rows.append({
                '批次号': BATCH_NO, '送货单号': sd_no, '物料编码': mat_code, '物料名称': mat_name,
                '数量': qty, '单位': unit, '批次': batch,
                '校验结果': '；'.join(t for t, d in checks), '原因': reason,
                '建议动作': '人工确认后入库' if level == LABEL_PENDING else '禁止自动入库',
                '复核状态': LABEL_PENDING if level == LABEL_PENDING else '不处理',
            })
            stat[level] += 1
            diff_rows.append({
                '送货单号': sd_no, '物料编码': mat_code, '物料名称': mat_name,
                '入库数量': qty, '入库前库存': cur_stock, '入库后库存': cur_stock + qty,
                '状态': level, '说明': reason,
            })
            continue

        # ---- 通过校验 → 生成 ERP 入库单 ----
        erp_rows.append({
            '仓库': '成品仓', '库位': loc or '待分配', '物料编码': mat_code, '物料名称': mat_name,
            '数量': qty, '单位': unit, '批次': batch or '待补', 'PO号': po_no,
            '供应商': supplier, '入库日期': IN_DATE, '备注': '三单匹配通过，可入库',
        })
        diff_rows.append({
            '送货单号': sd_no, '物料编码': mat_code, '物料名称': mat_name,
            '入库数量': qty, '入库前库存': cur_stock, '入库后库存': cur_stock + qty,
            '状态': LABEL_PASS, '说明': '正常入库',
        })
        work_rows.append({
            '批次号': BATCH_NO, '送货单号': sd_no, '物料编码': mat_code, '物料名称': mat_name,
            '数量': qty, '单位': unit, '批次': batch,
            '校验结果': LABEL_PASS, '原因': '通过三单匹配 + 入库前校验',
            '建议动作': '确认后导入 ERP', '复核状态': LABEL_PENDING,
        })
        stat[LABEL_PASS] += 1

    print(f'[校验] 可入库 {stat[LABEL_PASS]} / 需确认 {stat[LABEL_PENDING]} / 重复 {stat[LABEL_DUP]} / 库位缺失 {stat[LABEL_LOC]} / 负库存 {stat[LABEL_NEG]} / 禁止 {stat[LABEL_REJECT]}')

    # 4. 输出 1：ERP入库单_可导入.xlsx（按模板表头）
    wb = Workbook()
    ws = wb.active
    ws.title = 'ERP入库单'
    headers = list(e_rows[0]) if e_rows else ['仓库', '库位', '物料编码', '物料名称', '数量', '单位', '批次', 'PO号', '供应商', '入库日期', '备注']
    ws.append(headers)
    for r in erp_rows:
        ws.append([r.get(h, '') for h in headers])
    style_sheet(ws, {'A': 10, 'B': 10, 'C': 12, 'D': 18, 'E': 10, 'F': 8, 'G': 14, 'H': 14, 'I': 22, 'J': 12, 'K': 20})
    wb.save(P_OUT_ERP)
    print(f'[OK] ERP入库单_可导入.xlsx（{len(erp_rows)} 行）')

    # 5. 输出 2：库存更新后台账.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '库存更新后台账'
    headers = ['物料编码', '物料名称', '原库存', '入库数量', '新库存', '单位', '库位', '更新时间', '处理人', '状态']
    ws.append(headers)
    # 汇总已通过入库的库存变化
    for r in diff_rows:
        if r['状态'] == LABEL_PASS:
            ws.append([r['物料编码'], r['物料名称'], r['入库前库存'], r['入库数量'],
                       r['入库后库存'], '', '', datetime.now().strftime('%Y-%m-%d %H:%M:%S'), PROCESSOR, LABEL_PASS])
    style_sheet(ws, {'A': 12, 'B': 18, 'C': 10, 'D': 10, 'E': 10, 'F': 8, 'G': 10, 'H': 18, 'I': 10, 'J': 10})
    wb.save(P_OUT_BACK)
    print(f'[OK] 库存更新后台账.xlsx（{ws.max_row-1} 行）')

    # 6. 输出 3：库存更新差异表.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '库存更新差异表'
    h = ['送货单号', '物料编码', '物料名称', '入库数量', '入库前库存', '入库后库存', '状态', '说明']
    ws.append(h)
    for r in diff_rows:
        ws.append([r[k] for k in h])
    style_sheet(ws, {'A': 14, 'B': 12, 'C': 18, 'D': 10, 'E': 12, 'F': 12, 'G': 12, 'H': 34})
    for row_idx in range(2, ws.max_row + 1):
        st = str(ws.cell(row=row_idx, column=7).value)
        fill = FILL_MAP.get(st, FILL_OK)
        font = FONT_MAP.get(st)
        for c in range(1, len(h) + 1):
            cell = ws.cell(row=row_idx, column=c)
            cell.fill = fill
            if font:
                cell.font = font
    wb.save(P_OUT_DIFF)
    print(f'[OK] 库存更新差异表.xlsx（{len(diff_rows)} 行）')

    # 7. 输出 4：采购入库工作台账.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '采购入库工作台账'
    h4 = ['批次号', '送货单号', '物料编码', '物料名称', '数量', '单位', '批次',
          '校验结果', '原因', '建议动作', '复核状态']
    ws.append(h4)
    for r in work_rows:
        ws.append([r[k] for k in h4])
    style_sheet(ws, {'A': 10, 'B': 14, 'C': 12, 'D': 18, 'E': 10, 'F': 8, 'G': 14,
                     'H': 14, 'I': 34, 'J': 14, 'K': 12})
    for row_idx in range(2, ws.max_row + 1):
        # 第 8 列"校验结果"含状态标签（可入库/重复入库/库位缺失/禁止入库等）
        st_raw = str(ws.cell(row=row_idx, column=8).value)
        # 取第一个状态词（如"重复入库；库位缺失" → "重复入库"）
        st_key = next((k for k in STATUS_FILL if k in st_raw), None)
        fill = FILL_MAP.get(st_key, FILL_OK)
        font = FONT_MAP.get(st_key)
        for c in range(1, len(h4) + 1):
            cell = ws.cell(row=row_idx, column=c)
            cell.fill = fill
            if font:
                cell.font = font
    wb.save(P_OUT_WORK)
    print(f'[OK] 采购入库工作台账.xlsx（{len(work_rows)} 行）')

    # 8. 输出 5：入库单看板.html（含横向滚动）
    # 状态 → CSS class 映射（与 xlsx 同一套色系）
    STATUS_CLS = {
        LABEL_PASS: 'row-pass',      # 绿
        LABEL_PENDING: 'row-pending',  # 黄
        LABEL_LOC: 'row-pending',      # 黄（库位缺失需确认）
        LABEL_DUP: 'row-dup',          # 橙
        LABEL_NEG: 'row-dup',          # 橙（负库存同样异常）
        LABEL_REJECT: 'row-reject',    # 灰
    }
    diff_html = ''
    for r in diff_rows:
        cls = STATUS_CLS.get(r['状态'], 'row-pass')
        # 入库前/后库存可能是数字或字符串'-'（核对未通过的）
        pre = f"{r['入库前库存']:.0f}" if isinstance(r['入库前库存'], (int, float)) else r['入库前库存']
        post = f"{r['入库后库存']:.0f}" if isinstance(r['入库后库存'], (int, float)) else r['入库后库存']
        qty = f"{r['入库数量']:.0f}" if isinstance(r['入库数量'], (int, float)) else r['入库数量']
        diff_html += (f"<tr class='{cls}'><td>{r['送货单号']}</td><td>{r['物料编码']}</td><td>{r['物料名称']}</td>"
                      f"<td>{qty}</td><td>{pre}</td><td>{post}</td>"
                      f"<td>{r['状态']}</td><td>{r['说明']}</td></tr>")
    board = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>采购入库看板 - {BATCH_NO}</title>
<style>
body{{font-family:'Microsoft YaHei',sans-serif;background:#f5f6fa;margin:0;padding:24px;color:#222}}
h1{{font-size:22px}} .cards{{display:flex;gap:16px;flex-wrap:wrap;margin:20px 0}}
.card{{background:#fff;border-radius:10px;padding:18px 22px;min-width:140px;box-shadow:0 1px 4px rgba(0,0,0,.08)}}
.card .num{{font-size:30px;font-weight:bold}} .card .lbl{{color:#888;font-size:13px;margin-top:4px}}
.red{{color:#C00000}} .orange{{color:#ED7D31}} .yellow{{color:#BF9000}} .green{{color:#548235}}
.table-wrap{{overflow-x:auto;-webkit-overflow-scrolling:touch;background:#fff;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:20px}}
.table-wrap table{{border-collapse:collapse;width:100%;min-width:760px;table-layout:auto}}
th,td{{padding:10px 12px;text-align:left;border-bottom:1px solid #eee;font-size:13px;white-space:normal;word-break:break-word}}
th{{background:#1F4E79;color:#fff}}
tr.row-pass td{{background:#E2EFDA;color:#375623}}
tr.row-pending td{{background:#FFF2CC;color:#7F6000}}
tr.row-dup td{{background:#F8CBAD;color:#833C00}}
tr.row-reject td{{background:#D9D9D9;color:#404040}}
</style></head><body>
<h1>采购入库看板 · {BATCH_NO}</h1>
<div class="cards">
<div class="card"><div class="num">{len(diff_rows)}</div><div class="lbl">本批明细</div></div>
<div class="card"><div class="num green">{stat[LABEL_PASS]}</div><div class="lbl">可入库</div></div>
<div class="card"><div class="num orange">{stat[LABEL_PENDING]}</div><div class="lbl">需人工确认</div></div>
<div class="card"><div class="num red">{stat[LABEL_DUP]+stat[LABEL_NEG]+stat[LABEL_LOC]}</div><div class="lbl">校验异常</div></div>
<div class="card"><div class="num grey">{stat[LABEL_REJECT]}</div><div class="lbl">核对未通过</div></div>
</div>
<p><b>入库前校验异常：</b>重复入库 {stat[LABEL_DUP]} 项、库位缺失 {stat[LABEL_LOC]} 项、负库存 {stat[LABEL_NEG]} 项</p>
<h3>库存更新差异表</h3>
<div class="table-wrap"><table><tr><th>送货单号</th><th>物料编码</th><th>物料名称</th><th>入库数量</th><th>入库前库存</th><th>入库后库存</th><th>状态</th><th>说明</th></tr>
{diff_html}
</table></div></body></html>"""
    with open(P_OUT_BOARD, 'w', encoding='utf-8') as f:
        f.write(board)
    print('[OK] 入库单看板.html')

    # 9. 汇总
    print('\n===== 批次汇总 =====')
    print(f'明细: {len(diff_rows)} | 可入库: {stat[LABEL_PASS]} | 需确认: {stat[LABEL_PENDING]} | '
          f'重复: {stat[LABEL_DUP]} | 库位缺失: {stat[LABEL_LOC]} | 负库存: {stat[LABEL_NEG]} | 核对未通过: {stat[LABEL_REJECT]}')
    print(f'ERP 可导入行数: {len(erp_rows)}（导入前需仓库人工确认）')

    # 10. 企业微信通知草稿.txt（脚本自动生成，AI 检测绑定后决定发送或告知草稿）
    # （5.0.10 起企微消息能力已全面开放（不限企业规模），AI 可直接发送；发送失败时草稿兜底）
    dup_list = [r['送货单号'] for r in diff_rows if r['状态'] == LABEL_DUP]
    pending_list = [r['送货单号'] for r in diff_rows if r['状态'] in (LABEL_PENDING, LABEL_LOC)]
    n_lines = ['【采购入库通知】',
               f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}',
               f'本批明细 {len(diff_rows)} 条：可入库 {stat[LABEL_PASS]} / 需人工确认 {stat[LABEL_PENDING]} / 重复入库 {stat[LABEL_DUP]} / 库位缺失 {stat[LABEL_LOC]} / 负库存 {stat[LABEL_NEG]} / 核对未通过 {stat[LABEL_REJECT]}',
               f'ERP 可导入行数：{len(erp_rows)}（导入前需仓库人工确认）']
    if dup_list:
        n_lines.append(f'重复入库疑点（{len(dup_list)}）：{"、".join(dup_list)}')
    if pending_list:
        n_lines.append(f'需人工确认（{len(pending_list)}）：{"、".join(pending_list)}')
    n_lines.append('提示：入库单导入 ERP 前必须由仓库人工确认，不自动导入。')
    with open(P_OUT_NOTICE, 'w', encoding='utf-8') as f:
        f.write('\n'.join(n_lines))

    print(f'[OK] 企业微信通知草稿.txt（可入库 {stat[LABEL_PASS]} / 待确认 {stat[LABEL_PENDING]}）')


if __name__ == '__main__':
    main()
