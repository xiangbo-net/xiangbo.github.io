# -*- coding: utf-8 -*-
"""
案例7《采购送货单识别与三单匹配》输入素材生成器
================================================
生成素材：
  1. 01-input/送货单扫描件/  — 8 张送货单图片（模拟纸质扫描件，PIL 绘制）
  2. 01-input/送货单结构化结果.xlsx — 送货单 OCR 识别产物（8 条，覆盖 6 类异常）
  3. 01-input/PO_采购订单清单_2026W31.xlsx — 采购订单（6 条 PO）
  4. 01-input/IQC_来料检验结果_2026W31.xlsx — 来料检验结果（7 条）
  5. 01-input/物料主数据.xlsx — 物料主数据（6 条）
  6. 02-working/送货单OCR字段模板.xlsx — 识别字段模板（规则/模板 → 02-working）
样例覆盖 6 项检查：PO不存在 / 物料不一致 / 数量超交短交 / 批次缺失 / 未检验或不合格 / 逾期到货
用法：python gen_input_files.py（在案例7项目根目录下运行）
"""
import os
from openpyxl import Workbook

from PIL import Image, ImageDraw, ImageFont

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ============ 送货单数据（与图片一一对应） ============
# (送货单号, 供应商, PO号, 物料编码, 物料名称, 批次, 数量, 单位, 送货日期)
DELIVERIES = [
    ('SD2026-0701', '东莞京东利昇贸易', 'PO-2026-071', 'WL-1001', 'USB-C 数据线',    'B20260701', 100, '条', '2026-07-25'),
    ('SD2026-0702', '广州华安材料',     'PO-9999',     'WL-1002', '电子元器件包',    'B20260702',  50, '包', '2026-07-26'),  # PO不存在
    ('SD2026-0703', '深圳市腾达云服务', 'PO-2026-072', 'WL-9999', '无线网卡',        'B20260703',  30, '个', '2026-07-27'),  # 物料不一致
    ('SD2026-0704', '上海精工设备',     'PO-2026-073', 'WL-1003', '精密轴承',        'B20260704', 120, '套', '2026-07-28'),  # 数量超交
    ('SD2026-0705', '深圳市顺丰物流',   'PO-2026-074', 'WL-1004', '包装纸箱',        '',           500, '个', '2026-07-29'),  # 批次缺失
    ('SD2026-0706', '东莞京东利昇贸易', 'PO-2026-075', 'WL-1005', '电源适配器',      'B20260706',  80, '个', '2026-07-30'),  # 未检验
    ('SD2026-0707', '广州华安材料',     'PO-2026-076', 'WL-1006', '螺丝套装',        'B20260707', 200, '盒', '2026-07-31'),  # 不合格(NG)
    ('SD2026-0708', '深圳市凯悦大酒楼', 'PO-2026-077', 'WL-1001', 'USB-C 数据线',    'B20260708',  60, '条', '2026-08-05'),  # 逾期到货
]

# ============ PO 采购订单清单 ============
# (PO号, 供应商, 物料编码, 物料名称, 订购数量, 单位, 约定到货日期)
POS = [
    ('PO-2026-071', '东莞京东利昇贸易', 'WL-1001', 'USB-C 数据线',    100, '条', '2026-07-28'),
    ('PO-2026-072', '深圳市腾达云服务', 'WL-1002', '电子元器件包',     50, '包', '2026-07-30'),
    ('PO-2026-073', '上海精工设备',     'WL-1003', '精密轴承',       100, '套', '2026-07-30'),
    ('PO-2026-074', '深圳市顺丰物流',   'WL-1004', '包装纸箱',       500, '个', '2026-07-31'),
    ('PO-2026-075', '东莞京东利昇贸易', 'WL-1005', '电源适配器',      80, '个', '2026-08-01'),
    ('PO-2026-076', '广州华安材料',     'WL-1006', '螺丝套装',       200, '盒', '2026-08-02'),
    ('PO-2026-077', '深圳市凯悦大酒楼', 'WL-1001', 'USB-C 数据线',    60, '条', '2026-08-01'),
]

# ============ IQC 来料检验结果 ============
# (送货单号, 物料编码, 检验结果, 检验日期, 检验员)
IQC = [
    ('SD2026-0701', 'WL-1001', 'OK',  '2026-07-25', '质检员-林'),
    ('SD2026-0702', 'WL-1002', 'OK',  '2026-07-26', '质检员-林'),
    ('SD2026-0703', 'WL-9999', 'OK',  '2026-07-27', '质检员-林'),
    ('SD2026-0704', 'WL-1003', 'OK',  '2026-07-28', '质检员-林'),
    ('SD2026-0705', 'WL-1004', 'OK',  '2026-07-29', '质检员-林'),
    # SD2026-0706 无检验记录（未检验）
    ('SD2026-0707', 'WL-1006', 'NG',  '2026-07-31', '质检员-林'),  # 不合格
    ('SD2026-0708', 'WL-1001', 'OK',  '2026-08-05', '质检员-林'),
]

# ============ 物料主数据 ============
# (物料编码, 物料名称, 规格型号, 单位, 默认供应商)
MATERIALS = [
    ('WL-1001', 'USB-C 数据线',    'Type-C 1.5m 白色', '条', '东莞京东利昇贸易'),
    ('WL-1002', '电子元器件包',     '通用散料包',       '包', '广州华安材料'),
    ('WL-1003', '精密轴承',        '6204 深沟球',      '套', '上海精工设备'),
    ('WL-1004', '包装纸箱',        '40x30x20cm',      '个', '深圳市顺丰物流'),
    ('WL-1005', '电源适配器',      '12V 2A',           '个', '东莞京东利昇贸易'),
    ('WL-1006', '螺丝套装',        'M3 混合套装',      '盒', '广州华安材料'),
]


def find_font(size):
    """查找可用的中文字体。"""
    candidates = [
        'C:/Windows/Fonts/msyh.ttc',     # 微软雅黑
        'C:/Windows/Fonts/simhei.ttf',   # 黑体
        'C:/Windows/Fonts/simsun.ttc',   # 宋体
    ]
    for f in candidates:
        if os.path.exists(f):
            try:
                return ImageFont.truetype(f, size)
            except Exception:
                continue
    return ImageFont.load_default()


def draw_delivery(sd_no, supplier, po, mat_code, mat_name, batch, qty, unit, date, out_path):
    """用 PIL 绘制一张模拟纸质送货单（白底黑字 + 表格线）。"""
    W, H = 900, 560
    img = Image.new('RGB', (W, H), 'white')
    d = ImageDraw.Draw(img)
    f_title = find_font(34)
    f_head = find_font(22)
    f_body = find_font(20)

    # 标题
    d.text((330, 30), '采购送货单', fill='black', font=f_title)
    # 头部信息
    d.text((50, 100), f'送货单号：{sd_no}', fill='black', font=f_head)
    d.text((50, 140), f'供应商：{supplier}', fill='black', font=f_head)
    d.text((50, 180), f'PO 单号：{po}', fill='black', font=f_head)
    d.text((500, 140), f'送货日期：{date}', fill='black', font=f_head)

    # 表格
    x0, y0 = 50, 230
    col_ws = [110, 240, 150, 150, 90, 80]
    row_h = 45
    headers = ['物料编码', '物料名称', '批次号', '数量', '单位', '备注']
    cells = [
        (mat_code, mat_name, batch or '—', str(qty), unit, ''),
    ]
    # 画表头
    x = x0
    for i, h in enumerate(headers):
        d.rectangle([x, y0, x + col_ws[i], y0 + row_h], outline='black')
        d.text((x + 10, y0 + 10), h, fill='black', font=f_body)
        x += col_ws[i]
    # 画数据行
    y = y0 + row_h
    for row in cells:
        x = x0
        for i, v in enumerate(row):
            d.rectangle([x, y, x + col_ws[i], y + row_h], outline='black')
            d.text((x + 10, y + 10), v, fill='black', font=f_body)
            x += col_ws[i]
        y += row_h

    # 底部
    d.text((50, y + 20), '收货人签字：____________    送货人签字：____________', fill='black', font=f_head)
    img.save(out_path)
    print(f'[OK] 送货单图片 {sd_no}.png')


def write_deliveries_images():
    out_dir = os.path.join(ROOT, '01-input', '送货单扫描件')
    for r in DELIVERIES:
        draw_delivery(*r, os.path.join(out_dir, f'{r[0]}.png'))


def write_delivery_result():
    wb = Workbook()
    ws = wb.active
    ws.title = '送货单结构化结果'
    headers = ['送货单号', '供应商', 'PO号', '物料编码', '物料名称', '批次', '数量', '单位', '送货日期']
    ws.append(headers)
    for r in DELIVERIES:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '01-input', '送货单结构化结果.xlsx'))
    print(f'[OK] 送货单结构化结果.xlsx（{len(DELIVERIES)} 条）')


def write_po():
    wb = Workbook()
    ws = wb.active
    ws.title = '采购订单清单'
    headers = ['PO号', '供应商', '物料编码', '物料名称', '订购数量', '单位', '约定到货日期']
    ws.append(headers)
    for r in POS:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '01-input', 'PO_采购订单清单_2026W31.xlsx'))
    print(f'[OK] PO_采购订单清单_2026W31.xlsx（{len(POS)} 条）')


def write_iqc():
    wb = Workbook()
    ws = wb.active
    ws.title = '来料检验结果'
    headers = ['送货单号', '物料编码', '检验结果', '检验日期', '检验员']
    ws.append(headers)
    for r in IQC:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '01-input', 'IQC_来料检验结果_2026W31.xlsx'))
    print(f'[OK] IQC_来料检验结果_2026W31.xlsx（{len(IQC)} 条）')


def write_materials():
    wb = Workbook()
    ws = wb.active
    ws.title = '物料主数据'
    headers = ['物料编码', '物料名称', '规格型号', '单位', '默认供应商']
    ws.append(headers)
    for r in MATERIALS:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '01-input', '物料主数据.xlsx'))
    print(f'[OK] 物料主数据.xlsx（{len(MATERIALS)} 条）')


def write_template():
    """送货单 OCR 字段模板（规则 → 02-working）。"""
    wb = Workbook()
    ws = wb.active
    ws.title = '送货单OCR字段模板'
    headers = ['字段', '说明', '示例', '是否必填']
    rows = [
        ('送货单号', '送货单唯一编号', 'SD2026-0701', '是'),
        ('供应商', '送货方公司全称', '东莞京东利昇贸易', '是'),
        ('PO号', '对应采购订单编号', 'PO-2026-071', '是'),
        ('物料编码', '物料主数据中的编码', 'WL-1001', '是'),
        ('物料名称', '物料名称', 'USB-C 数据线', '是'),
        ('批次', '生产批次号', 'B20260701', '是'),
        ('数量', '送货数量（数值）', '100', '是'),
        ('单位', '数量单位', '条', '是'),
        ('送货日期', '日期（年-月-日）', '2026-07-25', '是'),
    ]
    ws.append(headers)
    for r in rows:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '02-working', '送货单OCR字段模板.xlsx'))
    print('[OK] 送货单OCR字段模板.xlsx（02-working）')


if __name__ == '__main__':
    write_deliveries_images()
    write_delivery_result()
    write_po()
    write_iqc()
    write_materials()
    write_template()
    print('\n全部输入素材生成完毕。')
