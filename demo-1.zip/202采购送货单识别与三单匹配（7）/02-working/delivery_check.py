# -*- coding: utf-8 -*-
"""
案例7《采购送货单识别与三单匹配》核心核对程序
================================================
功能：
  ① 读取 送货单结构化结果 + PO 采购订单 + IQC 来料检验 + 物料主数据
  ② 逐行三单匹配（送货单 ↔ PO ↔ IQC），执行 6 项检查：
      检查1 PO 不存在（送货单 PO 号不在 PO 清单）
      检查2 物料不一致（送货单物料编码/名称与 PO 不一致）
      检查3 数量超交或短交（送货数量 vs PO 订购数量）
      检查4 批次缺失（批次为空）
      检查5 未检验或不合格入库（IQC 无记录或 NG）
      检查6 逾期到货（送货日期 > PO 约定到货日期）
  ③ 输出 3 个交付物到 03-output/：
      送货单OCR结构化结果.xlsx（原样保存）
      入库核对异常清单.xlsx（异常明细）
      采购入库核对台账.xlsx（每条记录处理状态）
  ④ 补充输出 看板.html（含横向滚动）
"""
import os

from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# ============================================================
# ★ 可调设置区（员工提修改需求只改这里，不要动下方核心逻辑）★
# ============================================================
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BATCH_NO = '2026W31'            # 批次（可改）
PROCESSOR = '采购助理'          # 默认处理人（可改）

# 1) 数量允许偏差（可改）
QTY_TOLERANCE = 0               # 允许数量超交/短交的比例（0=严格）

# 2) 行颜色（十六进制色号，不带 #，可改）
COLOR_OK = 'FFFFFF'            # 正常：白
COLOR_WARN = 'FFF2CC'          # 关注：浅黄
COLOR_RISK = 'FCE4D6'          # 异常：浅橙
COLOR_HIGH = 'C00000'          # 严重：深红

# 3) 状态标签（可改）
LABEL_HIGH = '严重'
LABEL_MID = '异常'
LABEL_LOW = '关注'
LABEL_OK = '正常'
LABEL_PENDING = '待人工确认'
LABEL_REJECT = '建议驳回'
LABEL_PASS = '已确认'

# 4) 功能开关（True=启用 / False=关闭，可改）
ENABLE_CHECK_PO = True         # 检查1 PO 不存在
ENABLE_CHECK_MAT = True        # 检查2 物料不一致
ENABLE_CHECK_QTY = True        # 检查3 数量超交/短交
ENABLE_CHECK_BATCH = True      # 检查4 批次缺失
ENABLE_CHECK_IQC = True        # 检查5 未检验/不合格
ENABLE_CHECK_OVERDUE = True    # 检查6 逾期到货

# ============================================================
# 样式常量（由上方可调设置生成，一般无需改动）
# ============================================================
HEADER_FILL = PatternFill('solid', fgColor='1F4E79')
HEADER_FONT = Font(bold=True, color='FFFFFF')
FILL_OK = PatternFill('solid', fgColor=COLOR_OK)
FILL_LOW = PatternFill('solid', fgColor=COLOR_WARN)
FILL_MID = PatternFill('solid', fgColor=COLOR_RISK)
FILL_HIGH = PatternFill('solid', fgColor=COLOR_HIGH)
FILL_MAP = {LABEL_OK: FILL_OK, LABEL_LOW: FILL_LOW, LABEL_MID: FILL_MID, LABEL_HIGH: FILL_HIGH}
HIGH_FONT = Font(bold=True, color='FFFFFF')
THIN = Side(style='thin', color='B0B0B0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# ---------- 路径常量 ----------
P_DELIVERY = f'{ROOT}/01-input/送货单结构化结果.xlsx'
P_PO = f'{ROOT}/01-input/PO_采购订单清单_2026W31.xlsx'
P_IQC = f'{ROOT}/01-input/IQC_来料检验结果_2026W31.xlsx'
P_MAT = f'{ROOT}/01-input/物料主数据.xlsx'
P_OUT_OCR = f'{ROOT}/03-output/送货单OCR结构化结果.xlsx'
P_OUT_ANOMALY = f'{ROOT}/03-output/入库核对异常清单.xlsx'
P_OUT_WORK = f'{ROOT}/03-output/采购入库核对台账.xlsx'
P_OUT_BOARD = f'{ROOT}/03-output/三单匹配看板.html'
P_OUT_NOTICE = f'{ROOT}/03-output/企业微信通知草稿.txt'


def read_rows(path):
    """读取 xlsx 全部行。健壮性：文件缺失时返回空并提示（不崩溃）。"""
    if not os.path.exists(path):
        print(f'[兜底-提示] 文件不存在，按空处理: {path}')
        return [], []
    wb = load_workbook(path)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        return [], []
    return list(rows[0]), list(rows[1:])


def parse_date(s):
    try:
        return datetime.strptime(str(s).strip(), '%Y-%m-%d').date()
    except ValueError:
        return None


def style_sheet(ws, widths=None):
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = BORDER
    if widths:
        for col, w in widths.items():
            ws.column_dimensions[col].width = w


def main():
    print(f'[批次] {BATCH_NO} 三单匹配开始 ...')

    # 1. 加载数据
    hd, d_rows = read_rows(P_DELIVERY)
    hp, po_rows = read_rows(P_PO)
    hi, iqc_rows = read_rows(P_IQC)
    hm, mat_rows = read_rows(P_MAT)
    print(f'[读取] 送货单 {len(d_rows)} 条 | PO {len(po_rows)} 条 | IQC {len(iqc_rows)} 条 | 物料 {len(mat_rows)} 条')

    # 2. 组织数据
    # PO: (po_no) -> {supplier, mat_code, mat_name, qty, unit, due_date}
    po_map = {}
    for r in po_rows:
        if r and r[0]:
            po_map[str(r[0]).strip()] = {
                'supplier': str(r[1]).strip() if r[1] else '',
                'mat_code': str(r[2]).strip() if r[2] else '',
                'mat_name': str(r[3]).strip() if r[3] else '',
                'qty': float(r[4]) if r[4] is not None else 0,
                'unit': str(r[5]).strip() if r[5] else '',
                'due_date': parse_date(r[6]),
            }
    # IQC: (sd_no, mat_code) -> (result, check_date, checker)
    iqc_map = {}
    for r in iqc_rows:
        if r and r[0]:
            iqc_map[(str(r[0]).strip(), str(r[1]).strip() if r[1] else '')] = {
                'result': str(r[2]).strip() if r[2] else '',
                'date': parse_date(r[3]),
                'checker': str(r[4]).strip() if r[4] else '',
            }
    # 物料主数据: mat_code -> {name, spec, unit, supplier}
    mat_map = {str(r[0]).strip(): {
        'name': str(r[1]).strip() if r[1] else '',
        'spec': str(r[2]).strip() if r[2] else '',
        'unit': str(r[3]).strip() if r[3] else '',
        'supplier': str(r[4]).strip() if r[4] else '',
    } for r in mat_rows if r and r[0]}

    # 3. 逐条三单匹配
    anomaly_rows = []   # 异常清单
    work_rows = []      # 工作台账
    stat = {LABEL_HIGH: 0, LABEL_MID: 0, LABEL_LOW: 0, LABEL_OK: 0}
    stat_detail = {}

    def add(issue, lv, sd_no, supplier, po, mat_code, mat_name, qty, unit, due, content):
        anomaly_rows.append({
            '送货单号': sd_no, '供应商': supplier, 'PO号': po,
            '物料编码': mat_code, '物料名称': mat_name, '送货数量': qty, '单位': unit,
            '约定到货日': str(due) if due else '',
            '异常类型': issue, '风险等级': lv, '异常说明': content,
            '建议处理动作': LABEL_REJECT if lv == LABEL_HIGH else LABEL_PENDING,
        })
        stat_detail[issue] = stat_detail.get(issue, 0) + 1
        return (issue, lv)

    for r in d_rows:
        if not r or not r[0]:
            continue
        sd_no = str(r[0]).strip()
        supplier = str(r[1]).strip() if r[1] else ''
        po_no = str(r[2]).strip() if r[2] else ''
        mat_code = str(r[3]).strip() if r[3] else ''
        mat_name = str(r[4]).strip() if r[4] else ''
        batch = str(r[5]).strip() if r[5] else ''
        qty = float(r[6]) if r[6] is not None else 0
        unit = str(r[7]).strip() if r[7] else ''
        d_date = parse_date(r[8])

        issues = []   # [(标题, 等级)]
        # 检查1 PO 不存在
        po = po_map.get(po_no)
        if ENABLE_CHECK_PO and not po:
            issues.append(add('PO 不存在', LABEL_HIGH, sd_no, supplier, po_no,
                              mat_code, mat_name, qty, unit, None,
                              f'送货单 PO 号「{po_no}」不在采购订单清单中'))
        # 检查2 物料不一致
        if ENABLE_CHECK_MAT and po:
            if mat_code != po['mat_code']:
                issues.append(add('物料编码不一致', LABEL_MID, sd_no, supplier, po_no,
                                  mat_code, mat_name, qty, unit, po['due_date'],
                                  f'送货单物料编码「{mat_code}」≠ PO「{po["mat_code"]}」'))
            elif mat_name and po['mat_name'] and mat_name != po['mat_name']:
                issues.append(add('物料名称不一致', LABEL_MID, sd_no, supplier, po_no,
                                  mat_code, mat_name, qty, unit, po['due_date'],
                                  f'送货单物料名称「{mat_name}」≠ PO「{po["mat_name"]}」'))
        # 检查3 数量超交/短交
        if ENABLE_CHECK_QTY and po and po['qty'] > 0:
            tol = po['qty'] * QTY_TOLERANCE
            if qty > po['qty'] + tol:
                issues.append(add('数量超交', LABEL_HIGH, sd_no, supplier, po_no,
                                  mat_code, mat_name, qty, unit, po['due_date'],
                                  f'送货 {qty:.0f} > 订购 {po["qty"]:.0f}{po["unit"]}，超交 {qty-po["qty"]:.0f}'))
            elif qty < po['qty'] - tol:
                issues.append(add('数量短交', LABEL_MID, sd_no, supplier, po_no,
                                  mat_code, mat_name, qty, unit, po['due_date'],
                                  f'送货 {qty:.0f} < 订购 {po["qty"]:.0f}{po["unit"]}，短交 {po["qty"]-qty:.0f}'))
        # 检查4 批次缺失
        if ENABLE_CHECK_BATCH and not batch:
            issues.append(add('批次缺失', LABEL_MID, sd_no, supplier, po_no,
                              mat_code, mat_name, qty, unit, po['due_date'] if po else None,
                              '送货单未填批次号'))
        # 检查5 未检验或不合格
        iqc = iqc_map.get((sd_no, mat_code))
        if ENABLE_CHECK_IQC and not iqc:
            issues.append(add('未检验入库', LABEL_HIGH, sd_no, supplier, po_no,
                              mat_code, mat_name, qty, unit, po['due_date'] if po else None,
                              'IQC 无检验记录，不允许入库'))
        elif ENABLE_CHECK_IQC and iqc and iqc['result'] == 'NG':
            issues.append(add('IQC 不合格', LABEL_HIGH, sd_no, supplier, po_no,
                              mat_code, mat_name, qty, unit, po['due_date'] if po else None,
                              f'IQC 检验结果 NG（{iqc["checker"]}），不允许入库'))
        # 检查6 逾期到货
        if ENABLE_CHECK_OVERDUE and po and po['due_date'] and d_date:
            if d_date > po['due_date']:
                issues.append(add('逾期到货', LABEL_LOW, sd_no, supplier, po_no,
                                  mat_code, mat_name, qty, unit, po['due_date'],
                                  f'送货 {d_date} 晚于约定 {po["due_date"]} {(d_date-po["due_date"]).days} 天'))

        # 汇总等级
        if issues:
            order = {LABEL_HIGH: 3, LABEL_MID: 2, LABEL_LOW: 1}
            level = max(issues, key=lambda x: order[x[1]])[1]
        else:
            level = LABEL_OK
        stat[level] += 1

        # 工作台账
        iqc_summary = 'OK' if (iqc and iqc['result'] == 'OK') else (
            'NG' if (iqc and iqc['result'] == 'NG') else '未检验')
        work_rows.append({
            '批次号': BATCH_NO, '送货单号': sd_no, '供应商': supplier, 'PO号': po_no,
            '物料编码': mat_code, '物料名称': mat_name, '批次': batch or '—',
            '送货数量': qty, '单位': unit, '送货日期': str(d_date) if d_date else '',
            'IQC结果': iqc_summary,
            '检查项数': len(issues),
            '异常类型': '；'.join(t for t, lv in issues) if issues else '无',
            '风险等级': level,
            '分析时间': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            '分析人': PROCESSOR,
            '复核状态': LABEL_PENDING if issues else LABEL_PASS,
        })
    print(f'[匹配] 8 项检查 | 正常 {stat[LABEL_OK]} / 关注 {stat[LABEL_LOW]} / 异常 {stat[LABEL_MID]} / 严重 {stat[LABEL_HIGH]}')

    # 4. 输出 1：送货单OCR结构化结果.xlsx（原样保存，作为识别产物归档）
    wb = Workbook()
    ws = wb.active
    ws.title = '送货单结构化结果'
    headers = ['送货单号', '供应商', 'PO号', '物料编码', '物料名称', '批次', '数量', '单位', '送货日期']
    ws.append(headers)
    for r in d_rows:
        if r and r[0]:
            ws.append(list(r))
    style_sheet(ws, {'A': 14, 'B': 22, 'C': 16, 'D': 14, 'E': 20, 'F': 14, 'G': 10, 'H': 8, 'I': 12})
    wb.save(P_OUT_OCR)
    print(f'[OK] 送货单OCR结构化结果.xlsx（{len(d_rows)} 条）')

    # 5. 输出 2：入库核对异常清单.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '入库核对异常清单'
    h = ['送货单号', '供应商', 'PO号', '物料编码', '物料名称', '送货数量', '单位',
         '约定到货日', '异常类型', '风险等级', '异常说明', '建议处理动作']
    ws.append(h)
    for r in anomaly_rows:
        ws.append([r[k] for k in h])
    style_sheet(ws, {'A': 14, 'B': 20, 'C': 16, 'D': 12, 'E': 18, 'F': 10, 'G': 8,
                     'H': 12, 'I': 16, 'J': 10, 'K': 40, 'L': 14})
    for row_idx in range(2, ws.max_row + 1):
        lv = str(ws.cell(row=row_idx, column=10).value)
        fill = FILL_MAP.get(lv, FILL_OK)
        for c in range(1, len(h) + 1):
            cell = ws.cell(row=row_idx, column=c)
            cell.fill = fill
            if lv == LABEL_HIGH:
                cell.font = HIGH_FONT
    wb.save(P_OUT_ANOMALY)
    print(f'[OK] 入库核对异常清单.xlsx（{len(anomaly_rows)} 条）')

    # 6. 输出 3：采购入库核对台账.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '采购入库核对台账'
    h3 = ['批次号', '送货单号', '供应商', 'PO号', '物料编码', '物料名称', '批次',
          '送货数量', '单位', '送货日期', 'IQC结果', '检查项数', '异常类型',
          '风险等级', '分析时间', '分析人', '复核状态']
    ws.append(h3)
    for r in work_rows:
        ws.append([r[k] for k in h3])
    style_sheet(ws, {'A': 10, 'B': 14, 'C': 20, 'D': 14, 'E': 12, 'F': 18, 'G': 10,
                     'H': 10, 'I': 8, 'J': 12, 'K': 10, 'L': 8, 'M': 20, 'N': 10,
                     'O': 18, 'P': 10, 'Q': 12})
    for row_idx in range(2, ws.max_row + 1):
        lv = str(ws.cell(row=row_idx, column=14).value)
        fill = FILL_MAP.get(lv, FILL_OK)
        for c in range(1, len(h3) + 1):
            cell = ws.cell(row=row_idx, column=c)
            cell.fill = fill
            if lv == LABEL_HIGH:
                cell.font = HIGH_FONT
    wb.save(P_OUT_WORK)
    print(f'[OK] 采购入库核对台账.xlsx（{len(work_rows)} 行）')

    # 7. 输出 4：三单匹配看板.html（含横向滚动）
    work_html = ''
    for r in sorted(work_rows, key=lambda x: (x['风险等级'] != LABEL_HIGH, x['风险等级'] != LABEL_MID)):
        lv_class = ''
        if r['风险等级'] == LABEL_HIGH:
            lv_class = 'row-high'
        elif r['风险等级'] == LABEL_MID:
            lv_class = 'row-mid'
        elif r['风险等级'] == LABEL_LOW:
            lv_class = 'row-low'
        else:
            lv_class = 'row-ok'
        work_html += (f"<tr class='{lv_class}'><td>{r['送货单号']}</td><td>{r['供应商']}</td>"
                      f"<td>{r['PO号']}</td><td>{r['物料编码']}</td><td>{r['物料名称']}</td>"
                      f"<td>{r['送货数量']:.0f}{r['单位']}</td><td>{r['IQC结果']}</td>"
                      f"<td>{r['异常类型']}</td><td>{r['风险等级']}</td></tr>")
    board = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>三单匹配看板 - {BATCH_NO}</title>
<style>
body{{font-family:'Microsoft YaHei',sans-serif;background:#f5f6fa;margin:0;padding:24px;color:#222}}
h1{{font-size:22px}} .cards{{display:flex;gap:16px;flex-wrap:wrap;margin:20px 0}}
.card{{background:#fff;border-radius:10px;padding:18px 22px;min-width:140px;box-shadow:0 1px 4px rgba(0,0,0,.08)}}
.card .num{{font-size:30px;font-weight:bold}} .card .lbl{{color:#888;font-size:13px;margin-top:4px}}
.red{{color:#C00000}} .orange{{color:#ED7D31}} .yellow{{color:#BF9000}} .green{{color:#548235}}
.table-wrap{{overflow-x:auto;-webkit-overflow-scrolling:touch;background:#fff;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:20px}}
.table-wrap table{{border-collapse:collapse;width:100%;min-width:760px;table-layout:auto}}
th,td{{padding:10px 12px;text-align:left;border-bottom:1px solid #eee;font-size:13px;white-space:normal;word-break:break-word}}
th{{background:#1F4E79;color:#fff}}
tr.row-high td{{background:#C00000;color:#fff;font-weight:bold}}
tr.row-mid td{{background:#FCE4D6}}
tr.row-low td{{background:#FFF2CC}}
tr.row-ok td{{background:#FFFFFF}}
</style></head><body>
<h1>三单匹配看板 · {BATCH_NO}</h1>
<div class="cards">
<div class="card"><div class="num">{len(work_rows)}</div><div class="lbl">本批送货单</div></div>
<div class="card"><div class="num green">{stat[LABEL_OK]}</div><div class="lbl">正常</div></div>
<div class="card"><div class="num yellow">{stat[LABEL_LOW]}</div><div class="lbl">关注</div></div>
<div class="card"><div class="num orange">{stat[LABEL_MID]}</div><div class="lbl">异常</div></div>
<div class="card"><div class="num red">{stat[LABEL_HIGH]}</div><div class="lbl">严重</div></div>
<div class="card"><div class="num">{len(anomaly_rows)}</div><div class="lbl">异常明细数</div></div>
</div>
<p><b>主要异常类型：</b>{" / ".join(f"{t}×{n}" for t, n in sorted(stat_detail.items(), key=lambda x: -x[1])) if stat_detail else "无"}</p>
<h3>核对明细（按风险等级排序）</h3>
<div class="table-wrap"><table><tr><th>送货单号</th><th>供应商</th><th>PO号</th><th>物料编码</th><th>物料名称</th><th>数量</th><th>IQC</th><th>异常类型</th><th>风险</th></tr>
{work_html}
</table></div></body></html>"""
    with open(P_OUT_BOARD, 'w', encoding='utf-8') as f:
        f.write(board)
    print('[OK] 三单匹配看板.html')

    # 8. 汇总
    print('\n===== 批次汇总 =====')
    print(f'送货单: {len(work_rows)} | 正常: {stat[LABEL_OK]} | 关注: {stat[LABEL_LOW]} | '
          f'异常: {stat[LABEL_MID]} | 严重: {stat[LABEL_HIGH]}')
    print(f'异常类型: {"；".join(f"{t}×{n}" for t, n in stat_detail.items())}')
    high_list = [r['送货单号'] for r in work_rows if r['风险等级'] == LABEL_HIGH]
    if high_list:
        print(f'高风险送货单: {"、".join(high_list)}（建议驳回）')

    # 9. 企业微信通知草稿.txt（脚本自动生成，AI 检测绑定后决定发送或告知草稿）
    # （5.0.10 起企微消息能力已全面开放（不限企业规模），AI 可直接发送；发送失败时草稿兜底）
    n_lines = ['【三单匹配核对通知】',
               f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}',
               f'本批送货单 {len(work_rows)} 张：正常 {stat[LABEL_OK]} / 关注 {stat[LABEL_LOW]} / 异常 {stat[LABEL_MID]} / 严重 {stat[LABEL_HIGH]}',
               f'异常类型：{"；".join(f"{t}×{n}" for t, n in stat_detail.items()) if stat_detail else "无"}']
    if high_list:
        n_lines.append(f'高风险送货单（{len(high_list)} 张，建议驳回）：{"、".join(high_list)}')
    if stat[LABEL_MID] > 0:
        mid_list = [r['送货单号'] for r in work_rows if r['风险等级'] == LABEL_MID]
        n_lines.append(f'需采购确认（{len(mid_list)} 张）：{"、".join(mid_list)}')
    n_lines.append('提示：异常单不自动放行入库，必须采购和仓库人员确认后才能入库。')
    with open(P_OUT_NOTICE, 'w', encoding='utf-8') as f:
        f.write('\n'.join(n_lines))

    print(f'[OK] 企业微信通知草稿.txt（异常 {stat[LABEL_MID] + stat[LABEL_HIGH]} 张 / 高风险 {stat[LABEL_HIGH]}）')


if __name__ == '__main__':
    main()