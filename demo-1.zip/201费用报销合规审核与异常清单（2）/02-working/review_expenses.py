# -*- coding: utf-8 -*-
"""
案例2《费用报销合规审核与异常清单》核心审核程序
================================================
功能：
  ① 读取 发票OCR结构化结果、费用报销单、报销制度、差旅住宿标准、客户招待标准、历史报销记录
  ② 按报销单逐条交叉比对，执行 6 项合规校验：
      校验1 住宿超标（住宿费 > 该城市住宿上限）
      校验2 招待费缺审批单（业务招待费且无审批单；或招待金额超过客户标准上限）
      校验3 发票重复报销（发票号在历史报销记录中已存在）
      校验4 发票抬头不正确（发票购买方 ≠ 公司全称）
      校验5 报销超期（报销日期 - 开票日期 > 30 天）
      校验6 金额不一致（报销金额 ≠ 发票价税合计）
  ③ 输出 4 个交付物到 03-output/：
      费用报销审核异常清单.xlsx
      费用审核驾驶舱.html
      费用审核工作台账.xlsx
      财务审核FAQ_经验沉淀.md
  ④ 打印企业微信通知草稿内容（发送由 AI 按连接器状态决定）
  # （5.0.10 起企微消息能力已全面开放（不限企业规模），AI 可直接发送；发送失败时草稿兜底）
"""
import os

import re
from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# ============================================================
# ★ 可调设置区（员工提修改需求只改这里，不要动下方核心逻辑）★
# ============================================================
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BATCH_NO = '2026-05'           # 批次号（对应报销月份，可改）
PROCESSOR = '财务助理'          # 默认处理人（可改）
COMPANY_NAME = '深圳市启明科技有限公司'   # 公司全称（抬头校验基准，可改）

# 1) 行颜色（十六进制色号，不带 #，可改）
COLOR_OK = 'FFFFFF'            # 正常：白
COLOR_WARN = 'FFF2CC'          # 低风险：浅黄
COLOR_RISK = 'FCE4D6'          # 中风险：浅橙
COLOR_HIGH = 'C00000'          # 高风险：深红

# 2) 风险等级标签（可改）
LABEL_HIGH = '高风险'           # 需驳回或立即处理
LABEL_MID = '中风险'            # 需复核确认
LABEL_LOW = '低风险'            # 需关注
LABEL_OK = '正常'              # 无异常

# 3) 复核标签（可改）
LABEL_PENDING = '待复核'
LABEL_PASS = '通过'
LABEL_REJECT = '建议驳回'

# 4) 功能开关（True=启用 / False=关闭，可改）
ENABLE_HOTEL_CHECK = True      # 校验1 住宿超标
ENABLE_FEAST_CHECK = True      # 校验2 招待费审批/标准
ENABLE_DUP_CHECK = True        # 校验3 重复报销
ENABLE_TITLE_CHECK = True      # 校验4 抬头不正确
ENABLE_OVERDUE_CHECK = True    # 校验5 报销超期
ENABLE_AMOUNT_CHECK = True     # 校验6 金额不一致

REIMBURSE_DAYS = 30            # 报销期限（天，可改）

# ============================================================
# 样式常量（由上方可调设置生成，一般无需改动）
# ============================================================
HEADER_FILL = PatternFill('solid', fgColor='1F4E79')
HEADER_FONT = Font(bold=True, color='FFFFFF')
FILL_OK = PatternFill('solid', fgColor=COLOR_OK)
FILL_LOW = PatternFill('solid', fgColor=COLOR_WARN)
FILL_MID = PatternFill('solid', fgColor=COLOR_RISK)
FILL_HIGH = PatternFill('solid', fgColor=COLOR_HIGH)
FILL_MAP = {LABEL_OK: FILL_OK, LABEL_LOW: FILL_LOW, LABEL_MID: FILL_MID, LABEL_HIGH: FILL_HIGH}
HIGH_FONT = Font(bold=True, color='FFFFFF')
THIN = Side(style='thin', color='B0B0B0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

sys_encoding = 'utf-8'

# ---------- 路径常量 ----------
P_INVOICES = f'{ROOT}/01-input/发票OCR结构化结果.xlsx'
P_EXPENSES = f'{ROOT}/01-input/费用报销单_2026-05.xlsx'
P_POLICY = f'{ROOT}/02-working/员工费用报销管理制度_v3.2.md'
P_HOTEL = f'{ROOT}/02-working/差旅住宿标准表.xlsx'
P_CUSTOMER = f'{ROOT}/02-working/客户分级与招待标准对照表.xlsx'
P_HISTORY = f'{ROOT}/04-archive/历史报销记录_近6个月.xlsx'
P_OUT_ABN = f'{ROOT}/03-output/费用报销审核异常清单.xlsx'
P_OUT_DASH = f'{ROOT}/03-output/费用审核驾驶舱.html'
P_OUT_WORK = f'{ROOT}/03-output/费用审核工作台账.xlsx'
P_OUT_FAQ = f'{ROOT}/03-output/财务审核FAQ_经验沉淀.md'
P_OUT_NOTICE = f'{ROOT}/03-output/企业微信通知草稿.txt'  # 5.0.10 起企微消息能力已全面开放，AI 可直接发送；失败时草稿兜底


def style_sheet(ws, widths=None):
    """设置表头样式、边框与列宽。"""
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = BORDER
    if widths:
        for col, w in widths.items():
            ws.column_dimensions[col].width = w


def read_rows(path, sheet=None):
    """读取 xlsx 全部行（首行为表头，返回 表头list 与 数据list）。
    健壮性：文件不存在时返回空并打印提示（不崩溃，调用方自行兜底）。"""
    if not os.path.exists(path):
        print(f'[兜底-提示] 文件不存在，按空处理: {path}')
        return [], []
    wb = load_workbook(path)
    ws = wb[sheet] if sheet else wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        return [], []
    return list(rows[0]), list(rows[1:])


def load_hotel_caps():
    """读差旅住宿标准表 → {城市: 上限}。缺失时返回空，住宿校验退回默认 600 元。"""
    header, rows = read_rows(P_HOTEL)
    caps = {}
    for r in rows:
        if r and r[0]:
            caps[str(r[0]).strip()] = float(r[2]) if r[2] is not None else 0
    if not caps:
        print('[兜底-提示] 住宿标准为空，住宿校验按默认 600 元/晚 处理')
    return caps


def load_customer_limits():
    """读客户分级与招待标准对照表 → {客户: (等级, 上限, 是否需审批单)}。缺失时返回空，招待校验只看审批单。"""
    header, rows = read_rows(P_CUSTOMER)
    limits = {}
    for r in rows:
        if r and r[0]:
            limits[str(r[0]).strip()] = (str(r[1]).strip() if r[1] else '',
                                         float(r[2]) if r[2] is not None else 0,
                                         str(r[3]).strip() if r[3] else '')
    if not limits:
        print('[兜底-提示] 客户招待标准为空，招待校验只检查审批单')
    return limits


def load_hist_invoices():
    """读历史报销记录 → 已报销发票号集合。缺失时返回空，重复报销校验跳过。"""
    header, rows = read_rows(P_HISTORY)
    result = {str(r[0]).strip() for r in rows if r and r[0]}
    if not result:
        print('[兜底-提示] 历史报销记录为空，重复报销校验跳过')
    return result


def load_invoice_map():
    """读发票结构化结果 → {发票号: 行字典}。缺失时返回空，发票相关校验跳过。"""
    header, rows = read_rows(P_INVOICES)
    inv_map = {}
    for r in rows:
        if r and r[0]:
            d = dict(zip(header, r))
            inv_map[str(r[0]).strip()] = d
    if not inv_map:
        print('[兜底-提示] 发票结构化结果为空，抬头/住宿/金额校验无法比对')
    return inv_map


def norm(s):
    """去空格。"""
    return re.sub(r'\s+', '', str(s or ''))


def main():
    print(f'[批次] {BATCH_NO} 费用报销合规审核开始 ...')

    # 1. 加载各表（含兜底：文件缺失不崩溃，用默认值继续）
    inv_map = load_invoice_map()
    hotel_caps = load_hotel_caps()
    customer_limits = load_customer_limits()
    hist_invoices = load_hist_invoices()
    print(f'[读取] 发票 {len(inv_map)} 张 | 住宿标准 {len(hotel_caps)} 城 | 客户标准 {len(customer_limits)} 家 | 历史发票 {len(hist_invoices)} 张')

    # 2. 逐条审核报销单
    abn_rows = []    # 异常清单行
    work_rows = []   # 工作台账行
    stat = {LABEL_HIGH: 0, LABEL_MID: 0, LABEL_LOW: 0, LABEL_OK: 0}
    stat_detail = {}   # 异常类型计数

    header, exp_rows = read_rows(P_EXPENSES)
    for idx, e in enumerate(exp_rows, 1):
        if not e or not e[0]:
            continue
        rec = dict(zip(header, e))
        bx_no = str(rec['报销单号']).strip()
        person = str(rec['报销人']).strip()
        dept = str(rec['部门']).strip()
        fee_type = str(rec['费用类型']).strip()
        amount = float(rec['报销金额']) if rec['报销金额'] is not None else 0
        inv_no = str(rec['发票号码']).strip()
        inv_date = str(rec['开票日期']).strip()
        bx_date = str(rec['报销日期']).strip()
        has_approval = str(rec['是否有审批单']).strip()
        customer = str(rec['客户名称'] or '').strip()

        issues = []      # [(异常类型, 风险等级, 制度依据, 建议处理动作)]
        invoice = inv_map.get(inv_no, {})

        # 校验1 住宿超标
        if ENABLE_HOTEL_CHECK and fee_type == '住宿费' and invoice:
            city = invoice.get('销售方名称', '') or ''
            # 从销售方名称猜测城市（简单示例：包含城市名则用对应标准，否则用一线标准）
            city_found = ''
            for c in hotel_caps:
                if c in city:
                    city_found = c
                    break
            cap = hotel_caps.get(city_found, 600)
            if amount > cap:
                issues.append(('住宿超标', LABEL_HIGH,
                               f'住宿费上限 {cap:.0f} 元/晚（{city_found or "一线城市"}）',
                               f'超标准 {amount - cap:.0f} 元，超出部分不予报销'))

        # 校验2 招待费缺审批单/超客户标准
        if ENABLE_FEAST_CHECK and fee_type == '业务招待费':
            lim = customer_limits.get(customer)
            if not has_approval or has_approval == '无':
                issues.append(('招待费缺审批单', LABEL_HIGH,
                               '业务招待费必须附审批单方可报销',
                               '补审批单或不予报销'))
            if lim and lim[1] > 0 and amount > lim[1]:
                issues.append(('招待超客户标准', LABEL_MID,
                               f'客户 {customer}（{lim[0]}）招待上限 {lim[1]:.0f} 元/次',
                               f'超标准 {amount - lim[1]:.0f} 元，需总经理审批'))

        # 校验3 发票重复报销
        if ENABLE_DUP_CHECK and inv_no in hist_invoices:
            issues.append(('发票重复报销', LABEL_HIGH,
                           '同一张发票不得重复报销',
                           '驳回，核实是否重复付款'))

        # 校验4 发票抬头不正确
        if ENABLE_TITLE_CHECK and invoice:
            buyer = norm(invoice.get('购买方名称', ''))
            if buyer and buyer != norm(COMPANY_NAME):
                issues.append(('发票抬头不正确', LABEL_MID,
                               '发票抬头必须为公司全称',
                               '退回更换正确抬头发票'))

        # 校验5 报销超期
        if ENABLE_OVERDUE_CHECK and inv_date and bx_date:
            try:
                d_inv = datetime.strptime(inv_date, '%Y-%m-%d')
                d_bx = datetime.strptime(bx_date, '%Y-%m-%d')
                days = (d_bx - d_inv).days
                if days > REIMBURSE_DAYS:
                    issues.append(('报销超期', LABEL_LOW,
                                   f'报销期限 {REIMBURSE_DAYS} 天（发票开具日起）',
                                   f'超期 {days - REIMBURSE_DAYS} 天，需部门负责人说明原因'))
            except ValueError:
                pass

        # 校验6 金额不一致
        if ENABLE_AMOUNT_CHECK and invoice:
            inv_total = None
            try:
                inv_total = float(invoice.get('价税合计'))
            except (TypeError, ValueError):
                pass
            if inv_total is not None and abs(inv_total - amount) > 0.01:
                issues.append(('金额不一致', LABEL_HIGH,
                               f'发票价税合计 {inv_total:.2f} 元 ≠ 报销金额 {amount:.2f} 元',
                               '核实以发票为准，退回修改报销金额'))

        # 汇总风险等级：取最高
        if issues:
            level_order = {LABEL_HIGH: 3, LABEL_MID: 2, LABEL_LOW: 1}
            level = max(issues, key=lambda x: level_order[x[1]])[1]
            for it in issues:
                stat_detail[it[0]] = stat_detail.get(it[0], 0) + 1
        else:
            level = LABEL_OK
            issues = []
        stat[level] += 1

        # 异常清单行
        if issues:
            abn_rows.append({
                '报销单号': bx_no, '报销人': person, '部门': dept, '费用类型': fee_type,
                '报销金额': amount, '发票号码': inv_no,
                '异常原因': '；'.join(f'{t}（{a}）' for t, lv, a, act in issues),
                '风险等级': level,
                '制度依据': '；'.join(sorted({a for t, lv, a, act in issues})),
                '建议处理动作': '；'.join(sorted({act for t, lv, a, act in issues})),
                '复核状态': LABEL_PENDING, '复核人': '', '复核意见': '',
            })

        # 工作台账行
        work_rows.append({
            '批次号': BATCH_NO, '序号': idx, '报销单号': bx_no, '报销人': person,
            '部门': dept, '费用类型': fee_type, '报销金额': amount,
            '审核时间': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            '审核人': PROCESSOR,
            '风险等级': level,
            '异常项数': len(issues),
            '复核状态': LABEL_PENDING if issues else LABEL_PASS,
            '备注': '；'.join(t for t, lv, a, act in issues) if issues else '正常',
        })

    # 3. 输出 1：异常清单
    wb = Workbook()
    ws = wb.active
    ws.title = '费用报销审核异常清单'
    h = ['报销单号', '报销人', '部门', '费用类型', '报销金额', '发票号码', '异常原因',
         '风险等级', '制度依据', '建议处理动作', '复核状态', '复核人', '复核意见']
    ws.append(h)
    for r in abn_rows:
        ws.append([r[k] for k in h])
    style_sheet(ws, {'A': 14, 'B': 10, 'C': 10, 'D': 14, 'E': 12, 'F': 24, 'G': 45,
                     'H': 10, 'I': 35, 'J': 30, 'K': 10, 'L': 10, 'M': 18})
    for row_idx in range(2, ws.max_row + 1):
        lv = str(ws.cell(row=row_idx, column=8).value)
        fill = FILL_MAP.get(lv, FILL_OK)
        for c in range(1, len(h) + 1):
            cell = ws.cell(row=row_idx, column=c)
            cell.fill = fill
            if lv == LABEL_HIGH:
                cell.font = HIGH_FONT
    wb.save(P_OUT_ABN)
    print(f'[OK] 费用报销审核异常清单.xlsx（{len(abn_rows)} 条异常）')

    # 4. 输出 2：工作台账
    wb = Workbook()
    ws = wb.active
    ws.title = '费用审核工作台账'
    h2 = ['批次号', '序号', '报销单号', '报销人', '部门', '费用类型', '报销金额',
          '审核时间', '审核人', '风险等级', '异常项数', '复核状态', '备注']
    ws.append(h2)
    for r in work_rows:
        ws.append([r[k] for k in h2])
    style_sheet(ws, {'A': 10, 'B': 6, 'C': 14, 'D': 10, 'E': 10, 'F': 14, 'G': 12,
                     'H': 18, 'I': 10, 'J': 10, 'K': 8, 'L': 10, 'M': 30})
    for row_idx in range(2, ws.max_row + 1):
        lv = str(ws.cell(row=row_idx, column=10).value)
        fill = FILL_MAP.get(lv, FILL_OK)
        for c in range(1, len(h2) + 1):
            ws.cell(row=row_idx, column=c).fill = fill
    wb.save(P_OUT_WORK)
    print(f'[OK] 费用审核工作台账.xlsx（{len(work_rows)} 行）')

    # 5. 输出 3：驾驶舱 html
    top3 = sorted(stat_detail.items(), key=lambda x: -x[1])[:3]
    top3_str = ' / '.join(f'{t}×{n}' for t, n in top3) if top3 else '无'
    html = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>费用审核驾驶舱 - {BATCH_NO}</title>
<style>
body{{font-family:'Microsoft YaHei',sans-serif;background:#f5f6fa;margin:0;padding:24px;color:#222}}
h1{{font-size:22px}} .cards{{display:flex;gap:16px;flex-wrap:wrap;margin:20px 0}}
.card{{background:#fff;border-radius:10px;padding:18px 22px;min-width:140px;box-shadow:0 1px 4px rgba(0,0,0,.08)}}
.card .num{{font-size:30px;font-weight:bold}} .card .lbl{{color:#888;font-size:13px;margin-top:4px}}
.red{{color:#C00000}} .orange{{color:#ED7D31}} .yellow{{color:#BF9000}} .green{{color:#548235}}
/* 横向滚动容器：用户电脑分辨率不一时，窄屏也能完整查看表格 */
.table-wrap{{overflow-x:auto;-webkit-overflow-scrolling:touch;background:#fff;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.08)}}
/* 关键：table 用 width:100% 撑满 wrapper（宽屏铺满/窄屏撑到 wrapper 边界），
   min-width 保证最小宽度让窄屏触发滚动条 */
.table-wrap table{{border-collapse:collapse;width:100%;min-width:760px;table-layout:auto}}
/* td 默认 normal 换行（短数字"800.00"不会换行，长字段自然换行不被截） */
th,td{{padding:10px 12px;text-align:left;border-bottom:1px solid #eee;font-size:13px;white-space:normal;word-break:break-word}}
th{{background:#1F4E79;color:#fff}}
/* 异常原因列设最小列宽保证可读，不限最大宽度（避免截断） */
td.reason{{min-width:260px}}
</style></head><body>
<h1>费用审核驾驶舱 · 批次 {BATCH_NO}</h1>
<div class="cards">
<div class="card"><div class="num">{len(exp_rows)}</div><div class="lbl">报销单总数</div></div>
<div class="card"><div class="num green">{stat[LABEL_OK]}</div><div class="lbl">正常</div></div>
<div class="card"><div class="num yellow">{stat[LABEL_LOW]}</div><div class="lbl">低风险</div></div>
<div class="card"><div class="num orange">{stat[LABEL_MID]}</div><div class="lbl">中风险</div></div>
<div class="card"><div class="num red">{stat[LABEL_HIGH]}</div><div class="lbl">高风险</div></div>
<div class="card"><div class="num">{len(abn_rows)}</div><div class="lbl">待复核</div></div>
</div>
<h3>主要异常类型 TOP3：{top3_str}</h3>
<div class="table-wrap"><table><tr><th>报销单号</th><th>报销人</th><th>部门</th><th>费用类型</th><th>金额</th><th>风险等级</th><th>异常原因</th></tr>
"""
    for r in abn_rows:
        html += (f"<tr><td>{r['报销单号']}</td><td>{r['报销人']}</td><td>{r['部门']}</td>"
                 f"<td>{r['费用类型']}</td><td>{r['报销金额']:.2f}</td><td>{r['风险等级']}</td>"
                 f"<td class='reason'>{r['异常原因']}</td></tr>")
    html += "</table></div></body></html>"
    with open(P_OUT_DASH, 'w', encoding='utf-8') as f:
        f.write(html)
    print('[OK] 费用审核驾驶舱.html')

    # 6. 输出 4：FAQ 经验沉淀
    faq = f"""# 财务审核 FAQ（经验沉淀）· 批次 {BATCH_NO}

## 本次审核发现的高频问题
"""
    for t, n in sorted(stat_detail.items(), key=lambda x: -x[1]):
        faq += f"- **{t}**：{n} 笔\n"
    faq += """
## 常见问题与处理口径
1. **住宿超标**：按《员工费用报销管理制度》住宿标准执行，超出部分不予报销；特殊情况需提前审批。
2. **招待费缺审批单**：业务招待费必须先有审批单再报销；超 2000 元需总经理审批。
3. **发票重复报销**：同一发票号只允许报销一次，重复提交一律驳回并核实是否重复付款。
4. **发票抬头不正确**：发票抬头必须为公司全称，个人抬头或他司抬头退回更换。
5. **报销超期**：发票开具 30 天内提交；超期需部门负责人说明原因。
6. **金额不一致**：以发票价税合计为准，报销单金额与发票不符退回修改。

## 给财务的提示
- 高风险项先处理：重复报销、金额不一致、住宿超标、招待缺审批。
- 中风险项（抬头不正确、超客户标准）需与报销人核实后确认。
- 所有异常在《费用审核工作台账》中留痕，复核后方可付款。
"""
    with open(P_OUT_FAQ, 'w', encoding='utf-8') as f:
        f.write(faq)
    print('[OK] 财务审核FAQ_经验沉淀.md')

    # 7. 汇总（供企业微信通知草稿使用）
    print('\n===== 批次汇总 =====')
    print(f'报销单总数: {len(exp_rows)} | 正常: {stat[LABEL_OK]} | '
          f'低风险: {stat[LABEL_LOW]} | 中风险: {stat[LABEL_MID]} | 高风险: {stat[LABEL_HIGH]}')
    print(f'待复核: {len(abn_rows)} | 主要异常 TOP3: {top3_str}')
    print(f'待处理责任人: {", ".join(sorted({r["报销人"] for r in abn_rows}))}')

    # 8. 企业微信通知草稿.txt（脚本自动生成；5.0.10 起 AI 可直接发送，发送失败时草稿兜底）
    notice = ['【费用报销审核通知】',
              f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}',
              f'报销单总数：{len(exp_rows)} 张',
              f'待复核：{len(abn_rows)} 张 | 主要异常 TOP3：{top3_str}',
              f'待处理责任人：{", ".join(sorted({r["报销人"] for r in abn_rows})) or "无"}',
              '',
              '本通知为审核摘要，不代替财务审批；请打开异常清单逐条复核后再进入付款流程。']
    os.makedirs(f'{ROOT}/03-output', exist_ok=True)
    with open(P_OUT_NOTICE, 'w', encoding='utf-8') as f:
        f.write('\n'.join(notice))

    print(f'[OK] 企业微信通知草稿.txt')


if __name__ == '__main__':
    main()
