# -*- coding: utf-8 -*-
"""案例15 核心脚本：招聘简历批量筛选与评分
输入（01-input/）：岗位JD_销售经理.docx、候选人简历/*.docx、招聘评分标准.xlsx、候选人信息登记表.xlsx
流程：
  1. 读 JD 与评分标准
  2. 批量解析候选人简历（提取教育/工作年限/行业/技能/项目管理）
  3. 按 5 维度（教育/年限/行业/技能/项目管理）匹配评分
  4. 合规红线：评分不读取性别、年龄等不当因素（登记表仅用于联系/核验）
  5. 生成 推荐/备选/不推荐 名单 + 推荐理由 + 待核验项
输出（03-output/）：
  1. 候选人简历筛选评分表.xlsx
  2. 推荐面试名单.xlsx
  3. 招聘工作台账.xlsx
  4. 企业微信通知草稿.txt
"""
import os

import re
from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from docx import Document
from docx.shared import Pt
from docx.oxml.ns import qn

# ============================================================
# 可调设置区（改这里即可，不用动下面逻辑）
# ============================================================
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

P_JD = f'{ROOT}/01-input/岗位JD_销售经理.docx'
P_RESUME_DIR = f'{ROOT}/01-input/候选人简历'
P_SCORE_STD = f'{ROOT}/01-input/招聘评分标准.xlsx'
P_CANDIDATES = f'{ROOT}/01-input/候选人信息登记表.xlsx'

P_OUT_SCORE = f'{ROOT}/03-output/候选人简历筛选评分表.xlsx'
P_OUT_SHORT = f'{ROOT}/03-output/推荐面试名单.xlsx'
P_OUT_WORK = f'{ROOT}/03-output/招聘工作台账.xlsx'
P_OUT_NOTICE = f'{ROOT}/03-output/企业微信通知草稿.txt'

BATCH_NO = datetime.now().strftime('%Y-%m-%d')
PROCESSOR = '招聘筛选助手'

# 1) 名单标签（可改）
LABEL_RECOMMEND = '推荐面试'
LABEL_ALTERNATE = '备选'
LABEL_NOT = '不推荐'

# 2) 名单判定（可改）
SCORE_RECOMMEND = 80            # 总分 ≥80 → 推荐面试
SCORE_ALTERNATE = 60            # 60-79 → 备选；<60 → 不推荐
HARD_MIN_YEARS = 5              # 硬门槛：销售经验 ≥5 年
HARD_MIN_MANAGE = 3             # 硬门槛：团队管理 ≥3 年
REQUIRED_DEGREE = '本科'         # 硬门槛：学历 ≥ 本科

# 3) 合规红线声明（可改，评分逻辑不使用性别/年龄等字段）
COMPLIANCE_NOTE = ('合规说明：本次筛选仅依据与岗位相关的教育背景、工作年限、行业经验、技能与项目管理能力进行评分，'
                   '未使用性别、年龄等与岗位无关的因素；候选人信息登记表仅用于联系与信息核验。')

# 4) 颜色（可改）
COLOR_REC = 'E2EFDA'             # 推荐：浅绿
COLOR_ALT = 'FFF2CC'             # 备选：浅黄
COLOR_NOT = 'FCE4D6'             # 不推荐：浅橙


# ============================================================
# 样式（由上方设置生成，一般不用动）
# ============================================================
HEADER_FILL = PatternFill('solid', fgColor='1F4E79')
HEADER_FONT = Font(bold=True, color='FFFFFF')
FILL_REC = PatternFill('solid', fgColor=COLOR_REC)
FILL_ALT = PatternFill('solid', fgColor=COLOR_ALT)
FILL_NOT = PatternFill('solid', fgColor=COLOR_NOT)
THIN = Side(style='thin', color='B0B0B0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

STATUS_FILL = {LABEL_RECOMMEND: FILL_REC, LABEL_ALTERNATE: FILL_ALT, LABEL_NOT: FILL_NOT}


def style_sheet(ws, widths):
    for c, w in widths.items():
        ws.column_dimensions[c].width = w
    for cell in ws[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = BORDER
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.border = BORDER


def color_rows(ws, ncols, level_col):
    for r in range(2, ws.max_row + 1):
        lv = str(ws.cell(row=r, column=level_col).value or '')
        fill = STATUS_FILL.get(lv)
        if fill:
            for c in range(1, ncols + 1):
                ws.cell(row=r, column=c).fill = fill


def set_font(run, name='宋体', size=12, bold=False):
    run.font.name = name
    run.font.size = Pt(size)
    run.font.bold = bold
    r = run._element
    rPr = r.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = rPr.makeelement(qn('w:rFonts'), {})
        rPr.append(rFonts)
    rFonts.set(qn('w:eastAsia'), name)


def read_rows(path, sheet=None):
    if not os.path.exists(path):
        return [], []
    wb = load_workbook(path)
    ws = wb[sheet] if sheet else wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        return [], []
    return list(rows[0]), list(rows[1:])


def read_docx(path):
    if not os.path.exists(path):
        return ''
    doc = Document(path)
    return '\n'.join(p.text for p in doc.paragraphs if p.text.strip())


# ============================================================
# 1. 解析简历（结构化提取）
# ============================================================
def parse_resume(text):
    """从简历文本提取结构化信息。
    兼容多种小节写法：【教育背景】/教育背景：/教育背景: 等；
    年限句式兼容："8年销售经验，其中5年团队管理经验" / "8年销售经验，管理经验5年" 等。
    """
    info = {'教育': '', '销售年限': 0, '管理年限': 0, '行业': '', '技能': [], '项目': ''}
    # 教育（兼容【教育背景】xxx | / 教育背景：xxx 等写法）
    m = re.search(r'【教育背景】\s*(\S+?)\s*[|｜]|(?:【教育背景】|教育背景[：:])\s*(\S+?)(?:\s|$)', text)
    if m:
        info['教育'] = (m.group(1) or m.group(2) or '').strip()
    # 工作经历（销售经验 X 年，其中 X 年团队管理经验 / 管理经验 X 年）
    m = re.search(r'(\d+)\s*年销售经验，其中\s*(\d+)\s*年团队管理经验', text)
    if m:
        info['销售年限'] = int(m.group(1))
        info['管理年限'] = int(m.group(2))
    else:
        m = re.search(r'(\d+)\s*年销售经验(?:，|,|、)?\s*(?:其中\s*)?(?:管理经验|团队管理经验|带团队)\s*(\d+)\s*年', text)
        if m:
            info['销售年限'] = int(m.group(1))
            info['管理年限'] = int(m.group(2))
        else:
            m2 = re.search(r'(\d+)\s*年销售经验|销售经验\s*(\d+)\s*年', text)
            if m2:
                info['销售年限'] = int(m2.group(1) or m2.group(2))
    # 管理年限兜底提取（兼容"管理经验 X 年/带团队 X 年/团队管理 X 年"等句式）
    if info['管理年限'] == 0:
        m3 = re.search(r'(?:管理经验|带团队|团队管理|带过团队)\s*(\d+)\s*年', text)
        if m3:
            info['管理年限'] = int(m3.group(1))
    # 行业（AI 软件公司口径：优先 AI/智能制造/工业软件/SaaS/IT，汽车/通信为相关）
    for ind in ['AI', '智能制造', '工业软件', 'SaaS', 'IT', '汽车', '通信']:
        if ind in text:
            info['行业'] = ind
            break
    # 技能（评分标准里的关键词，含解决方案销售）
    for skill in ['解决方案销售', '大客户销售', '渠道管理', '商务谈判', '团队管理']:
        if skill in text:
            info['技能'].append(skill)
    # 项目经历（含"千万级"或管理规模；兼容【项目经历】/项目经历：）
    m = re.search(r'(?:【项目经历】|项目经历[：:])(.*?)(?=【|\n\s*教育背景|\n\s*工作经历|$)', text, re.S)
    if m:
        info['项目'] = m.group(1).strip()
    return info


# ============================================================
# 2. 五维评分
# ============================================================
def score_education(edu):
    """教育背景：硕士=100，本科=80，大专=60。"""
    if '硕士' in edu:
        return 100
    if '本科' in edu:
        return 80
    if '大专' in edu:
        return 60
    return 40


def score_years(years):
    """工作年限：≥8=100，5-7=80，3-4=60，<3=40。"""
    if years >= 8:
        return 100
    if years >= 5:
        return 80
    if years >= 3:
        return 60
    return 40


def score_industry(ind):
    """行业经验：AI/智能制造/工业软件/SaaS/IT=100，汽车/通信等相关=70，无关=50。"""
    if ind in ('AI', '智能制造', '工业软件', 'SaaS', 'IT'):
        return 100
    if ind in ('汽车', '通信'):
        return 70
    return 50


def score_skills(skills):
    """技能匹配：全中=100，缺 1=80，缺 2=60。"""
    n = len(skills)
    if n >= 4:
        return 100
    if n == 3:
        return 80
    if n == 2:
        return 60
    return 40


def score_project(manage_years, project_text):
    """项目/管理经验：管理≥5 年或千万级项目=100，3-4 年或大项目=80，<3 年=60。"""
    if manage_years >= 5 or '千万级' in project_text or '1 亿' in project_text:
        return 100
    if manage_years >= 3 or '大单' in project_text or '8000 万' in project_text:
        return 80
    return 60


# ============================================================
# 3. 主流程
# ============================================================
def main():
    print(f'===== 招聘简历批量筛选与评分 · {BATCH_NO} =====')
    jd_text = read_docx(P_JD)
    # 评分标准（权重）
    _, std_rows = read_rows(P_SCORE_STD)
    dims = []
    for r in std_rows:
        if r and r[0]:
            dims.append({'维度': str(r[0]), '权重': float(r[1] or 0) / 100.0})
    print(f'[读取] JD 就绪 | 评分维度 {len(dims)} 个 | 候选人登记表就绪')

    # 候选人登记（一致性核验）——按表头列名映射，兼容扩展字段（序号/邮箱/期望薪资等）
    headers, cand_rows = read_rows(P_CANDIDATES)
    hdr = {str(h).strip(): i for i, h in enumerate(headers) if h is not None}

    def _col(r, name, default=''):
        i = hdr.get(name)
        if i is None or i >= len(r) or r[i] is None:
            return default
        return str(r[i]).strip()

    cand_map = {}
    for r in cand_rows:
        nm = _col(r, '姓名')
        if nm:
            cand_map[nm] = {
                '性别': _col(r, '性别'), '年龄': _col(r, '年龄'), '电话': _col(r, '联系电话'),
                '一致性': _col(r, '简历与登记一致性'), '备注': _col(r, '备注'),
            }

    # 批量解析简历
    results = []
    for fn in sorted(os.listdir(P_RESUME_DIR)):
        if not fn.endswith('.docx'):
            continue
        name = fn.replace('的简历.docx', '').replace('.docx', '')
        text = read_docx(os.path.join(P_RESUME_DIR, fn))
        info = parse_resume(text)

        # 5 维评分
        s_edu = score_education(info['教育'])
        s_year = score_years(info['销售年限'])
        s_ind = score_industry(info['行业'])
        s_skill = score_skills(info['技能'])
        s_proj = score_project(info['管理年限'], info['项目'])
        scores = {'教育背景': s_edu, '工作年限': s_year, '行业经验': s_ind,
                  '技能匹配': s_skill, '项目管理': s_proj}
        total = sum(s * d['权重'] for s, d in zip(scores.values(), dims))
        total = round(total, 1)

        # 硬门槛（学历、销售年限——与管理年限、信息核验分开处理）
        reasons = []
        if info['销售年限'] < HARD_MIN_YEARS:
            reasons.append(f'销售经验 {info["销售年限"]} 年 < 要求 {HARD_MIN_YEARS} 年')
        if score_education(info['教育']) < 80:
            reasons.append(f'学历 {info["教育"]} 未达本科要求')
        manage_short = info['管理年限'] < HARD_MIN_MANAGE

        # 待核验项（登记表一致性）
        verify = []
        c = cand_map.get(name, {})
        if c.get('一致性') == '不一致':
            verify.append(c.get('备注', '登记信息与简历不一致，需核验'))
        if not verify:
            verify.append('无')

        # 名单判定：硬门槛→不推荐；信息待核验或管理短板→备选；高分→推荐
        if reasons:
            level = LABEL_NOT
            reason_str = '；'.join(reasons)
        elif verify and verify[0] != '无':
            level = LABEL_ALTERNATE
            reason_str = f'总分 {total}，但{verify[0]}，待核验通过后再推荐面试'
        elif manage_short:
            level = LABEL_ALTERNATE
            reason_str = f'总分 {total}，但管理经验仅 {info["管理年限"]} 年（要求 ≥{HARD_MIN_MANAGE} 年），建议备选'
        elif total >= SCORE_RECOMMEND:
            level = LABEL_RECOMMEND
            reason_str = f'总分 {total}，满足岗位核心要求（{info["教育"]}，{info["销售年限"]} 年销售/{info["管理年限"]} 年管理，{info["行业"] or "相关"}行业）'
        elif total >= SCORE_ALTERNATE:
            level = LABEL_ALTERNATE
            reason_str = f'总分 {total}，基本符合但有短板，建议备选'
        else:
            level = LABEL_NOT
            reason_str = f'总分 {total} 低于备选线，匹配度不足'

        results.append({
            '姓名': name, '教育背景': info['教育'], '销售年限': info['销售年限'],
            '管理年限': info['管理年限'], '行业经验': info['行业'] or '无',
            '技能': '、'.join(info['技能']) or '无',
            '教育背景分': s_edu, '工作年限分': s_year, '行业经验分': s_ind,
            '技能匹配分': s_skill, '项目管理分': s_proj, '总分': total,
            '推荐理由': reason_str, '待核验项': '；'.join(verify),
            '名单': level, '状态': '待通知',
        })

    # 排序（推荐→备选→不推荐，按总分）
    order = {LABEL_RECOMMEND: 0, LABEL_ALTERNATE: 1, LABEL_NOT: 2}
    results.sort(key=lambda x: (order[x['名单']], -x['总分']))

    n_rec = sum(1 for r in results if r['名单'] == LABEL_RECOMMEND)
    n_alt = sum(1 for r in results if r['名单'] == LABEL_ALTERNATE)
    n_not = sum(1 for r in results if r['名单'] == LABEL_NOT)
    print(f'[筛选] 简历 {len(results)} 份 | 推荐 {n_rec} / 备选 {n_alt} / 不推荐 {n_not}')
    print(f'[合规] {COMPLIANCE_NOTE}')

    # 输出 1：候选人简历筛选评分表.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '筛选评分'
    h1 = ['姓名', '教育背景', '销售年限', '管理年限', '行业经验', '技能',
          '教育背景分', '工作年限分', '行业经验分', '技能匹配分', '项目管理分',
          '总分', '名单', '推荐理由', '待核验项']
    ws.append(h1)
    for r in results:
        ws.append([r[k] for k in h1])
    style_sheet(ws, {'A': 8, 'B': 8, 'C': 8, 'D': 8, 'E': 8, 'F': 20,
                     'G': 10, 'H': 10, 'I': 10, 'J': 10, 'K': 10, 'L': 8,
                     'M': 10, 'N': 40, 'O': 30})
    color_rows(ws, len(h1), 13)
    wb.save(P_OUT_SCORE)
    print(f'[OK] 候选人简历筛选评分表.xlsx（{len(results)} 份）')

    # 输出 2：推荐面试名单.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '推荐面试名单'
    h2 = ['名单', '姓名', '总分', '教育背景', '销售年限', '管理年限', '行业经验',
          '推荐理由', '待核验项', '面试建议']
    ws.append(h2)
    for r in results:
        if r['名单'] == LABEL_NOT:
            continue
        interview = '建议 1 周内安排面试' if r['名单'] == LABEL_RECOMMEND else '建议进入备选池，视空缺再安排'
        ws.append([r['名单'], r['姓名'], r['总分'], r['教育背景'], r['销售年限'],
                   r['管理年限'], r['行业经验'], r['推荐理由'], r['待核验项'], interview])
    style_sheet(ws, {'A': 10, 'B': 8, 'C': 8, 'D': 8, 'E': 8, 'F': 8, 'G': 8, 'H': 40, 'I': 30, 'J': 24})
    color_rows(ws, len(h2), 1)
    wb.save(P_OUT_SHORT)
    print(f'[OK] 推荐面试名单.xlsx（{ws.max_row - 1} 行）')

    # 输出 3：招聘工作台账.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '招聘台账'
    h3 = ['姓名', '名单', '总分', '推荐理由', '待核验项', '状态', '面试安排', '处理人', '处理意见']
    ws.append(h3)
    for r in results:
        ws.append([r['姓名'], r['名单'], r['总分'], r['推荐理由'], r['待核验项'],
                   r['状态'], '', '', ''])
    style_sheet(ws, {'A': 8, 'B': 10, 'C': 8, 'D': 40, 'E': 30, 'F': 10, 'G': 14, 'H': 10, 'I': 24})
    color_rows(ws, len(h3), 2)
    wb.save(P_OUT_WORK)
    print(f'[OK] 招聘工作台账.xlsx（{len(results)} 行）')

    # 输出 4：企业微信通知草稿.txt（脚本自动生成，AI 检测绑定后决定发送或告知草稿）
    # （5.0.10 起企微消息能力已全面开放（不限企业规模），AI 可直接发送；发送失败时草稿兜底）
    top5 = [r for r in results if r['名单'] == LABEL_RECOMMEND][:5]
    verify_list = [f"{r['姓名']}：{r['待核验项']}" for r in results if r['待核验项'] != '无']
    n_lines = ['【招聘筛选通知】',
               f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}',
               f'本批次简历：{len(results)} 份',
               f'推荐面试：{n_rec} 人 | 备选：{n_alt} 人 | 不推荐：{n_not} 人']
    if top5:
        n_lines.append(f'候选人 TOP{len(top5)}（按总分）：')
        for r in top5:
            n_lines.append(f'  · {r["姓名"]}：{r["总分"]} 分（{r["教育背景"]}，{r["销售年限"]} 年销售）——{r["推荐理由"]}')
    if verify_list:
        n_lines.append('需人工核验信息：')
        for v in verify_list:
            n_lines.append(f'  · {v}')
    n_lines.append(COMPLIANCE_NOTE)
    n_lines.append('提示：本通知为筛选提醒，最终面试安排由用人经理确认。')
    with open(P_OUT_NOTICE, 'w', encoding='utf-8') as f:
        f.write('\n'.join(n_lines))

    print(f'[OK] 企业微信通知草稿.txt（推荐 {n_rec} / 备选 {n_alt} / 不推荐 {n_not}）')


if __name__ == '__main__':
    main()
