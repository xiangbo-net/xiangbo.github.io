# -*- coding: utf-8 -*-
"""案例12 核心脚本：生产异常日报自动汇总
输入（01-input/）：班组日报、车间微信群记录、设备异常记录、生产计划、部门责任分工表
流程：
  1. 提取异常事件（班组日报异常描述 + 微信群口语化记录 + 设备异常记录）
  2. 口语化转管理语言（微信吐槽 → 规范描述）
  3. 分类（设备/物料/人员/质量/计划）
  4. 关联生产计划识别影响工单
  5. 判断责任部门和建议动作（部门责任分工表关键字匹配）
输出（03-output/）：
  1. 生产异常日报.docx（Word：当日总览 + 异常清单 + 影响工单 + 责任部门跟进）
  2. 生产异常清单.xlsx（每条异常明细，状态标色）
  3. 生产异常工作台账.xlsx（异常ID/来源/分类/影响工单/责任部门/状态/处理人）
"""
import os

import re
from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml.ns import qn
from docx.enum.text import WD_PARAGRAPH_ALIGNMENT

# ============================================================
# 可调设置区（改这里即可，不用动下面逻辑）
# ============================================================
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# 输入路径
P_SHIFT = f'{ROOT}/01-input/班组日报_当天.xlsx'
P_WECHAT = f'{ROOT}/01-input/车间微信群记录.txt'
P_EQUIP = f'{ROOT}/01-input/设备异常记录.xlsx'
P_PLAN = f'{ROOT}/01-input/生产计划_当天.xlsx'
P_MAP = f'{ROOT}/01-input/部门责任分工表.xlsx'

# 输出路径
P_OUT_DOCX = f'{ROOT}/03-output/生产异常日报.docx'
P_OUT_LIST = f'{ROOT}/03-output/生产异常清单.xlsx'
P_OUT_WORK = f'{ROOT}/03-output/生产异常工作台账.xlsx'
P_OUT_NOTICE = f'{ROOT}/03-output/企业微信通知草稿.txt'

BATCH_NO = datetime.now().strftime('%Y-%m-%d')      # 批次（当天日期）
PROCESSOR = '生产管理助手'                          # 处理人标识

# 1) 优先级标签（可改）
LABEL_HIGH = '高优先级'
LABEL_MID = '中优先级'
LABEL_LOW = '低优先级'

# 2) 行颜色（可改）
COLOR_HIGH = 'C00000'            # 高优先级：深红
COLOR_MID = 'FCE4D6'             # 中优先级：浅橙
COLOR_LOW = 'FFF2CC'             # 低优先级：浅黄
COLOR_OK = 'FFFFFF'              # 正常：白

# 3) 功能开关（True=启用 / False=关闭，可改）
ENABLE_WECHAT = True             # 是否解析微信群记录
ENABLE_EQUIP = True              # 是否并入设备异常记录

# 4) 优先级规则（可改）
HIGH_STOP_MIN = 30               # 高优先级：单次停机 ≥ 30 分钟
HIGH_KEYWORDS = ['缺料', '断线', '完不成', '晚点交', '影响交期', '卡在检验']  # 高优先级：命中这些词
MID_KEYWORDS = ['偏高', '异常', '划痕', '制冷', '请假', '缺人手']             # 中优先级：命中这些词


# ============================================================
# 样式（由上方设置生成，一般不用动）
# ============================================================
HEADER_FILL = PatternFill('solid', fgColor='1F4E79')
HEADER_FONT = Font(bold=True, color='FFFFFF')
FILL_HIGH = PatternFill('solid', fgColor=COLOR_HIGH)
FILL_MID = PatternFill('solid', fgColor=COLOR_MID)
FILL_LOW = PatternFill('solid', fgColor=COLOR_LOW)
FILL_OK = PatternFill('solid', fgColor=COLOR_OK)
HIGH_FONT = Font(bold=True, color='FFFFFF')
THIN = Side(style='thin', color='B0B0B0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)


def style_sheet(ws, widths):
    """表头样式 + 列宽 + 边框。"""
    for c, w in widths.items():
        ws.column_dimensions[c].width = w
    for cell in ws[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = BORDER
    for row in ws.iter_rows(min_row=2):
        for cell in row:
            cell.border = BORDER


def color_rows(ws, col_idx, ncols, level_col):
    """按优先级列着色。"""
    for r in range(2, ws.max_row + 1):
        lv = str(ws.cell(row=r, column=level_col).value or '')
        fill = FILL_HIGH if lv == LABEL_HIGH else (FILL_MID if lv == LABEL_MID else (FILL_LOW if lv == LABEL_LOW else FILL_OK))
        for c in range(1, ncols + 1):
            cell = ws.cell(row=r, column=c)
            cell.fill = fill
            if lv == LABEL_HIGH:
                cell.font = HIGH_FONT


def set_font(run, name='宋体', size=12, bold=False):
    """设置中文字体（同时设 ascii 和 eastAsia）。"""
    run.font.name = name
    run.font.size = Pt(size)
    run.font.bold = bold
    r = run._element
    rPr = r.get_or_add_rPr()
    rFonts = rPr.find(qn('w:rFonts'))
    if rFonts is None:
        rFonts = rPr.makeelement(qn('w:rFonts'), {})
        rPr.append(rFonts)
    rFonts.set(qn('w:eastAsia'), name)


def shade_cell(cell, color_hex, white_text=False):
    """给 docx 单元格填充背景色（与 Excel 颜色约定一致）。"""
    tcPr = cell._tc.get_or_add_tcPr()
    shd = tcPr.find(qn('w:shd'))
    if shd is None:
        shd = tcPr.makeelement(qn('w:shd'), {})
        tcPr.append(shd)
    shd.set(qn('w:val'), 'clear')
    shd.set(qn('w:color'), 'auto')
    shd.set(qn('w:fill'), color_hex)
    if white_text:
        for p in cell.paragraphs:
            for run in p.runs:
                run.font.color.rgb = RGBColor(0xFF, 0xFF, 0xFF)


def read_rows(path, sheet=None):
    """读取 xlsx 全部行（首行为表头，返回 表头list 与 数据list）。"""
    if not os.path.exists(path):
        return [], []
    wb = load_workbook(path)
    ws = wb[sheet] if sheet else wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        return [], []
    return list(rows[0]), list(rows[1:])


# ============================================================
# 1. 提取异常事件
# ============================================================
def load_shift_events():
    """从班组日报提取异常事件。"""
    events = []
    header, rows = read_rows(P_SHIFT)
    if not rows:
        return events
    for r in rows:
        if r and str(r[7] or '').strip():
            events.append({
                'source': '班组日报',
                'time': f'{BATCH_NO} 上午',
                'raw': str(r[7]).strip(),
                'who': str(r[0] or ''),
                'line': str(r[1] or ''),
                'wo': str(r[3] or ''),        # 生产工单（表头第4列）
                'product': str(r[4] or ''),   # 产品（表头第5列）
            })
    return events


def load_wechat_events():
    """解析微信群记录（口语化 → 管理语言），提取异常事件。
    兼容两种记录格式：
      ① 整理版：【群名片】时间 内容（样例素材格式）
      ② 微信导出版：时间 昵称: 内容（如 "08-14 10:23 张三: 线体1又停机了"）
    """
    events = []
    if not ENABLE_WECHAT or not os.path.exists(P_WECHAT):
        return events
    pat1 = re.compile(r'【(.+?)】(\d{2}:\d{2})\s*(.*)')        # 【昵称】时间 内容
    pat2 = re.compile(r'(\d{2}[-/]\d{2})\s+(\d{2}:\d{2})\s+([^:：]+)[:：]\s*(.*)')  # 日期 时间 昵称: 内容
    pat3 = re.compile(r'(\d{2}:\d{2})\s+([^:：]+)[:：]\s*(.*)')  # 时间 昵称: 内容
    with open(P_WECHAT, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            who, t, text = '', '', ''
            m = pat1.match(line)
            if m:
                who, t, text = m.group(1), m.group(2), m.group(3)
            else:
                m = pat2.match(line) or pat3.match(line)
                if m:
                    if m.lastindex == 4:
                        t, who, text = m.group(2), m.group(3), m.group(4)
                    else:
                        t, who, text = m.group(1), m.group(2), m.group(3)
            if not text:
                continue
            # 只提取"问题类"发言：过滤答复/确认/收到类
            # 注：不过滤"在查"（"品质那边在查"属问题陈述，非答复确认）
            if re.search(r'收到|先观察|已安排|我看了|安排|先别|报修单|复核', text):
                continue
            # 判断是否异常：命中设备/物料/人员/质量/计划关键字
            if re.search(r'停机|卡料|抛料|空调|缺料|不够|划痕|卡在检验|请假|缺人手|完不成|晚点交|良率|断线', text):
                m_wo = re.search(r'WO-\d+-\d+', text)
                events.append({
                    'source': '微信群',
                    'time': f'{BATCH_NO} {t}' if t else f'{BATCH_NO} 上午',
                    'raw': text,
                    'who': who,
                    'line': '',
                    'wo': m_wo.group(0) if m_wo else '',
                    'product': '',
                })
    return events


def load_equip_events():
    """从设备异常记录提取。"""
    events = []
    if not ENABLE_EQUIP:
        return events
    header, rows = read_rows(P_EQUIP)
    for r in rows:
        if r and str(r[4] or '').strip():
            raw_time = str(r[0] or '')
            m_t = re.search(r'\d{2}:\d{2}', raw_time)
            events.append({
                'source': '设备记录',
                'time': f'{BATCH_NO} {m_t.group(0)}' if m_t else raw_time,   # 归一化到批次当天
                'raw': f'设备 {r[1]} {r[2]}：{r[4]}（{r[5]}）',
                'who': str(r[7] or ''),
                'line': str(r[3] or ''),
                'wo': '',
                'product': '',
                'stop_min': float(r[6] or 0),
            })
    return events


# ============================================================
# 2. 口语化转管理语言（微信吐槽 → 规范描述）
# ============================================================
def to_management_language(raw, line=''):
    """把口语化描述转成管理语言（若原文已含线体名则不再加前缀）。"""
    t = raw.strip()
    rules = [
        (r'修好了，耽误了(\d+)分钟([，,]\s*WO-\d+-\d+)?.*?晚点交', r'停机约 \1 分钟\2 工单交期存在延误风险'),
        (r'又停机了.*今天第\d+次.*', '当日多次停机（同类故障复发）'),
        (r'停机.*报修.*耽误了(\d+)分钟', r'停机 \1 分钟，已报修'),
        (r'传送带[:：]?\s*卡料|卡料停机', '传送带卡料停机'),
        (r'贴片机抛料偏多|贴片机抛料率.*偏高|抛料率.*偏高|抛料偏多', '贴片机抛料率异常偏高'),
        (r'空调坏了|空调.*没修|制冷异常|温度有点高', '车间空调制冷异常，温度偏高'),
        (r'风扇异响.*已报修|风扇异响', '风扇异响（已报修）'),
        (r'料不够了.*最快.*明天到|料不够了', '原材料库存不足，补货需至次日'),
        (r'有.{1,6}外观划痕', '来料外观划痕，检验未放行'),
        (r'卡在检验', '来料滞留检验环节'),
        (r'(\d+)个人.*请假|临时请假.*缺人手', r'人员临时请假，人手不足'),
        (r'缺人手', '人员缺勤，人手不足'),
        (r'完不成', '工单存在延期风险'),
        (r'可能要晚点交|晚点交', '工单交期存在延误风险'),
        (r'断线', '产线存在停产风险'),
    ]
    for pat, repl in rules:
        if re.search(pat, t):
            t = re.sub(pat, repl, t)
            # 清理替换后残留的尾巴（如"车间空调制冷异常...车间空调制冷异"）
            break
    # 线体前缀：原文未含线体名时才加
    if line and line not in t:
        t = f'{line} {t}'
    return t


def extract_topic(raw):
    """提取主题键（用于聚合同一设备/物料/人员的多次记录）。
    规则：优先按线体+设备聚合；物料按名称+问题拆开；人员按线体。"""
    # 线体1 传送带（班组日报/微信群/设备记录 EQ-101 统一）
    # 含"耽误了X分钟"的交期类发言（如"修好了，耽误了40分钟…晚点交"）同属传送带停机事件
    if ('线体1' in raw and re.search(r'停机|卡料', raw)) or '传送带' in raw or 'EQ-101' in raw or re.search(r'耽误了\d+分钟', raw):
        return '设备|线体1传送带'
    # 线体2 贴片机（抛料）
    if ('线体2' in raw and '抛料' in raw) or '贴片机' in raw or 'EQ-205' in raw:
        return '设备|线体2贴片机'
    # 线体5 空调（传感器车间）
    if 'EQ-301' in raw or '空调' in raw or '制冷' in raw or '传感器车间' in raw:
        return '设备|线体5空调'
    # 风扇（低优先级演示）
    if '风扇' in raw:
        return '设备|线体5风扇'
    # 控制板：缺料 vs 来料质量 拆开
    if '控制板' in raw:
        if '划痕' in raw or '卡在检验' in raw or '放行' in raw:
            return '物料|控制板来料'
        return '物料|控制板缺料'
    if '请假' in raw or '缺人手' in raw:
        return '人员|线体3'
    m = re.search(r'WO-\d+', raw)
    if m:
        return f'计划|{m.group(0)}'
    return f'其他|{raw[:6]}'


def extract_line(raw, line=''):
    """从原文提取线体名。"""
    if line:
        return line
    m = re.search(r'线体\d', raw)
    return m.group(0) if m else ''


# ============================================================
# 3. 分类 + 责任部门 + 建议动作
# ============================================================
def classify_and_assign(raw, line='', wo=''):
    """返回 (异常类型, 责任部门, 建议动作, 优先级)。"""
    header, rows = read_rows(P_MAP)
    # 遍历映射表（按类型顺序匹配关键字）
    for r in rows:
        if not r or not r[0]:
            continue
        etype, keywords, dept = str(r[0]), str(r[1]), str(r[2])
        if re.search(keywords, raw):
            action = suggest_action(etype, raw)
            prio = judge_priority(raw, etype)
            return etype, dept, action, prio
    return '其他异常', '待确认', '人工确认归属部门', LABEL_LOW


def suggest_action(etype, raw):
    """按类型给建议动作。"""
    if etype == '设备异常':
        if '停机' in raw or '卡料' in raw:
            return '检修设备并排查重复故障根因'
        return '安排维修并评估对产线影响'
    if etype == '物料异常':
        return '协调补货/催料，加快来料检验放行'
    if etype == '质量异常':
        return '品质复核并出具处置意见'
    if etype == '人员异常':
        return '协调机动工顶岗/安排加班补产'
    if etype == '计划异常':
        return '评估工单排期并给出调整方案'
    return '人工确认后处理'


def judge_priority(raw, etype):
    """优先级判定。"""
    # 设备停机时长
    m = re.search(r'停机.*?(\d+)', raw)
    if m and int(m.group(1)) >= HIGH_STOP_MIN:
        return LABEL_HIGH
    if any(k in raw for k in HIGH_KEYWORDS):
        return LABEL_HIGH
    if any(k in raw for k in MID_KEYWORDS):
        return LABEL_MID
    return LABEL_LOW


# ============================================================
# 4. 关联生产计划 → 影响工单
# ============================================================
def load_plan_map():
    """生产计划：线体 → [(工单, 产品, 计划数量, 时段)]；同时建 产品名 → 工单 映射。"""
    plan_map = {}
    product_map = {}
    header, rows = read_rows(P_PLAN)
    for r in rows:
        if r and r[2]:
            plan_map.setdefault(str(r[2]).strip(), []).append(
                (str(r[0]), str(r[1]), str(r[3] or ''), str(r[4] or '')))
        if r and r[1]:
            product_map.setdefault(str(r[1]).strip(), str(r[0]))
    return plan_map, product_map


def find_affected_wo(line, wo, plan_map, product_map, raw=''):
    """找影响工单：优先事件自带工单 → 按产品名回查 → 按线体关联。"""
    if wo:
        return wo
    for prod, w in product_map.items():
        if prod in raw:
            return w
    if line and line in plan_map:
        return '、'.join(p[0] for p in plan_map[line][:2])
    return ''


# ============================================================
# 5. 主流程
# ============================================================
def main():
    print(f'===== 生产异常日报自动汇总 · {BATCH_NO} =====')
    events = []
    events += load_shift_events()
    events += load_wechat_events()
    events += load_equip_events()
    print(f'[提取] 原始异常事件 {len(events)} 条（班组日报+微信群+设备记录）')

    plan_map, product_map = load_plan_map()
    rows = []        # 异常清单行
    stat = {LABEL_HIGH: 0, LABEL_MID: 0, LABEL_LOW: 0}
    dept_set = set()

    # 按主题键聚合（同一设备/物料/人员的多次记录合并为一条异常）
    groups = {}
    for ev in events:
        topic = extract_topic(ev['raw'])
        groups.setdefault(topic, []).append(ev)

    for i, (topic, evs) in enumerate(sorted(groups.items()), 1):
        ex_id = f'EX-{BATCH_NO.replace("-", "")}-{i:02d}'
        # 主事件：优先选有线体信息的（设备记录），其次时间最早的
        main_ev = next((e for e in evs if e.get('line')), evs[0])
        raw = main_ev['raw']
        line = extract_line(raw, main_ev['line'])
        # 多条记录 → 补充"当日多次"信息
        extra = ''
        if len(evs) > 1:
            total_stop = sum(float(e.get('stop_min', 0) or 0) for e in evs)
            stop_desc = f'，累计停机约 {total_stop:.0f} 分钟' if total_stop >= 30 else ''
            extra = f'（当日同类事件 {len(evs)} 次{stop_desc}）'
        mgmt = to_management_language(raw, line) + extra
        # 组内若有交期风险记录（如"晚点交"），合并后保留该信息
        if any(re.search(r'晚点交|交期|延误', e['raw']) for e in evs) and '交期' not in mgmt and '延误' not in mgmt:
            mgmt += '，工单交期存在延误风险'
        # 分类 + 责任部门 + 动作 + 优先级（取组内最高）
        etype, dept, action, _ = classify_and_assign(raw, line, main_ev['wo'])
        prio = LABEL_LOW
        for ev in evs:
            _, _, _, p = classify_and_assign(ev['raw'], ev['line'], ev['wo'])
            rank = {LABEL_HIGH: 3, LABEL_MID: 2, LABEL_LOW: 1}
            if rank.get(p, 0) > rank.get(prio, 0):
                prio = p
        # 影响工单
        wo = find_affected_wo(line, main_ev['wo'], plan_map, product_map, raw)
        sources = '、'.join(sorted({e['source'] for e in evs}))
        first_raw = evs[0]['raw'][:60]
        if len(evs) > 1:
            first_raw += f' 等{len(evs)}条'
        rows.append({
            '异常ID': ex_id, '时间': main_ev['time'], '来源': sources,
            '原始记录': first_raw, '管理语言': mgmt,
            '异常类型': etype, '影响工单': wo,
            '责任部门': dept, '建议动作': action,
            '优先级': prio, '状态': '待跟进',
        })
        stat[prio] += 1
        dept_set.add(dept)

    # 输出 1：生产异常日报.docx
    doc = Document()
    doc.add_heading(f'生产异常日报（{BATCH_NO}）', level=0)
    p = doc.add_paragraph(f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")} | 生成方：{PROCESSOR}')
    for run in p.runs:
        set_font(run, '宋体', 10)

    doc.add_heading('一、当日异常总览', level=1)
    doc.add_paragraph(
        f'当日共记录生产异常 {len(rows)} 起：高优先级 {stat[LABEL_HIGH]} 起、'
        f'中优先级 {stat[LABEL_MID]} 起、低优先级 {stat[LABEL_LOW]} 起。'
        f'涉及责任部门：{"、".join(sorted(dept_set))}。')

    doc.add_heading('二、异常明细（含影响工单与责任部门）', level=1)
    table = doc.add_table(rows=1, cols=8)
    table.style = 'Light Grid Accent 1'
    hdr = table.rows[0].cells
    for j, t in enumerate(['异常ID', '时间', '来源', '管理语言', '异常类型', '影响工单', '责任部门', '优先级']):
        hdr[j].text = t
    for r in rows:
        cells = table.add_row().cells
        for j, k in enumerate(['异常ID', '时间', '来源', '管理语言', '异常类型', '影响工单', '责任部门', '优先级']):
            cells[j].text = str(r[k])
        # 按优先级给整行着色（高=深红/白字，中=浅橙，低=浅黄，正常=白）
        lv = r['优先级']
        if lv == LABEL_HIGH:
            for c in cells:
                shade_cell(c, COLOR_HIGH, white_text=True)
        elif lv == LABEL_MID:
            for c in cells:
                shade_cell(c, COLOR_MID)
        elif lv == LABEL_LOW:
            for c in cells:
                shade_cell(c, COLOR_LOW)

    doc.add_heading('三、高优先级异常', level=1)
    high_rows = [r for r in rows if r['优先级'] == LABEL_HIGH]
    if high_rows:
        for r in high_rows:
            doc.add_paragraph(
                f'· {r["异常ID"]} {r["管理语言"]}（{r["异常类型"]}，影响工单 {r["影响工单"] or "待定"}，'
                f'责任部门 {r["责任部门"]}，建议：{r["建议动作"]}）')
    else:
        doc.add_paragraph('· 当日无高优先级异常。')

    doc.add_heading('四、待跟进责任部门', level=1)
    for r in rows:
        doc.add_paragraph(f'· {r["责任部门"]}：跟进 {r["异常ID"]}（{r["管理语言"]}），建议 {r["建议动作"]}。')
    doc.save(P_OUT_DOCX)
    print(f'[OK] 生产异常日报.docx（{len(rows)} 条异常）')

    # 输出 2：生产异常清单.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '生产异常清单'
    h1 = ['异常ID', '时间', '来源', '原始记录', '管理语言', '异常类型', '影响工单',
          '责任部门', '建议动作', '优先级', '状态']
    ws.append(h1)
    for r in rows:
        ws.append([r[k] for k in h1])
    style_sheet(ws, {'A': 20, 'B': 16, 'C': 8, 'D': 30, 'E': 30, 'F': 10,
                     'G': 20, 'H': 12, 'I': 22, 'J': 10, 'K': 8})
    color_rows(ws, 10, len(h1), 10)
    wb.save(P_OUT_LIST)
    print(f'[OK] 生产异常清单.xlsx（{len(rows)} 条）')

    # 输出 3：生产异常工作台账.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '异常台账'
    h2 = ['异常ID', '来源', '异常类型', '影响工单', '责任部门', '优先级', '状态', '处理人', '处理意见']
    ws.append(h2)
    for r in rows:
        ws.append([r['异常ID'], r['来源'], r['异常类型'], r['影响工单'],
                   r['责任部门'], r['优先级'], r['状态'], '', ''])
    style_sheet(ws, {'A': 20, 'B': 10, 'C': 10, 'D': 20, 'E': 12, 'F': 10, 'G': 10, 'H': 10, 'I': 24})
    color_rows(ws, 6, len(h2), 6)
    wb.save(P_OUT_WORK)
    print(f'[OK] 生产异常工作台账.xlsx（{len(rows)} 行）')

    # 输出 4：企业微信通知草稿.txt（脚本自动生成，AI 检测绑定后决定发送或告知草稿）
    # （5.0.10 起企微消息能力已全面开放（不限企业规模），AI 可直接发送；发送失败时草稿兜底）
    high = [r for r in rows if r['优先级'] == LABEL_HIGH]
    dept_set2 = sorted({r['责任部门'] for r in rows})
    lines = [
        '【生产异常日报通知】',
        f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}',
        f'当日异常总数：{len(rows)} 起（高 {stat[LABEL_HIGH]} / 中 {stat[LABEL_MID]} / 低 {stat[LABEL_LOW]}）',
        f'高优先级异常（{len(high)} 起）：',
    ]
    for r in high:
        lines.append(f'  · {r["管理语言"]}（影响工单 {r["影响工单"] or "待定"}，责任部门 {r["责任部门"]}）')
    wo_set = sorted({w.strip() for r in rows if r['影响工单']
                     for w in str(r['影响工单']).replace('、', ',').split(',') if w.strip()})
    lines.append(f'影响工单：{"、".join(wo_set) if wo_set else "无"}')
    lines.append(f'待跟进责任部门：{"、".join(dept_set2)}')
    lines.append('提示：本通知为汇总提醒，跟进动作由责任部门执行。')
    with open(P_OUT_NOTICE, 'w', encoding='utf-8') as f:
        f.write('\n'.join(lines))

    print(f'[OK] 企业微信通知草稿.txt（异常 {len(rows)} 起 / 高优先级 {len(high)}）')

    print(f'[汇总] 高 {stat[LABEL_HIGH]} / 中 {stat[LABEL_MID]} / 低 {stat[LABEL_LOW]}，共 {len(rows)} 条')


if __name__ == '__main__':
    main()
