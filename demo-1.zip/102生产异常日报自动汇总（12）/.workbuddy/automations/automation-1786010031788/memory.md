# 自动化执行记录：案例12-生产异常日报（每天 18:00）

## 2026-08-06 17:55（首次执行）
- 运行环境：`C:/Users/QYJ-NN/.workbuddy/binaries/python/envs/default/Scripts/python.exe`（openpyxl 3.1.5 + python-docx 可用）
- 输入：01-input 下 5 个文件齐全（班组日报/微信群/设备记录/生产计划/责任部门映射表）
- 执行结果：提取原始事件 15 条 → 聚合 8 条异常（高 4 / 中 3 / 低 1），生成 生产异常日报.docx、生产异常清单.xlsx、生产异常工作台账.xlsx
- 企业微信：连接器 disconnected（未绑定）→ 通知保存为 03-output/企业微信通知草稿.txt（未推送生产群）
- 待办：用户绑定企业微信连接器后，次日自动化即可直接推送生产管理群
