# -*- coding: utf-8 -*-
"""
案例9《采购计划生成与缺料风险预警》输入素材生成器
================================================
生成 6 个输入文件（样例数据），覆盖演示点：
  - BOM 展开（产品 → 多物料用量）
  - 库存扣减 + 在途扣减 + 安全库存补齐
  - 净需求计算（毛需求 - 库存 - 在途 + 安全库存）
  - 供应商提前期 → 建议下单日期
  - 缺料风险分级（高/中/低）与最早缺料日
基准日：2026-08-06（未来 14 天 = 8-06 ~ 8-19）
用法：python gen_input_files.py（在案例9项目根目录下运行）
"""
import os
from openpyxl import Workbook

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ============ 1. 生产计划_MPS_未来14天.xlsx ============
# (产品编码, 产品名称, 计划日期, 计划数量)
# 每天：成品A 200 件、成品B 50 件
MPS = []
for i in range(14):
    day = f'2026-08-{6+i:02d}'
    MPS.append(('P-A001', '智能终端A', day, 200))
    MPS.append(('P-B001', '配件套装B', day, 50))

# ============ 2. BOM_产品用量表.xlsx ============
# (父产品编码, 父产品名称, 子物料编码, 子物料名称, 单件用量)
BOM = [
    ('P-A001', '智能终端A', 'WL-1001', 'USB-C 数据线', 2),
    ('P-A001', '智能终端A', 'WL-1002', '电子元器件包', 1),
    ('P-A001', '智能终端A', 'WL-1005', '电源适配器',   1),
    ('P-B001', '配件套装B', 'WL-1003', '精密轴承',     1),
    ('P-B001', '配件套装B', 'WL-1006', '螺丝套装',     2),
]

# ============ 3. 库存台账（承接案例8库存更新后） ============
# (物料编码, 物料名称, 当前库存, 单位, 库位)
STOCK = [
    ('WL-1001', 'USB-C 数据线', 300, '条', 'A-01-01'),
    ('WL-1002', '电子元器件包', 3000, '包', 'B-02-01'),  # 库存充足（正常演示）
    ('WL-1003', '精密轴承',     350, '套', 'A-03-02'),   # 库存覆盖5天（中风险演示）
    ('WL-1005', '电源适配器',     0, '个', 'A-02-03'),   # 库存 0（高风险触发）
    ('WL-1006', '螺丝套装',      50, '盒', 'D-99-99'),   # 库存极低（高风险触发）
]

# ============ 4. 在途采购订单.xlsx ============
# (采购单号, 物料编码, 物料名称, 在途数量, 预计到货日)
IN_TRANSIT = [
    ('PO-INT-001', 'WL-1005', '电源适配器',  1000, '2026-08-18'),  # 到货晚（风险点）
]

# ============ 5. 安全库存规则.xlsx ============
# (物料编码, 物料名称, 安全库存, 损耗率%)
SAFETY = [
    ('WL-1001', 'USB-C 数据线',  500, 2),
    ('WL-1002', '电子元器件包',  300, 1),
    ('WL-1003', '精密轴承',      100, 1),
    ('WL-1005', '电源适配器',    200, 2),
    ('WL-1006', '螺丝套装',      150, 1),
]

# ============ 6. 供应商提前期表.xlsx ============
# (物料编码, 物料名称, 默认供应商, 提前期天数)
LEADTIME = [
    ('WL-1001', 'USB-C 数据线', '东莞京东利昇贸易',  5),
    ('WL-1002', '电子元器件包', '广州华安材料',      7),
    ('WL-1003', '精密轴承',     '上海精工设备',      5),    # 提前期5天（中风险：8-12缺料，8-07前下单来得及）
    ('WL-1005', '电源适配器',   '东莞京东利昇贸易', 15),   # 提前期长（高风险）
    ('WL-1006', '螺丝套装',     '广州华安材料',      8),
]


def write_mps():
    wb = Workbook()
    ws = wb.active
    ws.title = '生产计划MPS'
    headers = ['产品编码', '产品名称', '计划日期', '计划数量']
    ws.append(headers)
    for r in MPS:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '01-input', '生产计划_MPS_未来14天.xlsx'))
    print(f'[OK] 生产计划_MPS_未来14天.xlsx（{len(MPS)} 条）')


def write_bom():
    wb = Workbook()
    ws = wb.active
    ws.title = 'BOM用量表'
    headers = ['父产品编码', '父产品名称', '子物料编码', '子物料名称', '单件用量']
    ws.append(headers)
    for r in BOM:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '01-input', 'BOM_产品用量表.xlsx'))
    print(f'[OK] BOM_产品用量表.xlsx（{len(BOM)} 条）')


def write_stock():
    wb = Workbook()
    ws = wb.active
    ws.title = '库存台账'
    headers = ['物料编码', '物料名称', '当前库存', '单位', '库位']
    ws.append(headers)
    for r in STOCK:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '01-input', '库存台账_实时库存.xlsx'))
    print('[OK] 库存台账_实时库存.xlsx')


def write_intransit():
    wb = Workbook()
    ws = wb.active
    ws.title = '在途采购'
    headers = ['采购单号', '物料编码', '物料名称', '在途数量', '预计到货日']
    ws.append(headers)
    for r in IN_TRANSIT:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '01-input', '在途采购订单.xlsx'))
    print('[OK] 在途采购订单.xlsx')


def write_safety():
    wb = Workbook()
    ws = wb.active
    ws.title = '安全库存规则'
    headers = ['物料编码', '物料名称', '安全库存', '损耗率%']
    ws.append(headers)
    for r in SAFETY:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '01-input', '安全库存规则.xlsx'))
    print('[OK] 安全库存规则.xlsx')


def write_leadtime():
    wb = Workbook()
    ws = wb.active
    ws.title = '供应商提前期'
    headers = ['物料编码', '物料名称', '默认供应商', '提前期天数']
    ws.append(headers)
    for r in LEADTIME:
        ws.append(list(r))
    wb.save(os.path.join(ROOT, '01-input', '供应商提前期表.xlsx'))
    print('[OK] 供应商提前期表.xlsx')


if __name__ == '__main__':
    write_mps()
    write_bom()
    write_stock()
    write_intransit()
    write_safety()
    write_leadtime()
    print('\n全部输入素材生成完毕。')
