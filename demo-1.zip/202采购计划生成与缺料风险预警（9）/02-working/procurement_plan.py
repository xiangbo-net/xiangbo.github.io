# -*- coding: utf-8 -*-
"""
案例9《采购计划生成与缺料风险预警》核心推演程序
================================================
功能（业务推演链路）：
  ① 读取未来 14 天生产计划（MPS）
  ② 展开 BOM → 逐物料累计毛需求
  ③ 扣减：现有库存 + 在途采购（预计到货日前的）
  ④ 补齐：加损耗率 + 安全库存
  ⑤ 计算净需求
  ⑥ 结合供应商提前期 → 建议下单日期
  ⑦ 标记：最早缺料日、影响工单、缺料风险等级
  ⑧ 输出 3 个交付物到 03-output/：
      未来14天采购计划建议.xlsx
      缺料风险清单.xlsx
      采购计划工作台账.xlsx
  ⑨ 补充输出 看板.html
"""
import os

from datetime import datetime, date, timedelta

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

# ============================================================
# ★ 可调设置区（员工提修改需求只改这里，不要动下方核心逻辑）★
# ============================================================
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BATCH_NO = '2026-08-06'         # 批次/基准日（可改）
PROCESSOR = '计划员'            # 默认处理人（可改）
BASE_DATE = '2026-08-06'       # 基准日（可改）
PLAN_DAYS = 14                 # 计划天数（可改）

# 1) 风险阈值（可改）
HIGH_DAYS = 3                  # 最早缺料日 ≤ 3 天 → 高风险
MID_DAYS = 7                   # 最早缺料日 ≤ 7 天 → 中风险
URGENT_LEAD = 0                # 建议下单日期晚于最早缺料日 → 紧急（0=启用）

# 2) 行颜色（十六进制色号，不带 #，可改）—— 4 状态 4 色：正常绿/低黄/中橙/高深红
COLOR_PASS = 'E2EFDA'          # 正常：浅绿
COLOR_LOW = 'FFF2CC'            # 低风险：浅黄
COLOR_MID = 'F8CBAD'            # 中风险：浅橙
COLOR_HIGH = 'FFC7CE'           # 高风险：浅红（区别于中风险）

# 3) 状态标签（可改）
LABEL_HIGH = '高风险'
LABEL_MID = '中风险'
LABEL_LOW = '低风险'
LABEL_OK = '正常'

# 状态 → 填充色 映射（xlsx 与 HTML 看板共用，4 状态 4 色）
STATUS_FILL = {
    LABEL_OK: 'E2EFDA',         # 正常：浅绿
    LABEL_LOW: 'FFF2CC',        # 低风险：浅黄
    LABEL_MID: 'F8CBAD',        # 中风险：浅橙
    LABEL_HIGH: 'FFC7CE',       # 高风险：浅红（区别于中风险）
}
STATUS_FONT = {
    LABEL_OK: '375623',         # 深绿
    LABEL_LOW: '7F6000',        # 深黄
    LABEL_MID: '833C00',        # 深橙
    LABEL_HIGH: '9C0006',       # 深红（区别于中风险）
}

# 4) 功能开关（True=启用 / False=关闭，可改）
ENABLE_BOM_EXPAND = True       # BOM 展开
ENABLE_STOCK_DEDUCT = True     # 库存扣减
ENABLE_INTRANSIT = True        # 在途扣减
ENABLE_SAFETY = True           # 安全库存+损耗
ENABLE_LEADTIME = True         # 提前期下单日
ENABLE_RISK = True             # 缺料风险分级

# ============================================================
# 样式常量（由上方可调设置生成，一般无需改动）
# ============================================================
HEADER_FILL = PatternFill('solid', fgColor='1F4E79')
HEADER_FONT = Font(bold=True, color='FFFFFF')
FILL_MAP = {st: PatternFill('solid', fgColor=hexc) for st, hexc in STATUS_FILL.items()}
FONT_MAP = {st: Font(color=hexc) for st, hexc in STATUS_FONT.items()}
THIN = Side(style='thin', color='B0B0B0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# ---------- 路径常量 ----------
P_MPS = f'{ROOT}/01-input/生产计划_MPS_未来14天.xlsx'
P_BOM = f'{ROOT}/01-input/BOM_产品用量表.xlsx'
P_STOCK = f'{ROOT}/01-input/库存台账_实时库存.xlsx'
P_INT = f'{ROOT}/01-input/在途采购订单.xlsx'
P_SAFETY = f'{ROOT}/01-input/安全库存规则.xlsx'
P_LEAD = f'{ROOT}/01-input/供应商提前期表.xlsx'
P_OUT_PLAN = f'{ROOT}/03-output/未来14天采购计划建议.xlsx'
P_OUT_RISK = f'{ROOT}/03-output/缺料风险清单.xlsx'
P_OUT_WORK = f'{ROOT}/03-output/采购计划工作台账.xlsx'
P_OUT_BOARD = f'{ROOT}/03-output/缺料风险看板.html'
P_OUT_NOTICE = f'{ROOT}/03-output/企业微信通知草稿.txt'


def read_rows(path):
    """读取 xlsx 全部行。健壮性：文件缺失时返回空并提示（不崩溃）。"""
    if not os.path.exists(path):
        print(f'[兜底-提示] 文件不存在，按空处理: {path}')
        return [], []
    wb = load_workbook(path)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        return [], []
    return list(rows[0]), list(rows[1:])


def parse_date(s):
    try:
        return datetime.strptime(str(s).strip(), '%Y-%m-%d').date()
    except ValueError:
        return None


def style_sheet(ws, widths=None):
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = BORDER
    if widths:
        for col, w in widths.items():
            ws.column_dimensions[col].width = w


def color_rows(ws, status_col, ncols):
    """按状态列给整行上色。"""
    for row_idx in range(2, ws.max_row + 1):
        st_raw = str(ws.cell(row=row_idx, column=status_col).value)
        st_key = next((k for k in STATUS_FILL if k in st_raw), None)
        fill = FILL_MAP.get(st_key, PatternFill('solid', fgColor='FFFFFF'))
        font = FONT_MAP.get(st_key)
        for c in range(1, ncols + 1):
            cell = ws.cell(row=row_idx, column=c)
            cell.fill = fill
            if font:
                cell.font = font


def main():
    print(f'[批次] {BATCH_NO} 采购计划推演开始（基准日 {BASE_DATE}）...')
    base = parse_date(BASE_DATE) or date.today()

    # 1. 加载数据
    hm, mps_rows = read_rows(P_MPS)
    hb, bom_rows = read_rows(P_BOM)
    hs, s_rows = read_rows(P_STOCK)
    hi, i_rows = read_rows(P_INT)
    hf, f_rows = read_rows(P_SAFETY)
    hl, l_rows = read_rows(P_LEAD)
    print(f'[读取] 生产计划 {len(mps_rows)} | BOM {len(bom_rows)} | 库存 {len(s_rows)} | 在途 {len(i_rows)} | 规则 {len(f_rows)} | 提前期 {len(l_rows)}')

    # 2. 组织数据
    stock_map = {str(r[0]).strip(): float(r[2]) if r[2] is not None else 0 for r in s_rows if r and r[0]}
    intransit_map = {}   # 物料 -> [(在途数量, 预计到货日)]
    for r in i_rows:
        if r and r[0]:
            mat = str(r[1]).strip() if r[1] else ''
            qty = float(r[3]) if len(r) > 3 and r[3] is not None else 0
            eta = parse_date(r[4]) if len(r) > 4 else None
            intransit_map.setdefault(mat, []).append((qty, eta))
    safety_map = {str(r[0]).strip(): (float(r[2]) if len(r) > 2 and r[2] is not None else 0,
                                      float(r[3]) if len(r) > 3 and r[3] is not None else 0)
                  for r in f_rows if r and r[0]}
    lead_map = {str(r[0]).strip(): (str(r[2]).strip() if len(r) > 2 and r[2] else '',
                                    int(r[3]) if len(r) > 3 and r[3] is not None else 0)
                for r in l_rows if r and r[0]}

    # 3. BOM 展开 → 毛需求（按物料汇总未来 14 天）
    mat_names = {}
    gross_map = {}   # 物料 -> 毛需求
    affected_wo = {}  # 物料 -> 影响工单（产品名）
    for r in mps_rows:
        if not r or not r[0]:
            continue
        prod_code = str(r[0]).strip()
        prod_name = str(r[1]).strip() if r[1] else prod_code
        plan_date = parse_date(r[2])
        qty = float(r[3]) if r[3] is not None else 0
        if plan_date is None or plan_date < base or plan_date > base + timedelta(days=PLAN_DAYS):
            continue
        for br in bom_rows:
            if not br or not br[0]:
                continue
            parent = str(br[0]).strip()
            if parent != prod_code:
                continue
            mat_code = str(br[2]).strip() if br[2] else ''
            mat_name = str(br[3]).strip() if br[3] else ''
            usage = float(br[4]) if len(br) > 4 and br[4] is not None else 0
            gross_map[mat_code] = gross_map.get(mat_code, 0) + qty * usage
            mat_names[mat_code] = mat_name
            affected_wo.setdefault(mat_code, set()).add(prod_name)

    # 4. 逐物料计算净需求
    plan_rows = []
    risk_rows = []
    work_rows = []
    stat = {LABEL_OK: 0, LABEL_LOW: 0, LABEL_MID: 0, LABEL_HIGH: 0}

    for mat_code, gross in sorted(gross_map.items()):
        mat_name = mat_names.get(mat_code, '')
        cur_stock = stock_map.get(mat_code, 0)
        safety, loss = safety_map.get(mat_code, (0, 0))
        supplier, lead_days = lead_map.get(mat_code, ('', 0))

        # 在途（预计到货日 ≤ 最早缺料日 或 14 天内到货的都算可用）
        intransit_total = 0
        intransit_detail = []
        for qty, eta in intransit_map.get(mat_code, []):
            if eta and eta <= base + timedelta(days=PLAN_DAYS):
                intransit_total += qty
                intransit_detail.append(f'{qty:.0f}@{eta}')

        # 扣减：毛需求 - 库存 - 在途，再补安全库存
        deduct = (cur_stock + intransit_total) if ENABLE_STOCK_DEDUCT else 0
        net_needed = max(0, gross - deduct)
        # 安全库存补齐 + 损耗
        if ENABLE_SAFETY:
            net_needed = max(net_needed, safety)  # 保证有安全库存
            net_needed += gross * loss / 100.0
        net_needed = round(max(0, net_needed))

        # 最早缺料日：按日均消耗反推库存耗尽日
        daily_use = gross / PLAN_DAYS if PLAN_DAYS > 0 else 0
        if daily_use <= 0:
            first_short_date = None
        else:
            days_cover = (cur_stock + intransit_total - safety) / daily_use
            short_offset = int(days_cover) + 1
            first_short_date = base + timedelta(days=short_offset)

        # 建议下单日期 = 最早缺料日 - 提前期
        order_date = None
        urgent = False
        if ENABLE_LEADTIME and first_short_date and lead_days > 0:
            order_date = first_short_date - timedelta(days=lead_days)
            if order_date < base:
                order_date = base  # 最晚今天下单
            if first_short_date - timedelta(days=lead_days) < base:
                urgent = True

        # 风险分级
        if ENABLE_RISK:
            if net_needed <= 0:
                level = LABEL_OK
            elif first_short_date is None:
                level = LABEL_OK
            elif urgent or (first_short_date - base).days <= HIGH_DAYS:
                level = LABEL_HIGH
            elif (first_short_date - base).days <= MID_DAYS:
                level = LABEL_MID
            else:
                level = LABEL_LOW
        else:
            level = LABEL_OK
        stat[level] += 1

        # 采购计划建议行（有净需求才建议采购）
        plan_rows.append({
            '物料编码': mat_code, '物料名称': mat_name, '毛需求': round(gross),
            '现有库存': cur_stock, '在途数量': intransit_total, '安全库存': safety,
            '损耗率%': loss, '净需求': net_needed, '默认供应商': supplier,
            '提前期天数': lead_days, '建议下单日期': str(order_date) if order_date else '—',
            '最早缺料日': str(first_short_date) if first_short_date else '—',
            '风险等级': level,
        })
        # 缺料风险行（净需求 > 0 的）
        if net_needed > 0:
            risk_rows.append({
                '物料编码': mat_code, '物料名称': mat_name, '净需求': net_needed,
                '最早缺料日': str(first_short_date) if first_short_date else '—',
                '建议下单日期': str(order_date) if order_date else '—',
                '影响工单': '、'.join(sorted(affected_wo.get(mat_code, set()))),
                '风险等级': level,
                '建议动作': '立即下单加急' if level == LABEL_HIGH else (
                    '本周内下单' if level == LABEL_MID else '下周内下单'),
            })
        # 工作台账
        work_rows.append({
            '批次号': BATCH_NO, '物料编码': mat_code, '物料名称': mat_name,
            '毛需求': round(gross), '可用库存(含在途)': deduct,
            '净需求': net_needed, '最早缺料日': str(first_short_date) if first_short_date else '—',
            '建议下单日期': str(order_date) if order_date else '—',
            '风险等级': level,
            '分析时间': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            '分析人': PROCESSOR, '复核状态': '需人工确认' if net_needed > 0 else '已确认',
        })

    print(f'[推演] 物料 {len(gross_map)} 个 | 正常 {stat[LABEL_OK]} / 低风险 {stat[LABEL_LOW]} / 中风险 {stat[LABEL_MID]} / 高风险 {stat[LABEL_HIGH]}')

    # 5. 输出 1：未来14天采购计划建议.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '采购计划建议'
    h = ['物料编码', '物料名称', '毛需求', '现有库存', '在途数量', '安全库存', '损耗率%',
         '净需求', '默认供应商', '提前期天数', '建议下单日期', '最早缺料日', '风险等级']
    ws.append(h)
    for r in plan_rows:
        ws.append([r[k] for k in h])
    style_sheet(ws, {'A': 12, 'B': 18, 'C': 10, 'D': 10, 'E': 10, 'F': 10, 'G': 8,
                     'H': 10, 'I': 20, 'J': 10, 'K': 14, 'L': 14, 'M': 10})
    color_rows(ws, 13, len(h))
    wb.save(P_OUT_PLAN)
    print(f'[OK] 未来14天采购计划建议.xlsx（{len(plan_rows)} 行）')

    # 6. 输出 2：缺料风险清单.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '缺料风险清单'
    h2 = ['物料编码', '物料名称', '净需求', '最早缺料日', '建议下单日期', '影响工单', '风险等级', '建议动作']
    ws.append(h2)
    for r in risk_rows:
        ws.append([r[k] for k in h2])
    style_sheet(ws, {'A': 12, 'B': 18, 'C': 10, 'D': 14, 'E': 14, 'F': 20, 'G': 10, 'H': 16})
    color_rows(ws, 7, len(h2))
    wb.save(P_OUT_RISK)
    print(f'[OK] 缺料风险清单.xlsx（{len(risk_rows)} 条）')

    # 7. 输出 3：采购计划工作台账.xlsx
    wb = Workbook()
    ws = wb.active
    ws.title = '采购计划工作台账'
    h3 = ['批次号', '物料编码', '物料名称', '毛需求', '可用库存(含在途)', '净需求',
          '最早缺料日', '建议下单日期', '风险等级', '分析时间', '分析人', '复核状态']
    ws.append(h3)
    for r in work_rows:
        ws.append([r[k] for k in h3])
    style_sheet(ws, {'A': 12, 'B': 12, 'C': 18, 'D': 10, 'E': 16, 'F': 10,
                     'G': 14, 'H': 14, 'I': 10, 'J': 18, 'K': 10, 'L': 12})
    color_rows(ws, 9, len(h3))
    wb.save(P_OUT_WORK)
    print(f'[OK] 采购计划工作台账.xlsx（{len(work_rows)} 行）')

    # 8. 输出 4：缺料风险看板.html（含横向滚动，状态色板同规范）
    STATUS_CLS = {LABEL_OK: 'row-pass', LABEL_LOW: 'row-pending', LABEL_MID: 'row-dup', LABEL_HIGH: 'row-high'}
    risk_html = ''
    for r in sorted(risk_rows, key=lambda x: (x['风险等级'] != LABEL_HIGH, x['风险等级'] != LABEL_MID)):
        cls = STATUS_CLS.get(r['风险等级'], 'row-pass')
        risk_html += (f"<tr class='{cls}'><td>{r['物料编码']}</td><td>{r['物料名称']}</td>"
                      f"<td>{r['净需求']:.0f}</td><td>{r['最早缺料日']}</td><td>{r['建议下单日期']}</td>"
                      f"<td>{r['影响工单']}</td><td>{r['风险等级']}</td><td>{r['建议动作']}</td></tr>")
    board = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>缺料风险看板 - {BATCH_NO}</title>
<style>
body{{font-family:'Microsoft YaHei',sans-serif;background:#f5f6fa;margin:0;padding:24px;color:#222}}
h1{{font-size:22px}} .cards{{display:flex;gap:16px;flex-wrap:wrap;margin:20px 0}}
.card{{background:#fff;border-radius:10px;padding:18px 22px;min-width:140px;box-shadow:0 1px 4px rgba(0,0,0,.08)}}
.card .num{{font-size:30px;font-weight:bold}} .card .lbl{{color:#888;font-size:13px;margin-top:4px}}
.red{{color:#C00000}} .orange{{color:#ED7D31}} .yellow{{color:#BF9000}} .green{{color:#548235}}
.table-wrap{{overflow-x:auto;-webkit-overflow-scrolling:touch;background:#fff;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:20px}}
.table-wrap table{{border-collapse:collapse;width:100%;min-width:760px;table-layout:auto}}
th,td{{padding:10px 12px;text-align:left;border-bottom:1px solid #eee;font-size:13px;white-space:normal;word-break:break-word}}
th{{background:#1F4E79;color:#fff}}
tr.row-pass td{{background:#E2EFDA;color:#375623}}
tr.row-pending td{{background:#FFF2CC;color:#7F6000}}
tr.row-dup td{{background:#F8CBAD;color:#833C00}}
tr.row-high td{{background:#FFC7CE;color:#9C0006;font-weight:bold}}
</style></head><body>
<h1>缺料风险看板 · {BATCH_NO}</h1>
<div class="cards">
<div class="card"><div class="num">{len(gross_map)}</div><div class="lbl">物料数</div></div>
<div class="card"><div class="num green">{stat[LABEL_OK]}</div><div class="lbl">正常</div></div>
<div class="card"><div class="num yellow">{stat[LABEL_LOW]}</div><div class="lbl">低风险</div></div>
<div class="card"><div class="num orange">{stat[LABEL_MID]}</div><div class="lbl">中风险</div></div>
<div class="card"><div class="num red">{stat[LABEL_HIGH]}</div><div class="lbl">高风险</div></div>
</div>
<h3>缺料风险清单（按风险排序）</h3>
<div class="table-wrap"><table><tr><th>物料编码</th><th>物料名称</th><th>净需求</th><th>最早缺料日</th><th>建议下单日期</th><th>影响工单</th><th>风险等级</th><th>建议动作</th></tr>
{risk_html}
</table></div></body></html>"""
    with open(P_OUT_BOARD, 'w', encoding='utf-8') as f:
        f.write(board)
    print('[OK] 缺料风险看板.html')

    # 9. 汇总
    print('\n===== 批次汇总 =====')
    print(f'物料: {len(gross_map)} | 正常: {stat[LABEL_OK]} | 低: {stat[LABEL_LOW]} | 中: {stat[LABEL_MID]} | 高: {stat[LABEL_HIGH]}')
    high_mats = [r['物料名称'] for r in risk_rows if r['风险等级'] == LABEL_HIGH]
    if high_mats:
        print(f'高风险物料: {"、".join(high_mats)}')
        first = min(r['最早缺料日'] for r in risk_rows if r['风险等级'] == LABEL_HIGH)
        print(f'最早缺料日: {first}')

    # 10. 企业微信通知草稿.txt（脚本自动生成，AI 检测绑定后决定发送或告知草稿）
    # （5.0.10 起企微消息能力已全面开放（不限企业规模），AI 可直接发送；发送失败时草稿兜底）
    n_lines = ['【缺料风险预警通知】',
               f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}',
               f'物料 {len(gross_map)} 个：正常 {stat[LABEL_OK]} / 低 {stat[LABEL_LOW]} / 中 {stat[LABEL_MID]} / 高 {stat[LABEL_HIGH]}']
    if high_mats:
        n_lines.append(f'高风险物料（{len(high_mats)}）：{"、".join(high_mats)}')
        n_lines.append(f'最早缺料日：{first}')
    mid_mats = [r['物料名称'] for r in risk_rows if r['风险等级'] == LABEL_MID]
    if mid_mats:
        n_lines.append(f'中风险物料（{len(mid_mats)}）：{"、".join(mid_mats)}')
    wo_set = sorted({r['影响工单'] for r in risk_rows if r.get('影响工单')})
    if wo_set:
        n_lines.append(f'影响工单：{"、".join(wo_set)}')
    n_lines.append('建议采购动作：高风险物料立即下单加急，采购计划需采购和计划人员确认后执行。')
    n_lines.append('提示：本通知为推演提醒，不自动下单。')
    with open(P_OUT_NOTICE, 'w', encoding='utf-8') as f:
        f.write('\n'.join(n_lines))

    print(f'[OK] 企业微信通知草稿.txt（高风险 {stat[LABEL_HIGH]} / 最早缺料 {first if high_mats else "无"}）')


if __name__ == '__main__':
    main()
