#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
发票批量识别与报销初审 - PDF解析 + 图片OCR 并行，合并交叉对比 + 异常标注 + 输出生成
========================================================================
【识别架构：PDF解析 + 图片OCR 并行】（用户确认的方案）
  方式一（PDF解析）：01-input/发票文件/*.pdf → 直接读取 PDF 文本层解析（pdfplumber）
  方式二（图片OCR）：01-input/发票图片_OCR/*.{图片} → 直接 OCR 识别（ocr-local skill，结果在 ocr_results.json）
  两种方式并行提取字段，按发票号码合并到一张表，同一张票两种方式的值交叉对比，
  不一致字段标记"低置信度"风险；与历史台账比对标记"疑似重复"；
  与公司基准比对标记"抬头异常"。

输入：
  1. 01-input/发票文件/*.pdf             - PDF 发票源文件（方式一：直接解析）
  2. 01-input/发票图片_OCR/*.{png,jpg}   - 发票图片（方式二：OCR 识别）
  3. 02-working/ocr_results.json         - 本地 OCR 识别结果（方式二产出）
  4. 01-input/公司抬头与税号.txt         - 购买方抬头与税号比对基准
  5. 04-archive/历史发票台账.xlsx        - 历史发票台账（检测疑似重复）

输出：
  1. 03-output/发票OCR结构化结果.xlsx    - PDF解析与OCR结果合并的结构化明细（含异常高亮）
  2. 03-output/发票初审异常清单.xlsx     - 异常项清单（低置信度/重复/抬头异常）
  3. 03-output/发票识别工作台账.xlsx     - 批次工作台账（批次/处理人/复核状态）
  4. 03-output/企业微信通知草稿.txt      - 企业微信通知草稿

核心逻辑说明：
  - 两种方式各自独立解析字段 → 以发票号码关联合并
  - 同一张票两种方式都有结果：字段级交叉对比，不一致 → 低置信度
  - 只有一种方式有结果：直接采用该方式结果（数据来源列标注方式）
  - 数字/税号/日期字段精确匹配（SequenceMatcher 会把 29.33 与 329.33 误判一致）
"""
import json

import re
import sys
import os
from datetime import datetime
from difflib import SequenceMatcher

import pdfplumber
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

sys.stdout.reconfigure(encoding='utf-8')

# ---------- 路径常量 ----------
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DIR_PDF = f'{ROOT}/01-input/发票文件'            # 方式一：PDF 发票源文件
DIR_IMG = f'{ROOT}/01-input/发票图片_OCR'         # 方式二：发票图片
PATH_OCR_JSON = f'{ROOT}/02-working/ocr_results.json'
PATH_TITLE_TXT = f'{ROOT}/01-input/公司抬头与税号.txt'
PATH_ARCHIVE = f'{ROOT}/04-archive/历史发票台账.xlsx'
PATH_OUT1 = f'{ROOT}/03-output/发票OCR结构化结果.xlsx'
PATH_OUT2 = f'{ROOT}/03-output/发票初审异常清单.xlsx'
PATH_OUT3 = f'{ROOT}/03-output/发票识别工作台账.xlsx'
PATH_NOTICE = f'{ROOT}/03-output/企业微信通知草稿.txt'

# ============================================================
# ★ 可调常量区（员工提修改需求只改这里，不要动下方核心逻辑）★
# ============================================================
BATCH_NO = '2026-08'          # 批次号（对应报销月份，可改）
PROCESSOR = '财务助理'          # 默认处理人（可改）

# 1) 行颜色（十六进制色号，不带 #，可改）
COLOR_NORMAL = 'FFFFFF'        # 正常：白
COLOR_LOW_CONF = 'FFF2CC'      # 低置信度：浅黄
COLOR_DUPLICATE = 'FCE4D6'     # 疑似重复：浅橙
COLOR_HEADER_ABN = 'C00000'    # 抬头异常：深红

# 2) 复核标签（出现在"人工复核"列，可改）
LABEL_PASS = '通过'            # 正常票的复核状态
LABEL_REVIEW = '需复核'        # 异常票的复核状态
LABEL_PENDING = '待复核'       # 异常清单中的初始复核状态

# 3) 功能开关（True=启用 / False=关闭，可改）
ENABLE_LOW_CONF_CHECK = True   # 低置信度检测（两种方式读出的结果不一致）
ENABLE_DUP_CHECK = True        # 疑似重复检测（发票号码在历史台账中已存在）
ENABLE_HEADER_CHECK = True     # 抬头异常检测（购买方与公司基准不一致）
ENABLE_DEMO_ARCHIVE = True     # 历史台账缺失时，自动建演示台账（模拟"疑似重复"效果）

# 4) 识别结果标签（"识别结果"列的取值，可改）
LABEL_NORMAL = '正常'          # 无任何异常
LABEL_LOW_CONF = '低置信度'     # 两种方式读出的结果不一致
LABEL_DUPLICATE = '疑似重复'    # 历史台账已存在该发票号码
LABEL_HEADER_ABN = '抬头异常'   # 购买方名称/税号与公司基准不一致

# 5) 公司基准默认值（01-input/公司抬头与税号.txt 缺失或未设置时使用；可改）
DEFAULT_BASE_NAME = '深圳流诚动力科技有限公司'
DEFAULT_BASE_TAX = '91440300MAEM33TH0G'

# ============================================================
# 样式常量（由上方可调常量生成，一般无需改动）
# ============================================================
HEADER_FILL = PatternFill('solid', fgColor='1F4E79')     # 深蓝表头
HEADER_FONT = Font(bold=True, color='FFFFFF')
LOW_CONF_FILL = PatternFill('solid', fgColor=COLOR_LOW_CONF)   # 浅黄：低置信度
DUPLICATE_FILL = PatternFill('solid', fgColor=COLOR_DUPLICATE)  # 浅橙：疑似重复
HEADER_ABN_FILL = PatternFill('solid', fgColor=COLOR_HEADER_ABN) # 深红：抬头异常
ABN_FONT = Font(bold=True, color='FFFFFF')
THIN = Side(style='thin', color='B0B0B0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# 提取的核心字段（10 项）
FIELDS = ['发票号码', '开票日期', '发票类型', '购买方名称', '购买方税号',
          '销售方名称', '销售方税号', '金额', '税额', '价税合计']

# 需精确匹配的字段（数字/代码类，模糊相似度会误判，如 29.33 vs 329.33）
EXACT_FIELDS = {'发票号码', '购买方税号', '销售方税号', '金额', '税额', '价税合计', '开票日期'}


def style_sheet(ws, widths=None):
    """设置表头样式、边框与列宽。"""
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = BORDER
    if widths:
        for col, w in widths.items():
            ws.column_dimensions[col].width = w


# ============================================================
# 一、方式一：PDF 文本层直接解析
# ============================================================
# 公司名称常见结尾词（用于名称清洗：去除竖排杂质）
ENDS = ('有限公司', '有限责任公司', '股份有限公司', '公司', '集团', '贸易',
        '餐馆', '饭店', '酒店', '工作室', '商店', '中心')


def clip_name(name):
    """名称块清洗：去空格后，若不以常见结尾词收尾则截断到最靠后的结尾词。"""
    name = re.sub(r'[\s*#x\uff0a|]', '', name or '')
    name = name.replace('《', '（').replace('》', '）')  # 归一：OCR/防伪字体把全角括号识别成书名号
    if any(name.endswith(e) for e in ENDS):
        return name
    best = -1
    for e in ENDS:
        idx = name.rfind(e)
        if idx != -1:
            best = max(best, idx + len(e))
    return name[:best] if best > 0 else name


def extract_pdf_fields(pdf_path):
    """方式一：从电子发票 PDF 文本层直接提取字段。"""
    with pdfplumber.open(pdf_path) as pdf:
        txt = '\n'.join(p.extract_text() or '' for p in pdf.pages)

    def clean(s):
        s = re.sub(r'\s+', '', s or '')
        return s.replace('《', '（').replace('》', '）')  # 归一：防伪字体/OCR 把全角括号识别成书名号

    # 数电发票防伪字体存在字符重复（如"发发发票票票号号号码码码"），先压缩重复字符
    # 注意：仅压缩非数字重复，避免误伤发票号码中的连续数字（如 0000）
    txt_compressed = re.sub(r'([^\d])\1{2,}', r'\1', txt)

    m = re.search(r'发票号码[:：]+\s*([0-9]{15,25})', txt_compressed)
    m_date = re.search(r'开票日期[:：]+\s*(\d{4})年(\d{1,2})月(\d{1,2})日', txt_compressed)
    # 名称：提取全部"名称"后的词段，取第一个非表头词段为购买方、第二个为销售方
    # 兼容两种版式：a) "名称：深圳流诚..."（冒号）；b) "买 名 称 深圳流诚..."（无冒号）
    name_blocks = re.findall(r'名\s*称\s*[:：]?\s*([^\s]+)', txt_compressed)
    header_words = ('规格', '型号', '单位', '数量', '单价', '金额', '税率', '征收率', '税额', '项目名称', '单')
    names = []
    for nb in name_blocks:
        if not any(nb.startswith(w) for w in header_words):
            names.append(nb)
    m_buyer_name = names[0] if names else ''
    m_seller_name = names[1] if len(names) > 1 else ''
    # 税号：兼容"统一社会信用代码/纳税人识别号: xxx"与竖排拆分"统一社会信用代码 纳税人识别号 / : xxx"
    m_tax = re.findall(r'(?:统一社会信用代码|纳税人识别号)[/／]?\s*[:：]?\s*([0-9A-Za-z]{15,22})', txt_compressed)
    m_type = re.search(r'(电子发票[（(][^）)]+[）)])', txt_compressed)
    # 金额行：合计（大写/小写括号兼容全半角；跨行用 re.S）
    m_total = re.search(r'价税合计[（(]大写[)）]\s*(.*?)\s*[（(]小写[)）]\s*[¥￥]?\s*([0-9,]+\.\d{2})',
                        txt_compressed, re.S)
    # 金额/税额：取"合 计"行
    m_amt = re.search(r'合\s*计\s*[¥￥]?\s*([0-9,]+\.\d{2})\s*[¥￥]?\s*([0-9,]+\.\d{2})', txt_compressed)

    fields = {
        '发票号码': clean(m.group(1)) if m else '',
        '开票日期': f'{m_date.group(1)}-{m_date.group(2).zfill(2)}-{m_date.group(3).zfill(2)}' if m_date else '',
        '发票类型': clean(m_type.group(1)) if m_type else '电子发票（普通发票）',
        '购买方名称': clip_name(m_buyer_name),
        '购买方税号': clean(m_tax[0]) if len(m_tax) > 0 else '',
        '销售方名称': clip_name(m_seller_name),
        '销售方税号': clean(m_tax[1]) if len(m_tax) > 1 else '',
        '金额': m_amt.group(1).replace(',', '') if m_amt else '',
        '税额': m_amt.group(2).replace(',', '') if m_amt else '',
        '价税合计': m_total.group(2).replace(',', '') if m_total else '',
    }
    return fields


# ============================================================
# 二、方式二：图片 OCR 字段提取（从 ocr_results.json 读取）
# ============================================================
def extract_ocr_fields(ocr_text):
    """方式二：从 OCR 结果文本提取字段（宽松正则 + 清洗）。

    要点：
    - 数电发票 OCR 后文字间常带空格、购/销方向标签可能被误识
    - 名称定位：取"名称"后首个非空字段块，过滤表格表头（规格/型号/单位/数量）
    - 税号定位：以"识别号"前缀锚定，避免与 20 位发票号码混淆
    - 金额类：允许数字与小数点间带空格（如 "2000. 00"）
    """
    t = ocr_text or ''

    def clean(s):
        s = re.sub(r'[\s*#x\uff0a|]', '', s or '')
        return s.replace('《', '（').replace('》', '）')  # 归一：OCR 把全角括号识别成书名号

    def skip_header(name):
        """过滤表头干扰（项目名称/规格型号等）。"""
        bad = ('规格', '型号', '单位', '数量', '单价', '金额', '税率', '征收率', '税额', '项目名称')
        return any(b in name for b in bad)

    m = re.search(r'发\s*票\s*号\s*码\s*[:：]?\s*([0-9]{15,25})', t)
    m_date = re.search(r'开\s*[票标枝]\s*日\s*期\s*[:：]?\s*(\d{4})\s*年\s*(\d{1,2})\s*月\s*(\d{1,2})\s*日', t)
    # 发票类型：OCR 常将"票"误识为"标/RAY"等，且"发"前可能有杂字符，宽泛匹配"电子...发...票"
    m_type = re.search(r'电\s*子\s*[^\n]{0,4}发\s*[^\n]{0,4}[票标]', t)
    if not m_type:
        m_type = re.search(r'电\s*子\s*发\s*[^\s]{0,4}', t)
    if not m_type:
        m_type = re.search(r'(电子\s*发\s*[票标])', t)
    # 名称：以"名称"为分隔切分（不依赖购/销方向词，因 OCR 对方向词误识严重：
    #       购→遇/加/有/同，销→稍/全/二/攻），每段取"名称"后内容
    name_segments = re.split(r'名\s*称', t)
    name_blocks = []
    for seg in name_segments[1:]:
        m_seg = re.match(r'\s*[:：]?\s*([^\n|]+)', seg)
        if m_seg:
            name_blocks.append(m_seg.group(1))
    names = [clip_name(b) for b in name_blocks if not skip_header(clean(b))]
    buyer = names[0] if names else ''
    seller = names[1] if len(names) > 1 else ''
    # 税号：以"识别号/识别弛"前缀锚定（OCR 常将"号"误识为"弛"），数字间允许空格
    taxes = re.findall(r'识别\s*(?:号|弛)\s*[:：]?\s*([0-9A-Za-z][0-9A-Za-z ]{14,23})', t)
    tax_clean = [clean(x) for x in taxes]
    # 金额/税额：合计行（OCR 常将"合"误识为"可/企"；税额可能仅 1-2 位小数；
    #             电信服务等发票合计行可能只有单金额"合 计 ¥12.10"）
    m_amt = re.search(r'(?:合|可|企)\s*计\s*[¥￥尘苦对区Yy于]?\s*([0-9]+\.\s*[0-9]{1,2})(?:\s*[¥￥尘苦对区Yy]?\s*([0-9]+\.\s*[0-9]{1,2}))?', t)
    # 价税合计：小写金额行（括号兼容全半角及《》误识）
    m_total = re.search(r'价\s*税\s*合\s*计.*?[（(《]\s*小\s*写\s*[)）》]\s*[¥￥对史]?\s*([0-9]+\.\s*[0-9]{2})', t)
    if not m_total:
        m_total = re.search(r'[（(《]\s*小\s*写\s*[)）》]\s*[¥￥对史]?\s*([0-9]+\.\s*[0-9]{2})', t)

    def num(v):
        return re.sub(r'\s+', '', v or '')

    fields = {
        '发票号码': clean(m.group(1)) if m else '',
        '开票日期': f'{m_date.group(1)}-{m_date.group(2).zfill(2)}-{m_date.group(3).zfill(2)}' if m_date else '',
        '发票类型': '电子发票（普通发票）' if m_type else '',
        '购买方名称': buyer,
        '购买方税号': tax_clean[0] if tax_clean else '',
        '销售方名称': seller,
        '销售方税号': tax_clean[1] if len(tax_clean) > 1 else '',
        '金额': num(m_amt.group(1)) if m_amt else '',
        '税额': num(m_amt.group(2)) if m_amt else '',
        '价税合计': num(m_total.group(1)) if m_total else '',
    }
    # 兜底：价税合计缺失时用 金额+税额 估算（标记供复核）
    if not fields['价税合计'] and fields['金额'] and fields['税额']:
        try:
            fields['价税合计'] = str(round(float(fields['金额']) + float(fields['税额']), 2))
        except ValueError:
            pass
    return fields


# ============================================================
# 三、字段比对：两种方式的结果值一致性
# ============================================================
def compare_fields(value_a, value_b):
    """比较两个通道的字段值是否一致（a=PDF解析, b=OCR）。"""
    result = {}
    for k in FIELDS:
        va = (value_a or {}).get(k, '')
        vb = (value_b or {}).get(k, '')
        if not va and not vb:
            result[k] = {'a': '', 'b': '', 'match': True, 'ratio': 1.0}
            continue
        if not va or not vb:
            result[k] = {'a': va, 'b': vb, 'match': False, 'ratio': 0.0}
            continue
        if k in EXACT_FIELDS:
            match = (va == vb)
            ratio = 1.0 if match else 0.0
        else:
            ratio = SequenceMatcher(None, va, vb).ratio()
            match = ratio >= 0.9
        result[k] = {'a': va, 'b': vb, 'match': match, 'ratio': round(ratio, 2)}
    return result


# ============================================================
# 四、主流程
# ============================================================
def main():
    # 1. 读比对基准（公司抬头与税号）——兼容旧格式（公司全称/统一社会信用代码）与新格式（本公司抬头/税号）
    if os.path.exists(PATH_TITLE_TXT):
        with open(PATH_TITLE_TXT, encoding='utf-8') as f:
            title_txt = f.read()
        m_name = re.search(r'(?:公司全称|本公司抬头)[:：]\s*(\S+)', title_txt)
        m_tax = re.search(r'(?:统一社会信用代码/纳税人识别号|税号)[:：]\s*([0-9A-Za-z]+)', title_txt)
        base_name = m_name.group(1) if m_name else DEFAULT_BASE_NAME
        base_tax = m_tax.group(1) if m_tax else DEFAULT_BASE_TAX
        print(f'[基准] 读取公司基准: {base_name} / {base_tax}')
    else:
        base_name, base_tax = DEFAULT_BASE_NAME, DEFAULT_BASE_TAX
        print(f'[基准-提示] 01-input/公司抬头与税号.txt 不存在，使用默认抬头: {base_name} / {base_tax}')

    # 2. 读历史台账（取已有发票号码集合）
    hist_invoices = set()
    if os.path.exists(PATH_ARCHIVE):
        hist = load_workbook(PATH_ARCHIVE)
        hist_ws = hist.active
        for row in hist_ws.iter_rows(min_row=2, values_only=True):
            if row[0]:
                hist_invoices.add(str(row[0]).strip())
        hist.close()
    elif ENABLE_DEMO_ARCHIVE:
        print('[台账-提示] 历史台账不存在，演示模式：自动用本批第 1 张发票模拟"疑似重复"')
    else:
        print('[台账-提示] 历史台账不存在且演示开关关闭，跳过疑似重复检测')

    # 3. 方式一：遍历 PDF 文件，直接解析
    pdf_files = [f for f in sorted(os.listdir(DIR_PDF)) if f.lower().endswith('.pdf')]
    channel_a = {}   # {发票号码: {字段: 值, '文件': 文件名}}
    for f in pdf_files:
        path = os.path.join(DIR_PDF, f)
        try:
            fields = extract_pdf_fields(path)
            if fields.get('发票号码'):
                channel_a[fields['发票号码']] = {**fields, '文件': f}
                print(f"[PDF解析] {f} -> 发票号 {fields['发票号码']}")
            else:
                print(f"[PDF解析-警告] {f} 未解析出发票号码，跳过")
        except Exception as e:
            print(f"[PDF解析-失败] {f}: {e}")

    # 4. 方式二：读取 OCR 结果，仅保留与图片目录中实际文件匹配的结果
    img_files = [f for f in sorted(os.listdir(DIR_IMG)) if f.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp'))]
    channel_b = {}   # {发票号码: {字段: 值, '文件': 文件名, '置信度': x}}
    if img_files:
        if os.path.exists(PATH_OCR_JSON):
            with open(PATH_OCR_JSON, encoding='utf-8') as f:
                ocr_results = json.load(f)
            # 仅保留图片目录中真实存在的图片对应的 OCR 结果
            for ocr in ocr_results:
                fname = ocr.get('file', '')
                # 兼容：ocr file 可能是完整文件名或带路径
                base = os.path.basename(fname)
                if base not in img_files:
                    continue
                fields = extract_ocr_fields(ocr.get('text', ''))
                if fields.get('发票号码'):
                    channel_b[fields['发票号码']] = {
                        **fields, '文件': base, '置信度': ocr.get('confidence', 0)}
                    print(f"[图片OCR-识别] {base} -> 发票号 {fields['发票号码']} (置信度 {ocr.get('confidence', 0)}%)")
        else:
            print('[图片OCR-警告] 未找到 ocr_results.json，请先运行 run_ocr_local.js 识别图片')
    else:
        print('[图片OCR-提示] 01-input/发票图片_OCR/ 下暂无图片文件，方式二跳过')

    # 4.5 演示台账：历史台账不存在且开关开启时，用本批第 1 张发票模拟"疑似重复"
    if ENABLE_DEMO_ARCHIVE and not os.path.exists(PATH_ARCHIVE):
        first_id = None
        if channel_a:
            first_id = sorted(channel_a)[0]
        elif channel_b:
            first_id = sorted(channel_b)[0]
        if first_id:
            hist_invoices.add(first_id)
            wb_hist = Workbook()
            ws_hist = wb_hist.active
            ws_hist.title = '历史发票台账'
            ws_hist.append(['发票号码', '开票日期', '发票类型', '购买方名称', '购买方税号',
                            '销售方名称', '金额', '税额', '价税合计', '报销单号', '处理人', '复核状态', '录入时间'])
            ws_hist.append([first_id])
            wb_hist.save(PATH_ARCHIVE)
            print(f'[台账-演示] 已生成演示台账并写入发票号 {first_id}（模拟疑似重复，供演示查看）')

    # 5. 合并两种方式的结果：以发票号码为关联键
    all_invoice_ids = set(channel_a) | set(channel_b)
    rows_detail = []   # 结构化结果表
    rows_abn = []      # 异常清单
    rows_work = []     # 工作台账

    for idx, inv_id in enumerate(sorted(all_invoice_ids), 1):
        va = channel_a.get(inv_id, {})   # 方式一：PDF解析结果
        vb = channel_b.get(inv_id, {})   # 方式二：OCR结果
        cmp = compare_fields(va, vb)

        # 数据来源与取值策略：
        #  两种方式都有 → 以 PDF 解析值为准（权威），OCR 值用于交叉验证
        #  仅 PDF → 直接用 PDF 解析值
        #  仅图片 → 直接用 OCR 值
        if va and vb:
            source = 'PDF解析+OCR'
            pick = lambda k: (va.get(k) or vb.get(k, '')) if cmp[k]['match'] else (va.get(k) or vb.get(k, ''))
            conf = vb.get('置信度', 0)
        elif va:
            source = '仅PDF解析'
            pick = lambda k: va.get(k, '')
            conf = 0
        else:
            source = '仅OCR'
            pick = lambda k: vb.get(k, '')
            conf = vb.get('置信度', 0)

        row = {
            '发票号码': inv_id,
            '开票日期': pick('开票日期'),
            '发票类型': pick('发票类型'),
            '购买方名称': pick('购买方名称'),
            '购买方税号': pick('购买方税号'),
            '销售方名称': pick('销售方名称'),
            '销售方税号': pick('销售方税号'),
            '金额': pick('金额'),
            '税额': pick('税额'),
            '价税合计': pick('价税合计'),
            'OCR置信度': conf,
            '数据来源': source,
            'PDF文件': va.get('文件', ''),
            '图片文件': vb.get('文件', ''),
        }

        # 判定异常
        issues = []
        # a) 低置信度：两种方式都有值但字段不一致（开关控制）
        low_conf_fields = []
        if ENABLE_LOW_CONF_CHECK and va and vb:
            for k in FIELDS:
                item = cmp.get(k)
                if item and not item['match']:
                    low_conf_fields.append(f"{k}(PDF:{item['a'] or '空'}|OCR:{item['b'] or '空'})")
        if low_conf_fields:
            issues.append(LABEL_LOW_CONF)
        # b) 疑似重复：发票号码在历史台账中已存在（开关控制）
        is_dup = ENABLE_DUP_CHECK and (inv_id in hist_invoices)
        if is_dup:
            issues.append(LABEL_DUPLICATE)
        # c) 抬头异常：以 PDF 解析值（或 OCR 值）为准与公司基准比对（开关控制）
        header_name = va.get('购买方名称', '') or vb.get('购买方名称', '')
        header_tax = va.get('购买方税号', '') or vb.get('购买方税号', '')
        header_abn = ENABLE_HEADER_CHECK and ((header_name != base_name) or (header_tax != base_tax))
        if header_abn:
            issues.append(LABEL_HEADER_ABN)
        if not issues:
            issues.append(LABEL_NORMAL)

        row['识别结果'] = '/'.join(issues)
        row['人工复核'] = LABEL_REVIEW if issues != [LABEL_NORMAL] else LABEL_PASS
        rows_detail.append(row)

        # 异常清单行（只列异常项）
        if issues != [LABEL_NORMAL]:
            if low_conf_fields:
                desc = '；'.join(low_conf_fields)
            elif is_dup:
                desc = '历史台账已存在该发票号码'
            else:
                desc = f'购买方名称/税号与公司基准不一致（解析值: {header_name}/{header_tax}）'
            rows_abn.append({
                '发票号码': inv_id,
                '数据来源': source,
                '异常类型': '/'.join([i for i in issues if i != LABEL_NORMAL]),
                '异常说明': desc,
                '涉及字段': ','.join([f.split('(')[0] for f in low_conf_fields]) if low_conf_fields else '',
                'OCR置信度': conf,
                'PDF文件': va.get('文件', ''),
                '图片文件': vb.get('文件', ''),
                '复核状态': LABEL_PENDING,
                '复核人': '',
                '复核意见': '',
            })

        # 工作台账行
        rows_work.append({
            '批次号': BATCH_NO,
            '序号': idx,
            '发票号码': inv_id,
            '数据来源': source,
            '识别时间': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            '处理人': PROCESSOR,
            '异常标记': row['识别结果'],
            '复核状态': row['人工复核'],
            '备注': f"OCR置信度 {conf}%" if conf else '仅PDF解析',
        })

    # ---------- 6. 生成输出 Excel ----------
    # 6.1 发票OCR结构化结果.xlsx
    wb1 = Workbook()
    ws1 = wb1.active
    ws1.title = '发票OCR结构化结果'
    h1 = ['发票号码', '开票日期', '发票类型', '购买方名称', '购买方税号',
          '销售方名称', '销售方税号', '金额', '税额', '价税合计',
          'OCR置信度', '数据来源', 'PDF文件', '图片文件', '识别结果', '人工复核']
    ws1.append(h1)
    for r in rows_detail:
        ws1.append([r[k] for k in h1])
    style_sheet(ws1, {'A': 24, 'B': 14, 'C': 20, 'D': 26, 'E': 22, 'F': 26, 'G': 22,
                      'H': 10, 'I': 10, 'J': 10, 'K': 12, 'L': 14, 'M': 40, 'N': 40,
                      'O': 18, 'P': 10})
    # 高亮：低置信度(浅黄) / 疑似重复(浅橙) / 抬头异常(深红)——颜色取自可调常量区
    for row_idx in range(2, ws1.max_row + 1):
        res = str(ws1.cell(row=row_idx, column=15).value)
        if LABEL_HEADER_ABN in res:
            for c in range(1, 17):
                cell = ws1.cell(row=row_idx, column=c)
                cell.fill = HEADER_ABN_FILL
                cell.font = ABN_FONT
        elif LABEL_DUPLICATE in res:
            for c in range(1, 17):
                ws1.cell(row=row_idx, column=c).fill = DUPLICATE_FILL
        elif LABEL_LOW_CONF in res:
            for c in range(1, 17):
                ws1.cell(row=row_idx, column=c).fill = LOW_CONF_FILL
    wb1.save(PATH_OUT1)
    print(f'[OK] 发票OCR结构化结果.xlsx（{len(rows_detail)} 行）')

    # 6.2 发票初审异常清单.xlsx
    wb2 = Workbook()
    ws2 = wb2.active
    ws2.title = '初审异常清单'
    h2 = ['发票号码', '数据来源', '异常类型', '异常说明', '涉及字段', 'OCR置信度',
          'PDF文件', '图片文件', '复核状态', '复核人', '复核意见']
    ws2.append(h2)
    for r in rows_abn:
        ws2.append([r[k] for k in h2])
    style_sheet(ws2, {'A': 24, 'B': 14, 'C': 20, 'D': 70, 'E': 30, 'F': 12,
                      'G': 40, 'H': 40, 'I': 12, 'J': 12, 'K': 24})
    for row_idx in range(2, ws2.max_row + 1):
        abn_type = str(ws2.cell(row=row_idx, column=3).value)
        fill = LOW_CONF_FILL
        if LABEL_HEADER_ABN in abn_type:
            fill = HEADER_ABN_FILL
        elif LABEL_DUPLICATE in abn_type:
            fill = DUPLICATE_FILL
        for c in range(1, 12):
            cell = ws2.cell(row=row_idx, column=c)
            cell.fill = fill
            if fill == HEADER_ABN_FILL:
                cell.font = ABN_FONT
    wb2.save(PATH_OUT2)
    print(f'[OK] 发票初审异常清单.xlsx（{len(rows_abn)} 行异常）')

    # 6.3 发票识别工作台账.xlsx
    wb3 = Workbook()
    ws3 = wb3.active
    ws3.title = '发票识别工作台账'
    h3 = ['批次号', '序号', '发票号码', '数据来源', '识别时间', '处理人', '异常标记', '复核状态', '备注']
    ws3.append(h3)
    for r in rows_work:
        ws3.append([r[k] for k in h3])
    style_sheet(ws3, {'A': 12, 'B': 6, 'C': 24, 'D': 14, 'E': 22, 'F': 12, 'G': 18, 'H': 12, 'I': 20})
    for row_idx in range(2, ws3.max_row + 1):
        mark = str(ws3.cell(row=row_idx, column=7).value)
        if '抬头异常' in mark:
            for c in range(1, 10):
                ws3.cell(row=row_idx, column=c).fill = HEADER_ABN_FILL
        elif '疑似重复' in mark:
            for c in range(1, 10):
                ws3.cell(row=row_idx, column=c).fill = DUPLICATE_FILL
        elif '低置信度' in mark:
            for c in range(1, 10):
                ws3.cell(row=row_idx, column=c).fill = LOW_CONF_FILL
    wb3.save(PATH_OUT3)
    print(f'[OK] 发票识别工作台账.xlsx（{len(rows_work)} 行）')

    # ---------- 7. 企业微信通知草稿 ----------
    total = len(rows_detail)
    ok = sum(1 for r in rows_detail if r['识别结果'] == '正常')
    low = sum(1 for r in rows_detail if '低置信度' in r['识别结果'])
    dup = sum(1 for r in rows_detail if '疑似重复' in r['识别结果'])
    notice = f"""【发票识别批次 {BATCH_NO} 通知】请财务同事复核

本批次共读取发票 {total} 张，成功识别 {total} 张。
识别结果汇总：
- 正常：{ok} 张
- 低置信度：{low} 张
- 疑似重复：{dup} 张
- 抬头异常：{sum(1 for r in rows_detail if '抬头异常' in r['识别结果'])} 张

需人工复核的清单请查看：
发票初审异常清单.xlsx（含 PDF解析 vs OCR 交叉对比差异、疑似重复发票、抬头异常项）

请在本批次工作台账中确认复核状态并填写复核人，谢谢！
"""
    with open(PATH_NOTICE, 'w', encoding='utf-8') as f:
        f.write(notice)

    print(f'[OK] 企业微信通知草稿.txt')

    # 汇总输出到控制台
    print('\n===== 批次汇总 =====')
    print(f'读取发票: {total} | 成功识别: {total} | 低置信度: {low} | 疑似重复: {dup}')


if __name__ == '__main__':
    main()
