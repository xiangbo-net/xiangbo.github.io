#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
发票批量识别与报销初审 - 配套输入文件生成脚本
=================================================
功能：生成案例所需的模拟配套输入文件
  1. 01-input/公司抬头与税号.txt        - 比对基准（购买方抬头与税号）
  2. 01-input/报销单_2026-05.xlsx       - 5 月报销单（含本次 3 张发票的报销申请）
  3. 02-working/发票识别字段模板.xlsx   - 发票识别字段模板（10 字段）
  4. 04-archive/历史发票台账.xlsx       - 历史发票台账（含 1 张与本次重复的发票号，用于演示"疑似重复"标注）

说明：模拟数据基于 3 张真实发票 PDF 的文本层购买方信息（深圳流诚动力科技有限公司，
统一社会信用代码 91440300MAEM33TH0G）构造，保证比对逻辑可真实运行。
"""
import os
import sys
from datetime import datetime
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

sys.stdout.reconfigure(encoding='utf-8')

# ---------- 路径常量 ----------
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PATH_TXT_TITLE = f'{ROOT}/01-input/公司抬头与税号.txt'
PATH_REIMBURSE = f'{ROOT}/01-input/报销单_2026-05.xlsx'
PATH_TEMPLATE = f'{ROOT}/02-working/发票识别字段模板.xlsx'
PATH_ARCHIVE = f'{ROOT}/04-archive/历史发票台账.xlsx'

# ---------- 公共样式 ----------
HEADER_FILL = PatternFill('solid', fgColor='1F4E79')   # 深蓝表头
HEADER_FONT = Font(bold=True, color='FFFFFF')


def style_header(ws):
    """给工作表首行设置表头样式。"""
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center')


def set_col_widths(ws, widths: dict):
    """按列名设置列宽。"""
    for col_name, w in widths.items():
        # 将列名（A/B/C...）转换为 openpyxl 可用的列
        from openpyxl.utils import column_index_from_string
        ws.column_dimensions[col_name].width = w


def gen_title_txt():
    """生成公司抬头与税号比对基准文件。"""
    content = """【公司抬头与税号基准信息】
（用于发票购买方比对）

公司全称：深圳流诚动力科技有限公司
统一社会信用代码/纳税人识别号：91440300MAEM33TH0G
注册地址：深圳市南山区
（数据来源：2026-05 批次发票购买方信息汇总）

【比对规则说明】
1. 发票购买方名称应与"公司全称"完全一致
2. 发票购买方税号应与"统一社会信用代码"完全一致
3. 不一致项标记为"抬头异常"，需人工复核
"""
    with open(PATH_TXT_TITLE, 'w', encoding='utf-8') as f:
        f.write(content)
    print(f'[OK] 公司抬头与税号.txt 已生成 -> {PATH_TXT_TITLE}')


def gen_reimburse():
    """生成 5 月报销单（含本次 3 张发票的报销申请）。"""
    wb = Workbook()
    ws = wb.active
    ws.title = '报销单2026-05'
    headers = ['报销单号', '报销日期', '报销人', '部门', '发票号码', '发票金额',
               '费用类型', '备注', '报销状态']
    ws.append(headers)
    rows = [
        ['BX2026-0501', '2026-05-06', '张三', '销售部', '26432000001721218126', 2000.00, '餐饮招待', '客户招待晚宴', '待审核'],
        ['BX2026-0502', '2026-05-12', '李四', '采购部', '25447000000583042527', 329.33, '办公采购', '京东办公用品采购', '待审核'],
        ['BX2026-0503', '2026-05-18', '王五', '技术部', '26112000002933741551', 69.00, '软件服务', '飞书订阅服务费', '待审核'],
    ]
    for r in rows:
        ws.append(r)
    style_header(ws)
    set_col_widths(ws, {'A': 14, 'B': 12, 'C': 10, 'D': 10, 'E': 24, 'F': 12,
                        'G': 12, 'H': 20, 'I': 12})
    wb.save(PATH_REIMBURSE)
    print(f'[OK] 报销单_2026-05.xlsx 已生成 -> {PATH_REIMBURSE}')


def gen_template():
    """生成发票识别字段模板（10 字段）。"""
    wb = Workbook()
    ws = wb.active
    ws.title = '字段模板'
    headers = ['字段编号', '字段名称', '字段类型', '是否必填', '字段说明', '校验规则']
    ws.append(headers)
    rows = [
        ['F01', '发票号码', '文本', '是', '发票右上角号码', '20位数字'],
        ['F02', '开票日期', '日期', '是', 'YYYY-MM-DD', '格式校验'],
        ['F03', '发票类型', '文本', '是', '如：电子发票（普通发票）', '枚举校验'],
        ['F04', '购买方名称', '文本', '是', '公司抬头', '与基准抬头比对'],
        ['F05', '购买方税号', '文本', '是', '统一社会信用代码', '18位数字字母'],
        ['F06', '销售方名称', '文本', '是', '开票方公司', '非空'],
        ['F07', '金额', '数值', '是', '不含税金额', '>0'],
        ['F08', '税额', '数值', '是', '增值税额', '>=0'],
        ['F09', '价税合计', '数值', '是', '金额+税额', '=金额+税额'],
        ['F10', 'OCR置信度', '数值', '否', '0-100 识别置信度', '<90 标记低置信度'],
    ]
    for r in rows:
        ws.append(r)
    style_header(ws)
    set_col_widths(ws, {'A': 10, 'B': 14, 'C': 10, 'D': 10, 'E': 24, 'F': 26})
    wb.save(PATH_TEMPLATE)
    print(f'[OK] 发票识别字段模板.xlsx 已生成 -> {PATH_TEMPLATE}')


def gen_archive():
    """生成历史发票台账（含 1 张与本批次重复的发票号）。"""
    wb = Workbook()
    ws = wb.active
    ws.title = '历史发票台账'
    headers = ['发票号码', '开票日期', '发票类型', '购买方名称', '购买方税号',
               '销售方名称', '金额', '税额', '价税合计', '报销单号', '处理人',
               '复核状态', '录入时间']
    ws.append(headers)
    # 注：25447000000583042527（京东）在 2025-06 已入账，本次再次识别将标记"疑似重复"；
    #     其余历史记录使用不重复的发票号，保证演示效果为"仅 1 张重复"
    rows = [
        ['25447000000583042527', '2025-06-09', '电子发票（普通发票）', '深圳流诚动力科技有限公司',
         '91440300MAEM33TH0G', '东莞京东利昇贸易有限公司', 292.27, 37.06, 329.33,
         'BX2025-0612', '张财务', '已复核', '2025-06-12 10:20:33'],
        ['26112000002933741550', '2026-03-15', '电子发票（普通发票）', '深圳流诚动力科技有限公司',
         '91440300MAEM33TH0G', '深圳市腾达云服务有限公司', 950.00, 57.00, 1007.00,
         'BX2026-0318', '李会计', '已复核', '2026-03-18 14:05:12'],
        ['25112000001345208861', '2026-02-20', '电子发票（普通发票）', '深圳流诚动力科技有限公司',
         '91440300MAEM33TH0G', '深圳市顺丰物流有限公司', 500.00, 45.00, 545.00,
         'BX2026-0221', '王出纳', '已复核', '2026-02-21 11:00:00'],
    ]
    for r in rows:
        ws.append(r)
    style_header(ws)
    set_col_widths(ws, {'A': 24, 'B': 14, 'C': 24, 'D': 24, 'E': 22, 'F': 24,
                        'G': 10, 'H': 10, 'I': 10, 'J': 14, 'K': 10, 'L': 10, 'M': 20})
    wb.save(PATH_ARCHIVE)
    print(f'[OK] 历史发票台账.xlsx 已生成 -> {PATH_ARCHIVE}（含 1 张重复发票演示数据）')


if __name__ == '__main__':
    gen_title_txt()
    gen_reimburse()
    gen_template()
    gen_archive()
    print('\n全部配套输入文件生成完毕。')
