#!/usr/bin/env node
/**
 * 发票本地 OCR 批处理脚本（基于 ocr-local skill 的 Tesseract.js）
 * 改进点（相对 skill 原版 ocr.js）：
 *  1. langPath 指向本地 tessdata 目录（避免 CDN 下载失败）
 *  2. 对 result.data.words 为 undefined 的情况做防御处理
 *  3. 输出格式：每张图片 {text, confidence, words, file}
 * 用法：node run_ocr_local.js <图片目录> <输出json>
 */
const Tesseract = require('tesseract.js');
const path = require('path');
const fs = require('fs');

const IMG_DIR = process.argv[2];
const OUT_JSON = process.argv[3];
// 本地语言包目录：优先取环境变量 TESSDATA_DIR（换机器时在启动命令前设置一次即可），
// 其次回退到工作台目录下的 .tessdata/（用户按 readme 把语言包放进来），最后回退到常见默认位置。
// 注：不写死 C:/Users/xxx，避免换机器/换系统（Windows/macOS）后路径失效。
// 注意：这里要按"目录是否真实存在"选择，不能用 || 短路（|| 只看值真假，不看路径是否存在）。
const OS_CANDIDATES = process.platform === 'darwin'
  ? [path.join(process.env.HOME || '', '.workbuddy', 'binaries', 'node', 'workspace'),
     '/usr/local/share/tessdata', '/opt/homebrew/share/tessdata']   // macOS 常见位置
  : ['C:/Users/QYJ-NN/.workbuddy/binaries/node/workspace'];          // Windows 常见位置
const CANDIDATES = [
  process.env.TESSDATA_DIR,
  path.join(__dirname, '.tessdata')
].concat(OS_CANDIDATES).filter(Boolean);
let TESSDATA = CANDIDATES[0] || '';
for (const cand of CANDIDATES) {
  if (fs.existsSync(cand)) { TESSDATA = cand; break; }
}
const CACHE_DIR = path.join(IMG_DIR, '..', '..', '02-working', '.tesseract-cache');

if (!IMG_DIR || !OUT_JSON) {
  console.error('Usage: node run_ocr_local.js <imageDir> <outJson>');
  process.exit(1);
}

if (!TESSDATA || !fs.existsSync(TESSDATA)) {
  console.error(`Tessdata dir not found. 请设置环境变量 TESSDATA_DIR 指向语言包目录，或把语言包放到 02-working/.tessdata/`);
  process.exit(1);
}

async function main() {
  const files = fs.readdirSync(IMG_DIR).filter(f => /\.(png|jpe?g|bmp)$/i.test(f));
  const results = [];
  console.log(`找到 ${files.length} 张发票图片，开始本地 OCR ...`);

  for (let i = 0; i < files.length; i++) {
    const f = files[i];
    const imgPath = path.join(IMG_DIR, f);
    console.log(`\n[${i + 1}/${files.length}] 识别: ${f}`);
    try {
      const result = await Tesseract.recognize(imgPath, 'chi_sim+eng', {
        langPath: TESSDATA,
        cachePath: CACHE_DIR,
        logger: m => {
          if (m.status === 'recognizing text') {
            process.stderr.write(`\r  进度: ${Math.round(m.progress * 100)}%`);
          }
        }
      });
      process.stderr.write('\n');
      const words = (result.data && Array.isArray(result.data.words))
        ? result.data.words.map(w => ({ text: w.text, confidence: w.confidence, bbox: w.bbox }))
        : [];
      const conf = (result.data && typeof result.data.confidence === 'number')
        ? result.data.confidence : 0;
      results.push({
        file: f,
        confidence: Math.round(conf * 100) / 100,
        wordCount: words.length,
        text: result.data.text || ''
      });
      console.log(`  置信度: ${conf.toFixed(1)}，识别字符数: ${(result.data.text || '').length}`);
    } catch (e) {
      console.error(`  识别失败: ${e.message}`);
      results.push({ file: f, confidence: 0, wordCount: 0, text: '', error: e.message });
    }
  }

  fs.writeFileSync(OUT_JSON, JSON.stringify(results, null, 2), 'utf-8');
  console.log(`\n全部完成，结果已写入: ${OUT_JSON}`);
}

main().catch(e => { console.error(e); process.exit(1); });
