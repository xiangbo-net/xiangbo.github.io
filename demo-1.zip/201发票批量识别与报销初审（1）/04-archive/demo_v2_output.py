"""按 v2 提示词流程模拟生成 4 个输出文件（演示版）。"""
import os

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from datetime import datetime

# 项目根目录（脚本所在目录的上上级 = 项目根，换机器/换目录都能跑）
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# ============================================================
# ★ 可调常量区（员工提修改需求只改这里，不要动下方核心逻辑）★
# ============================================================
# 1) 行颜色（十六进制色号，不带 #，可改）——与 process_invoices.py 保持一致
COLOR_NORMAL = 'FFFFFF'        # 正常：白
COLOR_LOW_CONF = 'FFF2CC'      # 低置信度：浅黄
COLOR_DUPLICATE = 'FCE4D6'     # 疑似重复：浅橙
COLOR_TITLE_ABN = 'F8CBAD'     # 非本公司抬头：红橙

# 2) 复核标签（可改）
LABEL_PASS = '通过'
LABEL_REVIEW = '需复核'
LABEL_PENDING = '待复核'

# 3) 识别结果标签（可改）
LABEL_NORMAL = '正常'
LABEL_LOW_CONF_TAG = '低置信度'
LABEL_DUPLICATE_TAG = '疑似重复'
LABEL_TITLE_ABN_TAG = '非本公司抬头'

# ============================================================
# 样式常量（由上方可调常量生成，一般无需改动）
# ============================================================
COLOR_OK = PatternFill(start_color=COLOR_NORMAL, end_color=COLOR_NORMAL, fill_type='solid')        # 白：正常
COLOR_REVIEW_LOW = PatternFill(start_color=COLOR_LOW_CONF, end_color=COLOR_LOW_CONF, fill_type='solid')   # 浅黄：低置信度
COLOR_REVIEW_DUP = PatternFill(start_color=COLOR_DUPLICATE, end_color=COLOR_DUPLICATE, fill_type='solid')   # 浅橙：疑似重复
COLOR_REVIEW_TITLE = PatternFill(start_color=COLOR_TITLE_ABN, end_color=COLOR_TITLE_ABN, fill_type='solid') # 红橙：非本公司抬头
HEADER_FILL = PatternFill(start_color='305496', end_color='305496', fill_type='solid')
HEADER_FONT = Font(color='FFFFFF', bold=True)
def fill_for(state):
    return {LABEL_LOW_CONF_TAG: COLOR_REVIEW_LOW, LABEL_DUPLICATE_TAG: COLOR_REVIEW_DUP,
            LABEL_TITLE_ABN_TAG: COLOR_REVIEW_TITLE}.get(state, COLOR_OK)

# ========== 演示数据（本脚本为演示版，数据由流程识别后由 AI 填充；此处为样例） ==========
# 字段：发票号 / 开票日期 / 发票类型 / 购买方 / 购买方税号 / 销售方 / 销售方税号 / 金额 / 税额 / 价税 / 来源 / PDF文件 / 图片文件 / 异常
DATA = [
    ('25447000000563838211', '2025-06-06', '电子发票(普通发票)', '深圳流诚动力科技有限公司', '91440300MAEM33TH0G', '东莞京东利昇贸易有限公司', '91441900351266820T', 133.71, 17.38, 151.09, '仅PDF解析', '电子元件151.09.pdf', '', LABEL_NORMAL),
    ('25447000000583042527', '2025-06-09', '电子发票（普通发票）', '深圳流诚动力科技有限公司', '91440300MAEM33TH0G', '东莞京东利昇贸易有限公司', '91441900351266820T', 292.27, 37.06, 329.33, '仅PDF解析', 'jd329.33.pdf', '', LABEL_DUPLICATE_TAG),
    ('26112000002933741551', '2026-07-16', '电子发票（普通发票）', '深圳流诚动力科技有限公司', '91440300MAEM33TH0G', '北京飞书科技有限公司', '91110106MA0065EG39', 65.09, 3.91, 69.00, '仅PDF解析', '北京飞书科技有限公司-69.00-2026年07月16日.pdf', '', LABEL_NORMAL),
    ('26432000001721218126', '2026-07-24', '电子发票（普通发票）', '深圳流诚动力科技有限公司', '91440300MAEM33TH0G', '慈利县桥边柴火鸡餐馆', '92430821MA4TBTNG7H', 1980.20, 19.80, 2000.00, '仅PDF解析', 'dzfp_26432000001721218126_慈利县桥边柴火鸡餐馆_20260724091612.pdf', '', LABEL_NORMAL),
    ('26957000000212276489', '2026-08-04', '电子发票（普通发票）', '腾楷科技（深圳）有限公司', '91440300MA5F0CW57P', '中国联合网络通信有限公司深圳市分公司', '91440300892254961D', 112.10, '', 112.10, '仅图片识别', '', '6b728ec2c77b49a427f9d241c27f947c.jpg', LABEL_TITLE_ABN_TAG),
]

# ========== 1. 发票OCR结构化结果.xlsx ==========
wb = Workbook()
ws = wb.active
ws.title = '发票OCR结构化结果'
headers = ['发票号码', '开票日期', '发票类型', '购买方名称', '购买方税号', '销售方名称', '销售方税号', '金额', '税额', '价税合计', '数据来源', 'PDF文件', '图片文件', '识别结果', '人工复核']
ws.append(headers)
for c in range(1, len(headers)+1):
    ws.cell(row=1, column=c).fill = HEADER_FILL
    ws.cell(row=1, column=c).font = HEADER_FONT
    ws.cell(row=1, column=c).alignment = Alignment(horizontal='center')

now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
for row in DATA:
    no, dt, tp, bn, bt, sn, st, am, tx, tot, src, pdf, img, state = row
    review = LABEL_PASS if state == LABEL_NORMAL else LABEL_REVIEW
    ws.append([no, dt, tp, bn, bt, sn, st, am, tx, tot, src, pdf, img, state, review])
    r = ws.max_row
    for c in range(1, len(headers)+1):
        ws.cell(row=r, column=c).fill = fill_for(state)
wb.save(f'{ROOT}/03-output/发票OCR结构化结果.xlsx')
print('[OK] 发票OCR结构化结果.xlsx（5 行）')

# ========== 2. 发票初审异常清单.xlsx ==========
wb = Workbook()
ws = wb.active
ws.title = '异常清单'
headers = ['发票号码', '数据来源', '异常类型', '异常说明', '涉及字段', 'PDF文件', '图片文件', '复核状态', '复核人', '复核意见']
ws.append(headers)
for c in range(1, len(headers)+1):
    ws.cell(row=1, column=c).fill = HEADER_FILL
    ws.cell(row=1, column=c).font = HEADER_FONT
abnormal = [
    ('25447000000583042527', '仅PDF解析', '疑似重复', '历史台账已存在该发票号码（2025-06-09 录入，处理人 张财务）', '', 'jd329.33.pdf', '', '待复核', '', ''),
    ('26957000000212276489', '仅图片识别', '非本公司抬头', '购买方名称/税号与本公司抬头不一致（本公司：深圳流诚动力科技有限公司/91440300MAEM33TH0G）', '购买方名称、购买方税号', '', '6b728ec2c77b49a427f9d241c27f947c.jpg', '待复核', '', ''),
]
for row in abnormal:
    ws.append(list(row))
wb.save(f'{ROOT}/03-output/发票初审异常清单.xlsx')
print('[OK] 发票初审异常清单.xlsx（2 行异常）')

# ========== 3. 发票识别工作台账.xlsx ==========
wb = Workbook()
ws = wb.active
ws.title = '工作台账'
headers = ['批次号', '序号', '发票号码', '数据来源', '识别时间', '处理人', '异常标记', '复核状态', '备注']
ws.append(headers)
for c in range(1, len(headers)+1):
    ws.cell(row=1, column=c).fill = HEADER_FILL
    ws.cell(row=1, column=c).font = HEADER_FONT
for i, row in enumerate(DATA, 1):
    no, dt, tp, bn, bt, sn, st, am, tx, tot, src, pdf, img, state = row
    review = LABEL_PASS if state == LABEL_NORMAL else LABEL_REVIEW
    note = src + (f' | 本公司抬头确认=深圳流诚动力科技有限公司' if i == 1 else '')
    ws.append(['2026-08', i, no, src, now, '演示员工', state, review, note])
wb.save(f'{ROOT}/03-output/发票识别工作台账.xlsx')
print('[OK] 发票识别工作台账.xlsx（5 行）')

# ========== 4. 企业微信通知草稿.txt ==========
normal = sum(1 for d in DATA if d[13] == LABEL_NORMAL)
abn = len(DATA) - normal
notice = f"""【发票初审批次通知 - 2026-08】
================================
收票数: 5
识别成功: 5
正常: {normal}
异常（需复核）: {abn}
  - 疑似重复 1 张: 25447000000583042527（jd329.33.pdf）
  - 非本公司抬头 1 张: 26957000000212276489（图片发票，购买方为"腾楷科技（深圳）有限公司"）

本公司抬头确认结果: 深圳流诚动力科技有限公司 / 91440300MAEM33TH0G
（本次首次通过弹窗确认，已保存至 01-input/公司抬头与税号.txt）

请到 03-output/ 查看详细异常清单并填写复核意见。
"""
with open(f'{ROOT}/03-output/企业微信通知草稿.txt', 'w', encoding='utf-8') as f:
    f.write(notice)

print('[OK] 企业微信通知草稿.txt')

print()
print('===== 演示批次汇总 =====')
print(f'读取发票: 5 | 识别成功: 5 | 低置信度: 0 | 疑似重复: 1 | 非本公司抬头: 1')