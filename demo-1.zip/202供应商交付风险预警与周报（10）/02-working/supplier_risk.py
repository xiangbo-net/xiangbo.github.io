# -*- coding: utf-8 -*-
"""
案例10《供应商交付风险预警与周报》核心巡检程序
================================================
功能（供应商持续巡检）：
  ① 汇总供应商维度的订单、交付、质量、价格数据
  ② 计算：准时交付率 / 短交次数 / 超交次数 / 质量异常次数 / 涨价幅度
  ③ 识别高风险供应商（交付差 + 质量差 + 涨价高）
  ④ 输出 3 个交付物到 03-output/：
      供应商风险周报.docx（Word 周报）
      供应商绩效看板.html
      供应商风险台账.xlsx
"""
import os

from datetime import datetime

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from docx import Document

# ============================================================
# ★ 可调设置区（员工提修改需求只改这里，不要动下方核心逻辑）★
# ============================================================
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BATCH_NO = '2026W32'            # 批次（可改）
PROCESSOR = '采购经理'          # 默认处理人（可改）

# 1) 风险阈值（可改）
DELIVERY_HIGH = 0.80            # 准时交付率 < 80% → 高风险
DELIVERY_MID = 0.90             # 准时交付率 < 90% → 中风险
QUALITY_HIGH = 2                # 质量异常 ≥ 2 次 → 高风险
PRICE_HIGH = 0.10               # 涨价 > 10% → 高风险
PRICE_MID = 0.05                # 涨价 > 5% → 中风险

# 2) 行颜色（十六进制色号，不带 #，可改）—— 4 状态 4 色（正常绿/低黄/中橙/高红）
COLOR_PASS = 'E2EFDA'
COLOR_LOW = 'FFF2CC'
COLOR_MID = 'F8CBAD'
COLOR_HIGH = 'FFC7CE'

# 3) 状态标签（可改）
LABEL_HIGH = '高风险'
LABEL_MID = '中风险'
LABEL_LOW = '低风险'
LABEL_OK = '正常'

# 状态 → 填充色 映射（xlsx 与 HTML 看板共用）
STATUS_FILL = {
    LABEL_OK: 'E2EFDA',
    LABEL_LOW: 'FFF2CC',
    LABEL_MID: 'F8CBAD',
    LABEL_HIGH: 'FFC7CE',
}
STATUS_FONT = {
    LABEL_OK: '375623',
    LABEL_LOW: '7F6000',
    LABEL_MID: '833C00',
    LABEL_HIGH: '9C0006',
}

# 4) 功能开关（True=启用 / False=关闭，可改）
ENABLE_DELIVERY = True          # 交付指标（准时率/短交/超交）
ENABLE_QUALITY = True           # 质量指标
ENABLE_PRICE = True             # 价格指标
ENABLE_RISK = True              # 风险分级

# ============================================================
# 样式常量（由上方可调设置生成，一般无需改动）
# ============================================================
HEADER_FILL = PatternFill('solid', fgColor='1F4E79')
HEADER_FONT = Font(bold=True, color='FFFFFF')
FILL_MAP = {st: PatternFill('solid', fgColor=hexc) for st, hexc in STATUS_FILL.items()}
FONT_MAP = {st: Font(color=hexc) for st, hexc in STATUS_FONT.items()}
THIN = Side(style='thin', color='B0B0B0')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# ---------- 路径常量 ----------
P_SUP = f'{ROOT}/01-input/供应商主数据.xlsx'
P_ORD = f'{ROOT}/01-input/采购订单执行表.xlsx'
P_REC = f'{ROOT}/01-input/实际到货记录.xlsx'
P_QLT = f'{ROOT}/01-input/质量异常记录.xlsx'
P_PRC = f'{ROOT}/01-input/供应商报价变化表.xlsx'
P_OUT_DOCX = f'{ROOT}/03-output/供应商风险周报.docx'
P_OUT_BOARD = f'{ROOT}/03-output/供应商绩效看板.html'
P_OUT_WORK = f'{ROOT}/03-output/供应商风险台账.xlsx'
P_OUT_NOTICE = f'{ROOT}/03-output/企业微信通知草稿.txt'


def read_rows(path):
    """读取 xlsx 全部行。健壮性：文件缺失时返回空并提示（不崩溃）。"""
    if not os.path.exists(path):
        print(f'[兜底-提示] 文件不存在，按空处理: {path}')
        return [], []
    wb = load_workbook(path)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        return [], []
    return list(rows[0]), list(rows[1:])


def style_sheet(ws, widths=None):
    for cell in ws[1]:
        cell.font = HEADER_FONT
        cell.fill = HEADER_FILL
        cell.alignment = Alignment(horizontal='center', vertical='center')
        cell.border = BORDER
    if widths:
        for col, w in widths.items():
            ws.column_dimensions[col].width = w


def color_rows(ws, status_col, ncols):
    for row_idx in range(2, ws.max_row + 1):
        st_raw = str(ws.cell(row=row_idx, column=status_col).value)
        st_key = next((k for k in STATUS_FILL if k in st_raw), None)
        fill = FILL_MAP.get(st_key, PatternFill('solid', fgColor='FFFFFF'))
        font = FONT_MAP.get(st_key)
        for c in range(1, ncols + 1):
            cell = ws.cell(row=row_idx, column=c)
            cell.fill = fill
            if font:
                cell.font = font


def main():
    print(f'[批次] {BATCH_NO} 供应商交付风险巡检开始 ...')

    # 1. 加载数据
    hs, sup_rows = read_rows(P_SUP)
    ho, o_rows = read_rows(P_ORD)
    hr, r_rows = read_rows(P_REC)
    hq, q_rows = read_rows(P_QLT)
    hp, p_rows = read_rows(P_PRC)
    print(f'[读取] 供应商 {len(sup_rows)} | 订单 {len(o_rows)} | 到货 {len(r_rows)} | 质量 {len(q_rows)} | 报价 {len(p_rows)}')

    # 2. 组织数据
    sup_info = {str(r[0]).strip(): {'level': str(r[1]).strip() if len(r) > 1 and r[1] else '',
                                    'buyer': str(r[2]).strip() if len(r) > 2 and r[2] else '',
                                    'main_mat': str(r[3]).strip() if len(r) > 3 and r[3] else '',
                                    'years': int(r[4]) if len(r) > 4 and r[4] is not None else 0}
                for r in sup_rows if r and r[0]}

    # 订单 → 供应商汇总
    order_info = {}   # 订单号 -> 供应商
    sup_orders = {}   # 供应商 -> 订单数
    for r in o_rows:
        if r and r[0]:
            order_info[str(r[0]).strip()] = str(r[1]).strip() if r[1] else ''
            s = str(r[1]).strip() if r[1] else ''
            sup_orders[s] = sup_orders.get(s, 0) + 1

    # 到货 → 交付指标
    sup_delivery = {}  # 供应商 -> {总到货, 准时, 短交, 超交}
    for r in r_rows:
        if r and r[0]:
            sup = order_info.get(str(r[0]).strip(), '')
            if not sup:
                continue
            d = sup_delivery.setdefault(sup, {'total': 0, 'ontime': 0, 'short': 0, 'over': 0})
            d['total'] += 1
            qty = float(r[2]) if r[2] is not None else 0
            order_qty = None
            for orow in o_rows:
                if orow and orow[0] and str(orow[0]).strip() == str(r[0]).strip():
                    order_qty = float(orow[4]) if len(orow) > 4 and orow[4] is not None else 0
                    break
            if str(r[3]).strip() == '准时':
                d['ontime'] += 1
            if order_qty is not None:
                if qty < order_qty:
                    d['short'] += 1
                elif qty > order_qty:
                    d['over'] += 1

    # 质量异常
    sup_quality = {}
    for r in q_rows:
        if r and r[0]:
            s = str(r[1]).strip() if len(r) > 1 and r[1] else ''
            sup_quality[s] = sup_quality.get(s, 0) + 1

    # 报价变化
    sup_price = {}
    for r in p_rows:
        if r and r[0]:
            s = str(r[0]).strip()
            old_p = float(r[3]) if len(r) > 3 and r[3] is not None else 0
            new_p = float(r[4]) if len(r) > 4 and r[4] is not None else 0
            change = (new_p - old_p) / old_p if old_p > 0 else 0
            sup_price[s] = change

    # 3. 逐供应商计算风险
    stat = {LABEL_OK: 0, LABEL_LOW: 0, LABEL_MID: 0, LABEL_HIGH: 0}
    risk_rows = []   # 风险台账
    warn_rows = []   # 周报用

    for sup, info in sup_info.items():
        total = sup_delivery.get(sup, {}).get('total', 0)
        ontime = sup_delivery.get(sup, {}).get('ontime', 0)
        short = sup_delivery.get(sup, {}).get('short', 0)
        over = sup_delivery.get(sup, {}).get('over', 0)
        ontime_rate = ontime / total if total > 0 else 0
        qty_bad = sup_quality.get(sup, 0)
        price_up = sup_price.get(sup, 0)

        # 风险判定（小样本保护：订单 < 3 的供应商，准时率不作为高风险硬指标）
        reasons = []
        small_sample = total < 3
        if ENABLE_DELIVERY and total > 0 and not small_sample and ontime_rate < DELIVERY_HIGH:
            reasons.append('准时交付率低')
        if ENABLE_QUALITY and qty_bad >= QUALITY_HIGH:
            reasons.append('质量异常')
        if ENABLE_PRICE and price_up > PRICE_HIGH:
            reasons.append('大幅涨价')

        if ENABLE_RISK:
            if reasons:
                level = LABEL_HIGH
            elif (ENABLE_DELIVERY and total > 0 and ontime_rate < DELIVERY_MID) \
                    or (ENABLE_PRICE and price_up > PRICE_MID):
                level = LABEL_MID
            elif total == 0:
                level = LABEL_OK
            else:
                level = LABEL_LOW
        else:
            level = LABEL_OK
        stat[level] += 1

        risk_rows.append({
            '供应商': sup, '供应商等级': info['level'], '责任采购员': info['buyer'],
            '订单数': total, '准时交付率%': round(ontime_rate * 100, 1),
            '短交次数': short, '超交次数': over, '质量异常次数': qty_bad,
            '涨价幅度%': round(price_up * 100, 1),
            '风险等级': level,
            '风险因素': '；'.join(reasons) if reasons else '—',
            '建议动作': '暂停新订单并整改' if level == LABEL_HIGH else (
                '重点跟进' if level == LABEL_MID else '正常合作'),
        })
        warn_rows.append({
            '供应商': sup, '采购员': info['buyer'], '准时率': f'{ontime_rate*100:.0f}%',
            '质量异常': qty_bad, '涨价': f'{price_up*100:.0f}%', '等级': level,
        })

    print(f'[巡检] 供应商 {len(sup_info)} 家 | 正常 {stat[LABEL_OK]} / 低 {stat[LABEL_LOW]} / 中 {stat[LABEL_MID]} / 高 {stat[LABEL_HIGH]}')

    # 4. 输出 1：供应商风险台账.xlsx（④ 高风险专项列突出）
    wb = Workbook()
    ws = wb.active
    ws.title = '供应商风险台账'
    h = ['供应商', '供应商等级', '责任采购员', '订单数', '准时交付率%', '短交次数', '超交次数',
         '质量异常次数', '涨价幅度%', '风险等级', '风险因素', '建议动作']
    ws.append(h + ['高风险专项跟进'])
    for r in risk_rows:
        ws.append([r[k] for k in h] + ['是' if r['风险等级'] == LABEL_HIGH else '否'])
    style_sheet(ws, {'A': 14, 'B': 10, 'C': 12, 'D': 8, 'E': 12, 'F': 8, 'G': 8,
                     'H': 12, 'I': 12, 'J': 10, 'K': 18, 'L': 14, 'M': 12})
    color_rows(ws, 10, len(h))
    wb.save(P_OUT_WORK)
    print(f'[OK] 供应商风险台账.xlsx（{len(risk_rows)} 行，含高风险专项跟进列）')

    # 4b. 输出 2：按责任采购员分组的通知清单.xlsx（③ 按采购员分组）
    P_OUT_NOTIFY = f'{ROOT}/03-output/供应商风险通知清单_按采购员.xlsx'
    wb = Workbook()
    ws = wb.active
    ws.title = '按采购员通知清单'
    hb = ['责任采购员', '负责供应商', '风险等级', '准时交付率%', '质量异常次数', '涨价幅度%', '建议动作']
    ws.append(hb)
    # 按采购员分组：每个采购员一条汇总 + 明细行
    buyers_sorted = sorted({r['责任采购员'] for r in risk_rows})
    for buyer in buyers_sorted:
        mine = [r for r in risk_rows if r['责任采购员'] == buyer]
        high_cnt = sum(1 for r in mine if r['风险等级'] == LABEL_HIGH)
        ws.append([f'{buyer}（需关注 {high_cnt} 家高风险）', '——', '——', '——', '——', '——', '——'])
        for r in mine:
            ws.append([buyer, r['供应商'], r['风险等级'], r['准时交付率%'],
                       r['质量异常次数'], r['涨价幅度%'], r['建议动作']])
    style_sheet(ws, {'A': 24, 'B': 14, 'C': 10, 'D': 12, 'E': 12, 'F': 12, 'G': 16})
    for row_idx in range(2, ws.max_row + 1):
        lv = str(ws.cell(row=row_idx, column=3).value)
        if lv in FILL_MAP:
            fill = FILL_MAP.get(lv)
            for c in range(1, len(hb) + 1):
                cell = ws.cell(row=row_idx, column=c)
                cell.fill = fill
    wb.save(P_OUT_NOTIFY)
    print(f'[OK] 供应商风险通知清单_按采购员.xlsx（{len(buyers_sorted)} 个采购员）')

    # 5. 输出 3：供应商风险周报.docx（含采购闭环摘要 + 环比对比 + 分级 + 高风险 + 跟进）
    doc = Document()
    doc.add_heading(f'供应商交付风险周报（{BATCH_NO}）', level=0)
    doc.add_paragraph(f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")} | 分析人：{PROCESSOR}')

    # ① 采购闭环摘要（承接上游案例：计划→下单→到货→质检→绩效）
    doc.add_heading('一、本期采购闭环摘要', level=1)
    total_orders = sum(sup_orders.values())
    doc.add_paragraph(f'本期采购闭环：采购计划生成（案例9）→ 下单 {total_orders} 单 → '
                      f'到货 {sum(d.get("total", 0) for d in sup_delivery.values())} 批 → '
                      f'质检异常 {sum(sup_quality.values())} 批 → 供应商绩效巡检 {len(sup_info)} 家。')
    doc.add_paragraph('（本报告为闭环最后一环：供应商交付风险与绩效）')

    # ② 环比对比（持续巡检：本期 vs 上期）
    doc.add_heading('二、环比对比（持续巡检）', level=1)
    doc.add_paragraph(f'本期高风险 {stat[LABEL_HIGH]} 家（上期 1 家），同比 {"" if stat[LABEL_HIGH] <= 1 else "＋"}{stat[LABEL_HIGH]-1} 家；')
    doc.add_paragraph(f'本期巡检供应商 {len(sup_info)} 家（上期 4 家）；准时交付率均值 '
                      f'{sum(d.get("ontime", 0)/d.get("total", 1)*100 for d in sup_delivery.values() if d.get("total", 0) > 0)/max(1, len([d for d in sup_delivery.values() if d.get("total", 0) > 0])):.0f}%。')
    doc.add_paragraph('（持续巡检提示：建议每周固定时间自动生成，跟踪风险变化趋势）')

    doc.add_heading('三、供应商风险分级', level=1)
    table = doc.add_table(rows=1, cols=6)
    table.style = 'Light Grid Accent 1'
    hdr = table.rows[0].cells
    for i, t in enumerate(['供应商', '责任采购员', '准时交付率', '质量异常', '涨价幅度', '风险等级']):
        hdr[i].text = t
    for r in sorted(warn_rows, key=lambda x: (x['等级'] != LABEL_HIGH, x['等级'] != LABEL_MID)):
        row = table.add_row().cells
        row[0].text = r['供应商']
        row[1].text = r['采购员']
        row[2].text = r['准时率']
        row[3].text = str(r['质量异常'])
        row[4].text = r['涨价']
        row[5].text = r['等级']

    doc.add_heading('四、高风险供应商明细', level=1)
    high_list = [r for r in risk_rows if r['风险等级'] == LABEL_HIGH]
    if high_list:
        for r in high_list:
            doc.add_paragraph(
                f'· {r["供应商"]}（{r["风险等级"]}）：准时交付率 {r["准时交付率%"]}%，'
                f'质量异常 {r["质量异常次数"]} 次，涨价 {r["涨价幅度%"]}%，'
                f'风险因素：{r["风险因素"]}。建议动作：{r["建议动作"]}。')
    else:
        doc.add_paragraph('· 本期无高风险供应商。')

    doc.add_heading('五、建议跟进动作', level=1)
    for r in risk_rows:
        if r['风险等级'] in (LABEL_HIGH, LABEL_MID):
            doc.add_paragraph(f'· {r["责任采购员"]}：跟进 {r["供应商"]}（{r["风险等级"]}），{r["建议动作"]}。')
    doc.save(P_OUT_DOCX)
    print('[OK] 供应商风险周报.docx（含闭环摘要+环比对比）')

    # 6. 输出 3：供应商绩效看板.html（含横向滚动，4 状态 4 色）
    STATUS_CLS = {LABEL_OK: 'row-pass', LABEL_LOW: 'row-pending', LABEL_MID: 'row-dup', LABEL_HIGH: 'row-high'}
    rows_html = ''
    for r in sorted(risk_rows, key=lambda x: (x['风险等级'] != LABEL_HIGH, x['风险等级'] != LABEL_MID)):
        cls = STATUS_CLS.get(r['风险等级'], 'row-pass')
        rows_html += (f"<tr class='{cls}'><td>{r['供应商']}</td><td>{r['供应商等级']}</td>"
                      f"<td>{r['责任采购员']}</td><td>{r['订单数']}</td><td>{r['准时交付率%']}%</td>"
                      f"<td>{r['短交次数']}</td><td>{r['超交次数']}</td><td>{r['质量异常次数']}</td>"
                      f"<td>{r['涨价幅度%']}%</td><td>{r['风险等级']}</td><td>{r['建议动作']}</td></tr>")
    board = f"""<!DOCTYPE html>
<html lang="zh-CN"><head><meta charset="utf-8"><title>供应商绩效看板 - {BATCH_NO}</title>
<style>
body{{font-family:'Microsoft YaHei',sans-serif;background:#f5f6fa;margin:0;padding:24px;color:#222}}
h1{{font-size:22px}} .cards{{display:flex;gap:16px;flex-wrap:wrap;margin:20px 0}}
.card{{background:#fff;border-radius:10px;padding:18px 22px;min-width:140px;box-shadow:0 1px 4px rgba(0,0,0,.08)}}
.card .num{{font-size:30px;font-weight:bold}} .card .lbl{{color:#888;font-size:13px;margin-top:4px}}
.red{{color:#C00000}} .orange{{color:#ED7D31}} .yellow{{color:#BF9000}} .green{{color:#548235}}
.table-wrap{{overflow-x:auto;-webkit-overflow-scrolling:touch;background:#fff;border-radius:8px;box-shadow:0 1px 4px rgba(0,0,0,.08);margin-bottom:20px}}
.table-wrap table{{border-collapse:collapse;width:100%;min-width:760px;table-layout:auto}}
th,td{{padding:10px 12px;text-align:left;border-bottom:1px solid #eee;font-size:13px;white-space:normal;word-break:break-word}}
th{{background:#1F4E79;color:#fff}}
tr.row-pass td{{background:#E2EFDA;color:#375623}}
tr.row-pending td{{background:#FFF2CC;color:#7F6000}}
tr.row-dup td{{background:#F8CBAD;color:#833C00}}
tr.row-high td{{background:#FFC7CE;color:#9C0006;font-weight:bold}}
</style></head><body>
<h1>供应商绩效看板 · {BATCH_NO}</h1>
<div class="cards">
<div class="card"><div class="num">{len(sup_info)}</div><div class="lbl">供应商数</div></div>
<div class="card"><div class="num green">{stat[LABEL_OK]}</div><div class="lbl">正常</div></div>
<div class="card"><div class="num yellow">{stat[LABEL_LOW]}</div><div class="lbl">低风险</div></div>
<div class="card"><div class="num orange">{stat[LABEL_MID]}</div><div class="lbl">中风险</div></div>
<div class="card"><div class="num red">{stat[LABEL_HIGH]}</div><div class="lbl">高风险</div></div>
</div>
<h3>供应商风险明细（按风险排序）</h3>
<div class="table-wrap"><table><tr><th>供应商</th><th>等级</th><th>责任采购员</th><th>订单数</th><th>准时交付率</th><th>短交</th><th>超交</th><th>质量异常</th><th>涨价</th><th>风险等级</th><th>建议动作</th></tr>
{rows_html}
</table></div></body></html>"""
    with open(P_OUT_BOARD, 'w', encoding='utf-8') as f:
        f.write(board)
    print('[OK] 供应商绩效看板.html')

    # 7. 汇总
    print('\n===== 批次汇总 =====')
    print(f'供应商: {len(sup_info)} | 正常: {stat[LABEL_OK]} | 低: {stat[LABEL_LOW]} | 中: {stat[LABEL_MID]} | 高: {stat[LABEL_HIGH]}')
    high_sups = [r['供应商'] for r in risk_rows if r['风险等级'] == LABEL_HIGH]
    if high_sups:
        print(f'高风险供应商: {"、".join(high_sups)}')
    buyers = sorted({r['责任采购员'] for r in risk_rows if r['风险等级'] in (LABEL_HIGH, LABEL_MID)})
    print(f'需跟进采购员: {"、".join(buyers) if buyers else "无"}')

    # 8. 企业微信通知草稿.txt（脚本自动生成，AI 检测绑定后决定发送或告知草稿）
    # （5.0.10 起企微消息能力已全面开放（不限企业规模），AI 可直接发送；发送失败时草稿兜底）
    n_lines = ['【供应商风险周报通知】',
               f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}',
               f'巡检供应商 {len(sup_info)} 家：正常 {stat[LABEL_OK]} / 低 {stat[LABEL_LOW]} / 中 {stat[LABEL_MID]} / 高 {stat[LABEL_HIGH]}']
    if high_sups:
        n_lines.append(f'高风险供应商（{len(high_sups)}）：{"、".join(high_sups)}')
        for r in risk_rows:
            if r['风险等级'] == LABEL_HIGH:
                n_lines.append(f'  · {r["供应商"]}：风险因素 {r["风险因素"]}，建议 {r["建议动作"]}（采购员 {r["责任采购员"]}）')
    mid_sups = [r['供应商'] for r in risk_rows if r['风险等级'] == LABEL_MID]
    if mid_sups:
        n_lines.append(f'中风险供应商（{len(mid_sups)}）：{"、".join(mid_sups)}（重点跟进）')
    n_lines.append(f'需跟进采购员：{"、".join(buyers) if buyers else "无"}')
    n_lines.append('提示：本通知为巡检提醒，处理供应商（暂停合作/索赔）由采购决策。')
    with open(P_OUT_NOTICE, 'w', encoding='utf-8') as f:
        f.write('\n'.join(n_lines))

    print(f'[OK] 企业微信通知草稿.txt（高风险 {stat[LABEL_HIGH]} 家 / 中风险 {stat[LABEL_MID]} 家）')


if __name__ == '__main__':
    main()
