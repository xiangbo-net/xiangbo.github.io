#!/usr/bin/env python3
"""
客户历史池管理模块 (pool_manager v1.0)
用于持久化存储已发现的POI客户，实现跨搜索会话的去重

缓存位置规则：
  {workspace}/精准获客/.logs/client_pool.json
  按工作空间隔离，不污染skill目录和配置目录
"""
import json
import re
import os
from datetime import datetime
from pathlib import Path
from typing import Optional


def name_fingerprint(name: str) -> str:
    """对公司名称做归一化处理，用于模糊去重"""
    n = name.strip()
    # 去除空白字符
    n = re.sub(r"\s+", "", n)
    # 去除常见后缀
    suffixes = [
        "有限公司", "股份公司", "集团公司", "实业公司",
        "有限责任公司", "股份有限公司", "集团有限公司",
        "(普通合伙)", "（普通合伙）", "(有限合伙)", "（有限合伙）",
    ]
    for sfx in suffixes:
        if n.endswith(sfx):
            n = n[: -len(sfx)]
            break
    # 去括号内容（如分公司标识）
    n = re.sub(r"[（(][^)）]*[)）]", "", n)
    return n.strip()


def init_pool() -> dict:
    """创建空的历史池结构"""
    return {
        "version": 1,
        "last_updated": datetime.now().strftime("%Y-%m-%dT%H:%M:%S"),
        "combo_history": {},
        "clients": [],
        "stats": {
            "total_clients": 0,
            "total_combos": 0,
            "finished_combos": 0,
        },
    }


def load_pool(pool_path: str) -> dict:
    """
    加载历史池文件，不存在则初始化
    返回池数据字典
    """
    path = Path(pool_path)
    if path.exists():
        try:
            with open(path, "r", encoding="utf-8") as f:
                pool = json.load(f)
            # 保证关键字段存在
            if "combo_history" not in pool:
                pool["combo_history"] = {}
            if "clients" not in pool:
                pool["clients"] = []
            if "stats" not in pool:
                pool["stats"] = {"total_clients": 0, "total_combos": 0, "finished_combos": 0}
            return pool
        except (json.JSONDecodeError, KeyError):
            print(f"[pool] 历史池文件损坏，重新初始化: {pool_path}")
            return init_pool()
    else:
        # 确保目录存在
        path.parent.mkdir(parents=True, exist_ok=True)
        pool = init_pool()
        save_pool(pool, pool_path)
        print(f"[pool] 已创建新的客户历史池: {pool_path}")
        return pool


def save_pool(pool: dict, pool_path: str):
    """保存历史池到文件"""
    pool["last_updated"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    pool["stats"]["total_clients"] = len(pool["clients"])
    pool["stats"]["total_combos"] = len(pool["combo_history"])
    pool["stats"]["finished_combos"] = sum(
        1 for c in pool["combo_history"].values() if c.get("finished", False)
    )
    path = Path(pool_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(pool_path, "w", encoding="utf-8") as f:
        json.dump(pool, f, ensure_ascii=False, indent=2)


def combo_key(keyword: str, city: str) -> str:
    """生成组合键: '城市|关键词'"""
    return f"{city.strip()}|{keyword.strip()}"


def check_combo(pool: dict, keyword: str, city: str) -> dict:
    """
    检查某个关键词|城市组合是否已完成搜索
    返回: {"finished": bool, "detail": {...} or None}
    """
    key = combo_key(keyword, city)
    record = pool["combo_history"].get(key)
    if record and record.get("finished", False):
        return {"finished": True, "detail": record}
    return {"finished": False, "detail": record}


def mark_combo_searching(pool: dict, keyword: str, city: str):
    """标记一个组合正在搜索（记录开始）"""
    key = combo_key(keyword, city)
    if key not in pool["combo_history"]:
        pool["combo_history"][key] = {
            "last_searched": datetime.now().strftime("%Y-%m-%d"),
            "total_results": 0,
            "total_api_calls": 0,
            "finished": False,
        }


def mark_combo_done(pool: dict, keyword: str, city: str, total_results: int, api_calls: int):
    """标记一个组合的搜索已完成"""
    key = combo_key(keyword, city)
    pool["combo_history"][key] = {
        "last_searched": datetime.now().strftime("%Y-%m-%d"),
        "total_results": total_results,
        "total_api_calls": api_calls,
        "finished": True,
    }


def build_seen_index(pool: dict) -> tuple:
    """
    从历史池中构建去重索引
    返回: (seen_uids: set, seen_fingerprints: set)
      - seen_uids: 所有已见 POI uid
      - seen_fingerprints: "name_fingerprint|city" 组合
    """
    seen_uids = set()
    seen_fingerprints = set()
    for client in pool.get("clients", []):
        uid = client.get("uid", "")
        if uid:
            seen_uids.add(uid)
        fp = client.get("name_fingerprint", "")
        city = client.get("city", "")
        if fp and city:
            seen_fingerprints.add(f"{fp}|{city}")
    return seen_uids, seen_fingerprints


def filter_results_by_pool(results: dict, pool: dict) -> dict:
    """
    从搜索结果中过滤掉已在历史池中的POI
    results: {uid: poi_dict, ...} 来自 search_all() 的输出
    pool: 历史池数据

    返回: {uid: poi_dict, ...} 过滤后的结果
    """
    seen_uids, seen_fingerprints = build_seen_index(pool)

    filtered = {}
    skip_uid = 0
    skip_fuzzy = 0

    for uid, poi in results.items():
        # 第一层：按 uid 精确去重
        if uid in seen_uids:
            skip_uid += 1
            continue

        # 第二层：按名称指纹+城市模糊去重
        fp = name_fingerprint(poi.get("name", ""))
        city = poi.get("city", "")
        if fp and city and f"{fp}|{city}" in seen_fingerprints:
            skip_fuzzy += 1
            continue

        filtered[uid] = poi

    return filtered, skip_uid, skip_fuzzy


def merge_results_to_pool(pool: dict, new_results: dict, keyword: str, city: str,
                          score_map: Optional[dict] = None, priority_map: Optional[dict] = None):
    """
    将新的搜索结果合并到历史池中
    new_results: {uid: poi_dict, ...} 过滤后的新结果
    score_map: {uid: score, ...} 评分映射（可选）
    priority_map: {uid: priority, ...} 优先级映射（可选）
    """
    existing_map = {}
    for client in pool.get("clients", []):
        uid = client.get("uid", "")
        if uid:
            existing_map[uid] = client

    now = datetime.now().strftime("%Y-%m-%dT%H:%M:%S")
    added_count = 0

    for uid, poi in new_results.items():
        if uid in existing_map:
            # 更新已有记录
            client = existing_map[uid]
            client["last_seen"] = now
            client["found_count"] = client.get("found_count", 1) + 1
            # 如果新评分更高，更新
            if score_map and uid in score_map:
                new_score = score_map[uid]
                if new_score > client.get("score", 0):
                    client["score"] = new_score
                    client["priority"] = priority_map.get(uid, client.get("priority", "")) if priority_map else client.get("priority", "")
        else:
            # 新增记录
            client = {
                "uid": uid,
                "name": poi.get("name", ""),
                "name_fingerprint": name_fingerprint(poi.get("name", "")),
                "city": poi.get("city", ""),
                "address": poi.get("address", ""),
                "phone": poi.get("tel", ""),
                "score": score_map.get(uid, 0) if score_map else 0,
                "priority": priority_map.get(uid, "") if priority_map else "",
                "first_found": now,
                "last_seen": now,
                "found_count": 1,
            }
            pool["clients"].append(client)
            added_count += 1

    return added_count, len(new_results)


def update_combo_after_search(pool: dict, keyword: str, city: str,
                              new_count: int, api_calls: int, finished: bool = False):
    """搜索完成后更新组合历史"""
    key = combo_key(keyword, city)
    now = datetime.now().strftime("%Y-%m-%d")

    if key in pool["combo_history"]:
        record = pool["combo_history"][key]
        record["last_searched"] = now
        record["total_results"] = record.get("total_results", 0) + new_count
        record["total_api_calls"] = record.get("total_api_calls", 0) + api_calls
    else:
        pool["combo_history"][key] = {
            "last_searched": now,
            "total_results": new_count,
            "total_api_calls": api_calls,
            "finished": finished,
        }

    if finished:
        pool["combo_history"][key]["finished"] = True


def get_pool_stats(pool: dict) -> dict:
    """获取历史池统计摘要"""
    clients = pool.get("clients", [])
    combos = pool.get("combo_history", {})

    # 按城市统计
    by_city = {}
    for c in clients:
        city = c.get("city", "未知")
        by_city[city] = by_city.get(city, 0) + 1

    # 按优先级统计
    by_priority = {"P1": 0, "P2": 0, "P3": 0}
    for c in clients:
        pri = c.get("priority", "")
        if "P1" in pri:
            by_priority["P1"] += 1
        elif "P2" in pri:
            by_priority["P2"] += 1
        else:
            by_priority["P3"] += 1

    finished_combos = sum(1 for c in combos.values() if c.get("finished", False))

    return {
        "total": len(clients),
        "by_city": by_city,
        "by_priority": by_priority,
        "combos_total": len(combos),
        "combos_finished": finished_combos,
    }


# ====== 命令行入口 ======
if __name__ == "__main__":
    import sys
    pool_path = sys.argv[1] if len(sys.argv) > 1 else "client_pool.json"

    pool = load_pool(pool_path)
    print(f"历史池: {pool_path}")
    print(f"  客户总数: {len(pool['clients'])}")
    print(f"  组合数: {len(pool['combo_history'])}")
    print(f"  已完成组合: {pool['stats']['finished_combos']}")
    stats = get_pool_stats(pool)
    print(f"\n城市分布: {stats['by_city']}")
    print(f"优先级分布: {stats['by_priority']}")
