# Overseas Customer Miner

海外精准获客智能体 — 自动搜索海外潜在客户、获取联系信息，输出 Excel 客户清单、洞察看板与个性化英文沟通话术。

## 类型

Agent 型（单个 AI 专家）

## 功能

- 基于 Tavily 搜索海外目标企业官网与公开信息
- 智能补充联系邮箱、电话、社交媒体等联系方式
- 自动分类客户类型并生成 Excel 客户清单
- 生成可视化 HTML 洞察看板
- 针对每家客户生成个性化英文沟通话术

## 使用示例

- "我是做五金配件出口的，想找德国的汽车零部件经销商，帮我搜一下。"
- "我们做不锈钢厨具，帮我在英国找厨房用品经销商。"
- "帮我在东南亚找电子产品 OEM 代工合作伙伴。"

## 头像

头像已放在 `avatars/` 目录下。如需替换为自定义头像，要求：
- 格式：PNG（推荐）或 JPG
- 尺寸：512×512 px
- 大小：单张不超过 500KB

## 安装

WorkBuddy 通过 `.codebuddy-plugin/plugin.json` 自动发现激活，无需额外注册脚本。

1. 将专家包解压到以下目录：

```bash
~/.workbuddy/plugins/marketplaces/my-experts/plugins/overseas-customer-miner/
```

2. 重启 WorkBuddy（或刷新插件列表），即可在对话框中使用。

> 首次使用需要在对话中配置 Tavily API Key，具体操作由 AI 引导完成。

## 打包分享

请使用项目内的打包脚本生成发布包，避免手动 `zip` 导致中文文件名编码问题或敏感文件泄露：

```bash
# 精简分发版（推荐，不含 dev-tools 调试脚本）
python tavily-customer-miner/scripts/dev-tools/package_v1.3_clean.py

# 完整版（含 dev-tools，本地备份/开发用）
python tavily-customer-miner/scripts/dev-tools/package_v1.3.py
```

输出位置：
- `~/.workbuddy/userdata/wxskill/overseas-customer-miner/output/`
- `dist/`

打包脚本已自动排除真实 API Key（`.env.tavily`）、调试脚本（`dev-tools/`）以及内部文档。
