---
name: tavily-customer-miner
version: 1.3.0
description: 海外企业客户挖掘底层脚本集合，被「海外地图获客」专家调用，正常用户应通过专家入口使用。触发词：海外客户、外贸客户、国外客户、海外获客、客户挖掘、tavily 脚本、执行客户挖掘脚本、调试客户挖掘
author: agent_created
agent_created: true
trigger:
  - tavily-customer-miner
  - 海外客户
  - 外贸客户
  - 国外客户
  - 海外获客
  - 客户挖掘
  - 运行 tavily 脚本
  - 执行客户挖掘脚本
  - 调试客户挖掘
---

# Tavily 海外客户挖掘 Skill（底层脚本）

本 Skill 包含执行脚本和配置模板，正常使用时由 **「海外地图获客」** 专家自动调用。

---

## 跨平台兼容约定

本 Skill 脚本需要在 macOS 和 Windows 上同等工作。以下规则须严格遵守：

### 路径写法规则

| 场景 | 处理方式 |
|------|---------|
| SKILL.md 中的路径引用 | 使用 Unix 风格 `/` 作为文档路径写法（如 `~/.workbuddy/userdata/`），WorkBuddy 统一处理路径映射 |
| 脚本调用命令 | macOS 用 `python3`，Windows 用 `python`。代码块注释中标注平台差异 |
| Python 脚本内路径拼接 | 全部使用 `os.path.join()`，**禁止**硬编码 `/` 或 `\\` 分隔符 |
| 用户目录展开 | 使用 `os.path.expanduser("~/.workbuddy/...")` 而非硬编码绝对路径 |
| 临时目录 | 使用 `tempfile.gettempdir()` 跨平台临时目录，**禁止**硬写 `/tmp/` |
| 文件名过滤 | 同时过滤 Windows + macOS 非法字符：`\/:*?"<>|` |

### 脚本执行兼容

```bash
# macOS:
python3 scripts/tavily_customer_mine.py --config config.json

# Windows:
python scripts\tavily_customer_mine.py --config config.json
```

### 文件打开编码

所有文件读写均使用 `encoding="utf-8"`（Python 默认在 Windows 上可能使用系统编码，必须显式指定）。

---

## P0 — 触发条件与入口话术

**触发条件**：用户输入"帮我找/挖/搜一些海外客户"、"我是XX行业，想找XX国家的XX类型客户"、"我是XX厂，做XX产品，想找XX国家的客户"等类似意图。

**入口话术**：
- 如果用户提供了完整需求（公司名 + 产品 + 目标国家 + 客户类型）→ 直接进入 P0.5 历史复用检查
- 如果用户只部分提供 → 进入 P1 需求收集，逐项追问（不要一次性抛完所有问题）
- 如果用户只给出模糊表达（如"帮我找客户"）→ 先问"你的公司做什么产品？想找哪个国家的客户？"

---

## P0.5 — 历史搜索信息复用

1. 读取 `~/.workbuddy/userdata/wxskill/overseas-customer-miner/config.json`，检查是否有 `last_search` 字段且非 null
2. 如果有，用 AskUserQuestion 弹窗展示并询问：

   ```
   您上次搜索时填写的信息如下：
     🏢 公司名称：{company_name}
     📦 产品描述：{product_description}
     🌍 目标国家：{target_country}

   这次是否沿用这些信息？
   ```

   选项：`["沿用，直接搜索（推荐）", "修改部分信息", "重新输入"]`

3. 用户选择后的处理：
   - **沿用** → 跳过 Step 1-2，将 `last_search` 直接填入搜索参数，进入 P2 搜索策略生成
   - **修改** → 进入 P1 需求收集，但将 `last_search` 的信息预填充为默认值提示用户调整
   - **重新输入或没有历史** → 正常进入 P1，从头逐项收集信息

---

## P1 — 需求收集（逐项追问）

按以下顺序逐项询问，每次只问一个：

1. **公司名**：你的公司叫什么名字？
2. **产品描述**：你们主要做什么产品？
3. **目标国家**：想找哪个国家的客户？
4. **客户类型**：想找什么类型的客户？（经销商/代理商/批发商/OEM厂商等）

### 交互规则

- 凡是能用选项回答的问题，**必须使用 AskUserQuestion 弹窗**
- 必须用弹窗询问的典型问题：
  - 产品定位/档次（**多选 multiSelect**）：大众快时尚 / 中端市场 / 高端/设计师款
  - 目标客户类型（**多选 multiSelect**）：经销商 / 批发商 / 品牌/终端用户 / 零售商 / 其他
  - 目标市场/国家（**单选**，如果用户没明确说）：美国 / 德国 / 英国 / 泰国 / 日本 / 其他
- 开放性问题示例：公司名、公司英文名、具体产品关键词、特殊要求
- **禁止**：把选项写成普通文本列表让用户自由回复，必须弹窗选择
- 目标市场多选处理：如果用户选了多个国家，搜索时以第一个国家作为主要目标国家（用于 `target_country` 参数和输出命名），搜索词中覆盖所有选中国家

---

## P1.5 — 用户画像看板确认（基础信息收集完成后展示）

> 在 P1 的基础信息（公司名、产品、国家、客户类型、产品档次）全部收集完成后，**先不要直接进入搜索策略**，先用卡片把"用户画像"呈现给用户确认，再进入 P2。

1. **渲染用户画像看板（内联可视化卡片）**：
   - 先调用 `read_me`（加载 `diagram` / `mockup` / `interactive` / `chart` 任一模块）获取卡片样式规范。
   - 用 `show_widget` 渲染一张**内联 HTML 卡片**（深色背景，蓝色 `#3b82f6` 主色 + 白色文字 + 灰色 `#8b8fa3` 次要文字，圆角 10px），展示：
     - **您的公司名称**：`{company_name}`
     - **主营业务**：`{product_description}`
     - **客户类型**：`{customer_types}`（如 经销商 / 代理商）
     - **产品定位档次**：`{product_tier}`（用户选了"大众快时尚 / 中端市场 / 高端·设计师款"则展示；未选则不展示该字段）
     - **查找国家**：`{target_country}`
   - 卡片下方可附一行 **AI 补充建议**（可选，基于用户输入主动给出）：如"建议同时覆盖 X 国扩大线索池""该品类客户多为经销商，搜索词已侧重 distributors / wholesalers"等。
2. **确认弹窗（AskUserQuestion）**：卡片展示后，立即弹出确认：
   - 选项 1：**确认无误，继续生成搜索方案（推荐）**
   - 选项 2：**修改公司名称 / 主营业务**
   - 选项 3：**修改客户类型**
   - 选项 4：**修改查找国家**
3. **分支处理**：
   - 用户选"确认" → 进入 P2（生成搜索策略 + 现有"是否开始搜索"弹窗）。
   - 用户选"修改 XX" → 回到 P1 对应收集项重填该字段，重填后**重新渲染本画像卡片**确认，形成闭环。
4. **不要提及** `Python`、`脚本`、`JSON`、`卡片组件` 等技术词；用"这是您这次的画像，确认一下对不对"等自然语言。

---

## P2 — 搜索策略生成

- 使用 **Light 模式**，生成 4 个搜索词
- 同步生成 `search_queries_cn` 中英映射
- **不要展示积分消耗**
- 搜索词必须在确认弹窗前在对话中完整展示，让用户清楚知道会用哪些关键词去搜索
- 展示完搜索方案后，**必须使用 AskUserQuestion 弹窗**询问用户是否开始搜索：

```
是否开始搜索？
  1. 开始搜索（推荐）
  2. 调整搜索词
```

**禁止**：
- 不要写"约 X 积分"、"消耗 X 积分"、"X 分"
- 不要提供"换成 Standard 模式"的选项入口（如果用户明确说"不要 Light 模式"，才切换为 Standard/Deep 模式）
- 不要把"是否开始搜索"写成普通文本列表

### 配置文件模板

配置 JSON 的 **meta 中必须包含 `output_dir` 字段**，值为任务输出目录的完整绝对路径。`generate_outputs.py` 会从该字段决定最终产物写入哪个目录。如果缺少此字段或值为空，脚本会自动生成一个新目录名，导致同一任务的中间文件和最终交付物被拆分到两个不同目录。

```json
{
  "company_name": "公司名",
  "search_queries": ["query1", "query2"],
  "search_queries_cn": {"query1": "中文1"},
  "target_country": "germany",
  "search_depth": "basic",
  "search_mode": "light",
  "max_results": 20,
  "top_n_for_extract": 0,
  # ↑ 0 = 提取全部企业的网站内容（默认），正数=仅提取评分前 N 家
  "dedup_enabled": true,
  "product_description": "五金配件螺丝螺母"
}
```

---

## P3 — 执行搜索与结果处理

### 任务目录结构

每次搜索独立目录，所有产出物在一起：

```
output/日期_公司_国家/
├── .intermediate/                     ← 隐藏目录（中间文件）
│   ├── _config.json                   ← 搜索配置
│   ├── _search_out.json               ← 搜索结果原始数据
│   ├── _search_out_enriched.json      ← 富化后数据（含话术）
│   └── _crawl_progress.json           ← 爬虫进度（运行时）
├── 公司_目标标识_搜索结果.json        ← 最终交付物（JSON）
├── 公司_目标标识_客户清单.xlsx
├── 公司_目标标识_客户洞察看板.html
└── 公司_目标标识_客户沟通话术.md
```

- 路径：`~/.workbuddy/userdata/wxskill/overseas-customer-miner/output/日期_公司_国家/`
- userdata 根目录仅保留 `config.json`，**禁止写入任何中间文件**
- 目标标识（target_tag）：使用第一个搜索词的中文翻译前 20 字符，用于文件名

### 脚本调用

```bash
# macOS:
python3 tavily_customer_mine.py --config output/任务目录/.intermediate/_config.json \
  --output output/任务目录/.intermediate/_search_out.json

# Windows:
python tavily_customer_mine.py --config output\任务目录\.intermediate\_config.json \
  --output output\任务目录\.intermediate\_search_out.json
```

### 深度提取说明（2026-07-09 更新）

`top_n_for_extract` 参数默认值为 **0**，表示对全部有效企业调用 Tavily Extract API 获取网站内容并提取联系信息。

- `0` = 全部提取（当前默认值，最大化邮箱覆盖率）
- `正数` = 仅提取评分前 N 家（兼容旧配置）

> **设计背景**：Tavily Extract 能突破 WAF/Cloudflare 等安全防护屏障，对爬虫无法直接访问的网站有独特的获取能力。全量提取 + 爬虫互补的 A+B+C 方案可将邮箱覆盖率从 ~42% 提升至 ~78%。

---

## P4 — 去重与自动分类筛选

### 历史去重检查

> 2026-07-09 变更：无重复时自动跳过弹窗，减少用户干预。

AI 先读取去重结果，判断重复数量：

- **当 `dup_count = 0` 时**：直接告知用户"无历史重复客户，无需过滤"，**跳过弹窗**，直接进入分类筛选阶段。
- **当 `dup_count > 0` 时**：用 AskUserQuestion 弹窗询问：

  ```
  检查到历史记录中有 N 家已存在的企业。

  是否过滤已存在的重复客户？
    1. 是，过滤重复客户（推荐）
    2. 否，保留全部
  ```

### 结果分类（自动过滤）

调用 `generate_outputs.py --apply-filter`，脚本会自动：
1. 分类所有结果（company / directory / association / article / other）
2. **自动保留** `company`（企业）+ `association`（协会/机构）
3. **自动剔除** `article`（文章/资讯）、`directory`（名录/目录）、`other`（政府/教育/招聘网站）

直接告知用户结果：

```
分类完成！原始 XX 家，剔除 XX 家，保留 XX 家（企业 + 协会）。
```

**不要**在这个步骤之后做任何额外过滤。

### 脚本调用

```bash
# 仅分类统计
python generate_outputs.py --input result.json --classify-only

# 分类+自动过滤
python generate_outputs.py --input result.json --apply-filter
```

---

## P5 — 联系信息补充

### 自动获取联系信息（无需用户干预）

> 2026-07-09 变更：联系信息获取改为**自动执行**，不再弹窗询问用户，减少操作步骤。

AI 直接自动执行全部获取，并在对话中告知用户：

```
筛选后保留 32 家企业：
  📞 已有联系方式：4 家
  📧 已有邮箱：1 家
  🌐 有官网但缺少联系信息：28 家

正在自动深度获取企业联系信息，请稍候...
（前台实时处理，所有进度都会在对话中展示）
```

**行为规则**：
- 直接执行 `crawl_contacts.py --max 0`（全部获取），无需 AskUserQuestion 弹窗
- 运行完成后自动进入 P6 话术生成阶段

### 运行中状态提示

正确示例：
```
信息正在深度获取中，28 家企业排队处理...

> 说明：网络环境和企业网站响应速度差异较大，实际完成时间可能与预估存在偏差，请耐心等待。
```

**禁止**：
- 不要写"爬虫正在运行"、"爬取中"、"抓取中"
- 不要给出精确倒计时如"还剩 20 秒"、"预计 2-3 分钟"
- 如果必须给时间，用模糊表述如"需要几分钟"、"稍等片刻"

### 完成状态提示

> 2026-07-09 变更：过滤改为**自动执行**，不再弹窗询问用户，直接设置 `KEEP_ONLY_WITH_CONTACT=1` 仅保留有联系方式的企业。

```
信息获取完成！共补充 24 家企业的联系信息。

现在总共 28 家企业有联系方式（覆盖率 88%）。
已自动过滤无联系信息的企业，仅保留有联系方式的进入最终产出。
```

**行为规则**：
- 自动设置 `KEEP_ONLY_WITH_CONTACT=1`，运行 `generate_outputs.py`
- 无需 AskUserQuestion 弹窗，直接生成最终产出（Excel / HTML / MD）

### 脚本调用

```bash
python crawl_contacts.py --input result.json --output result.json --max 10
```

### 爬取策略说明（2026-07-09 更新）

- **触发条件**：有官网且**缺少邮箱**的企业即触发爬取（不再要求电话也缺失），因为海外获客邮箱价值远大于电话
- **爬取页面**：首页 + `/about` + `/contact` + `/contact-us` + `/team` + `/our-team` + `/management`，共 7 个页面
- **覆盖提升**：团队/管理层页面常包含 `sales@`、`info@` 等公开联系邮箱，对 B2B 获客价值很高

---

## P6 — 话术生成与最终输出

### 个性化话术生成

读取 `.intermediate/_search_out.json`，对**每家**企业，结合其 `company_name`、`content_summary`、`website` 以及用户最初的产品描述，用 LLM 生成英文 `pitch_email` 和 `pitch_phone`，写入到 `.intermediate/_search_out_enriched.json`。

关键：每家话术必须不同，用到企业具体业务信息。

### 运行输出生成脚本

```bash
python generate_outputs.py --input output/任务目录/.intermediate/_search_out_enriched.json
```

### 输出规范

输出 **3 份**交付文件，全部归档到 `output/日期_公司_国家/` 目录：

1. **Excel**（`{公司}_{目标标识}_客户清单.xlsx`）：结构化表格，包含公司名、官网、联系电话、邮箱、国家、评分、优先级，以及邮件话术、电话话术两列
2. **HTML**（`{公司}_{目标标识}_客户洞察看板.html`）：Chart.js 可视化仪表盘，详见下方样式规范
3. **MD**（`{公司}_{目标标识}_客户沟通话术.md`）：按优先级（P1→P2→P3）排列的完整话术文档

### 写入历史记录

运行完成后，将本轮搜索信息写入 `config.json` 的 `last_search` 字段，下次对话可快捷复用：

```json
"last_search": {
  "company_name": "用户输入的公司名",
  "product_description": "用户输入的产品描述",
  "target_country": "用户输入的目标国家",
  "searched_at": "当前时间，ISO 8601 格式"
}
```

保持 `config.json` 中原有的 `translation`、`notification_emails` 等字段不变。

### HTML 看板样式规范

| 元素 | 样式 |
|------|------|
| 页面背景 | `#0f1117`（深灰黑） |
| 卡片背景 | `#1a1d27` |
| 卡片边框 | `#2a2e3a` |
| 主文字色 | `#e1e4ea`（浅灰白） |
| 次要文字色 | `#8b8fa3` |
| 强调色/链接 | `#3b82f6`（蓝色） |
| P1 高优先级 | `#ef4444`（红色） |
| P2 中优先级 | `#f59e0b`（琥珀色/橙色） |
| P3 低优先级 | `#6b7280`（灰色） |
| 有联系信息 | `#22c55e`（绿色） |
| 卡片圆角 | `10px` |
| 阴影 | 浅阴影（border 过渡 hover 时高亮边框） |
| 统计指标 | 5 张卡片（客户总数、P1 高优先级、P2 中优先级、P3 低优先级、有联系信息） |
| 图表 | 2 个 Chart.js 环形图（doughnut）：优先级分布 + 联系信息完整度 |
| 客户卡片 | 白色圆角 10px，含名称、badge 标签、联系信息网格、话术展开按钮 |
| 话术展示 | 按钮切换（toggle），展开后为蓝色浅底边框块，非引号边框 |
| 表格 | 深色表头，无斑马纹（`:nth-child` 未使用） |
| 页面标题 | 《海外客户洞察》 |
| 过滤器 | 优先级筛选项：`P1 高优 / P2 中等 / P3 参考` |

### 文件展示规范（关键 — 复制到工作目录 + present_files）

1. 从脚本 stdout 解析 `__OUTPUT_FILES__:` JSON 行，提取 excel / html / md 的完整路径
2. **复制到当前工作目录**：用 Bash 工具执行 `cp <原始路径> ./`，保持文件名不变
3. 调用 `present_files`：files 按 HTML → Excel → MD 顺序传入
4. 文字回复仅用一句业务语言告知结果，不需要 markdown 链接或路径文字

---

## P7 — 交付展示与后续引导

### 交付流程

1. 确认 3 份文件均已生成（Excel / HTML / MD）
2. 执行文件复制到工作目录 + present_files（见上方规范）
3. 展示完成后，输出以下引导：

```
客户挖掘完成！共找到 N 家企业，已为你准备好以下资料：
  📊 客户清单（Excel）—— 便于筛选和跟进
  📈 洞察看板（HTML）—— 可视化分析概览
  📝 沟通话术（MD）—— 每家的邮件/电话话术

接下来你可以：
① 换个国家或关键词继续挖掘
② 调整筛选条件重新生成
③ 对特定企业进行深入调研（如需深度调研，可配合「客户洞察与售前报告」使用）
你想做什么？
```

### 设计原则

- 每次 3-4 个选项，不超过 5 个
- 选项递进关系：挖掘 → 分析 → 行动
- 用户回答后进入对应子流程

---

## P8 — 搜索计划管理后台

### 触发词

当用户说以下任何一句话时，启动管理后台（端口 5679）：
> 打开管理后台、打开控制台、启动面板、查看计划列表、查看我的计划、显示搜索计划、打开计划面板、启动服务、启动后台、启动调度器

当用户说以下任何一句话时，关闭管理后台：
> 关闭管理后台、关闭控制台、停止服务、停止后台、关闭调度器、停止调度器

### 启动逻辑

```
用户说"打开管理后台"
        │
        ▼
检查端口 5679 是否已被占用
        │
        ├── 已占用 → present_files(http://localhost:5679)
        │            回复"管理后台已在运行，已为您打开"
        │
        └── 未占用 → 后台启动 python scripts/scheduler_server.py --port 5679
                     等待 2 秒 → 重新检查端口
                     ├── 成功 → present_files(http://localhost:5679)
                     └── 失败 → 回复错误信息及解决建议
```

### 关闭逻辑

```
用户说"关闭管理后台" → 查找 scheduler_server.py 进程 → 发送终止信号
→ 确认端口已释放 → 回复"管理后台已关闭"
```

### 可配置项

| 功能 | 说明 |
|------|------|
| 查看搜索计划列表 | 显示所有已配置的计划 |
| 新建定时搜索任务 | 设定搜索词、国家、频率 |
| 查看执行记录 | 历史执行列表及结果下载 |
| 配置邮件推送 | 设置 SMTP 和接收邮箱 |
| API Key 管理 | 在设置页更新 Tavily Key |

### 脚本路径

```
scripts/scheduler_server.py    ← Flask 服务（端口 5679）
scripts/dashboard.html         ← 单页管理后台（自动加载）
```

---

## P9 — 自动化任务（WorkBuddy 调度系统 · 独立模式）

### P9.1 概述

自动化任务允许用户在对话中用一句话创建定时执行的海外客户搜索，系统将在指定时间自动运行完整的搜索流水线并产出结果。

**适用场景**：
- 每周固定时间自动搜索（如"每周一上午9点搜德国的汽车零件客户"）
- 多个国家的定期客户挖掘（如"每月1号搜日本/每月15号搜德国"）
- 无人值守的定时交付

**架构**：使用 WorkBuddy 内置的 `automation_update` 工具创建定时任务，自动化触发时直接调用脚本链执行搜索，**不依赖 Flask 管理后台服务**。

### 前置规则（自动化任务执行前必须检查）

自动化任务触发时，**必须先执行以下前置校验**，任何一项不通过则终止执行并提示用户：

| 校验项 | 检查方式 | 未通过处理 |
|:-------|:---------|:-----------|
| **Tavily API Key** | 读取 `config.json` 的 `tavily_api_key` 字段或 `.env.tavily` 文件 | 终止执行，报告"搜索服务的密钥未配置，请在对话中说'配置密钥'来设置" |
| **Python 依赖** | 尝试 import requests, openpyxl, jinja2 等核心依赖 | 自动运行 `install_deps.bat`（Windows）或 `install_deps.sh`（macOS/Linux）安装（约 30-60 秒） |

> **重要**：API Key 检查是自动化任务的**硬性前置条件**。如果未配置密钥，自动化任务不会继续执行搜索，而是终止并等待用户配置。用户可在对话中对专家说"配置密钥"完成设置。

```
用户说"每周一上午9点自动搜索德国的汽车零部件经销商"
    │
    ▼
WorkBuddy 自动化系统 (automation_update)
    │  scheduleType="recurring", rrule="FREQ=WEEKLY;BYDAY=MO;BYHOUR=9;BYMINUTE=0"
    ▼
自动化触发时，AI 按 P9.4 流水线直接执行脚本链
    │
    ├── 1. 检查 API Key 配置
    ├── 2. 搜索词轮转（从词池中按轮转索引取 4 组，避免与前 N 次重复）
    ├── 3. 构建搜索配置 JSON
    ├── 4. 运行 tavily_customer_mine.py（搜索）
    ├── 5. 运行 generate_outputs.py --apply-filter（分类过滤）
    ├── 6. 运行 crawl_contacts.py（联系信息获取）
    ├── 7. 运行 generate_outputs.py（生成 Excel/HTML/MD 产出）
    └── 8. 展示结果 + 更新索引 + 更新搜索词轮转记录
```

### P9.2 用户触发方式

用户在对话中说以下任何一句话时，创建自动化任务：

| 用户意图 | 示例 |
|---------|------|
| 定时搜索 | "每周一上午9点帮我搜索德国的汽车零件经销商客户" |
| 定期执行 | "每月1号自动跑一次日本的车载电子客户搜索" |
| 不重复执行 | "下周三下午3点执行一次美国客户搜索" |
| 修改计划 | "把德国搜索改成每两周一次" |
| 查看任务 | "查看我的自动化任务列表" |
| 删除任务 | "删除德国搜索的自动化任务" |

**对话示例**：

```
用户：每周一搜索德国的汽车零件经销商客户
  ↓
AI：好的！配置如下，确认后我将创建定时任务：
  🏢 公司/产品：汽车零部件（待补充）
  🌍 目标国家：德国
  🏷️ 客户类型：经销商
  🔁 频率：每周一
  ⏰ 时间：09:00
  📊 搜索结果范围：适中
  📋 联系方式获取：全部（仅保留有联系方式的企业）
  💬 自动生成话术：是

  是否确认创建这个自动化任务？
  [确认创建] [修改参数]
```

### P9.3 自动化 Prompt 模板

创建自动化任务时，使用以下模板作为 prompt（其中的 `{{变量}}` 在创建时替换为实际值）：

```
执行海外客户挖掘自动化任务。请严格按以下步骤执行：

# ── 0. 任务参数（不要询问用户，直接使用） ──
公司名称: {{company_name}}
产品描述: {{product_description}}
目标国家: {{target_country}}
客户类型: {{customer_types}}
联系方式获取: 全部（默认全部获取，产出仅保留有联系方式的企业）
生成话术: 是（默认生成模板化话术）

# ── 1. 加载 SKILL 并检查环境 ──
- 加载 tavily-customer-miner skill
- 读取 ~/.workbuddy/userdata/wxskill/overseas-customer-miner/config.json，检查 tavily_api_key 是否存在
- 如果 API Key 缺失，终止并报告"API Key 未配置，请先在设置页或对话中配置搜索服务的密钥"
- 检查 scripts/requirements.txt 依赖是否已安装（有 import errors 则安装，约 30-60 秒）
  - 安装过程中如果会话自动结束，重新进入对话点击"继续"即可恢复
- 检查当前操作系统类型：
  - Windows：脚本路径用反斜杠 `\`，python 命令用 `python`
  - macOS/Linux：脚本路径用正斜杠 `/`，python 命令用 `python3`

# ── 2. 搜索词轮转生成（避免每次重复，降低搜索结果重合度）──

读取轮转记录文件：
  rotation_file = "~/.workbuddy/userdata/wxskill/overseas-customer-miner/auto_query_rotation.json"

如果文件不存在，初始化为：
  {{
    "{{任务名称}}": {{
      "product": "{{product_description}}",
      "country": "{{target_country}}",
      "rotation_index": 0,
      "total_cycles": 0
    }}
  }}

使用以下 12 组搜索角度词池，按轮转索引取 4 组：

搜索词池（12 组不同角度）：
  Angle 0:  产品关键词 + "distributors" + 国家名（寻找经销商）
  Angle 1:  产品关键词 + "wholesalers" + 国家名（寻找批发商）
  Angle 2:  产品关键词 + "suppliers" + 国家名（寻找供应商）
  Angle 3:  产品关键词 + "importers" + 国家名（寻找进口商）
  Angle 4:  产品关键词 + "buyers" + 国家名（寻找采购商）
  Angle 5:  产品关键词 + "retailers" + 国家名（寻找零售商）
  Angle 6:  产品关键词 + "dealers" + 国家名（寻找经销商/代理商）
  Angle 7:  产品关键词 + "manufacturers of" + 产品名（寻找同类产品制造商）
  Angle 8:  客户类型词 + 产品关键词 + 国家名（精准客户类型匹配）
  Angle 9:  行业总称 + "companies in" + 国家名 + 城市/区域（区域覆盖）
  Angle 10: 产品关键词 + "market" + 国家名 + "leaders"（市场领导者/头部企业）
  Angle 11: 产品关键词 + "trading" + 国家名 + "companies"（贸易公司）

轮转逻辑：
  - 从 rotation_index 开始，取 Angle N, N+1, N+2, N+3（模 12 循环）
  - 例：rotation_index=0 → 取 Angle 0,1,2,3；rotation_index=4 → 取 Angle 4,5,6,7
  - 每执行一次，rotation_index = (rotation_index + 4) % 12，total_cycles += 1
  - 每完成 3 个完整轮次（total_cycles ≥ 3），所有角度加时间限定词重新生效，重置 rotation_index=0
  - 每个角度需生成 2 个搜索词：1 个英文 + 1 个目标国家本地语言
  - 同时生成 search_queries_cn 中英映射

写入轮转记录文件：
  - 更新 rotation_index 和 total_cycles
  - 记录本次使用的搜索词到 last_used_queries
  - 记录 last_updated 时间

输出本次 4 组搜索词（共 8 个，4 英 + 4 当地语言）：
  - 在搜索结果报告中展示使用的搜索词

# ── 3. 构建搜索配置 ──
- 创建临时目录：output_dir = os.path.expanduser("~/.workbuddy/userdata/wxskill/overseas-customer-miner/output/")

- 创建本次任务目录：task_dir = output_dir + "{日期}_{公司}_{国家}/"（日期格式 YYYYMMDD）
- 创建 .intermediate/ 子目录
- 生成 _config.json：
  {{
    "company_name": "{company_name}",
    "product_description": "{product_description}",
    "search_queries": ["搜索词1", "搜索词2", ...],
    "search_queries_cn": {{"词1": "中文1", "词2": "中文2"}},
    "target_country": "{target_country}",
    "customer_types": "{customer_types}",
    "search_depth": "{search_depth}",
    "search_mode": "light",
    "max_results": {max_results},
    "top_n_for_extract": 0,        # 0=全部提取（当前默认）
    "dedup_enabled": true,
    "meta": {{
      "output_dir": "{任务目录完整绝对路径}"
    }}
  }}

- meta 中必须包含 output_dir 字段，值为任务输出目录的完整绝对路径

# ── 4. 执行搜索（tavily_customer_mine.py）──
- 切换工作目录到 tavily-customer-miner/scripts/
- 运行：
  python tavily_customer_mine.py --config {_config.json路径} --output {_search_out.json路径}
- 检查退出码和 stdout
- 如果失败，重试 1 次后仍失败则终止

# ── 5. 分类+自动过滤（generate_outputs.py --apply-filter）──
- 运行：
  python generate_outputs.py --input {_search_out.json路径} --apply-filter
- 脚本会自动分类并保留 company + association
- 记录过滤结果（原始数、剔除数、保留数）

# ── 6. 去重检查 ──
- 读取 ~/.workbuddy/userdata/wxskill/overseas-customer-miner/dedup_index.json
- 如果存在，对搜索结果做 URL 去重
- 更新 dedup_index.json（保留最近 100 条运行记录）

# ── 7. 联系信息获取（crawl_contacts.py）──
- 运行：
  python crawl_contacts.py --input {_search_out.json路径} --output {_search_out.json路径} --max 0
- 检查退出码，超时 10 分钟
- 记录获取到的联系方式数量

# ── 8. 生成最终产出（generate_outputs.py）──
- 由于自动化模式下没有 AI 逐家生成个性化话术，generate_outputs.py 会自动为每个企业生成模板话术（脚本内置兜底逻辑）
- **关键**：设置 KEEP_ONLY_WITH_CONTACT=1，仅保留有联系方式的企业
- 运行：
  KEEP_ONLY_WITH_CONTACT=1 python generate_outputs.py --input {_search_out.json路径}
  （Windows 上用：set KEEP_ONLY_WITH_CONTACT=1 && python generate_outputs.py --input {_search_out.json路径}）
- 从 stdout 解析 __OUTPUT_FILES__: JSON 行，提取 excel/html/md 文件路径

# ── 9. 清理和收尾 ──
- **获取当前工作目录**：用 Bash 执行 `pwd`（macOS/Linux）或 `cd`（Windows），获取自动化配置的 cwds 工作目录路径，记为 `{workspace_dir}`
- 创建时间戳子目录：生成当前时间的 `YYYY-MM-DD-HH-MM-SS` 格式字符串（如 `2026-07-09-09-30-59`），记为 `{timestamp}`
  用 Bash 执行：mkdir -p {workspace_dir}/{timestamp}
- 从 __OUTPUT_FILES__ 解析的路径中，逐一复制 3 份产出文件到该子目录：
  用 Bash 执行：cp <源excel路径> {workspace_dir}/{timestamp}/ && cp <源html路径> {workspace_dir}/{timestamp}/ && cp <源md路径> {workspace_dir}/{timestamp}/
- 用 present_files 展示结果（使用子目录中的副本路径）
- 更新 ~/.workbuddy/skill_data_index.json 产出路径
- 更新 ~/.workbuddy/userdata/wxskill/overseas-customer-miner/config.json 的 last_search 字段

# ── 10. 结果报告 ──
在文字回复中报告：
✅ 自动化任务执行完成！
  - 公司/产品：{company_name}
  - 目标国家：{target_country}
  - 搜索词使用：X 组
  - 结果数量：保留 X 家企业，获取 X 家联系方式
  - 产出文件路径：{paths}
```

### P9.4 完整流水线示意

```
Step 1: 前置校验（硬性条件，不通过则终止）
  ├── 读取 tavily_api_key / .env.tavily → 检查 API Key
  │   ├── 已配置 → 继续执行
  │   └── 未配置 → 终止，提示"搜索服务的密钥未配置"
  └── 检查 Python 依赖
      ├── 已安装 → 继续
      └── 未安装 → 自动安装依赖（约 30-60 秒，安装过程中如会话中断请点击"继续"恢复）

Step 2: 搜索词轮转生成（降低重复率）
  ├── 读取 auto_query_rotation.json 轮转记录
  ├── 从 12 组搜索角度词池中，按 rotation_index 取 4 组
  ├── 每组生成 2 个词（英文 + 本地语言）
  └── 执行后更新 rotation_index = (index + 4) % 12

Step 3: 配置构建
  ├── 创建任务目录 output/YYYYMMDD_公司_国家/
  └── 写入 .intermediate/_config.json（含轮转后的搜索词）

Step 4: 搜索执行
  └── tavily_customer_mine.py --config config --output search_out

Step 5: 分类过滤
  └── generate_outputs.py --input search_out --apply-filter
      ├── 自动保留 company + association
      └── 自动剔除 article + directory + other

Step 6: 去重
  └── 对比 dedup_index.json URL 去重

Step 7: 联系信息获取
  └── crawl_contacts.py --input search_out --output search_out --max 0
      ├── 全部获取（自动化默认获取全部）
      └── 耗时较长（根据企业数量而定）

Step 8: 产出生成（仅保留有联系方式的企业）
  └── KEEP_ONLY_WITH_CONTACT=1 generate_outputs.py --input search_out
      ├── 自动生成模板化话术（兜底机制）
      ├── 自动过滤无联系方式的客户
      ├── 产出 Excel 客户清单.xlsx
      ├── 产出 HTML 洞察看板.html
      └── 产出 MD 沟通话术.md

Step 9: 交付展示 + 更新轮转
  ├── present_files（HTML / Excel / MD）
  ├── 更新 skill_data_index.json
  ├── 更新 config.json 的 last_search
  └── 更新 auto_query_rotation.json（rotation_index + 本次搜索词）
```

### P9.5 参数映射

| 自动化参数 | 说明 | 默认值 |
|-----------|------|--------|
| `company_name` | 公司名（用于话术和产出文件名） | 必填 |
| `product_description` | 产品描述（用于搜索词和话术） | 必填 |
| `target_country` | 目标国家（英文） | 必填 |
| `customer_types` | 客户类型（如经销商/批发商等） | 经销商 |
| `search_queries` | 搜索词列表（4-8 个） | 自动生成 |
| `search_depth` | 搜索深度：`fast` / `basic` / `advanced` | `basic` |
| `max_results` | 每个搜索词最大结果数 | 20 |
| `max_crawl` | 联系方式获取数：0=全部获取 | 0 |
| `keep_only_contact` | 产出仅保留有联系方式的企业 | 是（KEEP_ONLY_WITH_CONTACT=1） |
| `generate_pitch` | 是否生成话术 | 是 |

### P9.6 创建自动化任务示例

#### 示例 1：每周一搜索德国汽车零件经销商

```json
{
  "name": "德国汽车零件客户-每周一",
  "scheduleType": "recurring",
  "rrule": "FREQ=WEEKLY;BYDAY=MO;BYHOUR=9;BYMINUTE=0",
  "prompt": "执行海外客户挖掘自动化任务。\n\n任务参数：\n公司名称: AutoTeile GmbH\n产品描述: 汽车零部件、发动机配件、刹车系统\n目标国家: germany\n客户类型: 经销商, 批发商\n搜索词: [\"Germany auto parts distributors\", \"汽车配件经销商 德国\", \"Germany car spare parts wholesalers\", \"德国汽配批发商\"]\n联系方式获取: 全部（仅保留有联系方式的企业）\n\n请加载 tavily-customer-miner skill，按 P9.3 的流水线步骤执行完整搜索。",
  "cwds": "E:\\workbuddyproject\\overseas-customer-miner-skill"
}
```

#### 示例 2：每月 1 号搜索日本电子元器件客户

```json
{
  "name": "日本电子元器件客户-每月1号",
  "scheduleType": "recurring",
  "rrule": "FREQ=MONTHLY;BYMONTHDAY=1;BYHOUR=10;BYMINUTE=0",
  "prompt": "执行海外客户挖掘自动化任务。\n\n任务参数：\n公司名称: Shenzhen Electronics Co., Ltd\n产品描述: 电子元器件、PCB电路板、半导体\n目标国家: japan\n客户类型: 经销商, OEM厂商\n搜索词: [\"Japan electronics components distributors\", \"日本电子元器件经销商\", \"Japan PCB manufacturers\", \"日本PCB制造商\"]\n联系方式获取: all\n\n请加载 tavily-customer-miner skill，按 P9.3 的流水线步骤执行完整搜索。",
  "cwds": "E:\\workbuddyproject\\overseas-customer-miner-skill"
}
```

#### 示例 3：一次性的英国客户搜索

```json
{
  "name": "英国医疗器械-单次",
  "scheduleType": "once",
  "scheduledAt": "2026-07-15T14:00",
  "prompt": "执行海外客户挖掘自动化任务。\n\n任务参数：\n公司名称: MedTech Ltd\n产品描述: 医疗器械、医疗耗材、手术器械\n目标国家: united kingdom\n客户类型: 经销商, 医院供应商\n搜索词: [\"UK medical device distributors\", \"英国医疗器械经销商\", \"UK hospital suppliers\", \"英国医院供应商\"]\n联系方式获取: 全部（仅保留有联系方式的企业）\n\n请加载 tavily-customer-miner skill，按 P9.3 的流水线步骤执行完整搜索。",
  "cwds": "E:\\workbuddyproject\\overseas-customer-miner-skill"
}
```

### P9.7 对话中创建自动化的操作流程

当用户在对话中提出自动化需求时，AI 执行以下流程：

```
用户说"每周一搜索德国的汽车零件客户"
    │
    ▼
Step A: 解析需求
    ├── 提取公司名/产品（如未提供则补充询问）
    ├── 提取目标国家 → 映射为英文代码（如 germany）
    ├── 提取客户类型
    ├── 提取频率和时间（每周一 09:00）
    └── 提取搜索范围（默认适中/light 模式）

    ▼
Step B: 生成搜索词（Light 模式，4 个词）
    ├── 根据公司产品 + 目标国家 + 客户类型
    └── 自动生成 search_queries + search_queries_cn

    ▼
Step C: 展示配置并确认
    ├── 用业务语言展示完整配置
    └── AskUserQuestion 弹窗：[确认创建] [修改参数]

    ▼
Step D: 创建自动化任务
    ├── 使用 automation_update(mode="create", ...)
    ├── 设置 scheduleType、rrule 或 scheduledAt
    ├── 填写完整的 prompt（替换为实际参数）
    └── 设置 cwds 为项目根目录

    ▼
Step E: 回复用户
    ├── "✅ 自动化任务已创建成功！每周一 09:00 我将自动搜索 {国家} 的 {客户类型} 客户。"
    ├── "首次执行时间：{下次执行时间}"
    └── "你可以随时对我说：查看自动化任务 / 删除这个任务 / 修改参数"
```

### P9.8 自动化任务管理（用户可执行的对话操作）

| 用户说 | AI 执行 |
|--------|---------|
| "查看我的自动化任务" | 调用 automation_update(mode="list")，展示所有自动化任务及其下次执行时间 |
| "查看XX任务的详情" | 调用 automation_update(mode="view", id="任务ID") |
| "删除XX自动化任务" | 调用 automation_update(mode="delete", id="任务ID") |
| "暂停XX任务" | 调用 automation_update(mode="update", id="任务ID", status="PAUSED") |
| "恢复XX任务" | 调用 automation_update(mode="update", id="任务ID", status="ACTIVE") |
| "查询执行历史" | 查看 search_plans/logs/ 目录下对应的执行日志 |

### P9.9 自动化模式 vs 对话模式差异

| 维度 | 对话模式（P1-P7） | 自动化模式（P9） |
|:----:|:-----------------:|:----------------:|
| 用户交互 | 全程实时交互，弹窗确认每一步 | 无用户交互，配置在创建时确定 |
| 话术生成 | AI 逐家生成个性化话术 | `generate_outputs.py` 模板化兜底话术 |
| 去重检查 | 弹窗询问是否过滤重复 | 自动去重（dedup_index.json） |
| 联系方式获取 | 弹窗选择范围 | 全部获取 + 仅保留有联系方式的企业 |
| 结果交付 | present_files 展示 | present_files 展示 |
| 失败处理 | AI 实时汇报并询问下一步 | AI 自动重试 1 次，失败后报告错误 |

### P9.10 自动化任务维护要点

1. **必须配置 API Key**（硬性前置条件）：自动化任务触发时会自动校验 `tavily_api_key` 是否已配置。如果未配置，任务会终止执行并提示用户。请在创建自动化前在对话中对专家说"配置密钥"来设置
2. **依赖安装**：首次使用需确保 Python 依赖已安装（运行 `install_deps.bat` 或 `install_deps.sh`）
3. **网络环境**：自动化执行需要网络连通（搜索 API + 目标网站爬取）
4. **执行时间**：每次完整执行约 3-10 分钟（取决于结果数量和联系方式获取范围）
5. **日志查看**：执行日志和产出文件在 `~/.workbuddy/userdata/wxskill/overseas-customer-miner/output/` 目录下
6. **跨 Skill 联动**：自动化执行完成后会自动更新 `~/.workbuddy/skill_data_index.json`，可供 mail-sender-skill 等消费方使用

---

## 配置检查与 API Key 管理

### 实际配置路径

对话式 API Key 配置通过 `configure_key.py` 管理，使用 `.env.tavily` 文件存储。`config.json` 中的 `tavily_api_key` 字段仅由管理后台（scheduler_server）使用。

### 检查流程（首次使用 — 2026-07-14 优化：快速引导，不做联网校验）

> **原则**：新装 / 重装时不做任何联网校验、不预先安装依赖，本地未配置就立即引导输入 Key。Key 有效性推迟到首次真实搜索时验证。

1. 运行 `python scripts/configure_key.py --check`（**纯本地**读取 `.env.tavily`，判断是否存在且以 `tvly-` 开头，**不联网**，瞬时返回）。
   - 返回 `configured: true` → 跳过本步。
2. 返回 `configured: false` → **立即引导输入，不等依赖、不等网络**：
   - 告知用户："第一次使用需要配置搜索服务的密钥，请把你申请的 Key 粘贴到下方即可。"
   - 使用 AskUserQuestion 弹窗，提供选项：
     - "我已有 Key"（用户在"其他"文本框中粘贴 Key）
     - "我还没有 Key，教我怎么申请"（引导查看 Tavily API Key 申请指南文档 `tavily_api_key_guide.md`）
   - 运行 `python scripts/configure_key.py --key <用户粘贴的Key>`
3. **禁止**在配置阶段调用 `validate_setup.py` 或向 `api.tavily.com` 发请求验证 Key 有效性（国内网络易超时，拖慢首次引导）。
4. **依赖安装推迟**：不在首次对话一开始就安装 Python 依赖，推迟到首次真实搜索前按需安装（多数环境已预装）；安装时用"正在准备运行环境，请稍候"等自然语言。
5. **惰性校验**：Key 是否有效在首次执行 `tavily_customer_mine.py` 搜索请求时验证；若返回 401，提示用户"密钥似乎无效，请说'重新配置密钥'后粘贴正确 Key"并回到配置流程。
6. **不要提及** `Python`、`脚本`、`配置文件`、`Tavily` 等专业术语。

### 依赖检查（2026-07-14 优化：推迟到首次搜索前）

- **不再在首次对话一开始就安装依赖**，改为推迟到"首次真实搜索前"按需安装，避免新装 / 重装时白等 30-60 秒。
- 核心依赖仅 requests + pandas + openpyxl + jinja2（约 30-60 秒安装完成，多数环境已预装）。
- 未安装 → 自动运行 `scripts/install_deps.bat`（Windows）或 `scripts/install_deps.sh`（macOS/Linux）。
- 安装时用"正在准备运行环境，请稍候"等自然语言，**不要说"下载大文件"**。
- **注意**：安装过程中如果会话自动结束，重新进入对话点击"继续"即可恢复，不会丢失进度

---

## 三种运行模式说明

系统内置三种运行模式，对应不同场景下的积分成本与邮箱覆盖率权衡。**当前默认使用「全面覆盖模式」**（A+B+C 全量方案，2026-07-09 更新）。

### 模式对比总览

| 维度 | ① 全面覆盖（当前） | ② 成本均衡 | ③ 快速预览 |
|:----:|:-----------------:|:----------:|:----------:|
| **适用场景** | 最大化邮箱覆盖率 | 日常搜索，兼顾成本和质量 | 快速验证市场，低积分消耗 |
| **Tavily Extract 范围** | 全部有效企业 | 评分前 15 家 | 评分前 15 家 |
| **爬虫页面数** | 7 页（含团队页） | 7 页（含团队页） | 4 页（基础版） |
| **爬取触发条件** | 只要缺邮箱就爬 | 只要缺邮箱就爬 | 缺电话且缺邮箱才爬 |
| **预期邮箱覆盖率** | **~78%** | **~62%** | **~42%** |
| **预期积分/次** | ~45 分 | ~22 分 | ~21 分 |

### 模式①：全面覆盖模式（当前默认）

`top_n_for_extract: 0` + 7页面爬虫 + 以邮箱缺失为爬取条件

- 对企业官网进行 Tavily Extract 全量提取（突破 WAF 屏障）
- 爬虫搜索首页、About、Contact、Contact-Us、Team、Our-Team、Management 共 7 个页面
- 只要企业缺少邮箱（无论是否有电话），爬虫即进行补充
- **积分消耗最高，但邮箱覆盖率也最高**

### 模式②：成本均衡模式

`top_n_for_extract: 15` + 7页面爬虫 + 以邮箱缺失为爬取条件

- 仅对评分最高的 15 家企业进行 Tavily Extract 深度提取
- 爬虫同样搜索 7 个页面，按邮箱缺失触发
- 积分消耗与当前基本持平，覆盖率通过扩展页面和触发条件获得显著提升
- **性价比较高的日常选择**

### 模式③：快速预览模式

`top_n_for_extract: 10` + 4页面爬虫 + 旧条件（缺电话且缺邮箱才爬）

- 原始方案，与 2026-07-08 之前的系统行为一致
- 仅对少数高评分企业进行深度提取
- 爬虫仅搜索 4 个基础页面，且只对完全无联系信息的企业爬取
- **积分消耗最低，适合快速验证一个市场的客户存在性**

### 模式切换方式

在搜索配置的 `_config.json` 中调整以下参数：

```json
{
  "top_n_for_extract": 0,          // ①全面:0  ②均衡:15  ③预览:10
  "crawl_paths_extended": true,    // ①true  ②true  ③false
  "crawl_only_missing_email": true // ①true  ②true  ③false
}
```

> 当前默认配置：`top_n_for_extract: 0`（在 `tavily_customer_mine.py` 中硬默认），
> 7 页面爬虫（在 `crawl_contacts.py` 中硬编码），
> 仅缺邮箱条件（在 `crawl_contacts.py` 中硬编码）。

---

## 禁止技术术语

用户是普通外贸业务人员，对话中严禁出现：
- `Python`、`脚本`、`代码`、`程序`
- `JSON`、`数据文件`
- `编码问题`、`UTF-8`、`GBK`
- `API`、`接口`、`请求`
- `爬虫`、`抓取`、`爬取`
- `进程`、`线程`、`锁`
- `Tavily`（统一用"搜索引擎"或"搜索服务"代替）
- `兜底`、`fallback`（统一用"备用方案"代替）

所有技术操作都在后台完成，对用户只描述业务进展。

---

## 用户操作接口速查表

| 用户说 | 实际响应 |
|--------|---------|
| "换个国家搜索" | 回到 P1，修改目标国家，保持产品描述不变，重新生成搜索策略 |
| "换一组关键词" | 回到 P2，重新生成搜索策略（4 个搜索词），保持国家/产品不变 |
| "只看有联系方式的" | 设置 `KEEP_ONLY_WITH_CONTACT=1`，重新运行 `generate_outputs.py` 过滤 |
| "重新配置" / "换一个 Key" | 运行 `configure_key.py` 重新配置 API Key |
| "验证配置" | 运行 `configure_key.py --check` 检查 `.env.tavily` 状态 |
| "打开管理后台" | 启动 `scheduler_server.py`（端口 5679），打开管理后台 |
| "关闭管理后台" | 停止 `scheduler_server.py` 进程 |
| "修改部分信息" | 进入 P0.5 "修改"分支，调整上次搜索参数 |
| "沿用上次的" | 直接使用 `config.json` 中的 `last_search` 继续搜索 |

---

## 直接执行脚本（仅高级/调试场景）

搜索脚本：
```bash
python tavily_customer_mine.py --config config.json --output result.json
```

联系信息补充：
```bash
python crawl_contacts.py --input result.json --output result.json
```

生成交付文件：
```bash
python generate_outputs.py --input result.json
```

仅分类统计：
```bash
python generate_outputs.py --input result.json --classify-only
```

分类+自动过滤：
```bash
python generate_outputs.py --input result.json --apply-filter
```

---

## 分类决策记录（2026-07-03 确认）

此记录防止后续迭代遗忘/误改分类逻辑。

### 自动保留的类型（不再弹窗询问用户）

| 保留 | 类型 | 说明 |
|:----:|:----:|:----:|
| ✅ | **company** 企业 | 核心目标客户，必须保留 |
| ❌ | **directory** 名录/目录 | 名录/黄页/B2B平台，非目标客户，自动剔除（如需放开可改）
| ✅ | **association** 协会/机构 | 行业协会，可辅助拓展客户 |
| ❌ | **article** 文章/资讯 | 新闻博客，非客户，自动剔除 |
| ❌ | **other** 政府/教育/招聘网站 | 非客户，自动剔除 |

### 分类命中规则

- **government/education**: `.gov`、`.edu` → other（单次命中）
- **association**: 强词（association/society/chamber 等 11 个）单次命中；弱词（institute/organization/committee/standards）需 ≥2 个
- **article**: 17 个关键词需 ≥2 个命中
- **directory**: 强词（list of/directory/manufacturers in/companies in/companies near）单次命中；弱词（top /best /leading /suppliers）需 ≥2 个；名称/描述含自述词（we are/our/we provide 等）跳过 directory
- **job/recruitment**: URL 招聘域名 / 公司名含 recruitment/staffing / 描述中招聘词 ≥3 个 → other
- **company**: 以上都不满足的兜底

### 联系信息过滤规则（2026-07-03 确认）

`generate_outputs.py` 中 `KEEP_ONLY_WITH_CONTACT` 默认关闭（不过滤）。

- 用户选择"仅保留有联系方式的企业" → `KEEP_ONLY_WITH_CONTACT=1`
- 用户选择"保留全部" → `KEEP_ONLY_WITH_CONTACT=0`
- 默认不过滤，避免用户选择"保留全部"后仍被误过滤

### B2B 平台域名黑名单（2026-07-03 新增）

以下 B2B 黄页/目录/电商平台域名加入 `non_company_domains`，命中即归类 `other`，在 `--apply-filter` 时自动剔除。

**欧洲（12 个）**：
`europages.fr` `europages.com` `europages.de` `europages.co.uk` `europages.it` `europages.es` `europages.nl`
`kompass.com` `wlw.de` `mfg.com` `industrystock.com` `b2b.partcommunity.com`

**亚洲（12 个）**：
`alibaba.com` `made-in-china.com` `globalsources.com` `hktdc.com`
`tradekey.com` `ec21.com` `ecplaza.net` `indiamart.com` `tradeindia.com` `exportersindia.com`
`go4worldbusiness.com` `tradewheel.com`

**美洲/其他（7 个）**：
`thomasnet.com` `mercadolibre.com` `mercadolivre.com.br`
`zauba.com` `b2brazil.com` `exporta.co` `mexicobusiness.net`

**如需放开**：在 `generate_outputs.py` 的 `classify_customer()` → `non_company_domains` 列表中删除对应域名即可。

### URL 路径目录关键词（2026-07-03 新增）

独立于域名黑名单，检查 URL 路径中的目录类关键词，用于捕获未知新的 B2B 目录平台。命中任意一个即归类 `directory`。

**多语言覆盖**：

| 语言 | 关键词 |
|:----:|:-------|
| English | `/suppliers/` `/companies/` `/directory/` `/manufacturers/` `/distributors/` `/wholesalers/` |
| Français | `/entreprises/` `/fournisseurs/` `/grossiste/` `/distributeur/` |
| Deutsch | `/lieferanten/` `/unternehmen/` `/händler/` |
| Español | `/proveedores/` `/empresas/` `/distribuidores/` |
| Italiano | `/fornitori/` `/aziende/` `/grossisti/` |

**如需放开**：在 `generate_outputs.py` 的 `classify_customer()` → `url_path_dir_keywords` 列表中删除对应词即可。
