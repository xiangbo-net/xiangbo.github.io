"""
scheduler_server.py — 搜索计划管理后台服务

架构：Flask HTTP 服务 + 内部定时器 + subprocess 执行引擎
端口：5679
依赖：pip install flask flask-cors python-dateutil tzdata

API 端点（完整列表见 scheduler_design.md §2.1）：
  GET    /                        → 返回 dashboard.html
  GET    /api/plans               → 计划列表
  POST   /api/plans               → 创建计划
  GET    /api/plans/<name>        → 计划详情 + 最近执行
  PUT    /api/plans/<name>        → 更新计划
  DELETE /api/plans/<name>        → 删除计划
  POST   /api/plans/<name>/pause  → 暂停
  POST   /api/plans/<name>/resume → 恢复
  POST   /api/plans/<name>/run    → 立即执行
  GET    /api/plans/<name>/runs   → 执行记录列表
  GET    /api/runs/<run_id>       → 单条执行记录
  GET    /api/runs/<run_id>/files → 产出文件列表
  GET    /api/runs/<run_id>/download/<filename> → 下载产出文件
  GET    /api/stats               → 统计概览
  GET    /api/status              → 服务状态
  GET    /api/config              → 系统配置（API Key 状态等）
  POST   /api/config/apikey       → 更新 API Key
  GET/POST/DELETE /api/config/emails → 通知邮箱管理

数据目录：
  ~/.workbuddy/userdata/wxskill/overseas-customer-miner/
  ├── search_plans/               ← 计划配置文件
  │   ├── logs/                   ← 执行日志
  │   └── tmp/                    ← 临时文件
  ├── output/                     ← 手动搜索产物（不变）
  └── config.json                 ← 后台配置（通知邮箱、翻译服务）
"""

import json
import logging
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import unquote

# ─── 依赖检查 ───
_missing = []
try:
    from flask import Flask, request, jsonify, send_file, send_from_directory
except ImportError:
    _missing.append("flask")
try:
    from flask_cors import CORS
except ImportError:
    _missing.append("flask-cors")
try:
    from dateutil.rrule import rrulestr
    from dateutil.parser import parse as parse_dt
except ImportError:
    _missing.append("python-dateutil")

if _missing:
    print(f"错误：请先安装缺失依赖（pip install {' '.join(_missing)}）")
    sys.exit(1)

try:
    import tzdata  # Windows 时区支持
except ImportError:
    pass  # 非 Windows 或已安装

# ─── 日志 ───
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("scheduler-server")

# ─── 常量 ───
DEFAULT_PORT = 5679
DEFAULT_HOST = "127.0.0.1"

# 数据目录
USERDATA_DIR = (
    Path.home()
    / ".workbuddy"
    / "userdata"
    / "wxskill"
    / "overseas-customer-miner"
)
SEARCH_PLANS_DIR = USERDATA_DIR / "search_plans"
LOGS_DIR = SEARCH_PLANS_DIR / "logs"
TMP_DIR = SEARCH_PLANS_DIR / "tmp"
OUTPUT_DIR = USERDATA_DIR / "output"
TRANSLATION_REQUESTS_DIR = USERDATA_DIR / "translation_requests"
CONFIG_FILE = USERDATA_DIR / "config.json"

# 脚本目录（与当前文件同目录）
SCRIPTS_DIR = Path(__file__).parent.resolve()

# 预设参数映射
RESULT_RANGE_MAP = {
    "low": {"max_results": 10, "search_depth": "fast", "label": "少（约30家）"},
    "medium": {"max_results": 20, "search_depth": "basic", "label": "适中（约60家）"},
    "high": {"max_results": 20, "search_depth": "advanced", "label": "多（约100家）"},
}

CONTACT_SCOPE_MAP = {
    "top10": {"crawl_max": 10, "label": "获取前 10 家（推荐）"},
    "all": {"crawl_max": 0, "label": "获取全部"},
}

# 搜索模式映射
SEARCH_MODE_MAP = {
    "light": {"search_mode": "light", "label": "Light（轻度 / 4个词）"},
    "standard": {"search_mode": "standard", "label": "Standard（标准 / 6个词）"},
    "deep": {"search_mode": "deep", "label": "Deep（深度 / 8个词）"},
}

# 语言映射（用于搜索词生成）
LANGUAGE_MAP = {
    "en": "English",
    "de": "Deutsch",
    "fr": "Français",
    "es": "Español",
    "it": "Italiano",
    "ja": "日本語",
    "ko": "한국어",
    "th": "ไทย",
    "vi": "Tiếng Việt",
    "pt": "Português",
    "ru": "Русский",
    "ar": "العربية",
}

# 定时器间隔（秒）
SCHEDULER_INTERVAL = 1800  # 30 分钟
# 补执行窗口（小时）
CATCHUP_WINDOW_HOURS = 24
# 防止重复执行的最小间隔（秒）
MIN_RUN_INTERVAL = 300  # 5 分钟

# 搜索模式描述（仅决定搜索词数量）
SEARCH_MODE_INFO = {
    "light": {
        "label": "Light（轻度 / 4个词）",
        "desc": "4 个精准搜索词，适合日常获客",
        "query_count": 4,
    },
    "standard": {
        "label": "Standard（标准 / 6个词）",
        "desc": "6 个搜索词，覆盖更广，适合新品开拓",
        "query_count": 6,
    },
    "deep": {
        "label": "Deep（深度 / 8个词）",
        "desc": "8 个深度搜索词，结果更全，适合深度调研",
        "query_count": 8,
    },
}

# 搜索结果范围描述（决定 search_depth / max_results / 单查询积分）
# 注：当指定国家时，fast 会自动升级为 basic，但积分仍为 1
RESULT_RANGE_INFO = {
    "low": {
        "max_results": 10,
        "search_depth": "fast",
        "label": "少（约30家）",
        "credits_per_query": 1,
        "estimated_results": 30,
    },
    "medium": {
        "max_results": 20,
        "search_depth": "basic",
        "label": "适中（约60家）",
        "credits_per_query": 1,
        "estimated_results": 60,
    },
    "high": {
        "max_results": 20,
        "search_depth": "advanced",
        "label": "多（约100家）",
        "credits_per_query": 2,
        "estimated_results": 100,
    },
}

# 联系方式获取描述与积分预估
# 注：crawl_contacts.py 优先免费 requests 爬取，403 失败时走 Extract API（约 1 积分/URL）
CONTACT_SCOPE_INFO = {
    "top10": {
        "label": "获取前 10 家（推荐）",
        "desc": "自动访问全部企业官网提取电话和邮箱，并以邮箱号为准；结果仅保留前 10 家有邮箱的企业",
        "estimated_credits": 10,
    },
    "all": {
        "label": "获取全部（耗时更长）",
        "desc": "自动访问全部企业官网提取电话和邮箱，并以邮箱号为准；积分按实际企业数估算",
        "max_crawl": 0,
        "estimated_credits": None,  # 按结果范围估算企业数
    },
}


# =========================================================================
#  后台配置管理（config.json）
# =========================================================================

def load_config() -> dict:
    """加载后台配置文件。"""
    if CONFIG_FILE.exists():
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception as e:
            logger.warning(f"加载配置文件失败: {e}")
    return {
        "last_search": None,
        "translation": {
            "enabled": False,
            "api_key": "",
            "base_url": "https://api.openai.com/v1",
            "model": "gpt-4o-mini",
        },
        "smtp": {
            "server": "",
            "port": 587,
            "username": "",
            "password": "",
            "sender_email": "",
            "use_tls": True,
        },
        "notification_emails": [],
    }


def get_smtp_config() -> dict:
    """获取 SMTP 配置。"""
    return load_config().get("smtp", {
        "server": "",
        "port": 587,
        "username": "",
        "password": "",
        "sender_email": "",
        "use_tls": True,
    })


def save_config(config: dict):
    """保存后台配置文件。"""
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


def get_translation_config() -> dict:
    """获取翻译服务配置。"""
    return load_config().get("translation", {})


def get_notification_emails() -> list:
    """获取通知邮箱列表。"""
    return load_config().get("notification_emails", [])


# =========================================================================
#  数据目录初始化
# =========================================================================

def ensure_dirs():
    """确保所有数据目录存在。"""
    for d in [USERDATA_DIR, SEARCH_PLANS_DIR, LOGS_DIR, TMP_DIR, OUTPUT_DIR, TRANSLATION_REQUESTS_DIR]:
        d.mkdir(parents=True, exist_ok=True)


# =========================================================================
#  翻译与搜索词生成
# =========================================================================

def normalize_country_name(country_input: str) -> str:
    """将中文/英文/ISO 国家名统一转为英文全称（小写）。"""
    if not country_input:
        return ""
    from tavily_customer_mine import normalize_country
    return normalize_country(country_input.strip())


def translate_product_to_english(text: str) -> dict:
    """
    将中文产品描述翻译为英文产品关键词。
    返回 {"text": "英文", "translated": bool, "note": "说明"}
    """
    if not text or not text.strip():
        return {"text": "", "translated": False, "note": "请输入产品描述"}

    # 如果已经是英文，直接返回
    if re.match(r'^[\x00-\x7F\s]+$', text.strip()):
        return {"text": text.strip(), "translated": True, "note": "输入已是英文，直接使用"}

    cfg = get_translation_config()
    api_key = cfg.get("api_key", "").strip()
    base_url = cfg.get("base_url", "https://api.openai.com/v1").strip()
    model = cfg.get("model", "gpt-4o-mini").strip()

    if not api_key:
        return {
            "text": text.strip(),
            "translated": False,
            "note": "未配置翻译服务，无法自动翻译；请填写产品英文关键词",
        }

    try:
        import requests
        resp = requests.post(
            f"{base_url}/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "model": model,
                "messages": [
                    {
                        "role": "system",
                        "content": "You are a translation assistant for B2B product search. Translate the user's Chinese product description into a short English product keyword phrase suitable for web search. Only return the English keywords, no explanation."
                    },
                    {
                        "role": "user",
                        "content": f"Translate to English product keywords: {text}",
                    }
                ],
                "temperature": 0.3,
                "max_tokens": 60,
            },
            timeout=15,
        )
        if resp.status_code == 200:
            data = resp.json()
            translated = data["choices"][0]["message"]["content"].strip().strip('"').strip("'")
            if translated:
                return {"text": translated, "translated": True, "note": "已自动翻译"}
    except Exception as e:
        logger.warning(f"翻译失败: {e}")

    return {
        "text": text.strip(),
        "translated": False,
        "note": "自动翻译失败，请填写产品英文关键词",
    }


def _query_templates():
    """搜索词模板库。"""
    return [
        ("{product} distributors {country}", "{product} 经销商 {country_cn}"),
        ("{product} wholesalers {country}", "{product} 批发商 {country_cn}"),
        ("{product} suppliers {country}", "{product} 供应商 {country_cn}"),
        ("{product} manufacturers {country}", "{product} 制造商 {country_cn}"),
        ("{product} importers {country}", "{product} 进口商 {country_cn}"),
        ("{product} trading companies {country}", "{product} 贸易公司 {country_cn}"),
        ("{product} dealers {country}", "{product} 代理商 {country_cn}"),
        ("{product} export {country}", "{product} 出口 {country_cn}"),
    ]


def generate_search_queries(
    product: str,
    country: str,
    mode: str = "light",
    product_en: str = None,
    customer_types: list = None,
    refresh: bool = False,
) -> dict:
    """
    根据产品、国家、搜索模式生成搜索词。
    返回 {"queries": [{"query": "英文", "cn": "中文"}], "translation": {...}}
    """
    if not product or not country:
        return {"queries": [], "translation": {"text": "", "translated": False, "note": ""}}

    country_en = normalize_country_name(country)
    country_cn = country

    # 确定英文产品关键词
    translation = None
    if product_en and product_en.strip():
        product_en_clean = product_en.strip()
        translation = {"text": product_en_clean, "translated": True, "note": "使用用户提供的英文关键词"}
    else:
        translation = translate_product_to_english(product)
        product_en_clean = translation["text"]

    # 如果翻译失败且没有英文关键词，仍使用原词生成（但会提示用户）
    if not product_en_clean:
        product_en_clean = product.strip()

    templates = _query_templates()
    import random
    if refresh:
        # 换一批：打乱顺序
        random.shuffle(templates)

    # 根据模式决定数量
    count = SEARCH_MODE_INFO.get(mode, SEARCH_MODE_INFO["light"]).get("query_count", 4)

    queries = []
    for template_en, template_cn in templates[:count]:
        query_en = template_en.format(product=product_en_clean, country=country_en, country_cn=country_cn)
        query_cn = template_cn.format(product=product_en_clean, country=country_en, country_cn=country_cn)
        queries.append({"query": query_en, "cn": query_cn})

    return {"queries": queries, "translation": translation}


def estimate_search_credits(search_mode: str, result_range: str) -> dict:
    """预估搜索积分消耗。"""
    mode_info = SEARCH_MODE_INFO.get(search_mode, SEARCH_MODE_INFO["light"])
    range_info = RESULT_RANGE_INFO.get(result_range, RESULT_RANGE_INFO["medium"])

    query_count = mode_info["query_count"]
    per_query = range_info["credits_per_query"]
    total = per_query * query_count

    depth_label = "fast/basic（指定国家时自动升basic）" if range_info["search_depth"] == "fast" else range_info["search_depth"]

    return {
        "query_count": query_count,
        "per_query": per_query,
        "search_depth": range_info["search_depth"],
        "total": total,
        "desc": f"预计搜索消耗约 {total} 积分（{query_count} 个搜索词 × {per_query} 积分，{depth_label}）",
    }


def estimate_contact_credits(contact_scope: str, result_range: str = "medium") -> dict:
    """预估联系方式获取积分消耗。"""
    scope_info = CONTACT_SCOPE_INFO.get(contact_scope, CONTACT_SCOPE_INFO["top10"])
    range_info = RESULT_RANGE_INFO.get(result_range, RESULT_RANGE_INFO["medium"])

    if contact_scope == "all":
        estimated = range_info["estimated_results"]
    else:
        estimated = scope_info.get("estimated_credits", 10)

    return {
        "estimated_credits": estimated,
        "desc": f"预计联系方式获取消耗约 0-{estimated} 积分（按约 {estimated} 家企业估算，以邮箱为准）",
    }


def estimate_total_credits(search_mode: str, result_range: str, contact_scope: str) -> dict:
    """预估总积分消耗。"""
    search = estimate_search_credits(search_mode, result_range)
    contact = estimate_contact_credits(contact_scope, result_range)
    total = search["total"] + contact["estimated_credits"]
    return {
        "search": search,
        "contact": contact,
        "total": total,
        "desc": f"预计总消耗约 {total} 积分（搜索 {search['total']} + 联系方式 {contact['estimated_credits']}）",
    }


# =========================================================================
#  计划管理
# =========================================================================

class PlanManager:
    """搜索计划的 CRUD 和持久化管理。"""

    @staticmethod
    def _plan_path(name: str) -> Path:
        """获取计划配置文件的完整路径。"""
        safe_name = PlanManager._sanitize_filename(name)
        return SEARCH_PLANS_DIR / f"{safe_name}.json"

    @staticmethod
    def _sanitize_filename(name: str) -> str:
        """将计划名称转为安全的文件名。"""
        # 替换文件系统不安全的字符
        safe = re.sub(r'[<>:"/\\|?*]', "_", name)
        return safe.strip().replace(" ", "_")

    @staticmethod
    def list_plans() -> list:
        """列出所有计划（摘要信息）。"""
        plans = []
        for f in sorted(SEARCH_PLANS_DIR.glob("*.json")):
            if f.name.startswith("."):
                continue
            try:
                with open(f, "r", encoding="utf-8") as fp:
                    data = json.load(fp)
                plans.append(PlanManager._summarize(data))
            except (json.JSONDecodeError, KeyError, Exception) as e:
                logger.warning(f"读取计划文件失败 {f.name}: {e}")
        return plans

    @staticmethod
    def _summarize(data: dict) -> dict:
        """从完整配置提取摘要信息。"""
        last_run = data.get("last_run_at")
        next_run = None
        schedule = data.get("schedule", {})
        if schedule.get("rrule") and data.get("enabled", False):
            next_run = PlanManager._calc_next_run(
                schedule["rrule"], data.get("last_run_at")
            )

        return {
            "plan_name": data.get("plan_name", ""),
            "company_name": data.get("company_name", ""),
            "product_description": data.get("product_description", ""),
            "target_country": data.get("target_country", ""),
            "enabled": data.get("enabled", False),
            "status": "active" if data.get("enabled", False) else "paused",
            "created_at": data.get("created_at", ""),
            "updated_at": data.get("updated_at", ""),
            "total_runs": data.get("total_runs", 0),
            "last_run_at": last_run,
            "last_run_status": data.get("last_run_status"),
            "next_run": next_run.isoformat() if next_run else None,
            "schedule": {
                "frequency": schedule.get("frequency", "manual"),
                "time": schedule.get("time", ""),
            },
        }

    @staticmethod
    def get_plan(name: str) -> dict:
        """获取单个计划的完整配置和最近执行记录。"""
        path = PlanManager._plan_path(name)
        if not path.exists():
            return None
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)

        # 加载最近 10 条执行记录
        runs = []
        run_history = data.get("runs", [])
        for run_id in run_history[-10:]:
            log_path = PlanManager._find_log(run_id)
            if log_path:
                try:
                    with open(log_path, "r", encoding="utf-8") as lf:
                        runs.append(json.load(lf))
                except Exception:
                    pass
        data["runs"] = runs
        # 不返回 runs 中的完整历史 ID 列表
        return data

    @staticmethod
    def _find_log(run_id: str) -> Path:
        """按 run_id 查找日志文件。"""
        # run_id 格式: 2026-07-13_0900_计划名称
        for f in LOGS_DIR.glob(f"{run_id}.json"):
            return f
        # 尝试模糊匹配
        for f in LOGS_DIR.glob("*.json"):
            if run_id in f.stem:
                return f
        return None

    @staticmethod
    def create_plan(data: dict) -> dict:
        """创建新计划。"""
        plan_name = data.get("plan_name", "").strip()
        if not plan_name:
            raise ValueError("计划名称不能为空")

        # 检查是否已存在
        existing = PlanManager.get_plan(plan_name)
        if existing:
            raise ValueError(f"计划 '{plan_name}' 已存在")

        now = datetime.now(timezone.utc).isoformat()

        # 验证必填字段
        required = ["company_name", "product_description", "target_country", "search_queries"]
        for field in required:
            if not data.get(field):
                raise ValueError(f"字段 '{field}' 不能为空")

        # 构建计划配置
        schedule = PlanManager._build_schedule(data)
        rrule_str = schedule.get("rrule", "") if data.get("frequency", "manual") != "manual" else ""

        plan = {
            "plan_name": plan_name,
            "enabled": data.get("enabled", True),
            "created_at": now,
            "updated_at": now,
            "company_name": data["company_name"],
            "product_description": data["product_description"],
            "product_description_en": data.get("product_description_en",
                                                data["product_description"]),
            "product_en": data.get("product_en", ""),
            "target_country": data["target_country"],
            "target_country_en": data.get("target_country_en", ""),
            "customer_types": data.get("customer_types", []),
            "language": data.get("language", "en"),
            "search_queries": data.get("search_queries", []),
            "search_queries_cn": data.get("search_queries_cn", {}),
            "search_mode": data.get("search_mode", "light"),
            "result_range": data.get("result_range", "medium"),
            "contact_scope": data.get("contact_scope", "top10"),
            "auto_pitch": data.get("auto_pitch", True),
            "push_email": data.get("push_email", ""),
            "schedule": schedule,
            "last_run_at": None,
            "last_run_status": None,
            "total_runs": 0,
            "runs": [],
        }

        PlanManager._save_plan(plan)
        return PlanManager._summarize(plan)

    @staticmethod
    def update_plan(name: str, data: dict) -> dict:
        """更新已有计划。"""
        existing = PlanManager.get_plan(name)
        if not existing:
            raise ValueError(f"计划 '{name}' 不存在")

        # 如果更新了计划名称，需要删除旧文件
        new_name = data.get("plan_name", "").strip()
        if new_name and new_name != name:
            old_path = PlanManager._plan_path(name)
            if old_path.exists():
                old_path.unlink()

        now = datetime.now(timezone.utc).isoformat()

        # 合并更新
        for key in [
            "company_name", "product_description", "product_description_en",
            "product_en", "target_country", "target_country_en", "customer_types",
            "language", "search_queries", "search_queries_cn",
            "search_mode", "result_range", "contact_scope",
            "auto_pitch", "push_email", "enabled",
        ]:
            if key in data:
                existing[key] = data[key]

        # 更新计划名称
        if new_name:
            existing["plan_name"] = new_name

        # 更新定时设置
        if any(k in data for k in ["frequency", "days_of_week", "days_of_month", "time"]):
            existing["schedule"] = PlanManager._build_schedule(data)

        # 如果手动指定了 rrule
        if "rrule" in data.get("schedule", {}):
            existing["schedule"]["rrule"] = data["schedule"]["rrule"]

        existing["updated_at"] = now

        # 保存使用新名称
        PlanManager._save_plan(existing)
        return PlanManager._summarize(existing)

    @staticmethod
    def delete_plan(name: str) -> bool:
        """删除计划。"""
        path = PlanManager._plan_path(name)
        if path.exists():
            path.unlink()
            return True
        return False

    @staticmethod
    def _save_plan(plan: dict):
        """保存计划配置到文件。"""
        name = plan.get("plan_name", "unnamed")
        path = PlanManager._plan_path(name)
        path.parent.mkdir(parents=True, exist_ok=True)
        with open(path, "w", encoding="utf-8") as f:
            json.dump(plan, f, ensure_ascii=False, indent=2)

    @staticmethod
    def _build_schedule(data: dict) -> dict:
        """从表单数据构建定时配置和 RRULE。"""
        freq = data.get("frequency", "manual")
        time_str = data.get("time", "09:00")

        schedule = {
            "frequency": freq,
            "time": time_str,
            "rrule": "",
        }

        if freq == "daily":
            hour, minute = time_str.split(":") if ":" in time_str else ("09", "00")
            schedule["rrule"] = f"FREQ=DAILY;BYHOUR={int(hour)};BYMINUTE={int(minute)}"

        elif freq == "weekly":
            hour, minute = time_str.split(":") if ":" in time_str else ("09", "00")
            days = data.get("days_of_week", [])
            if days:
                day_str = ",".join(days)
                schedule["rrule"] = (
                    f"FREQ=WEEKLY;BYDAY={day_str};BYHOUR={int(hour)};BYMINUTE={int(minute)}"
                )
                schedule["days_of_week"] = days

        elif freq == "monthly":
            hour, minute = time_str.split(":") if ":" in time_str else ("09", "00")
            day = data.get("day_of_month", 1)
            schedule["rrule"] = (
                f"FREQ=MONTHLY;BYMONTHDAY={day};BYHOUR={int(hour)};BYMINUTE={int(minute)}"
            )
            schedule["day_of_month"] = day

        return schedule

    @staticmethod
    def _calc_next_run(rrule_str: str, last_run_at: str = None) -> datetime:
        """根据 RRULE 计算下次执行时间。"""
        if not rrule_str:
            return None
        try:
            rule = rrulestr(rrule_str, dtstart=datetime.now())
            now = datetime.now(timezone.utc).astimezone()
            # 获取从现在开始的第一个未来时间
            next_run = rule.after(now)
            return next_run
        except Exception as e:
            logger.warning(f"RRULE 解析失败 '{rrule_str}': {e}")
            return None

    @staticmethod
    def load_all_active() -> list:
        """加载所有启用的计划。"""
        plans = []
        for f in SEARCH_PLANS_DIR.glob("*.json"):
            if f.name.startswith("."):
                continue
            try:
                with open(f, "r", encoding="utf-8") as fp:
                    data = json.load(fp)
                if data.get("enabled", False):
                    plans.append(data)
            except Exception:
                continue
        return plans


# =========================================================================
#  执行日志管理
# =========================================================================

class LogManager:
    """执行日志的读写管理。"""

    @staticmethod
    def save_log(log_data: dict):
        """保存一条执行日志。"""
        run_id = log_data.get("run_id", str(uuid.uuid4()))
        log_path = LOGS_DIR / f"{run_id}.json"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        with open(log_path, "w", encoding="utf-8") as f:
            json.dump(log_data, f, ensure_ascii=False, indent=2)

    @staticmethod
    def get_log(run_id: str) -> dict:
        """读取一条执行日志。"""
        log_path = PlanManager._find_log(run_id)
        if log_path and log_path.exists():
            with open(log_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return None

    @staticmethod
    def list_logs(plan_name: str = None, limit: int = 50) -> list:
        """列出执行日志。"""
        logs = []
        for f in sorted(LOGS_DIR.glob("*.json"), reverse=True):
            try:
                with open(f, "r", encoding="utf-8") as fp:
                    data = json.load(fp)
                if plan_name and data.get("plan_name") != plan_name:
                    continue
                logs.append(data)
                if len(logs) >= limit:
                    break
            except Exception:
                continue
        return logs

    @staticmethod
    def get_output_files(run_id: str) -> list:
        """获取某次执行的产出文件列表。"""
        log_data = LogManager.get_log(run_id)
        if not log_data:
            return []
        files = log_data.get("output_files", {})
        result = []
        for filetype, filepath in files.items():
            if filepath and os.path.exists(filepath):
                result.append({
                    "type": filetype,
                    "path": filepath,
                    "filename": os.path.basename(filepath),
                    "size": os.path.getsize(filepath),
                })
        return result


# =========================================================================
#  执行引擎
# =========================================================================

class ExecutionEngine:
    """搜索计划的执行引擎，通过 subprocess 调用现有脚本。"""

    def __init__(self):
        self.running = {}  # plan_name -> thread

    def execute(self, plan: dict) -> dict:
        """
        执行一个搜索计划。
        返回执行结果日志。
        """
        plan_name = plan.get("plan_name", "unnamed")
        logger.info(f"[执行] 开始执行计划: {plan_name}")

        run_id = self._generate_run_id(plan_name)
        started_at = datetime.now().isoformat()

        result = {
            "plan_name": plan_name,
            "run_id": run_id,
            "started_at": started_at,
            "finished_at": None,
            "duration_seconds": 0,
            "status": "running",
            "search_result_count": 0,
            "after_filter_count": 0,
            "after_dedup_count": 0,
            "crawl_count": 0,
            "pitch_count": 0,
            "output_files": {},
            "error": None,
            "errors": [],
        }

        try:
            # ---- Step 1: 构造搜索配置 ----
            search_config = self._build_search_config(plan)
            config_path = TMP_DIR / f"{run_id}_config.json"
            with open(config_path, "w", encoding="utf-8") as f:
                json.dump(search_config, f, ensure_ascii=False)

            # ---- Step 2: 运行搜索脚本 ----
            logger.info(f"[执行] 运行搜索脚本: {plan_name}")
            search_result_path = self._run_search(config_path, run_id)
            if not search_result_path:
                raise RuntimeError("搜索脚本未产出结果文件")

            result["search_result_count"] = self._count_results(search_result_path)

            # ---- Step 3: 分类过滤 ----
            logger.info(f"[执行] 运行分类过滤: {plan_name}")
            self._run_classify_filter(search_result_path)
            result["after_filter_count"] = self._count_results(search_result_path)

            # ---- Step 4: 执行去重 ----
            logger.info(f"[执行] 历史去重: {plan_name}")
            dedup_count = self._run_dedup(search_result_path, plan_name)
            result["after_dedup_count"] = dedup_count

            # ---- Step 5: 爬取联系信息 ----
            # 逻辑统一：全部企业都访问，top10 后续只保留前 10 家有邮箱的结果
            contact_max = 0
            logger.info(f"[执行] 爬取联系信息 (all): {plan_name}")
            crawl_count = self._run_crawl(search_result_path, contact_max)
            result["crawl_count"] = crawl_count

            # 如果是 top10 模式，只保留前 10 家有邮箱的企业
            if plan.get("contact_scope", "top10") == "top10":
                self._limit_results_to_top10_with_email(search_result_path)

            # ---- Step 6: 生成话术 ----
            if plan.get("auto_pitch", True):
                logger.info(f"[执行] 生成话术: {plan_name}")
                pitch_count = self._generate_pitch(search_result_path, plan)
                result["pitch_count"] = pitch_count

            # ---- Step 7: 生成最终交付文件 ----
            logger.info(f"[执行] 生成交付文件: {plan_name}")
            output_files = self._run_generate_outputs(search_result_path, plan)
            result["output_files"] = output_files

            # ---- Step 8: 更新去重索引 ----
            self._update_dedup_index(search_result_path, run_id)

            # ---- Step 9: 邮件推送 ----
            push_email = plan.get("push_email", "")
            if push_email and output_files:
                self._send_email_notification(push_email, plan_name, output_files)

            result["status"] = "success"

        except Exception as e:
            logger.error(f"[执行] 计划执行失败 {plan_name}: {e}", exc_info=True)
            result["status"] = "failed"
            result["error"] = str(e)
            result["errors"].append(str(e))

        finally:
            finished_at = datetime.now()
            result["finished_at"] = finished_at.isoformat()
            result["duration_seconds"] = (
                finished_at - datetime.fromisoformat(started_at)
            ).total_seconds()

            # 保存日志
            LogManager.save_log(result)

            # 更新计划配置
            self._update_plan_after_run(plan_name, result)

            # 清理临时文件
            self._cleanup_temp(run_id)

        logger.info(
            f"[执行] 计划执行完成 {plan_name}: "
            f"status={result['status']}, "
            f"duration={result['duration_seconds']:.1f}s"
        )
        return result

    def _generate_run_id(self, plan_name: str) -> str:
        """生成唯一的运行 ID。"""
        now = datetime.now()
        safe_name = re.sub(r'[^a-zA-Z0-9\u4e00-\u9fff_-]', "_", plan_name)
        return f"{now.strftime('%Y%m%d_%H%M%S')}_{safe_name}"

    def _build_search_config(self, plan: dict) -> dict:
        """从计划配置构建搜索配置 JSON。"""
        result_range = RESULT_RANGE_MAP.get(
            plan.get("result_range", "medium"), RESULT_RANGE_MAP["medium"]
        )
        search_mode_cfg = SEARCH_MODE_MAP.get(
            plan.get("search_mode", "light"), SEARCH_MODE_MAP["light"]
        )

        # 国家名称处理：统一使用 tavily_customer_mine.normalize_country 规范化
        country = plan.get("target_country_en", "").strip() or plan.get("target_country", "").strip()
        from tavily_customer_mine import normalize_country

        country_en = normalize_country(country) if country else ""

        # 产品英文关键词处理：优先使用 product_en，否则使用 product_description 并翻译
        product_en = plan.get("product_en", "").strip()
        if not product_en:
            translation = translate_product_to_english(plan.get("product_description", ""))
            product_en = translation["text"]

        return {
            "company_name": plan.get("company_name", ""),
            "search_queries": plan.get("search_queries", []),
            "search_queries_cn": plan.get("search_queries_cn", {}),
            "target_country": country_en or country,
            "search_depth": result_range["search_depth"],
            "search_mode": search_mode_cfg["search_mode"],
            "max_results": result_range["max_results"],
            "top_n_for_extract": 999,  # 全部结果都走 Tavily Extract 深度提取
            "dedup_enabled": True,
            "product_description": product_en,
        }

    def _run_search(self, config_path: Path, run_id: str) -> Path:
        """调用 tavily_customer_mine.py 执行搜索。"""
        script = SCRIPTS_DIR / "tavily_customer_mine.py"
        output_path = TMP_DIR / f"{run_id}_search_result.json"

        env = os.environ.copy()
        # 确保 Python 能找到同目录下的模块导入
        env["PYTHONPATH"] = str(SCRIPTS_DIR)

        result = subprocess.run(
            [
                sys.executable,
                str(script),
                "--config", str(config_path),
                "--output", str(output_path),
            ],
            capture_output=True,
            text=True,
            timeout=300,  # 5 分钟超时
            env=env,
        )

        logger.info(f"[搜索] stdout: {result.stdout[-500:] if result.stdout else ''}")
        if result.returncode != 0:
            raise RuntimeError(
                f"搜索脚本执行失败 (code={result.returncode}): "
                f"{result.stderr[-500:]}"
            )

        # 如果 --output 方式没有产出，尝试从 stdout 解析
        if not output_path.exists():
            # 从 stdout 解析 __OUTPUT_FILES__
            match = re.search(r'__OUTPUT_FILES__:\s*(\{.*?\})', result.stdout, re.DOTALL)
            if match:
                files_info = json.loads(match.group(1))
                result_path = files_info.get("json", "")
                if result_path and os.path.exists(result_path):
                    # 复制到 tmp 目录
                    shutil.copy2(result_path, output_path)
                    return output_path

            # 尝试从 stderr 或 stdout 找输出文件路径
            for line in (result.stdout + result.stderr).split("\n"):
                line = line.strip()
                if line.startswith('{"output_file"'):
                    try:
                        info = json.loads(line)
                        fp = info.get("output_file", "")
                        if fp and os.path.exists(fp):
                            shutil.copy2(fp, output_path)
                            return output_path
                    except Exception:
                        pass

            raise RuntimeError("搜索脚本未产出可识别的结果文件")

        return output_path

    def _run_classify_filter(self, result_path: Path):
        """调用 generate_outputs.py --apply-filter 进行分类过滤。"""
        script = SCRIPTS_DIR / "generate_outputs.py"
        env = os.environ.copy()
        env["PYTHONPATH"] = str(SCRIPTS_DIR)

        result = subprocess.run(
            [sys.executable, str(script), "--input", str(result_path), "--apply-filter"],
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )

        logger.info(f"[分类] stdout: {result.stdout[-300:] if result.stdout else ''}")
        if result.returncode != 0:
            logger.warning(f"分类过滤可能未完全成功: {result.stderr[-300:]}")
            raise RuntimeError(f"分类过滤失败: {result.stderr[-300:]}")

    def _run_dedup(self, result_path: Path, plan_name: str) -> int:
        """执行去重并返回去重后的数量。"""
        try:
            # 加载去重索引
            dedup_path = USERDATA_DIR / "dedup_index.json"
            index = {"runs": [], "seen": []}
            if dedup_path.exists():
                with open(dedup_path, "r", encoding="utf-8") as f:
                    index = json.load(f)

            seen_urls = set(index.get("seen", []))

            # 加载搜索结果
            with open(result_path, "r", encoding="utf-8") as f:
                results = json.load(f)

            items = results.get("results", []) if isinstance(results, dict) else results
            before = len(items)

            # 去重
            deduped = [item for item in items if item.get("url", "") not in seen_urls]
            after = len(deduped)

            logger.info(f"[去重] 之前={before}, 之后={after}, 重复={before - after}")

            # 更新到索引
            for item in deduped:
                url = item.get("url", "")
                if url:
                    seen_urls.add(url)

            # 写回去重索引
            index["seen"] = list(seen_urls)
            index["runs"].append({
                "run_name": plan_name,
                "timestamp": datetime.now().isoformat(),
                "new_items": after,
            })
            # 只保留最近 100 条运行记录
            index["runs"] = index["runs"][-100:]

            with open(dedup_path, "w", encoding="utf-8") as f:
                json.dump(index, f, ensure_ascii=False)

            # 写回结果文件（去重后）
            if isinstance(results, dict):
                results["results"] = deduped
            else:
                results = deduped

            with open(result_path, "w", encoding="utf-8") as f:
                json.dump(results, f, ensure_ascii=False, indent=2)

            return after

        except Exception as e:
            logger.warning(f"[去重] 过程出错，继续执行: {e}")
            return self._count_results(result_path)

    def _run_crawl(self, result_path: Path, max_count: int) -> int:
        """调用 crawl_contacts.py 获取联系信息。"""
        script = SCRIPTS_DIR / "crawl_contacts.py"
        enriched_path = result_path.with_suffix(".enriched.json")

        env = os.environ.copy()
        env["PYTHONPATH"] = str(SCRIPTS_DIR)

        # 检查是否已经有联系方式
        with open(result_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        items = data.get("results", []) if isinstance(data, dict) else data

        # 统计已有联系方式的
        has_contact = sum(
            1 for item in items
            if item.get("phone") or item.get("email")
        )

        # 如果全部都有联系方式，跳过爬取
        if has_contact >= len(items):
            logger.info("[爬取] 所有企业已有联系方式，跳过")
            return has_contact

        cmd = [
            sys.executable, str(script),
            "--input", str(result_path),
            "--output", str(enriched_path),
            "--max", str(max_count),
            "--concurrent", "5",
        ]

        try:
            result = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=600,  # 10 分钟超时
                env=env,
            )
            logger.info(f"[爬取] stdout: {result.stdout[-300:] if result.stdout else ''}")
            if result.returncode != 0:
                logger.warning(f"[爬取] 脚本异常: {result.stderr[-300:]}")

            # 如果存在富化后的文件，替换原文件
            if enriched_path.exists():
                shutil.copy2(enriched_path, result_path)
                enriched_path.unlink()

            # 统计爬取结果
            with open(result_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            new_items = data.get("results", []) if isinstance(data, dict) else data
            return sum(
                1 for item in new_items
                if item.get("phone") or item.get("email")
            )

        except subprocess.TimeoutExpired:
            logger.warning("[爬取] 超时，使用已有结果继续")
            return has_contact

    def _limit_results_to_top10_with_email(self, result_path: Path):
        """top10 模式下只保留前 10 家有邮箱的企业。"""
        with open(result_path, "r", encoding="utf-8") as f:
            data = json.load(f)
        items = data.get("results", []) if isinstance(data, dict) else data

        # 按是否有邮箱排序，保留前 10 个有邮箱的
        with_email = [item for item in items if item.get("email")]
        limited = with_email[:10]

        if isinstance(data, dict):
            data["results"] = limited
        else:
            data = limited

        with open(result_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        logger.info(f"[top10] 已限制结果至前 10 家有邮箱企业，原数量={len(items)}, 保留={len(limited)}")

    def _generate_pitch(self, result_path: Path, plan: dict) -> int:
        """
        为每个客户生成基本的邮件话术和电话话术。
        在有 AI 环境时调用 LLM，否则使用模板。
        """
        with open(result_path, "r", encoding="utf-8") as f:
            data = json.load(f)

        items = data.get("results", []) if isinstance(data, dict) else data
        company_desc = plan.get("product_description", "")
        company_name = plan.get("company_name", "")

        count = 0
        for item in items:
            try:
                customer_name = item.get("company_name", item.get("title", ""))
                summary = item.get("content_summary", item.get("content", ""))[:200]

                # 生成邮件话术模板（基于客户信息个性化）
                pitch_email = (
                    f"Subject: Partnership Opportunity with {company_name}\n\n"
                    f"Dear {customer_name} Team,\n\n"
                    f"I hope this message finds you well. My name is from {company_name}, "
                    f"a professional manufacturer specializing in {company_desc}.\n\n"
                    f"We have been following your company's work in the industry "
                    f"and believe there is strong potential for mutual growth.\n\n"
                    f"Based on our understanding, your business involves {summary[:100]}... "
                    f"We specialize in providing high-quality products that could complement "
                    f"your current offerings.\n\n"
                    f"Would you be open to a brief call to discuss potential collaboration?\n\n"
                    f"Looking forward to your response.\n\n"
                    f"Best regards,\n"
                    f"{company_name} Team"
                )

                pitch_phone = (
                    f"Hello, this is [Your Name] from {company_name}, "
                    f"a manufacturer of {company_desc}. "
                    f"I'm calling because we noticed your company's work in the industry "
                    f"and would like to explore potential cooperation opportunities. "
                    f"Would you have a few minutes to discuss?"
                )

                item["pitch_email"] = pitch_email
                item["pitch_phone"] = pitch_phone
                count += 1

            except Exception as e:
                logger.warning(f"[话术] 生成失败 '{item.get('title', '')}': {e}")

        # 写回文件
        with open(result_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

        logger.info(f"[话术] 已为 {count} 家企业生成话术")
        return count

    def _run_generate_outputs(self, result_path: Path, plan: dict) -> dict:
        """调用 generate_outputs.py 生成最终交付文件。"""
        script = SCRIPTS_DIR / "generate_outputs.py"
        env = os.environ.copy()
        env["PYTHONPATH"] = str(SCRIPTS_DIR)
        env["KEEP_ONLY_WITH_CONTACT"] = "1"  # 默认保留有联系方式的

        result = subprocess.run(
            [sys.executable, str(script), "--input", str(result_path)],
            capture_output=True,
            text=True,
            timeout=120,
            env=env,
        )

        logger.info(f"[交付] stdout: {result.stdout[-500:] if result.stdout else ''}")

        output_files = {"excel": "", "html": "", "md": ""}

        if result.returncode != 0:
            logger.warning(f"[交付] 生成可能未完全成功: {result.stderr[-300:]}")
            # 尝试从 stdout 中解析文件路径
        # 尝试解析 __OUTPUT_FILES__
        match = re.search(r'__OUTPUT_FILES__:\s*(\{.*?\})', result.stdout, re.DOTALL)
        if match:
            try:
                output_files = json.loads(match.group(1))
            except json.JSONDecodeError:
                pass
        else:
            logger.warning("[交付] 未在 stdout 中找到 __OUTPUT_FILES__")

        return output_files

    def _update_dedup_index(self, result_path: Path, run_id: str):
        """调用 cross_skill_index.py 更新跨 skill 索引。"""
        try:
            sys.path.insert(0, str(SCRIPTS_DIR))
            from cross_skill_index import update_index

            with open(result_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            items = data.get("results", []) if isinstance(data, dict) else data
            email_count = sum(1 for item in items if item.get("email"))

            update_index("tavily-customer-miner", {
                "company": data.get("company_name", "") if isinstance(data, dict) else "",
                "country": data.get("target_country", "") if isinstance(data, dict) else "",
                "output_dir": str(LOGS_DIR),
                "customer_count": len(items),
                "email_count": email_count,
                "json_file": str(result_path),
                "run_id": run_id,
            })
        except Exception as e:
            logger.warning(f"[索引] 更新失败: {e}")

    def _send_email_notification(self, email: str, plan_name: str, output_files: dict):
        """调用 mail_server:5678 发送邮件通知。"""
        try:
            import requests

            payload = {
                "customers": [
                    {
                        "email": email,
                        "subject": f"【搜索计划】{plan_name} 已生成最新客户报告",
                        "body": (
                            f"您好，\n\n"
                            f"搜索计划「{plan_name}」已完成最新一轮执行。\n\n"
                            f"产出文件列表：\n"
                            f"{' - Excel: ' + output_files.get('excel', '未生成') + chr(10)}"
                            f"{' - HTML 看板: ' + output_files.get('html', '未生成') + chr(10)}"
                            f"{' - MD 话术: ' + output_files.get('md', '未生成') + chr(10)}"
                            f"\n请登录管理后台查看详情。\n"
                            f"\n此邮件由搜索计划管理后台自动发送。"
                        ),
                    }
                ],
                "interval": 0,
                "batch": 1,
            }

            resp = requests.post(
                "http://127.0.0.1:5678/api/send",
                json=payload,
                timeout=30,
            )
            if resp.status_code == 200:
                logger.info(f"[邮件] 推送成功: {email}")
            else:
                logger.warning(f"[邮件] 推送响应异常: {resp.status_code} - {resp.text[:200]}")

        except ImportError:
            logger.warning("[邮件] requests 未安装，跳过邮件推送")
        except requests.exceptions.ConnectionError:
            logger.warning("[邮件] mail_server:5678 未运行，跳过推送")
        except Exception as e:
            logger.warning(f"[邮件] 推送失败: {e}")

    def _update_plan_after_run(self, plan_name: str, run_result: dict):
        """执行完毕后更新计划配置中的运行状态。"""
        try:
            plan = PlanManager.get_plan(plan_name)
            if not plan:
                return

            plan["last_run_at"] = run_result.get("started_at")
            plan["last_run_status"] = run_result.get("status")
            plan["total_runs"] = (plan.get("total_runs", 0) or 0) + 1

            # 追加 run_id 到历史
            runs = plan.get("runs", [])
            runs.append(run_result.get("run_id", ""))
            # 只保留最近 100 条
            plan["runs"] = runs[-100:]

            PlanManager._save_plan(plan)

        except Exception as e:
            logger.warning(f"[更新] 计划状态更新失败 {plan_name}: {e}")

    def _cleanup_temp(self, run_id: str):
        """清理临时文件。"""
        for f in TMP_DIR.glob(f"{run_id}_*"):
            try:
                f.unlink()
            except Exception:
                pass

    @staticmethod
    def _count_results(path: Path) -> int:
        """统计结果文件中的客户数量。"""
        try:
            if not path.exists():
                return 0
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            items = data.get("results", []) if isinstance(data, dict) else data
            return len(items)
        except Exception:
            return 0


# =========================================================================
#  定时器
# =========================================================================

class SchedulerThread(threading.Thread):
    """内部定时器，每 30 分钟扫描一次所有启用的计划。"""

    def __init__(self, engine: ExecutionEngine):
        super().__init__(daemon=True, name="scheduler")
        self.engine = engine
        self._pause = threading.Event()
        self._stop = threading.Event()
        self._pause.set()  # 默认运行
        self.last_check = None
        self.next_run_info = ""

    def run(self):
        logger.info("[定时器] 启动")
        while not self._stop.is_set():
            self._pause.wait()  # 如果暂停，会阻塞

            now = datetime.now()
            self.last_check = now.isoformat()

            try:
                self._check_plans()
            except Exception as e:
                logger.error(f"[定时器] 检查计划时出错: {e}")

            # 等待 30 分钟或直到被停止
            self._stop.wait(SCHEDULER_INTERVAL)

        logger.info("[定时器] 已停止")

    def _check_plans(self):
        """检查所有计划是否需要执行。"""
        active_plans = PlanManager.load_all_active()
        triggered = []

        for plan in active_plans:
            schedule = plan.get("schedule", {})
            rrule_str = schedule.get("rrule", "")
            if not rrule_str:
                continue

            try:
                next_run = PlanManager._calc_next_run(rrule_str, plan.get("last_run_at"))
                if next_run is None:
                    continue

                now = datetime.now(timezone.utc).astimezone()
                if next_run <= now:
                    # 防止 5 分钟窗口重复触发
                    last_run = plan.get("last_run_at")
                    if last_run:
                        last_dt = datetime.fromisoformat(last_run)
                        if (now - last_dt).total_seconds() < MIN_RUN_INTERVAL:
                            continue

                    logger.info(f"[定时器] 触发执行计划: {plan.get('plan_name')}")
                    # 在新线程中执行
                    t = threading.Thread(
                        target=self.engine.execute,
                        args=(plan,),
                        daemon=True,
                        name=f"exec-{plan.get('plan_name', '')[:16]}",
                    )
                    t.start()
                    triggered.append(plan.get('plan_name'))
                    self.next_run_info = (
                        f"{plan.get('plan_name')} → 已触发执行"
                    )
            except Exception as e:
                logger.warning(f"[定时器] 检查计划 '{plan.get('plan_name')}' 时出错: {e}")

        return triggered

    def scan_now(self) -> list:
        """手动扫描一次，返回已触发的计划名称列表。"""
        self.last_check = datetime.now().isoformat()
        try:
            return self._check_plans()
        except Exception as e:
            logger.error(f"[手动扫描] 出错: {e}")
            return []

    def pause(self):
        self._pause.clear()
        logger.info("[定时器] 暂停")

    def resume(self):
        self._pause.set()
        logger.info("[定时器] 恢复")

    def stop(self):
        self._stop.set()
        logger.info("[定时器] 停止信号已发送")


# =========================================================================
#  翻译文件桥接引擎（TranslationWatcher）
# =========================================================================

class TranslationWatcher:
    """
    文件桥接翻译引擎（方案A）。
    后台线程，每 2 秒扫描 translation_requests/ 目录，
    处理 status=pending 的翻译请求。
    
    翻译方式（按优先级）：
    1. 已配置 API Key → 使用 API 翻译
    2. 无 API Key → 使用免费 MyMemory API (无需 Key)
    3. MyMemory 失败 → 保持 pending，标注为 manual
    """

    def __init__(self, watch_dir: Path, interval: float = 2.0):
        self.watch_dir = watch_dir
        self.interval = interval
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None

    def start(self):
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._run, name="TranslationWatcher", daemon=True)
        self._thread.start()
        logger.info(f"[翻译桥接] 引擎已启动，扫描间隔 {self.interval} 秒")

    def stop(self):
        self._stop.set()
        logger.info("[翻译桥接] 引擎停止信号已发送")

    def _run(self):
        while not self._stop.wait(self.interval):
            try:
                self._process_pending()
            except Exception as e:
                logger.warning(f"[翻译桥接] 扫描异常: {e}")

    def _process_pending(self):
        if not self.watch_dir.exists():
            return
        for fpath in self.watch_dir.iterdir():
            if not fpath.name.endswith(".json"):
                continue
            try:
                with open(fpath, "r", encoding="utf-8") as f:
                    req = json.load(f)
                if req.get("status") != "pending":
                    continue
                if not req.get("original"):
                    continue
            except Exception:
                continue

            original = req["original"].strip()
            logger.info(f"[翻译桥接] 处理翻译请求: {fpath.name}, 原文: {original}")

            # 如果已是英文，直接返回
            if re.match(r'^[\x00-\x7F\s,.!?;:\'\"()-]+$', original):
                req["translated"] = original
                req["status"] = "completed"
                req["completed_at"] = datetime.now().isoformat()
                self._write_result(fpath, req)
                logger.info(f"[翻译桥接] ✓ 输入已是英文，直接使用: {original}")
                continue

            # 优先级1：尝试使用已配置的翻译 API
            translated = self._try_api_translate(original)
            if translated:
                req["translated"] = translated
                req["status"] = "completed"
                req["completed_at"] = datetime.now().isoformat()
                self._write_result(fpath, req)
                logger.info(f"[翻译桥接] ✓ API 翻译完成: {original} → {translated}")
                continue

            # 优先级2：尝试免费 MyMemory API
            translated = self._try_mymemory_translate(original)
            if translated:
                req["translated"] = translated
                req["status"] = "completed"
                req["completed_at"] = datetime.now().isoformat()
                self._write_result(fpath, req)
                logger.info(f"[翻译桥接] ✓ MyMemory 免费翻译完成: {original} → {translated}")
                continue

            # 全部失败：标记为 manual，等待人工处理
            req["status"] = "manual"
            req["note"] = "所有翻译方式均失败，请手动填写"
            req["completed_at"] = datetime.now().isoformat()
            self._write_result(fpath, req)
            logger.warning(f"[翻译桥接] ✗ 翻译失败: {original}")

    def _try_api_translate(self, text: str) -> str | None:
        """尝试使用已配置的翻译 API 翻译。"""
        cfg = get_translation_config()
        api_key = cfg.get("api_key", "").strip()
        if not api_key:
            return None
        base_url = cfg.get("base_url", "https://api.openai.com/v1").strip()
        model = cfg.get("model", "gpt-4o-mini").strip()
        try:
            import requests
            resp = requests.post(
                f"{base_url}/chat/completions",
                headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
                json={
                    "model": model,
                    "messages": [
                        {"role": "system", "content": "You are a translation assistant for B2B product search. Translate the user's Chinese text into short English keywords. Only return the English text, no explanation."},
                        {"role": "user", "content": f"Translate to English: {text}"}
                    ],
                    "temperature": 0.3,
                    "max_tokens": 60,
                },
                timeout=15,
            )
            if resp.status_code == 200:
                result = resp.json()["choices"][0]["message"]["content"].strip().strip('"').strip("'")
                return result if result else None
        except Exception as e:
            logger.warning(f"[翻译桥接] API 翻译失败: {e}")
        return None

    def _try_mymemory_translate(self, text: str) -> str | None:
        """使用免费的 MyMemory API 翻译（无需 API Key）。"""
        try:
            import requests
            resp = requests.get(
                "https://api.mymemory.translated.net/get",
                params={"q": text, "langpair": "zh-CN|en"},
                timeout=10,
            )
            if resp.status_code == 200:
                result = resp.json()
                translated = result.get("responseData", {}).get("translatedText", "").strip()
                if translated:
                    # MyMemory 有时会返回原文，做简单校验
                    if translated != text:
                        return translated
            return None
        except Exception as e:
            logger.warning(f"[翻译桥接] MyMemory 翻译失败: {e}")
            return None

    def _write_result(self, fpath: Path, data: dict):
        """写回翻译结果。"""
        try:
            with open(fpath, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
        except Exception as e:
            logger.error(f"[翻译桥接] 写回结果失败: {e}")


# =========================================================================
#  Flask 应用
# =========================================================================

def create_app(port: int = DEFAULT_PORT) -> Flask:
    """创建并配置 Flask 应用。"""
    app = Flask(__name__)
    CORS(app)

    engine = ExecutionEngine()
    scheduler = SchedulerThread(engine)
    start_time = datetime.now()

    # ─── 服务状态 ───

    @app.route("/api/status")
    def api_status():
        return jsonify({
            "running": scheduler.is_alive() if scheduler.is_alive() else scheduler._pause.is_set(),
            "uptime_seconds": (datetime.now() - start_time).total_seconds(),
            "plans_count": len(PlanManager.list_plans()),
            "scheduler_active": scheduler.is_alive() and scheduler._pause.is_set(),
            "last_check": scheduler.last_check,
            "port": port,
        })

    # ─── 统计概览 ───

    @app.route("/api/stats")
    def api_stats():
        plans = PlanManager.list_plans()
        total_plans = len(plans)
        active_plans = sum(1 for p in plans if p.get("enabled", False))
        total_runs = sum(p.get("total_runs", 0) for p in plans)
        total_new = sum(1 for p in plans if p.get("last_run_at"))

        last_run = None
        for p in plans:
            if p.get("last_run_at"):
                if not last_run or p["last_run_at"] > last_run:
                    last_run = p["last_run_at"]

        return jsonify({
            "total_plans": total_plans,
            "active_plans": active_plans,
            "total_runs": total_runs,
            "total_new": total_new,
            "last_run": last_run,
        })

    # ─── 计划列表 ───

    @app.route("/api/plans", methods=["GET"])
    def api_list_plans():
        plans = PlanManager.list_plans()
        return jsonify({"plans": plans})

    # ─── 创建计划 ───

    @app.route("/api/plans", methods=["POST"])
    def api_create_plan():
        data = request.get_json(force=True)
        try:
            plan = PlanManager.create_plan(data)
            return jsonify({"success": True, "plan": plan}), 201
        except ValueError as e:
            return jsonify({"success": False, "error": str(e)}), 400
        except Exception as e:
            logger.error(f"创建计划失败: {e}", exc_info=True)
            return jsonify({"success": False, "error": str(e)}), 500

    # ─── 单个计划详情 ───

    @app.route("/api/plans/<path:plan_name>", methods=["GET"])
    def api_get_plan(plan_name):
        plan = PlanManager.get_plan(plan_name)
        if not plan:
            return jsonify({"error": "计划不存在"}), 404
        return jsonify({"plan": plan})

    # ─── 更新计划 ───

    @app.route("/api/plans/<path:plan_name>", methods=["PUT"])
    def api_update_plan(plan_name):
        data = request.get_json(force=True)
        try:
            plan = PlanManager.update_plan(plan_name, data)
            return jsonify({"success": True, "plan": plan})
        except ValueError as e:
            return jsonify({"success": False, "error": str(e)}), 400
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

    # ─── 删除计划 ───

    @app.route("/api/plans/<path:plan_name>", methods=["DELETE"])
    def api_delete_plan(plan_name):
        try:
            PlanManager.delete_plan(plan_name)
            return jsonify({"success": True})
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

    # ─── 暂停 / 恢复 ───

    @app.route("/api/plans/<path:plan_name>/pause", methods=["POST"])
    def api_pause_plan(plan_name):
        try:
            PlanManager.update_plan(plan_name, {"enabled": False})
            return jsonify({"success": True})
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

    @app.route("/api/plans/<path:plan_name>/resume", methods=["POST"])
    def api_resume_plan(plan_name):
        try:
            PlanManager.update_plan(plan_name, {"enabled": True})
            return jsonify({"success": True})
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

    # ─── 立即执行 ───

    @app.route("/api/plans/<path:plan_name>/run", methods=["POST"])
    def api_run_plan(plan_name):
        plan = PlanManager.get_plan(plan_name)
        if not plan:
            return jsonify({"error": "计划不存在"}), 404

        # 检查是否正在运行
        if plan_name in engine.running:
            existing = engine.running.get(plan_name)
            if existing and existing.is_alive():
                return jsonify({"error": "该计划正在执行中，请稍后再试"}), 409

        # 在新线程中执行
        def _run_and_store():
            result = engine.execute(plan)
            engine.running[plan_name] = None

        t = threading.Thread(target=_run_and_store, daemon=True)
        engine.running[plan_name] = t
        t.start()

        return jsonify({"success": True, "message": f"计划 '{plan_name}' 已开始执行"}), 202

    # ─── 执行记录列表 ───

    @app.route("/api/plans/<path:plan_name>/runs", methods=["GET"])
    def api_plan_runs(plan_name):
        runs = LogManager.list_logs(plan_name=plan_name, limit=50)
        return jsonify({"runs": runs})

    # ─── 单条执行记录 ───

    @app.route("/api/runs/<run_id>", methods=["GET"])
    def api_get_run(run_id):
        log_data = LogManager.get_log(run_id)
        if not log_data:
            return jsonify({"error": "执行记录不存在"}), 404
        return jsonify({"run": log_data})

    # ─── 执行记录的文件列表 ───

    @app.route("/api/runs/<run_id>/files", methods=["GET"])
    def api_run_files(run_id):
        files = LogManager.get_output_files(run_id)
        return jsonify({"files": files})

    # ─── 下载产出文件 ───

    @app.route("/api/runs/<run_id>/download/<path:filename>", methods=["GET"])
    def api_download_file(run_id, filename):
        files = LogManager.get_output_files(run_id)
        for f_info in files:
            if f_info["filename"] == filename:
                return send_file(
                    f_info["path"],
                    as_attachment=True,
                    download_name=filename,
                )
        return jsonify({"error": "文件不存在"}), 404

    # ─── 系统配置 ───

    @app.route("/api/config", methods=["GET"])
    def api_get_config():
        # 读取 API Key 状态
        env_path = SCRIPTS_DIR / ".env.tavily"
        api_key = None
        api_key_configured = False
        if env_path.exists():
            with open(env_path, "r", encoding="utf-8") as f:
                for line in f:
                    if line.startswith("TAVILY_API_KEY="):
                        key = line.strip().split("=", 1)[1]
                        if key.startswith("tvly-"):
                            api_key_configured = True
                            api_key = key[:10] + "****" + key[-4:]
                        break

        # 检查 mail_server 状态
        mail_status = "unknown"
        try:
            import requests
            resp = requests.get("http://127.0.0.1:5678/api/status", timeout=3)
            mail_status = "running" if resp.status_code == 200 else "error"
        except Exception:
            mail_status = "stopped"

        return jsonify({
            "api_key_configured": api_key_configured,
            "api_key_preview": api_key,
            "output_dir": str(OUTPUT_DIR),
            "plans_dir": str(SEARCH_PLANS_DIR),
            "scheduler_status": {
                "running": scheduler.is_alive(),
                "last_check": scheduler.last_check,
                "interval_seconds": SCHEDULER_INTERVAL,
            },
            "mail_server": {
                "url": "http://127.0.0.1:5678",
                "status": mail_status,
            },
            "sender_email": get_smtp_config().get("sender_email", ""),
            "notification_emails": get_notification_emails(),
        })

    # ─── 更新 API Key ───

    @app.route("/api/config/apikey", methods=["POST"])
    def api_update_apikey():
        data = request.get_json(force=True)
        new_key = data.get("api_key", "").strip()

        if not new_key:
            return jsonify({"success": False, "error": "API Key 不能为空"}), 400
        if not new_key.startswith("tvly-"):
            return jsonify({"success": False, "error": "API Key 格式错误，应以 tvly- 开头"}), 400

        env_path = SCRIPTS_DIR / ".env.tavily"
        try:
            # 读取现有内容，保留其他配置
            lines = []
            if env_path.exists():
                with open(env_path, "r", encoding="utf-8") as f:
                    lines = f.readlines()

            updated = False
            for i, line in enumerate(lines):
                if line.strip().startswith("TAVILY_API_KEY="):
                    lines[i] = f"TAVILY_API_KEY={new_key}\n"
                    updated = True
                    break

            if not updated:
                lines.append(f"TAVILY_API_KEY={new_key}\n")

            with open(env_path, "w", encoding="utf-8") as f:
                f.writelines(lines)

            return jsonify({
                "success": True,
                "message": "API Key 已更新",
                "api_key_preview": new_key[:10] + "****" + new_key[-4:],
            })
        except Exception as e:
            logger.error(f"更新 API Key 失败: {e}")
            return jsonify({"success": False, "error": str(e)}), 500

    # ─── 通知邮箱管理 ───

    @app.route("/api/config/emails", methods=["GET"])
    def api_get_emails():
        cfg = load_config()
        emails = cfg.get("notification_emails", [])
        return jsonify({"success": True, "emails": emails})

    @app.route("/api/config/emails", methods=["POST"])
    def api_add_email():
        data = request.get_json(force=True)
        email = data.get("email", "").strip().lower()
        if not email or "@" not in email:
            return jsonify({"success": False, "error": "邮箱格式不正确"}), 400
        cfg = load_config()
        emails = cfg.get("notification_emails", [])
        if email in emails:
            return jsonify({"success": False, "error": "该邮箱已存在"}), 400
        emails.append(email)
        cfg["notification_emails"] = emails
        save_config(cfg)
        return jsonify({"success": True, "emails": emails})

    @app.route("/api/config/emails/<path:email>", methods=["DELETE"])
    def api_delete_email(email):
        email = email.strip().lower()
        cfg = load_config()
        emails = cfg.get("notification_emails", [])
        if email in emails:
            emails.remove(email)
        cfg["notification_emails"] = emails
        save_config(cfg)
        return jsonify({"success": True, "emails": emails})

    # ─── SMTP 邮件推送配置（代理到 mail_server:5678） ───

    @app.route("/api/config/mail", methods=["GET"])
    def api_get_mail_config():
        smtp = get_smtp_config()
        return jsonify({
            "success": True,
            "config": {
                "smtp_server": smtp.get("server", ""),
                "smtp_port": smtp.get("port", 587),
                "sender": smtp.get("sender_email", ""),
                "password": smtp.get("password", ""),
                "use_tls": smtp.get("use_tls", True),
            }
        })

    @app.route("/api/config/mail", methods=["POST"])
    def api_save_mail_config():
        data = request.get_json(force=True)
        try:
            import requests
            # 保存 SMTP 配置到本地（兼容前端字段名）
            cfg = load_config()
            cfg["smtp"] = {
                "server": data.get("smtp_server", data.get("server", "")),
                "port": data.get("smtp_port", data.get("port", 587)),
                "username": data.get("username", ""),
                "password": data.get("password", ""),
                "sender_email": data.get("sender", data.get("sender_email", "")),
                "use_tls": data.get("use_tls", True),
            }
            save_config(cfg)
            return jsonify({"success": True, "message": "SMTP 配置已保存"})
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

    @app.route("/api/config/mail/test", methods=["POST"])
    def api_test_mail():
        try:
            import requests
            resp = requests.post("http://127.0.0.1:5678/api/test", json={}, timeout=10)
            if resp.status_code == 200:
                return jsonify({"success": True, "message": "邮件发送测试成功"})
            return jsonify({"success": False, "error": resp.text[:200]}), 500
        except Exception as e:
            return jsonify({"success": False, "error": f"mail_server 未启动: {e}"}), 502

    # ─── 自动生成搜索词 ───

    @app.route("/api/generate-queries", methods=["POST"])
    def api_generate_queries():
        data = request.get_json(force=True)
        product = (data.get("product", "") or "").strip()
        product_en = (data.get("product_en", "") or "").strip()
        country = (data.get("country", "") or "").strip()
        mode = data.get("search_mode", "light").strip().lower()
        result_range = data.get("result_range", "medium").strip().lower()
        contact_scope = data.get("contact_scope", "top10").strip().lower()
        customer_types = data.get("customer_types", []) or []
        refresh = data.get("refresh", False)

        if not product:
            return jsonify({"success": False, "error": "请输入产品描述"}), 400
        if not country:
            return jsonify({"success": False, "error": "请选择目标国家"}), 400

        try:
            result = generate_search_queries(
                product, country, mode=mode, product_en=product_en,
                customer_types=customer_types, refresh=refresh,
            )
            queries = result["queries"]
            translation = result["translation"]
            # 计算预估消耗
            credit_estimate = estimate_total_credits(mode, result_range, contact_scope)

            return jsonify({
                "success": True,
                "queries": queries,
                "count": len(queries),
                "translation": translation,
                "credit_estimate": credit_estimate,
            })
        except Exception as e:
            logger.error(f"生成搜索词失败: {e}")
            return jsonify({"success": False, "error": str(e)}), 500

    # ─── 手动扫描 ───

    @app.route("/api/scheduler/scan", methods=["POST"])
    def api_scheduler_scan():
        triggered = scheduler.scan_now()
        return jsonify({
            "success": True,
            "triggered": triggered,
            "count": len(triggered),
            "message": f"扫描完成，触发了 {len(triggered)} 个计划" if triggered else "扫描完成，无需执行",
        })

    # ─── 打开输出文件夹 ───

    @app.route("/api/open-folder", methods=["POST"])
    def api_open_folder():
        try:
            os.makedirs(OUTPUT_DIR, exist_ok=True)
            if sys.platform == "win32":
                os.startfile(OUTPUT_DIR)
            elif sys.platform == "darwin":
                subprocess.run(["open", str(OUTPUT_DIR)])
            else:
                subprocess.run(["xdg-open", str(OUTPUT_DIR)])
            return jsonify({"success": True, "path": str(OUTPUT_DIR)})
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

    # ─── 首页（dashboard.html）───

    @app.route("/")
    def index():
        dashboard_path = SCRIPTS_DIR / "dashboard.html"
        if dashboard_path.exists():
            response = send_file(str(dashboard_path))
            # 防止浏览器缓存 dashboard.html，确保更新即时生效
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
            response.headers["Pragma"] = "no-cache"
            response.headers["Expires"] = "0"
            return response
        return "<h1>海外精准获客 · 搜索计划管理后台</h1><p>dashboard.html 未找到</p>"

    # ─── 头像 ───

    @app.route("/avatar")
    def avatar():
        avatar_path = SCRIPTS_DIR / "avatar.png"
        if avatar_path.exists():
            return send_file(str(avatar_path), mimetype="image/png")
        return "", 404

    # ─── 翻译桥接（方案A：文件桥接） ───

    @app.route("/api/translate-request", methods=["POST"])
    def api_translate_request():
        """
        创建翻译请求（文件桥接方案A）。
        写入 pending 请求文件到 translation_requests/ 目录，
        由 WorkBuddy AI 自动化任务检测并翻译后写回结果。
        """
        data = request.get_json(force=True)
        text = (data.get("text", "") or "").strip()
        if not text:
            return jsonify({"success": False, "error": "请输入要翻译的内容"}), 400

        request_id = f"tr_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}"
        now = datetime.now().isoformat()

        # 写入 pending 请求文件
        request_data = {
            "request_id": request_id,
            "original": text,
            "translated": None,
            "status": "pending",
            "created_at": now,
            "completed_at": None,
        }
        request_path = TRANSLATION_REQUESTS_DIR / f"{request_id}.json"
        with open(request_path, "w", encoding="utf-8") as f:
            json.dump(request_data, f, ensure_ascii=False, indent=2)

        logger.info(f"[翻译桥接] 创建翻译请求: {request_id}, 原文: {text}")
        return jsonify({
            "success": True,
            "request_id": request_id,
            "status": "pending",
            "note": "翻译请求已提交，等待 AI 处理",
        })

    @app.route("/api/translate-request/<request_id>", methods=["GET"])
    def api_get_translate_request(request_id):
        """查询翻译请求状态。"""
        safe_id = re.sub(r'[^a-zA-Z0-9_-]', '', request_id)
        request_path = TRANSLATION_REQUESTS_DIR / f"{safe_id}.json"
        if not request_path.exists():
            return jsonify({"success": False, "error": "翻译请求不存在"}), 404
        try:
            with open(request_path, "r", encoding="utf-8") as f:
                data = json.load(f)
            return jsonify({
                "success": True,
                "request_id": data["request_id"],
                "status": data["status"],
                "original": data["original"],
                "result": data.get("translated"),
                "created_at": data["created_at"],
                "completed_at": data.get("completed_at"),
            })
        except Exception as e:
            return jsonify({"success": False, "error": str(e)}), 500

    # 启动翻译文件桥接引擎
    watcher = TranslationWatcher(TRANSLATION_REQUESTS_DIR, interval=2.0)
    watcher.start()

    return app, engine, scheduler, watcher, start_time


# =========================================================================
#  主入口
# =========================================================================

def main():
    import argparse

    parser = argparse.ArgumentParser(description="搜索计划管理后台服务")
    parser.add_argument("--port", type=int, default=DEFAULT_PORT, help="监听端口")
    parser.add_argument("--host", type=str, default=DEFAULT_HOST, help="绑定地址")
    parser.add_argument("--no-scheduler", action="store_true", help="不启动定时器")
    args = parser.parse_args()

    # 确保目录存在
    ensure_dirs()

    # 创建应用
    app, engine, scheduler, watcher, start_time = create_app(args.port)

    # 启动定时器
    if not args.no_scheduler:
        # ── 关机恢复逻辑 ──
        # 检查是否有遗漏的执行
        missed = _check_missed_runs()
        if missed:
            logger.info(f"[恢复] 发现 {len(missed)} 个待补执行计划")
            for plan_data in missed:
                logger.info(f"[恢复] 补执行: {plan_data.get('plan_name')}")
                try:
                    engine.execute(plan_data)
                except Exception as e:
                    logger.error(f"[恢复] 补执行失败 {plan_data.get('plan_name')}: {e}")

        scheduler.start()

    logger.info(f"启动服务: http://{args.host}:{args.port}")
    app.run(host=args.host, port=args.port, debug=False)


def _check_missed_runs() -> list:
    """检查 24 小时内是否有遗漏的执行计划。"""
    missed = []
    for plan in PlanManager.load_all_active():
        schedule = plan.get("schedule", {})
        rrule_str = schedule.get("rrule", "")
        if not rrule_str:
            continue

        try:
            next_run = PlanManager._calc_next_run(rrule_str, plan.get("last_run_at"))
            if next_run is None:
                continue

            now = datetime.now(timezone.utc).astimezone()
            diff_hours = (now - next_run).total_seconds() / 3600

            # 如果在过去 24 小时内有错过的执行
            if 0 < diff_hours <= CATCHUP_WINDOW_HOURS:
                last_run = plan.get("last_run_at")
                if last_run:
                    last_dt = datetime.fromisoformat(last_run)
                    # 如果上次执行在下次计划时间之后，说明已补过
                    if last_dt > next_run:
                        continue
                missed.append(plan)
        except Exception as e:
            logger.warning(f"[恢复] 检查计划 '{plan.get('plan_name')}' 时出错: {e}")

    return missed


if __name__ == "__main__":
    main()
