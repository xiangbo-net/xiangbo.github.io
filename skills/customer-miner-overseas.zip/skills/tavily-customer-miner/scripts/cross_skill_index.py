"""
cross_skill_index.py — 跨 Skill 数据共享索引

本模块提供统一的读写接口，让不同的 Skill（tavily-customer-miner、mail-sender 等）
之间可以互相感知对方产出的数据位置，而不依赖具体的工作目录或上下文。

协议说明：
  - 索引文件位置：~/.workbuddy/skill_data_index.json
  - 索引文件由各个 Skill 的完成步骤写入，由消费方 Skill 读取
  - 这是一个"后续自我修复"的索引——即使初始为空，mail-sender 在找到数据后
    也会回写索引，下次调用时速度将大幅提升。

用法：
    from cross_skill_index import get_index, update_index, list_runs

    # mail-sender 侧：读取最近一次 runs 记录
    runs = list_runs("tavily-customer-miner")
    if runs:
        latest = runs[0]["output_dir"]  # 绝对路径

    # tavily-customer-miner 侧：写入完成记录
    update_index("tavily-customer-miner", {
        "company": "佛山电子",
        "country": "美国",
        "output_dir": "/path/to/runs/...",
        "customer_count": 31,
        "email_count": 8,
        "json_file": "/path/to/runs/.../结果_enriched.json"
    })
"""

import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

INDEX_PATH = Path.home() / ".workbuddy" / "skill_data_index.json"
MAX_HISTORY = 20  # 每个 skill 保留最近 20 条记录


# ─── 内部读写 ───


def _load() -> dict:
    """加载完整索引文件，文件不存在时返回空结构。"""
    if INDEX_PATH.exists():
        try:
            with open(INDEX_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except (json.JSONDecodeError, OSError):
            pass
    return {"version": 1, "skills": {}}


def _save(data: dict):
    """原子化写入索引文件。"""
    INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = INDEX_PATH.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(INDEX_PATH)


# ─── 公开 API ───


def get_index() -> dict:
    """返回完整的索引文件内容。"""
    return _load()


def update_index(skill_name: str, run_info: dict):
    """
    向索引中写入一条新的运行记录。

    参数：
        skill_name — skill 的名称，如 "tavily-customer-miner"
        run_info — 运行信息字典，应包含：
            - output_dir (str): 产出目录的绝对路径     [必填]
            - json_file (str): 核心数据文件的绝对路径   [推荐]
            - company (str):  公司名称                  [推荐]
            - country (str):  目标国家                  [推荐]
            - customer_count (int): 客户总数            [推荐]
            - email_count (int):   有邮箱的客户数        [推荐]
            - project_dir (str):  用户当前工作目录       [可选]

    自动添加的字段：
            - timestamp (str): 当前时间 ISO 格式
            - user_home (str): 用户 home 目录
    """
    record = {
        "timestamp": datetime.now(timezone.utc).astimezone().isoformat(),
        "user_home": str(Path.home()),
        **run_info,
    }

    data = _load()
    skill_data = data.setdefault("skills", {}).setdefault(skill_name, {"runs": []})
    runs = skill_data.setdefault("runs", [])

    # 首条插入（最新的在最前面）
    runs.insert(0, record)

    # 保留上限
    if len(runs) > MAX_HISTORY:
        runs[:] = runs[:MAX_HISTORY]

    # 更新 latest_run 快捷引用
    skill_data["latest_run"] = record
    data["_updated_at"] = record["timestamp"]

    _save(data)


def list_runs(skill_name: str, limit: int = 5) -> list[dict]:
    """
    列出某个 skill 的最新运行记录（按时间降序）。

    参数：
        skill_name — skill 名称
        limit — 最多返回条数

    返回：
        list[dict]，每个 dict 包含 run_info 中的所有字段
    """
    data = _load()
    runs = data.get("skills", {}).get(skill_name, {}).get("runs", [])
    return runs[:limit]


def get_latest_run(skill_name: str) -> Optional[dict]:
    """
    获取某个 skill 最近一次运行记录。

    返回 dict 或 None。
    """
    runs = list_runs(skill_name, limit=1)
    return runs[0] if runs else None


def remove_orphaned(skill_name: str) -> int:
    """
    移除索引中产出目录已不存在的记录（目录被用户手动删除）。

    参数：
        skill_name — skill 名称

    返回：
        int — 移除的记录数
    """
    data = _load()
    runs = data.get("skills", {}).get(skill_name, {}).get("runs", [])
    before = len(runs)
    runs[:] = [r for r in runs if os.path.isdir(r.get("output_dir", ""))]
    removed = before - len(runs)
    if removed > 0:
        if runs:
            data["skills"][skill_name]["latest_run"] = runs[0]
        else:
            data["skills"][skill_name].pop("latest_run", None)
        _save(data)
    return removed


# ─── 便捷判断 ───


def has_recent_run(skill_name: str, max_hours: int = 72) -> bool:
    """
    判断某个 skill 在过去 N 小时内是否有过运行记录。

    适用于 mail-sender 快速判断是否可以跳过扫描。
    """
    run = get_latest_run(skill_name)
    if not run:
        return False

    try:
        run_time = datetime.fromisoformat(run["timestamp"])
        now = datetime.now(timezone.utc).astimezone()
        delta_hours = (now - run_time).total_seconds() / 3600
        return delta_hours <= max_hours
    except (ValueError, KeyError):
        return False


# ─── 脚本入口：查看索引内容 ───

if __name__ == "__main__":
    import sys

    data = _load()
    skills = data.get("skills", {})

    if not skills:
        print("📭 skill_data_index.json 中暂无记录。")
        sys.exit(0)

    for skill_name, skill_data in skills.items():
        print(f"\n📦 {skill_name}")
        latest = skill_data.get("latest_run")
        if latest:
            print(f"  最新: {latest.get('company', '?')} | {latest.get('country', '?')}")
            print(f"  目录: {latest.get('output_dir', '?')}")
            print(f"  时间: {latest.get('timestamp', '?')}")
            print(f"  客户: {latest.get('customer_count', '?')} 家")
            print(f"  邮箱: {latest.get('email_count', '?')} 个")

        runs = skill_data.get("runs", [])
        if len(runs) > 1:
            print(f"  历史: {len(runs)} 条记录")
