#!/usr/bin/env python3
"""
企业联系信息深度获取脚本
========================
针对有官网但缺少电话/邮箱的企业，使用 requests 获取官网首页（及 /contact 页面），
提取所有电话和邮箱（多个用逗号分隔）。
用法：
  python scripts/crawl_contacts.py --input result.json --output result_enriched.json
"""

import argparse
import json
import os
import re
import sys
import threading
import time
import concurrent.futures
from datetime import datetime
from urllib.parse import urljoin, urlparse

import requests

# ──── 进程锁（防止同一命令被重复启动） ────
import msvcrt
_LOCK_FD = None


def acquire_lock(lock_path: str) -> bool:
    """获取独占文件锁，防止重复进程"""
    global _LOCK_FD
    os.makedirs(os.path.dirname(lock_path), exist_ok=True)
    try:
        _LOCK_FD = os.open(lock_path, os.O_CREAT | os.O_WRONLY, 0o644)
        msvcrt.locking(_LOCK_FD, msvcrt.LK_NBLCK, 1)
        # 写入当前进程 PID
        os.write(_LOCK_FD, str(os.getpid()).encode())
        return True
    except (IOError, OSError):
        if _LOCK_FD is not None:
            os.close(_LOCK_FD)
            _LOCK_FD = None
        print("错误：检测到另一个获取联系信息的进程正在运行，请等待完成后重试。")
        return False


def release_lock():
    """释放文件锁"""
    global _LOCK_FD
    if _LOCK_FD is not None:
        try:
            msvcrt.locking(_LOCK_FD, msvcrt.LK_UNLCK, 1)
            os.close(_LOCK_FD)
        except Exception:
            pass
        _LOCK_FD = None

# ──── 路径 ────
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PROGRESS_FILE = os.path.join(SKILL_DIR, "runs", "_crawl_progress.json")


def write_progress(current: int, total: int, found: int, status: str = "running", task_dir: str = None):
    """写入进度到文件（同时写到 .intermediate/ 和 skill runs 目录），供 AI 读取"""
    try:
        entry = {
            "status": status,
            "current": current,
            "total": total,
            "found": found,
            "updated_at": datetime.now().strftime("%H:%M:%S"),
        }
        # 写到 skill 公共目录（兼容旧路径）
        with open(PROGRESS_FILE, "w", encoding="utf-8") as f:
            json.dump(entry, f, ensure_ascii=False)
        # 同时写到任务目录的 .intermediate/（AI 可从中读取）
        if task_dir:
            # 确保写入 .intermediate/ 隐藏目录（兼容 task_dir 为任务根目录或已是 .intermediate 的情况）
            intermediate_dir = task_dir if task_dir.endswith('.intermediate') else os.path.join(task_dir, '.intermediate')
            os.makedirs(intermediate_dir, exist_ok=True)
            task_progress = os.path.join(intermediate_dir, "_crawl_progress.json")
            with open(task_progress, "w", encoding="utf-8") as f:
                json.dump(entry, f, ensure_ascii=False)
    except Exception:
        pass


# ──── 电话提取 ────
# 更加宽松的电话正则，覆盖各国格式
PHONE_PATTERNS = [
    # 国际格式: +1 234 567 8900, +49 9352 180, +86 755 8888 8888
    re.compile(r'(?<![a-zA-Z])\+\d{1,3}[\s.-]?\d{1,4}[\s.-]?\d{1,4}[\s.-]?\d{2,9}(?![a-zA-Z])'),
    # 美国格式: (800) 123-4567, 800-123-4567, 800.123.4567
    re.compile(r'\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}'),
    # 前缀引导: Tel: 123-456-7890, Phone: 123 456 7890
    re.compile(r'(?:tel|phone|call|contact|hotline)[:\s]*[+]?[\d][\d\s().-]{7,20}', re.I),
    # 普通 7-15 位数字（含空格/连字符）
    re.compile(r'\b\d{3,4}[\s.-]\d{3,4}[\s.-]\d{3,4}\b'),
]


def clean_phone(raw: str) -> str:
    p = re.sub(r'^(?:tel|phone|call|contact|hotline)[:\s]*', '', raw, flags=re.I)
    p = p.strip().strip(':').strip('-').strip()
    return p


def is_valid_phone(p: str) -> bool:
    digits = re.sub(r'[\s.\-\(\)]', '', p)
    return 7 <= len(digits) <= 18 and re.search(r'\d{4,}', digits)


def extract_phones(text: str) -> list:
    """提取所有合法电话，去重保留顺序"""
    if not text:
        return []
    seen = set()
    result = []
    for pat in PHONE_PATTERNS:
        for m in pat.findall(text):
            clean = clean_phone(m)
            if is_valid_phone(clean) and clean not in seen:
                seen.add(clean)
                result.append(clean)
    return result


# ──── 邮箱提取 ────
EMAIL_PATTERN = re.compile(r'[a-zA-Z0-9._%+\-]{2,}@[a-zA-Z0-9.\-]{2,}\.[a-zA-Z]{2,}')


def is_valid_email(e: str) -> bool:
    e = e.lower()
    # 排除图片文件（肯定不是邮箱）
    if e.split('@')[1].split('.')[-1] in ('png', 'jpg', 'jpeg', 'gif', 'svg', 'webp', 'ico', 'css', 'js'):
        return False
    # 排除占位符邮箱
    if any(p in e for p in ['example@', 'user@', 'your@', 'test@', '@domain.com', '@example.com']):
        return False
    # 排除格式异常
    if '..' in e or e.startswith('.') or e.endswith('.'):
        return False
    return True


def extract_emails(text: str) -> list:
    """提取所有有效邮箱，去重"""
    if not text:
        return []
    seen = set()
    result = []
    for m in EMAIL_PATTERN.findall(text):
        e = m.lower().strip()
        if e not in seen and is_valid_email(e):
            seen.add(e)
            result.append(e)
    return result


# ──── 获取核心 ────
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml",
    "Accept-Language": "en-US,en;q=0.9,zh-CN;q=0.8,zh;q=0.7",
    "Accept-Encoding": "gzip, deflate",
    "Connection": "keep-alive",
}
TIMEOUT = 5
DELAY = 0  # 多线程并发，不需要礼貌延迟
TAVILY_API_BASE = "https://api.tavily.com"
ENV_FILE = os.path.join(SKILL_DIR, ".env.tavily")

# 当 requests 获取失败时（403/JS挑战等），用 Tavily Extract 兜底
# 这种站点通常占 5-10%
_TAVILY_API_KEY = None


def load_tavily_key() -> str:
    global _TAVILY_API_KEY
    if _TAVILY_API_KEY:
        return _TAVILY_API_KEY
    if os.path.exists(ENV_FILE):
        with open(ENV_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("TAVILY_API_KEY="):
                    key = line.split("=", 1)[1].strip().strip('"').strip("'")
                    if key:
                        _TAVILY_API_KEY = key
                        return key
    return ""


def fetch_page(url: str) -> tuple:
    """
    获取网页 HTML 内容。
    返回: (html, blocked) — blocked=True 表示被安全防护拦截
    """
    try:
        resp = requests.get(url, headers=HEADERS, timeout=TIMEOUT, allow_redirects=True)
        resp.encoding = resp.apparent_encoding
        if resp.status_code == 403:
            return ("", True)  # 被安全防护拦截
        if resp.status_code == 200 and len(resp.text) > 200:
            return (resp.text, False)
        return ("", False)
    except Exception:
        return ("", False)


def fetch_via_tavily(url: str) -> str:
    """当 requests 获取失败时，用 Tavily Extract 兜底"""
    api_key = load_tavily_key()
    if not api_key:
        return ""
    try:
        resp = requests.post(
            f"{TAVILY_API_BASE}/extract",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "urls": [url],
                "extract_depth": "basic",
                "query": "contact information phone email address about us",
                "include_images": False,
                "format": "markdown",
            },
            timeout=10,
        )
        if resp.status_code == 200:
            results = resp.json().get("results", [])
            if results:
                return results[0].get("raw_content", "")
        return ""
    except Exception:
        return ""


def crawl_website(base_url: str) -> dict:
    """
    获取企业官网联系信息。
    策略：首页 → /about → /contact → ...
    如果 requests 被拦截（403），自动用 Tavily Extract 兜底。
    """
    phones = set()
    emails = set()
    used_tavily = False

    # 标准化 URL
    parsed = urlparse(base_url)
    if not parsed.scheme:
        base_url = "https://" + base_url
        parsed = urlparse(base_url)

    base_origin = f"{parsed.scheme}://{parsed.netloc}"

    # 要尝试的页面路径（扩展版：首页 + about + contact + 团队页）
    # 2026-07-09 变更记录：新增 /team、/our-team、/management 三个路径，
    # 团队/管理层页面常包含员工邮箱（如 sales@、info@），可大幅提高邮箱命中率
    paths = ["", "/about", "/contact", "/contact-us",
             "/team", "/our-team", "/management"]

    for path in paths:
        url = urljoin(base_url, path)
        html, blocked = fetch_page(url)
        
        # 如果被安全防护拦截，用 Tavily Extract 兜底
        if blocked and not used_tavily:
            tavily_html = fetch_via_tavily(url)
            if tavily_html:
                html = tavily_html
                used_tavily = True
        
        if not html:
            continue

        ph = extract_phones(html)
        em = extract_emails(html)
        for p in ph:
            phones.add(p)
        for e in em:
            emails.add(e)

        # 如果首页已经有电话或邮箱，仍然继续找 /contact 页面
        # 但只尝试前 2 个常见路径

    # 限制数量
    phones_list = list(phones)[:10]
    emails_list = list(emails)[:10]

    return {
        "phone": ", ".join(phones_list) if phones_list else "",
        "email": ", ".join(emails_list) if emails_list else "",
        "used_tavily": used_tavily,
    }


# ──── 主流程 ────
def main():
    parser = argparse.ArgumentParser(description="企业联系信息深度获取")
    parser.add_argument("--input", required=True, help="输入的 JSON 结果文件")
    parser.add_argument("--output", required=True, help="输出的 JSON 文件")
    parser.add_argument("--max", type=int, default=0, help="最多获取企业数（0=全部）")
    parser.add_argument("--concurrent", type=int, default=5, help="并发线程数（默认5）")
    args = parser.parse_args()

    # ── 获取进程锁，防止重复启动 ──
    lock_path = os.path.join(os.path.dirname(args.output), "._crawl.lock")
    if not acquire_lock(lock_path):
        sys.exit(1)

    # 任务目录（用于写入进度文件）
    task_dir = os.path.dirname(args.output)
    os.makedirs(task_dir, exist_ok=True)

    # 读数据
    with open(args.input, "r", encoding="utf-8") as f:
        data = json.load(f)

    customers = data.get("customers", [])
    total = len(customers)

    # 需要抓取的企业
    # 2026-07-09 变更记录：爬取条件从"缺电话且缺邮箱"改为"只要缺邮箱就爬"，
    # 海外获客邮箱价值远大于电话，有电话无邮箱的企业仍需爬取以补充邮箱
    to_crawl = []
    for c in customers:
        url = (c.get("website") or "").strip()
        has_phone = bool(c.get("phone") and c["phone"] not in ("", "-"))
        has_email = bool(c.get("email") and c["email"] not in ("", "-"))
        if url and url.startswith("http") and not has_email:
            to_crawl.append(c)

    if not to_crawl:
        print(f"所有 {total} 家企业都有联系信息或没有官网，无需抓取。")
        with open(args.output, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return

    # 限制数量
    if args.max > 0:
        to_crawl = to_crawl[:args.max]

    print(f"共 {total} 家企业，其中 {len(to_crawl)} 家需要深度获取联系信息...")
    print(f"使用 {args.concurrent} 个并发线程处理...\n")

    success = 0
    tavily_fallback = 0
    _lock = threading.Lock()  # 用于线程安全的计数器更新

    def process_one(customer: dict, idx: int) -> dict:
        """单个企业的爬取任务（多线程用）"""
        nonlocal tavily_fallback
        url = customer["website"]
        name = customer.get("company_name", "?")[:25]

        result = crawl_website(url)

        if result.get("used_tavily"):
            with _lock:
                tavily_fallback += 1

        # 记录结果
        out = {
            "phone": result["phone"],
            "email": result["email"],
            "phone_source": "crawl" + ("_tavily" if result.get("used_tavily") else ""),
            "email_source": "crawl" + ("_tavily" if result.get("used_tavily") else ""),
            "index": idx,
        }
        return out

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.concurrent) as executor:
        futures = {
            executor.submit(process_one, c, i): (i, c)
            for i, c in enumerate(to_crawl)
        }

        for future in concurrent.futures.as_completed(futures):
            i, c = futures[future]
            try:
                out = future.result()
                c["phone"] = out["phone"]
                c["email"] = out["email"]
                c["phone_source"] = out["phone_source"]
                c["email_source"] = out["email_source"]

                has_phone = bool(out["phone"])
                has_email = bool(out["email"])
                if has_phone or has_email:
                    success += 1

                tavily_tag = " [T]" if out["phone_source"] == "crawl_tavily" else ""
                print(f"  [{i + 1}/{len(to_crawl)}] {c.get('company_name', '?')[:25]:25s} -> 电话:{'Y' if has_phone else 'N'} 邮箱:{'Y' if has_email else 'N'}{tavily_tag}")
            except Exception as e:
                print(f"  [{i + 1}/{len(to_crawl)}] {c.get('company_name', '?')[:25]:25s} -> 异常:{str(e)[:30]}")

            # 每完成3家或最后一家时更新进度
            done_count = sum(1 for f in futures if f.done())
            if done_count % 3 == 0 or done_count == len(to_crawl):
                write_progress(done_count, len(to_crawl), success, task_dir=task_dir)

    # 更新统计
    stats = data.get("search_stats", {})
    stats["with_contact"] = sum(
        1 for c in customers
        if c.get("phone", "") not in ("", "-", None) or c.get("email", "") not in ("", "-", None)
    )
    stats["crawled_count"] = success
    stats["crawl_total"] = len(to_crawl)
    stats["crawl_credits"] = 0
    stats["tavily_fallback"] = tavily_fallback
    tavily_credits = (tavily_fallback + 4) // 5  # Tavily 兜底积分

    print(f"\n信息获取完成！")
    print(f"  成功补充: {success}/{len(to_crawl)} 家企业")
    print(f"  总联系信息覆盖率: {stats['with_contact']}/{stats.get('valid_companies', total)} "
          f"({stats['with_contact'] * 100 // max(stats.get('valid_companies', total), 1)}%)")

    # 标记完成
    write_progress(len(to_crawl), len(to_crawl), success, status="completed", task_dir=task_dir)

    # 输出
    with open(args.output, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    print(f"  输出文件: {args.output}")

    release_lock()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        release_lock()
        raise
