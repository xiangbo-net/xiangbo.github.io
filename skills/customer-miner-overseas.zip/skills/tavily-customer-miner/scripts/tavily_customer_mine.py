#!/usr/bin/env python3
"""
Tavily 海外客户挖掘 - 主搜索脚本
==================================

直接使用 REST API（避免 tavily-python SDK 的 httpx 兼容问题）。

用法：
  python scripts/tavily_customer_mine.py --config config.json
  python scripts/tavily_customer_mine.py --config config.json --output result.json
"""

import argparse
import json
import os
import re
import sys
import time
import hashlib
from datetime import datetime
from urllib.parse import urlparse

# 使用 requests 而非 tavily SDK（httpx 在某些 Windows 环境有兼容问题）
import requests

# ──────── 路径 ────────
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_FILE = os.path.join(SKILL_DIR, ".env.tavily")
DEDUP_FILE = os.path.join(SKILL_DIR, "dedup_index.json")
TAVILY_API_BASE = "https://api.tavily.com"


# ═══════════════════════════════════════════════════
#  0. 国家名规范化映射
# ═══════════════════════════════════════════════════

# Tavily API country 参数要求：小写英文国家全称（仅 topic=general 时可用）
# 支持中文名、英文简称、两位ISO代码 → 自动转换为 Tavily 要求的英文全称
COUNTRY_MAP = {
    # 中文 → 英文
    "中国": "china", "美国": "united states", "英国": "united kingdom",
    "德国": "germany", "法国": "france", "日本": "japan",
    "韩国": "south korea", "印度": "india", "泰国": "thailand",
    "新加坡": "singapore", "马来西亚": "malaysia", "越南": "vietnam",
    "加拿大": "canada", "澳大利亚": "australia", "巴西": "brazil",
    "俄罗斯": "russia", "荷兰": "netherlands", "意大利": "italy",
    "西班牙": "spain", "瑞士": "switzerland", "瑞典": "sweden",
    "挪威": "norway", "丹麦": "denmark", "芬兰": "finland",
    "波兰": "poland", "土耳其": "turkey", "沙特阿拉伯": "saudi arabia",
    "阿联酋": "united arab emirates", "南非": "south africa",
    "墨西哥": "mexico", "阿根廷": "argentina", "印度尼西亚": "indonesia",
    "菲律宾": "philippines", "新西兰": "new zealand",
    "台湾": "taiwan",
    "中国台湾": "taiwan",
    # 英文简称 → 英文全称
    "usa": "united states", "us": "united states",
    "uk": "united kingdom", "gb": "united kingdom",
    "uae": "united arab emirates",
    "korea": "south korea",
    "south korea": "south korea",
    # 两位ISO代码 → 英文全称
    "cn": "china", "de": "germany", "fr": "france",
    "jp": "japan", "sg": "singapore", "in": "india",
    "th": "thailand", "vn": "vietnam", "my": "malaysia",
    "kr": "south korea", "ca": "canada", "au": "australia",
    "br": "brazil", "ru": "russia", "nl": "netherlands",
    "it": "italy", "es": "spain", "ch": "switzerland",
    "se": "sweden", "no": "norway", "dk": "denmark",
    "fi": "finland", "pl": "poland", "tr": "turkey",
    "sa": "saudi arabia", "ae": "united arab emirates",
    "za": "south africa", "mx": "mexico", "ar": "argentina",
    "id": "indonesia", "ph": "philippines", "nz": "new zealand",
}


def normalize_country(country_input: str) -> str:
    """将各种格式的国家名规范化为 Tavily API 要求的英文全称（小写）"""
    if not country_input:
        return ""
    key = country_input.strip().lower()
    # 1) 优先查映射表
    if key in COUNTRY_MAP:
        return COUNTRY_MAP[key]
    # 2) 如果已经是有效英文且仅含字母空格（如 "germany"、"united states"），直接返回
    if re.match(r'^[a-z\s]+$', key) and len(key) > 2:
        return key
    # 3) 兜底返回原值（可能 API 会报错，但由请求层处理）
    return country_input


# ═══════════════════════════════════════════════════
#  1. 配置加载
# ═══════════════════════════════════════════════════

def parse_args() -> argparse.Namespace:
    """解析命令行参数"""
    parser = argparse.ArgumentParser(description="Tavily 海外客户挖掘")
    parser.add_argument("--config", help="配置文件路径")
    parser.add_argument("--output", help="输出文件路径（避免 stdout 编码问题）")
    return parser.parse_args()


def load_config(args: argparse.Namespace) -> dict:
    """从 --config 文件或 stdin 加载配置"""
    if args.config:
        with open(args.config, "r", encoding="utf-8") as f:
            return json.load(f)
    else:
        raw = sys.stdin.read()
        return json.loads(raw)


def load_api_key() -> str:
    if not os.path.exists(ENV_FILE):
        print(json.dumps({"error": ".env.tavily 不存在"}), file=sys.stderr)
        sys.exit(1)
    with open(ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("TAVILY_API_KEY="):
                key = line.split("=", 1)[1].strip().strip('"').strip("'")
                if key:
                    return key
    print(json.dumps({"error": "TAVILY_API_KEY 为空"}), file=sys.stderr)
    sys.exit(1)


def tavily_search(api_key: str, query: str, search_depth: str = "fast",
                  max_results: int = 20, country: str = None,
                  exclude_domains: list = None,
                  include_raw_content: bool = False) -> dict:
    """直接调用 Tavily Search REST API"""
    payload = {
        "query": query,
        "search_depth": search_depth,
        "max_results": max_results,
        "topic": "general",
        "include_answer": False,
        "include_raw_content": "markdown" if include_raw_content else False,
        "include_images": False,
        "include_usage": True,
    }
    # country 参数仅支持 basic / advanced 搜索深度
    if country:
        if search_depth in ("fast", "ultra-fast"):
            # 自动升级到 basic（同1积分，支持 country 参数）
            search_depth = "basic"
        # 关键：更新 payload 中的 search_depth，否则已赋值的 fast 仍会发出去
        payload["search_depth"] = search_depth
        payload["country"] = country
    if exclude_domains:
        payload["exclude_domains"] = exclude_domains

    try:
        resp = requests.post(
            f"{TAVILY_API_BASE}/search",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json=payload,
            timeout=30,
        )
        if resp.status_code == 200:
            return resp.json()
        else:
            error_body = resp.text[:200]
            return {
                "query": query,
                "error": f"HTTP {resp.status_code}: {error_body}",
                "results": [],
                "usage": {"credits": 0},
                "response_time": 0,
            }
    except Exception as e:
        return {
            "query": query,
            "error": str(e),
            "results": [],
            "usage": {"credits": 0},
            "response_time": 0,
        }


def tavily_extract(api_key: str, urls: list) -> dict:
    """直接调用 Tavily Extract REST API"""
    if not urls:
        return {"results": [], "failed_results": []}
    try:
        resp = requests.post(
            f"{TAVILY_API_BASE}/extract",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "urls": urls,
                "extract_depth": "basic",
                "include_images": False,
                "format": "markdown",
                "include_usage": True,
            },
            timeout=60,
        )
        if resp.status_code == 200:
            return resp.json()
        else:
            print(json.dumps({"warning": f"Extract HTTP {resp.status_code}"}), file=sys.stderr)
            return {"results": [], "failed_results": urls}
    except Exception as e:
        print(json.dumps({"warning": f"Extract 异常: {str(e)[:80]}"}), file=sys.stderr)
        return {"results": [], "failed_results": urls}


# ═══════════════════════════════════════════════════
#  2. 去重
# ═══════════════════════════════════════════════════

def dedup_results(all_results: list) -> list:
    seen_urls = set()
    unique = []
    for item in all_results:
        url = item.get("url", "").strip().rstrip("/")
        if not url or url in seen_urls:
            continue
        seen_urls.add(url)
        unique.append(item)
    return unique


# ═══════════════════════════════════════════════════
#  3. 联系信息提取
# ═══════════════════════════════════════════════════

PHONE_PATTERNS = [
    re.compile(r'\+\d{1,3}[\s.-]?\d{1,4}[\s.-]?\d{1,4}[\s.-]?\d{1,9}'),
    re.compile(r'(?:tel|phone|call|contact)[:\s]*\+?\d[\d\s.-]{7,15}'),
    re.compile(r'\+?\d{2,3}[\s.-]?\d{3,4}[\s.-]?\d{4,8}'),
]
EMAIL_PATTERN = re.compile(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')
ADDRESS_PATTERNS = [
    re.compile(r'\d+\s+[A-Za-z\s]+,\s*[A-Za-z\s]+,\s*[A-Z]{2}\s+\d{5}'),
    re.compile(r'[A-Za-zäöüßÄÖÜ\s]+\s+\d{3,5}\s+[A-Za-zäöüßÄÖÜ\s]+'),
]


def extract_contact(text: str) -> dict:
    if not text:
        return {"phone": None, "email": None, "address": None}
    phones = []
    for p in PHONE_PATTERNS:
        for m in p.findall(text):
            clean = re.sub(r'^(?:tel|phone|call|contact)[:\s]*', '', m, flags=re.I).strip()
            if len(clean) >= 6 and clean not in phones:
                phones.append(clean)
    emails = [e for e in set(EMAIL_PATTERN.findall(text)) if not re.search(r'^noreply|no.reply|donotreply', e, re.I)]
    addrs = []
    for a in ADDRESS_PATTERNS:
        addrs.extend(a.findall(text))
    return {
        "phone": phones[0] if phones else None,
        "email": emails[0] if emails else None,
        "address": addrs[0] if addrs else None,
    }


def extract_company_name(title: str, url: str) -> str:
    name = title or ""
    for s in [r"\s*[-–—|]\s*(?:Home|Official Site|Official Website|Wikipedia|LinkedIn|Bloomberg|Crunchbase)$",
              r"\s*\|\s*.+$", r"\s*-\s*.+$"]:
        name = re.sub(s, "", name).strip()
    return name if name else url


# ═══════════════════════════════════════════════════
#  4. 评分
# ═══════════════════════════════════════════════════

LEGAL_WORDS = ["Inc", "AG", "GmbH", "Ltd", "Corp", "LLC", "BV", "NV", "SA", "SE", "KG", "PLC"]
THIRD_PARTY = ["linkedin.com", "yelp.com", "crunchbase.com", "bloomberg.com",
               "glassdoor.com", "indeed.com", "facebook.com", "twitter.com", "x.com"]


def score_item(title: str, content: str, url: str, search_score: float, contact: dict) -> dict:
    text = f"{title} {content or ''}"
    s = min(4, int(search_score * 4))  # 相关性
    has_site = 1 if url and not any(d in url for d in THIRD_PARTY) else 0
    has_contact = 1 if contact.get("phone") or contact.get("email") else 0
    s += has_site + has_contact  # 信息完整度
    s += min(2, sum(1 for w in LEGAL_WORDS if w.lower() in text.lower()))  # 企业规模
    s += 1 if not any(d in url.lower() for d in THIRD_PARTY) else 0  # 权威性
    has_loc = bool(re.search(r'[A-Z][a-z]+,\s*[A-Z]{2}', content or ''))
    if contact.get("address"):
        has_loc = True
    s += 1 if has_loc else 0  # 位置
    priority = "P1" if s >= 7 else ("P2" if s >= 4 else "P3")
    return {"score": s, "priority": priority}


# ═══════════════════════════════════════════════════
#  5. 历史去重索引
# ═══════════════════════════════════════════════════

def load_dedup() -> dict:
    if not os.path.exists(DEDUP_FILE):
        return {"version": 1, "updated_at": None, "total_companies": 0, "companies": []}
    try:
        with open(DEDUP_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"version": 1, "updated_at": None, "total_companies": 0, "companies": []}


def save_dedup(index: dict):
    with open(DEDUP_FILE, "w", encoding="utf-8") as f:
        json.dump(index, f, ensure_ascii=False, indent=2)


def norm_name(name: str) -> str:
    n = name.strip().lower()
    n = re.sub(r'[,.\-]', ' ', n)
    n = re.sub(r'\s+(ltd|limited|gmbh|inc|incorporated|corp|corporation|llc|bv|nv|sa|se|kg|plc|ag|sas|co)\.?$', '', n)
    return re.sub(r'\s+', ' ', n).strip()


def check_duplicates(items: list, index: dict) -> tuple:
    if not index.get("companies") or not items:
        return items, [], 0
    new_list, dup_list = [], []
    for item in items:
        url = item.get("url", "").strip().rstrip("/")
        cname = norm_name(item.get("company_name", ""))
        is_dup = False
        for ex in index["companies"]:
            eu = (ex.get("website") or "").strip().rstrip("/")
            if url and eu and url == eu:
                is_dup = True
                break
            en = norm_name(ex.get("company_name", ""))
            if cname and en and cname == en and len(cname) > 3:
                is_dup = True
                break
        if is_dup:
            dup_list.append(item)
        else:
            new_list.append(item)
    return new_list, dup_list, len(dup_list)


def merge_index(new_items: list, run_name: str, index: dict):
    now = datetime.now().strftime("%Y-%m-%d")
    comps = index.get("companies", [])
    for item in new_items:
        url = item.get("url", "").strip().rstrip("/")
        cname = item.get("company_name", "")
        found = False
        for ex in comps:
            eu = (ex.get("website") or "").strip().rstrip("/")
            if url and eu and url == eu:
                ex["last_found"] = now
                ex["found_count"] = ex.get("found_count", 1) + 1
                if run_name not in ex.get("found_in_runs", []):
                    ex.setdefault("found_in_runs", []).append(run_name)
                found = True
                break
            en = norm_name(ex.get("company_name", ""))
            cn = norm_name(cname)
            if cn and en and cn == en and len(cn) > 3:
                ex["last_found"] = now
                ex["found_count"] = ex.get("found_count", 1) + 1
                if run_name not in ex.get("found_in_runs", []):
                    ex.setdefault("found_in_runs", []).append(run_name)
                found = True
                break
        if not found:
            comps.append({
                "company_name": cname,
                "website": url,
                "first_found": now,
                "last_found": now,
                "found_count": 1,
                "found_in_runs": [run_name],
                "countries": [item.get("country", "")] if item.get("country") else [],
                "has_contact_info": bool(item.get("phone") or item.get("email")),
                "best_phone": item.get("phone"),
                "best_email": item.get("email"),
            })
    index["total_companies"] = len(comps)
    index["companies"] = comps
    index["updated_at"] = datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00")
    save_dedup(index)


# ═══════════════════════════════════════════════════
#  6. 主流程
# ═══════════════════════════════════════════════════

def main():
    args = parse_args()
    config = load_config(args)

    # ── 输出编码处理（兼容 Windows/macOS/Linux） ──
    # 当 stdout 编码不支持中文时，自动写文件替代
    use_output_file = False
    output_path = None
    if args.output:
        output_path = args.output
        use_output_file = True
    else:
        stdout_enc = getattr(sys.stdout, "encoding", "").upper()
        if stdout_enc and stdout_enc not in ("UTF-8", "UTF8", "UTF-8-BOM"):
            # stdout 编码不支持中文（如 Windows 的 cp936/GBK）
            # 自动写入 runs 目录下的临时文件
            ts_main = datetime.now().strftime("%Y-%m-%d_%H%M%S")
            output_path = os.path.join(SKILL_DIR, "runs", f"_stdout_{ts_main}.json")
            use_output_file = True

    start = time.time()
    api_key = load_api_key()
    company_name = config.get("company_name", "Unknown")
    queries = config.get("search_queries", [])
    if not queries:
        print(json.dumps({"error": "search_queries 为空"}), file=sys.stderr)
        sys.exit(1)

    # 输出目录（统一到 wxskill 数据目录）
    # 优先级：config 中的 output_dir > 从 --output 参数推导 > 自动生成新目录名
    ts = datetime.now().strftime("%Y-%m-%d_%H%M")
    country_label = config.get("target_country", "global")
    run_name = f"{ts}_{company_name}_{country_label}"

    out_dir = config.get("output_dir")

    # 兜底：如果 config 中没有 output_dir，尝试从 --output 文件路径推导
    # Agent 应将中间文件放在 output/任务目录/.intermediate/ 下，从 --output 的父级目录向上找
    if not out_dir and args.output:
        _output_path = os.path.abspath(args.output)
        # --output 通常指向 .intermediate/_search_out.json
        # 其父目录是 .intermediate/，再上一级就是任务目录
        _parent = os.path.dirname(_output_path)       # .intermediate
        _grandparent = os.path.dirname(_parent)         # 任务目录
        # 验证路径特征：父目录名为 .intermediate，且祖父目录包含 "output"
        if (
            os.path.basename(_parent).startswith(".intermediate")
            and ("output" in _grandparent or "overseas-customer-miner" in _grandparent)
        ):
            out_dir = _grandparent

    # 最终回退：无法推导时才自动生成
    if not out_dir:
        out_dir = os.path.join(
            os.path.expanduser("~"), ".workbuddy", "userdata", "wxskill",
            "overseas-customer-miner", "output", run_name
        )
    os.makedirs(out_dir, exist_ok=True)

    # ── 搜索 ──
    depth = config.get("search_depth") or "fast"
    max_r = config.get("max_results") or 20
    country = config.get("target_country", "")
    country = normalize_country(country)  # 自动转换国家名为 Tavily 格式
    exclude = config.get("exclude_domains") or ["wikipedia.org"]
    raw_indices = config.get("include_raw_content_queries") or []
    product_desc = config.get("product_description") or ""


    print(json.dumps({"phase": "search", "queries": len(queries)}), file=sys.stderr)
    all_raw, search_detail, total_sc = [], [], 0
    for idx, q in enumerate(queries):
        use_raw = idx in raw_indices
        resp = tavily_search(api_key, q, depth, max_r, country, exclude, use_raw)
        usage = resp.get("usage", {})
        credits = usage.get("credits", 1) if "error" not in resp else 0
        total_sc += credits
        results = resp.get("results", [])
        for r in results:
            r["_query"] = q
        all_raw.extend(results)
        search_detail.append({
            "query": q, "results": len(results),
            "credits": credits, "error": resp.get("error"),
        })
        time.sleep(0.3)

    unique = dedup_results(all_raw)
    print(json.dumps({"phase": "search_done", "before_dedup": len(all_raw), "after_dedup": len(unique)}), file=sys.stderr)

    # ── 初筛 + 评分 ──
    processed = []
    for item in unique:
        title = item.get("title", "")
        content = item.get("content", "") or ""
        url = item.get("url", "")
        raw_c = item.get("raw_content") or ""
        cname = extract_company_name(title, url)
        text = f"{title}\n{content}\n{raw_c}"
        contact = extract_contact(text)
        sc = score_item(cname, content, url, item.get("score", 0), contact)
        processed.append({
            "company_name": cname,
            "website": url,
            "content_summary": content[:300],
            "search_score": item.get("score", 0),
            "matched_query": item.get("_query", ""),
            "country": country_label,
            "phone": contact["phone"],
            "email": contact["email"],
            "address": contact["address"],
            "has_raw_content": bool(raw_c),
            "score": sc["score"],
            "priority": sc["priority"],
        })
    processed.sort(key=lambda x: x["score"], reverse=True)

    # ── 历史去重 ──
    dedup_enabled = config.get("dedup_enabled", True)
    dup_count, dup_list = 0, []
    if dedup_enabled:
        index = load_dedup()
        new_items, dup_items, dc = check_duplicates(processed, index)
        dup_count, dup_list = dc, dup_items
        for d in dup_items:
            d["is_duplicate"] = True
        for n in new_items:
            n["is_duplicate"] = False
    else:
        new_items = processed
        for n in new_items:
            n["is_duplicate"] = False

    # ── Extract 深度提取 ──
    # 2026-07-09 变更记录：top_n_for_extract 的 0 值表示全部提取（A 方案），
    # 以最大化 Tavily Extract 对 WAF 防护网站的突破能力，补充爬虫无法触及的邮箱
    top_n = config.get("top_n_for_extract")  # None/0=全部，正数=前N家
    if top_n is None or top_n == 0:
        top_n = 0  # 统一处理 None 和 0 为"全部提取"
    extract_candidates = [n for n in new_items if not n.get("has_raw_content") and n.get("website")]
    if top_n > 0:
        extract_candidates = extract_candidates[:top_n]
    total_ec = 0
    extract_detail = []
    if extract_candidates:
        urls = [c["website"] for c in extract_candidates]
        print(json.dumps({"phase": "extract", "urls": len(urls)}), file=sys.stderr)
        ext_resp = tavily_extract(api_key, urls)
        results = ext_resp.get("results", [])
        total_ec = ext_resp.get("usage", {}).get("credits", 0)
        url_map = {}
        for ex in results:
            u = (ex.get("url") or "").strip().rstrip("/")
            url_map[u] = ex.get("raw_content", "")
        for item in extract_candidates:
            u = (item["website"] or "").strip().rstrip("/")
            raw = url_map.get(u, "")
            if raw:
                dc = extract_contact(raw)
                if not item.get("phone") and dc.get("phone"):
                    item["phone"] = dc["phone"]
                if not item.get("email") and dc.get("email"):
                    item["email"] = dc["email"]
                if not item.get("address") and dc.get("address"):
                    item["address"] = dc["address"]
                item["extract_raw_content"] = raw[:2000]
        extract_detail = [{"url": c["website"], "ok": bool(url_map.get(c["website"], ""))} for c in extract_candidates]

    # ── 输出 ──
    elapsed = round(time.time() - start, 2)
    valid = len(new_items)
    with_contact = sum(1 for n in new_items if n.get("phone") or n.get("email"))

    output = {
        "meta": {
            "company_name": company_name,
            "target_country": country_label,
            "product_description": product_desc,
            "search_date": datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00"),
            "search_mode": config.get("search_mode", "standard"),
            "search_credits": total_sc,
            "extract_credits": total_ec,
            "total_credits": total_sc + total_ec,
            "duration_seconds": elapsed,
            "output_dir": out_dir,
        },
        "search_queries": queries,
        "search_queries_cn": config.get("search_queries_cn", {}),
        "search_details": search_detail,
        "search_stats": {
            "before_dedup": len(all_raw),
            "after_dedup": len(unique),
            "valid_companies": valid,
            "duplicates": dup_count,
            "with_contact": with_contact,
        },
        "customers": new_items,
        "duplicates": dup_list[:10],
        "extract_details": extract_detail,
        "config_used": {
            "search_depth": depth,
            "max_results": max_r,
            "top_n_for_extract": top_n,
            "dedup_enabled": dedup_enabled,
        },
    }

    json_path = os.path.join(out_dir, f"{company_name}_{country_label}_搜索结果.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    if dedup_enabled:
        merge_index(new_items, run_name, index)

    # 输出结果：根据编码情况选择 stdout 或文件
    if use_output_file and output_path:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(output, f, ensure_ascii=False, indent=2)
        # stdout 只输出文件路径，避免乱码
        print(json.dumps({"output_file": output_path}))
    else:
        # stdout 支持 UTF-8，直接输出
        print(json.dumps(output, ensure_ascii=False))


if __name__ == "__main__":
    main()
