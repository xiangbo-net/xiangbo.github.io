import sys, json
sys.path.insert(0, 'E:/workbuddyproject/tavily-customer-miner/scripts')
import crawl_contacts

# 测试几个网站的爬取
urls = [
    'https://fab-tec.com',
    'https://www.americantoolanddie.com/tool-and-die',
    'https://www.nubsplasticsinc.com/mold_making.html',
    'https://www.msi-mold.com',
    'https://www.atd1.net',
]

for url in urls:
    print(f'\n=== {url} ===')
    result = crawl_contacts.crawl_website(url)
    print(f'  电话: {result["phone"][:50]}')
    print(f'  邮箱: {result["email"][:50]}')
