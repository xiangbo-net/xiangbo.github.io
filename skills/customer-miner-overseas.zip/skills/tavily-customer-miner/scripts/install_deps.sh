#!/bin/bash
echo "========================================"
echo " Tavily 客户挖掘 Skill - 依赖安装脚本"
echo "========================================"
echo ""
echo "正在安装核心 Python 依赖..."
echo "（约 30-60 秒，请勿关闭此窗口）"
echo ""
pip install -r scripts/requirements.txt
if [ $? -ne 0 ]; then
    echo "[错误] 依赖安装失败，请检查 Python 环境和网络连接"
    exit 1
fi

echo ""
echo "[OK] 核心依赖安装完成！"
echo ""
echo "如果后续需要使用管理后台（scheduler_server.py），"
echo "请单独安装额外依赖："
echo "  pip install flask flask-cors python-dateutil tzdata"
echo ""
echo "下一步操作："
echo "  1. 将 .env.tavily.example 重命名为 .env.tavily"
echo "  2. 打开 .env.tavily，填入你的 Tavily API Key"
echo "  3. 运行 python scripts/validate_setup.py 验证环境"
echo ""
