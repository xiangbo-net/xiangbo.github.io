#!/usr/bin/env python3
"""
configure_key.py — 通过对话写入 Tavily API Key

AI 在首次使用时调用此脚本，将用户在对话中输入的 Key 写入 .env.tavily。

用法：
  python scripts/configure_key.py --key tvly-xxxxxxxxxxxxxxxx

返回码：
  0 — 配置成功
  1 — 配置失败
"""
import argparse
import os
import sys
import json

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_FILE = os.path.join(SKILL_DIR, ".env.tavily")


def configure_key(api_key: str) -> bool:
    """写入 API Key 到 .env.tavily 并返回是否成功"""
    api_key = api_key.strip().strip('"').strip("'")

    if not api_key:
        print(json.dumps({"status": "fail", "message": "API Key 不能为空"}))
        return False

    if not api_key.startswith("tvly-"):
        print(json.dumps({
            "status": "warn",
            "message": "Key 格式看起来不太对，应以 tvly- 开头。不过我先帮你保存，有问题再重新配置。"
        }))

    try:
        os.makedirs(os.path.dirname(ENV_FILE), exist_ok=True)
        with open(ENV_FILE, "w", encoding="utf-8") as f:
            f.write("# Tavily API Key 配置文件\n")
            f.write("# 由 configure_key.py 自动生成\n")
            f.write(f"TAVILY_API_KEY={api_key}\n")

        print(json.dumps({
            "status": "ok",
            "message": f"API Key 已保存",
            "file": ENV_FILE,
        }))
        return True
    except Exception as e:
        print(json.dumps({"status": "fail", "message": f"写入失败: {e}"}))
        return False


# ─── 判断 Key 是否已配置 ───
def is_configured() -> bool:
    """检查 .env.tavily 是否已包含有效的 API Key"""
    if not os.path.isfile(ENV_FILE):
        return False
    try:
        with open(ENV_FILE, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("TAVILY_API_KEY="):
                    key = line.split("=", 1)[1].strip().strip('"').strip("'")
                    return bool(key) and key.startswith("tvly-")
    except Exception:
        pass
    return False


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="配置 Tavily API Key")
    parser.add_argument("--key", default="", help="你的 Tavily API Key（tvly- 开头）")
    parser.add_argument("--check", action="store_true", help="仅检查是否已配置，不写入")
    args = parser.parse_args()

    if args.check:
        if is_configured():
            print(json.dumps({"status": "ok", "configured": True}))
        else:
            print(json.dumps({"status": "ok", "configured": False}))
        sys.exit(0)

    if not args.key:
        print(json.dumps({"status": "fail", "message": "请提供 --key 参数，或在首次配置时粘贴你的 API Key"}))
        sys.exit(1)

    success = configure_key(args.key)
    sys.exit(0 if success else 1)
