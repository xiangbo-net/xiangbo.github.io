#!/usr/bin/env python3
"""生成四种输出文件：Excel / HTML / JSON(已有) / MD

产出物路径：~/.workbuddy/userdata/wxskill/overseas-customer-miner/output/日期_公司_国家/

用法：
  python scripts/generate_outputs.py --input output/任务目录/结果.json
  python scripts/generate_outputs.py --input output/任务目录/结果_enriched.json
  python scripts/generate_outputs.py --input output/任务目录/结果.json --classify-only
"""

# ──── 导入
import argparse
import json
import os
import re
import sys
from datetime import datetime, timezone, timedelta
from urllib.parse import urlparse
from zoneinfo import ZoneInfo

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

parser = argparse.ArgumentParser(description="生成最终交付文件")
parser.add_argument("--input", required=True, help="输入的 JSON 结果文件路径")
parser.add_argument("--classify-only", action="store_true", help="仅输出客户类型分类统计，不生成交付文件")
parser.add_argument("--apply-filter", action="store_true", help="分类并自动过滤，只保留 company + association，覆盖写入原文件")
args = parser.parse_args()

RESULT_FILE = args.input

# 读数据
with open(RESULT_FILE, "r", encoding="utf-8") as f:
    data = json.load(f)

company = data["meta"]["company_name"]
country_raw = data["meta"]["target_country"]
customers = data["customers"]
now = datetime.now().strftime("%Y-%m-%d %H:%M")
# 双时区时间（中国 UTC+8，目标国家/地区当地时间）
now_cn = datetime.now(timezone(timedelta(hours=8)))

# 目标国家/地区主要商业时区映射（ZoneInfo 自动处理夏令时）
TIMEZONE_MAP = {
    "united states": "America/New_York",
    "germany": "Europe/Berlin",
    "thailand": "Asia/Bangkok",
    "united kingdom": "Europe/London",
    "japan": "Asia/Tokyo",
    "china": "Asia/Shanghai",
    "france": "Europe/Paris",
    "italy": "Europe/Rome",
    "spain": "Europe/Madrid",
    "australia": "Australia/Sydney",
    "canada": "America/Toronto",
    "brazil": "America/Sao_Paulo",
    "india": "Asia/Kolkata",
    "south korea": "Asia/Seoul",
    "vietnam": "Asia/Ho_Chi_Minh",
    "malaysia": "Asia/Kuala_Lumpur",
    "singapore": "Asia/Singapore",
    "netherlands": "Europe/Amsterdam",
    "switzerland": "Europe/Zurich",
    "sweden": "Europe/Stockholm",
    "norway": "Europe/Oslo",
    "denmark": "Europe/Copenhagen",
    "finland": "Europe/Helsinki",
    "poland": "Europe/Warsaw",
    "turkey": "Europe/Istanbul",
    "russia": "Europe/Moscow",
    "saudi arabia": "Asia/Riyadh",
    "united arab emirates": "Asia/Dubai",
    "south africa": "Africa/Johannesburg",
    "mexico": "America/Mexico_City",
    "argentina": "America/Argentina/Buenos_Aires",
    "indonesia": "Asia/Jakarta",
    "philippines": "Asia/Manila",
    "new zealand": "Pacific/Auckland",
    "taiwan": "Asia/Taipei",
    "portugal": "Europe/Lisbon",
    "belgium": "Europe/Brussels",
    "austria": "Europe/Vienna",
    "czech republic": "Europe/Prague",
    "hungary": "Europe/Budapest",
    "romania": "Europe/Bucharest",
    "ukraine": "Europe/Kyiv",
    "israel": "Asia/Jerusalem",
    "egypt": "Africa/Cairo",
    "nigeria": "Africa/Lagos",
    "chile": "America/Santiago",
    "colombia": "America/Bogota",
}

target_zone = TIMEZONE_MAP.get(country_raw)
if target_zone:
    try:
        now_target = datetime.now(ZoneInfo(target_zone))
    except Exception:
        now_target = datetime.now(timezone.utc)
else:
    now_target = datetime.now(timezone.utc)

cn_time = now_cn.strftime("%Y-%m-%d %H:%M:%S")
target_time = now_target.strftime("%Y-%m-%d %H:%M:%S")
cn_daytime = "白天" if 6 <= now_cn.hour <= 17 else "夜晚"
target_daytime = "白天" if 6 <= now_target.hour <= 17 else "夜晚"

# 从 meta 中读取产品描述（由 AI 在 config 中传入），兜底默认值
product_desc = data.get("meta", {}).get("product_description", "precision manufacturing solutions")

# 国家映射（与 tavily_customer_mine.py 同步）
COUNTRY_MAP = {
    "united states": "美国", "germany": "德国", "thailand": "泰国",
    "united kingdom": "英国", "japan": "日本", "china": "中国",
    "france": "法国", "italy": "意大利", "spain": "西班牙",
    "australia": "澳大利亚", "canada": "加拿大", "brazil": "巴西",
    "india": "印度", "south korea": "韩国", "vietnam": "越南",
    "malaysia": "马来西亚", "singapore": "新加坡",
    "netherlands": "荷兰", "switzerland": "瑞士", "sweden": "瑞典",
    "norway": "挪威", "denmark": "丹麦", "finland": "芬兰",
    "poland": "波兰", "turkey": "土耳其", "russia": "俄罗斯",
    "saudi arabia": "沙特阿拉伯", "united arab emirates": "阿联酋",
    "south africa": "南非", "mexico": "墨西哥", "argentina": "阿根廷",
    "indonesia": "印度尼西亚", "philippines": "菲律宾",
    "new zealand": "新西兰", "taiwan": "台湾",
    "portugal": "葡萄牙", "belgium": "比利时", "austria": "奥地利",
    "czech republic": "捷克", "hungary": "匈牙利", "romania": "罗马尼亚",
    "ukraine": "乌克兰", "israel": "以色列", "egypt": "埃及",
    "nigeria": "尼日利亚", "chile": "智利", "colombia": "哥伦比亚",
}
country = COUNTRY_MAP.get(country_raw, country_raw)

# ──── 1. 客户类型分类 ────
def classify_customer(c: dict) -> str:
    """将客户结果分类：company / directory / association / article / other"""
    name = (c.get("company_name") or "").lower()
    desc = (c.get("content_summary") or "").lower()
    url = (c.get("website") or "").lower()
    text = f"{name} {desc} {url}"

    # 政府/教育类 → 归入 other（不含在 association 中）
    gov_edu_keywords = [".gov", ".edu"]
    for kw in gov_edu_keywords:
        if kw in text:
            return "other"

    # 协会/机构类：强关键词单个命中即触发；弱关键词需命中 ≥2 个
    assoc_strong = [
        "association", "society", "chamber", "council", "alliance",
        "foundation", "federation", "bureau of labor", "bls.gov",
        "nadca", "spe ",
    ]
    for kw in assoc_strong:
        if kw in text:
            return "association"

    assoc_weak = ["institute", "organization", "committee", "standards"]
    assoc_weak_count = sum(1 for kw in assoc_weak if kw in text)
    if assoc_weak_count >= 2:
        return "association"

    article_keywords = [
        "what is", "what are", "how to", "guide", "trends", "review",
        "news", "blog", "article", "2026", "2025",
        "what's new", "what works", "difference between",
        "unveils", "announces", "introduces",
        # 新增通用文章类关键词
        "procurement", "sourcing", "supply chain",
        "buyers guide", "buyer's guide",
        "case study", "podcast", "research",
        "industry news", "market report",
        "strategy", "strategies", "pitfall", "risk",
        "evolution of", "importance of", "guide for",
        # 市场研究报告类
        "report", "market size", "market share", "growth analysis",
        "industry analysis", "research report", "market analysis",
        "market growth", "market trend", "global market", "market research",
        "market forecast", "industry report", "market overview",
        "market insights",
    ]
    article_count = sum(1 for kw in article_keywords if kw in text)
    if article_count >= 2:
        return "article"

    # 名录/目录类：强关键词单次命中触发；弱关键词需 ≥2 个命中
    # 排除规则：如果名称或描述开头是企业自述（we are/our），跳过 directory
    directory_strong = ["list of", "directory", "manufacturers in", "companies in", "companies near"]
    directory_weak = ["top ", "best ", "leading ", "suppliers"]
    self_intro = ["we are", "we have", "we provide", "we offer", "our ", "we specialize"]
    # 先检查排除规则（只有确定是企业自述才跳过）
    if not any(p in (name + " " + desc[:80]).lower() for p in self_intro):
        for kw in directory_strong:
            if kw in name or kw in desc[:100]:
                return "directory"
        weak_count = sum(1 for kw in directory_weak if kw in name or kw in desc[:100])
        if weak_count >= 2:
            return "directory"

    # 招聘/猎头类网站（需满足多个条件才归类，避免误杀普通企业）
    # 条件1：URL 是已知招聘网站
    job_domains = ["indeed.com", "monster.com", "glassdoor.com", "stepstone.de",
                    "linkedin.com/jobs", "careerbuilder.com", "ziprecruiter.com",
                    "totaljobs.com", "reed.co.uk", "xing.com/jobs"]
    url_parsed = re.match(r'https?://([^/]+)', url)
    url_domain = url_parsed.group(1) if url_parsed else ""
    for d in job_domains:
        if d in url_domain or d in url:
            return "other"

    # 非企业网站域名（社交/视频/新闻门户/市场研究/B2B平台等）→ other
    non_company_domains = [
        # ─── 社交/视频/新闻门户 ───
        "youtube.com", "instagram.com", "facebook.com",
        "tiktok.com", "twitter.com", "x.com",
        "researchgate.net", "linkedin.com/posts", "reddit.com",
        # ─── 市场研究/报告网站 ───
        "fortunebusinessinsights.com", "grandviewresearch.com",
        "marketsandmarkets.com", "researchandmarkets.com",
        "alliedmarketresearch.com", "transparencymarketresearch.com",
        "reportlinker.com", "marketresearch.com", "marketdataforecast.com",
        "databridgemarketresearch.com", "dataintelo.com",
        "exactitudeconsultancy.com", "marketresearchfuture.com",
        "verifiedmarketresearch.com", "reportsanddata.com",
        "factmr.com", "statista.com", "ibisworld.com",
        "mordorintelligence.com", "businessresearchinsights.com",
        "thebusinessresearchcompany.com", "technavio.com",
        # ─── 欧洲 B2B 平台/黄页 ───
        "europages.fr", "europages.com", "europages.de", "europages.co.uk",
        "europages.it", "europages.es", "europages.nl",
        "kompass.com", "wlw.de", "mfg.com",
        "industrystock.com", "b2b.partcommunity.com",
        # ─── 亚洲 B2B 平台 ───
        "alibaba.com", "made-in-china.com", "globalsources.com", "hktdc.com",
        "tradekey.com", "ec21.com", "ecplaza.net",
        "indiamart.com", "tradeindia.com", "exportersindia.com",
        "go4worldbusiness.com", "tradewheel.com",
        # ─── 美洲/其他 B2B 平台 ───
        "thomasnet.com", "mercadolibre.com", "mercadolivre.com.br",
        "zauba.com", "b2brazil.com", "exporta.co",
        "mexicobusiness.net",
    ]
    for d in non_company_domains:
        if d in url_domain or d in url:
            return "other"

    # URL 路径目录关键词检查（捕获未在域名黑名单中的 B2B 目录/黄页平台）
    # 检查 URL 路径中是否包含常见的目录类路径关键词（多语言）
    url_path_dir_keywords = [
        # 英语
        "/suppliers/", "/companies/", "/directory/", "/manufacturers/",
        "/distributors/", "/wholesalers/",
        # 法语
        "/entreprises/", "/fournisseurs/", "/grossiste/", "/distributeur/",
        # 德语
        "/lieferanten/", "/unternehmen/", "/händler/",
        # 西班牙语
        "/proveedores/", "/empresas/", "/distribuidores/",
        # 意大利语
        "/fornitori/", "/aziende/", "/grossisti/",
    ]
    parsed_url = urlparse(url)
    url_path = parsed_url.path.lower() if parsed_url.path else ""
    for kw in url_path_dir_keywords:
        if kw in url_path:
            return "directory"

    # 条件2：公司名明确是招聘/人力相关
    job_name_keywords = ["recruitment", "employment agency", "staffing agency",
                         "staffing solution", "job portal", "job board",
                         "job search", "career center", "talent acquisition",
                         "manpower", "workforce"]
    for kw in job_name_keywords:
        if kw in name or kw in desc[:80]:
            return "other"

    # 条件3：内容中招聘类关键词密集出现（≥3个），说明整个页面是招聘列表
    job_content_keywords = ["salary", "wage", "we are hiring", "apply now",
                            "job openings", "current openings", "join our team",
                            "career opportunities", "job listing", "job posting",
                            "employment opportunity", "recruitment process"]
    job_hit_count = sum(1 for kw in job_content_keywords if kw in desc)
    if job_hit_count >= 3:
        return "other"

    return "company"

for c in customers:
    c["result_type"] = classify_customer(c)

type_count = {}
for c in customers:
    t = c.get("result_type", "other")
    type_count[t] = type_count.get(t, 0) + 1

print("客户类型分类统计:")
for t, n in sorted(type_count.items(), key=lambda x: -x[1]):
    print(f"  {t}: {n} 家")

companies = [c for c in customers if c["result_type"] == "company"]
directories = [c for c in customers if c["result_type"] == "directory"]
associations = [c for c in customers if c["result_type"] == "association"]
articles = [c for c in customers if c["result_type"] == "article"]
others = [c for c in customers if c["result_type"] == "other"]

print(f"\n企业: {len(companies)}")
print(f"名录: {len(directories)}")
print(f"协会/机构: {len(associations)}")
print(f"文章/资讯: {len(articles)}")
print(f"其他: {len(others)}")

# 如果只需要分类统计，到此结束
if args.classify_only:
    sys.exit(0)

# ──── 1.5 自动过滤（保留 company + association，写入原文件） ────
if args.apply_filter:
    keep_types = {"company", "association"}
    before = len(customers)
    customers = [c for c in customers if c.get("result_type") in keep_types]
    filtered = before - len(customers)
    print(f"\n过滤结果: 原始 {before} 家 → 保留 {len(customers)} 家（移除 {filtered} 家文章/招聘/名录/政府/教育等非企业数据）")
    data["customers"] = customers
    # 更新 search_stats
    stats = data.get("search_stats", {})
    stats["valid_companies"] = len(customers)
    stats["with_contact"] = sum(
        1 for c in customers
        if c.get("phone", "") not in ("", "-", None) or c.get("email", "") not in ("", "-", None)
    )
    with open(RESULT_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    sys.exit(0)

# 输出目录：使用 meta 中记录的搜索目录（每个任务独立目录）
OUTPUT_BASE = os.path.join(
    os.path.expanduser("~"), ".workbuddy", "userdata", "wxskill",
    "overseas-customer-miner", "output"
)
meta = data.get("meta", {})
OUT_DIR = meta.get("output_dir", "")
if not OUT_DIR:
    ts = datetime.now().strftime("%Y-%m-%d_%H%M")
    OUT_DIR = os.path.join(OUTPUT_BASE, f"{ts}_{company}_{country}")
os.makedirs(OUT_DIR, exist_ok=True)

print(f"\n输出目录: {OUT_DIR}")

# 从搜索词中提取目标描述（用于文件名），回退到目标国家
first_query = ""
search_details = data.get("search_details", [])
if search_details:
    first_q = search_details[0].get("query", "")
    queries_cn_from_data = data.get("search_queries_cn", {})
    if isinstance(queries_cn_from_data, list):
        # 如果是列表，通过 zip 转为 dict
        queries_en = data.get("search_queries", [])
        cn_map = dict(zip(queries_en, queries_cn_from_data))
        first_query = cn_map.get(first_q, queries_cn_from_data[0] if queries_cn_from_data else "")
    else:
        first_query = queries_cn_from_data.get(first_q, "")
if not first_query:
    first_query = country
target_tag = first_query[:20]

# ──── 2. AI 侧询问用户是否保留非企业类型 ────
FILTER_NON_COMPANY = os.environ.get("FILTER_NON_COMPANY", "").lower() in ("1", "true", "yes")
if FILTER_NON_COMPANY:
    keep_types = {"company", "directory"}
    filtered = [c for c in customers if c["result_type"] in keep_types]
    print(f"\n过滤后保留 {len(filtered)}/{len(customers)} 家（移除协会/文章/其他）")
    customers = filtered

# ──── 2.5 过滤无联系信息的企业（默认关闭，由 AI 通过环境变量控制） ────
KEEP_ONLY_WITH_CONTACT = os.environ.get("KEEP_ONLY_WITH_CONTACT", "").lower() in ("1", "true", "yes")
if KEEP_ONLY_WITH_CONTACT:
    before = len(customers)
    customers = [
        c for c in customers
        if c.get("phone", "") not in ("", "-", None)
        or c.get("email", "") not in ("", "-", None)
    ]
    filtered_out = before - len(customers)
    if filtered_out > 0:
        print(f"\n过滤 {filtered_out} 家无联系信息的企业，保留 {len(customers)} 家")
    else:
        print(f"\n全部 {len(customers)} 家企业都有联系信息")

# ──── 3. 补充话术（仅当 AI 未提前生成时兜底） ────
for c in customers:
    if c.get("pitch_email") and c.get("pitch_phone"):
        continue  # AI 已提前生成个性化话术，跳过

    name = c.get("company_name", "")
    rtype = c.get("result_type", "")

    if rtype == "directory":
        c["pitch_email"] = f"""Dear {name} Team,

I'm writing from {company}, a leading Chinese manufacturer of {product_desc}.

We noticed your directory/platform features companies in related industries.
We would like to explore the possibility of being listed or partnering with you.

Best regards,
{company}
Export Department"""

        c["pitch_phone"] = f"""Hello, this is [Name] from {company} in China.
We specialize in {product_desc}.

I see your platform/directory serves the industry.
We'd love to discuss potential partnership opportunities.
Do you have 5 minutes?"""
    else:
        c["pitch_email"] = f"""Dear {name} Team,

I'm writing from {company}, a leading Chinese manufacturer of {product_desc}.

As a company in this field, we understand quality and reliability are key to your operations. Our solutions are trusted by manufacturers worldwide for their superior quality and cost-effectiveness.

We would welcome the opportunity to discuss how we could support your business needs.

Best regards,
{company}
Export Department"""

        c["pitch_phone"] = f"""Hello, this is [Name] from {company} in China.
We specialize in {product_desc}.

I understand {name} operates in the industry, and our products could be a good fit.
Do you have 5 minutes for a quick discussion?"""

# ──── 4. Excel ────
try:
    import pandas as pd

    rows = []
    for c in customers:
        rt = c.get("result_type", "")
        type_label = {"company": "企业", "directory": "名录/目录", "association": "协会/机构",
                       "article": "文章/资讯", "other": "其他"}.get(rt, rt)
        rows.append({
            "序号": len(rows) + 1,
            "公司名称": c.get("company_name", ""),
            "类型": type_label,
            "官网": c.get("website", ""),
            "业务描述": (c.get("content_summary") or "")[:100],
            "国家": country,
            "联系电话": c.get("phone") or "",
            "邮箱": c.get("email") or "",
            "地址": c.get("address") or "",
            "评分": c.get("score", 0),
            "优先级": c.get("priority", ""),
            "是否重复": "是" if c.get("is_duplicate") else "否",
            "邮件话术": c.get("pitch_email", ""),
            "电话话术": c.get("pitch_phone", ""),
        })

    df = pd.DataFrame(rows)
    xlsx_path = os.path.join(OUT_DIR, f"{company}_{target_tag}_客户清单.xlsx")
    with pd.ExcelWriter(xlsx_path, engine="openpyxl") as writer:
        df.to_excel(writer, sheet_name="客户清单", index=False)
        ws = writer.sheets["客户清单"]
        for col in ws.columns:
            max_len = max(len(str(cell.value or "")) for cell in col)
            ws.column_dimensions[col[0].column_letter].width = min(max_len + 2, 40)
    print(f"\n[OK] Excel: {xlsx_path}")
except Exception as e:
    print(f"[FAIL] Excel: {e}")

# ──── 5. HTML ────
try:
    stats = {
        "total": len(customers),
        "p1": sum(1 for c in customers if c["priority"] == "P1"),
        "p2": sum(1 for c in customers if c["priority"] == "P2"),
        "p3": sum(1 for c in customers if c["priority"] == "P3"),
        "hasContact": sum(1 for c in customers if c.get("phone") or c.get("email")),
    }
    search_details = data.get("search_details", [])

    # 为搜索词添加中文描述（AI 在生成 config 时应传入 search_queries_cn）
    queries_cn = data.get("search_queries_cn", {})
    if isinstance(queries_cn, list):
        queries_en = data.get("search_queries", [])
        cn_map = dict(zip(queries_en, queries_cn))
        for sd in search_details:
            q = sd.get("query", "")
            sd["query_cn"] = cn_map.get(q) or q
    else:
        for sd in search_details:
            q = sd.get("query", "")
            sd["query_cn"] = queries_cn.get(q) or q

    # 为 meta 添加双时区时间和中文国家名
    data["meta"]["target_country_cn"] = country
    data["meta"]["cn_time"] = cn_time
    data["meta"]["target_time"] = target_time
    data["meta"]["cn_daytime"] = cn_daytime
    data["meta"]["target_daytime"] = target_daytime

    html_data = {
        "meta": data["meta"],
        "search_details": search_details,
        "customers": customers,
    }

    data_json = json.dumps(html_data, ensure_ascii=False)

    template_path = os.path.join(SKILL_DIR, "scripts", "dashboard_template.html")
    with open(template_path, "r", encoding="utf-8") as f:
        html = f.read()

    html = html.replace("__DATA__", data_json)

    html_path = os.path.join(OUT_DIR, f"{company}_{target_tag}_客户洞察看板.html")
    with open(html_path, "w", encoding="utf-8") as f:
        f.write(html)
    print(f"[OK] HTML: {html_path}")
except Exception as e:
    print(f"[FAIL] HTML: {e}")

# ──── 6. MD 话术文档 ────
try:
    p1_count = stats["p1"]
    p2_count = stats["p2"]
    p3_count = stats["p3"]
    contact_count = stats["hasContact"]

    type_label_map = {"company": "企业", "directory": "名录/目录", "association": "协会/机构",
                       "article": "文章/资讯", "other": "其他"}

    md = f"""# 客户沟通话术 · {company} ({country})

> 来源公司：{company}
> 生成时间：{now}
> 目标客户：{country} {target_tag}
> 总客户数：{stats["total"]} 家（P1: {p1_count}, P2: {p2_count}, P3: {p3_count}）
> 有联系信息：{contact_count} 家

---

"""
    for idx, c in enumerate(customers, 1):
        priority = c.get("priority", "P3")
        score = c.get("score", 0)
        name = c.get("company_name", "")
        website = c.get("website", "")
        phone = c.get("phone") or "未获取"
        email = c.get("email") or "未获取"
        address = c.get("address") or "未获取"
        desc = (c.get("content_summary") or "")[:200]
        rt = c.get("result_type", "")
        type_label = type_label_map.get(rt, rt)
        pitch_e = c.get("pitch_email", "")
        pitch_p = c.get("pitch_phone", "")

        dup_label = " 🔄 历史重复" if c.get("is_duplicate") else ""
        star = "⭐" if priority == "P1" else ("☆" if priority == "P2" else "·")

        md += f"""## {idx}. {name}  {star} {priority} | 评分 {score}/10 | {type_label}{dup_label}

**基本信息**
- 官网：{website}
- 联系电话：{phone}
- 邮箱：{email}
- 地址：{address}
- 业务：{desc}

**📧 邮件话术**

{pitch_e}

**📞 电话话术**

{pitch_p}

---

"""
    md_path = os.path.join(OUT_DIR, f"{company}_{target_tag}_客户沟通话术.md")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write(md)
    print(f"[OK] MD: {md_path}")
except Exception as e:
    print(f"[FAIL] MD: {e}")

print(f"\n所有文件已生成到: {OUT_DIR}")

# ──── 6.5 输出机器可读的文件路径（供 AI 解析并调用 present_files） ────
import json as _json
_output_files = {}
for _key, _var_name in [("excel", "xlsx_path"), ("html", "html_path"), ("md", "md_path")]:
    _path = locals().get(_var_name, "")
    if _path and os.path.isfile(_path):
        _output_files[_key] = _path
if _output_files:
    print("__OUTPUT_FILES__:" + _json.dumps(_output_files, ensure_ascii=False))

# ──── 6. 写入跨 Skill 共享索引 ────
try:
    # 使用绝对路径动态导入，不受工作目录影响
    _index_path = os.path.join(os.path.dirname(__file__), "cross_skill_index.py")
    if os.path.isfile(_index_path):
        import importlib.util as _iu
        _spec = _iu.spec_from_file_location("cross_skill_index", _index_path)
        _mod = _iu.module_from_spec(_spec)
        _spec.loader.exec_module(_mod)
        update_index = _mod.update_index

        email_count = sum(1 for c in customers if c.get("email"))

        # 推断可能的数据文件路径
        json_candidates = [
            RESULT_FILE,
            os.path.join(OUT_DIR, "结果_enriched.json"),
            os.path.join(OUT_DIR, f"{company}_{target_tag}_搜索结果.json"),
        ]
        json_file = next((p for p in json_candidates if os.path.isfile(p)), "")

        update_index("tavily-customer-miner", {
            "company": company,
            "country": country,
            "output_dir": OUT_DIR,
            "json_file": json_file,
            "customer_count": len(customers),
            "email_count": email_count,
        })

        print("[OK] 已写入跨 skill 共享索引（output_dir: %s）" % OUT_DIR)
    else:
        print("[INFO] cross_skill_index.py 未找到，跳过共享索引写入（不影响本次产出）")
except Exception as e:
    print(f"[INFO] 写入共享索引失败（不影响本次产出）: {e}")
