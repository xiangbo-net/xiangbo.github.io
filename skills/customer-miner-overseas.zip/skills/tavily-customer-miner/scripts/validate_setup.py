#!/usr/bin/env python3
"""
Tavily 客户挖掘 Skill - 环境验证脚本
检查 API Key、Python 依赖、目录结构是否就绪。
"""

import os
import sys
import json

SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ENV_FILE = os.path.join(SKILL_DIR, ".env.tavily")
REQUIREMENTS_FILE = os.path.join(SKILL_DIR, "scripts", "requirements.txt")


def check_python_version():
    print(f"[检查] Python 版本: {sys.version}")
    if sys.version_info >= (3, 9):
        print("  [OK] Python 版本满足要求 (>= 3.9)")
        return True
    else:
        print("  [WARN] Python 版本较低，建议 3.9+")
        return False


def check_env_file():
    print(f"[检查] API Key 配置文件: {ENV_FILE}")
    if not os.path.exists(ENV_FILE):
        print("  [FAIL] .env.tavily 文件不存在")
        print(f"  [提示] 请复制 .env.tavily.example 为 .env.tavily 并填入 API Key")
        return False

    api_key = None
    with open(ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("TAVILY_API_KEY="):
                api_key = line.split("=", 1)[1].strip().strip('"').strip("'")

    if not api_key:
        print("  [FAIL] TAVILY_API_KEY 为空")
        print("  [提示] 请打开 .env.tavily 填入你的 Tavily API Key")
        return False

    if not api_key.startswith("tvly-"):
        print("  [WARN] API Key 格式异常（应为 tvly- 开头）")
        print(f"         当前值: {api_key[:10]}...")

    print(f"  [OK] API Key 已配置（{api_key[:10]}...）")
    return True


def test_tavily_api():
    """发送一条简单请求验证 API Key 有效性"""
    print("[检查] Tavily API 连通性...")
    try:
        from tavily import TavilyClient
    except ImportError:
        print("  [SKIP] tavily-python 未安装，跳过 API 测试")
        return False

    # Re-read API key
    api_key = None
    with open(ENV_FILE, "r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line.startswith("TAVILY_API_KEY="):
                api_key = line.split("=", 1)[1].strip().strip('"').strip("'")

    if not api_key:
        return False

    try:
        client = TavilyClient(api_key=api_key)
        response = client.search(
            query="test",
            search_depth="basic",
            max_results=1,
            include_usage=True,
        )
        credits_used = response.get("usage", {}).get("credits", 0)
        print(f"  [OK] API 连通成功，消耗 {credits_used} 积分")
        return True
    except Exception as e:
        error_str = str(e)
        if "401" in error_str or "Unauthorized" in error_str:
            print("  [FAIL] API Key 无效（401 Unauthrized）")
            print("  [提示] 请检查 .env.tavily 中的 API Key 是否正确")
        elif "432" in error_str or "quota" in error_str.lower():
            print("  [WARN] API Key 有效，但当月积分已用完")
        elif "429" in error_str:
            print("  [WARN] 请求频率超限，请稍后重试")
        else:
            print(f"  [FAIL] API 测试失败: {error_str[:100]}")
        return False


def check_dependencies():
    print("[检查] Python 依赖...")
    required = ["tavily", "pandas", "openpyxl"]
    all_ok = True
    for pkg in required:
        try:
            __import__(pkg)
            print(f"  [OK] {pkg}")
        except ImportError:
            print(f"  [FAIL] {pkg} 未安装")
            all_ok = False

    if not all_ok:
        print("  [提示] 请运行: pip install -r scripts/requirements.txt")
    return all_ok


def check_directory_structure():
    print("[检查] 目录结构...")
    required_dirs = ["scripts", "runs"]
    all_ok = True
    for d in required_dirs:
        path = os.path.join(SKILL_DIR, d)
        if os.path.isdir(path):
            print(f"  [OK] {d}/")
        else:
            print(f"  [FAIL] {d}/ 不存在")
            all_ok = False
    return all_ok


def print_summary(results):
    print("\n" + "=" * 50)
    print("  验证结果汇总")
    print("=" * 50)
    pass_count = sum(1 for r in results if r)
    fail_count = sum(1 for r in results if not r)
    for i, (name, ok) in enumerate(zip(
        ["Python 版本", "API Key 配置", "API 连通性", "依赖安装", "目录结构"],
        results
    )):
        status = "[OK]" if ok else "[FAIL]"
        print(f"  {status} {name}")

    print(f"\n  通过: {pass_count}/{len(results)}")
    if fail_count == 0:
        print("\n  ✅ 环境就绪，可以开始使用！")
        print("  在 WorkBuddy 中触发 skill 即可开始客户挖掘。")
    else:
        print(f"\n  ❌ 仍有 {fail_count} 项未通过，请按提示修复。")
    print("=" * 50)


def main():
    print("=" * 50)
    print("  Tavily 客户挖掘 Skill - 环境验证")
    print("=" * 50)
    print(f"  Skill 目录: {SKILL_DIR}")
    print()

    results = []
    results.append(check_python_version())
    print()
    results.append(check_env_file())
    print()
    results.append(test_tavily_api())
    print()
    results.append(check_dependencies())
    print()
    results.append(check_directory_structure())
    print()

    print_summary(results)
    return 0 if all(results) else 1


if __name__ == "__main__":
    sys.exit(main())
