---
name: wx-bid-opportunity
description: 帮助企业从海量招中标信息中发现高价值商机，结合企业画像、资质能力、业绩和区域策略，完成标讯搜索、商机筛选、项目解读、投标机会评分、任务拆解。依赖 tender-search Skill 作为标讯数据源。当用户提到"招投标""商机""标讯""投标分析""投标评分""投标任务""招标公告分析""能不能投"等关键词，或需要招投标全流程辅助时使用。
agent_created: true
---

# 招投标商机专家

帮助企业从海量招中标信息中发现高价值商机。结合企业画像、资质能力、业绩和区域策略，覆盖标讯搜索→商机筛选→项目解读→投标评分→任务拆解全流程。

## 依赖声明

本 Skill 依赖独立的 `tender-search` Skill 作为标讯数据源。所有标讯查询通过 `tender-search` Skill 完成。

**本 Skill 不提供演示模式或模拟数据**。接口不可用时暂停标讯操作，引导用户恢复依赖。

## 运行期代码生成禁令

禁止在运行期间动态生成脚本文件（`.py`/`.sh`），所有数据处理必须使用 Skill 安装目录下的预置脚本。

## 目录结构规则（必须遵守）

# 

### Userdata 配置目录（读写，跨平台）

所有持久化配置存放在 WorkBuddy 安装目录下的统一 Userdata 路径：

```
~/.workbuddy/userdata/skill/wx-bid-opportunity/
```

- **macOS/Linux**: `$HOME/.workbuddy/userdata/skill/wx-bid-opportunity/`
- **Windows**: `%USERPROFILE%\\.workbuddy\\userdata\\skill\\wx-bid-opportunity\\`

由 `scripts/init_check.py` 和 `scripts/profile_manager.py` 中的 `get_skill_data_dir()` / `get_config_base_dir()` 统一解析，调用方无需自行拼接路径。

其下子目录结构：

```
config/           # 配置文件（company_profile.json, search_topics.json 等）
templates/        # 从 assets/templates/ 首次使用复制的模板缓存（预留）
```

### 产物目录（当前位置）

所有输出的业务文件保存在工作空间：

```
<workspace>/招投标商机/
├── .log/               # API 接口调用日志（按日期分目录）
├── 标讯搜索记录/        # 标讯搜索结果（MD + HTML）
├── 商机筛选/            # 商机筛选表（MD + HTML）
└── 重点项目/            # 重点项目完整方案
```

## 启动检查（每次调用必须执行）

每次用户调用本 Skill 时，首先按以下顺序执行启动检查：

### 0. 平台判定与路径定义（所有路径检查的前置步骤）

每次启动先用以下逻辑判定当前操作系统并定义好所有路径变量，后续所有路径引用均使用此处定义：

```
判定 OS：
  - 运行时环境已知 → 直接用 (darwin / win32)
  - 否则执行 uname -s：
    "Darwin"  → macOS
    "MINGW*" / "MSYS*" → Windows
    命令失败 → 判定为 Windows

定义路径：
  macOS:
    HOME_DIR   = $HOME
    SKILLS_DIR = $HOME/.workbuddy/skills
    ZLBX_CONF  = $HOME/.zlbx/config.json
    USERDATA   = $HOME/.workbuddy/userdata/skill/wx-bid-opportunity
  Windows:
    HOME_DIR   = %USERPROFILE%
    SKILLS_DIR = %USERPROFILE%\\.workbuddy\\skills
    ZLBX_CONF  = %USERPROFILE%\\.zlbx\\config.json
    USERDATA   = %USERPROFILE%\\.workbuddy\\userdata\\skill\\wx-bid-opportunity
```

全局路径变量速查表：

| 用途                     | macOS 路径                                          | Windows 路径                            |
| ---------------------- | ------------------------------------------------- | ------------------------------------- |
| Skill 安装根目录            | `$HOME/.workbuddy/skills/`                        | `%USERPROFILE%\\.workbuddy\\skills\\` |
| tender-search SKILL.md | `.../skills/tender-search/SKILL.md`               | 同上（反斜杠）                               |
| 知了标讯 API Key 配置        | `$HOME/.zlbx/config.json`                         | `%USERPROFILE%\\.zlbx\\config.json`   |
| 企业画像 userdata          | `~/.workbuddy/userdata/skill/wx-bid-opportunity/` | 同上（反斜杠）                               |
| 工作空间产物                 | `<workspace>/招投标商机/`                            | 同上（反斜杠）                               |

### 1. 检查企业画像初始化状态（非强制）

读取启动信息文件（路径由 `USERDATA/config/initialization_state.json`）

**本检查不拦截标讯搜索流程。** 初始化状态决定了后续分析能力的深度：

- **已初始化** → 标讯搜索时自动加载企业画像构建搜索参数，后续支持企业与项目匹配分析、商机筛选、投标评分等完整功能
- **未初始化**（`initialized` 为 `false` 或文件不存在）→
  - 如果用户提供了明确的关键词，**直接按关键词搜索标讯**
  - 搜索结果展示后，若用户需要进一步分析（商机筛选、企业与项目匹配、投标评分等），**此时再引导用户完成企业画像初始化**
  - 初始化流程遵循"流程1：企业画像初始化"的完整步骤

**核心规则**：
  1. 用户说"搜XX"或明确给出关键词 → 直接搜索，不拦截
  2. 用户说"帮我看看有什么商机"（无关键词）→ 如果未初始化，提示需要企业信息以便构建搜索关键词，建议初始化或直接输入关键词
  3. 搜索完成拿到结果后，如果用户要求做筛选/匹配/评分分析 → 引导初始化

### 2. 检查 tender-search 依赖

#### 2.1 平台路径定义（macOS / Windows）

**Skill 标准安装目录由 WorkBuddy 系统规则决定**，需先判定操作系统：

```
macOS:   $HOME/.workbuddy/skills/tender-search/SKILL.md
Windows: %USERPROFILE%\\.workbuddy\\skills\\tender-search\\SKILL.md
```

判定方式：

- 如果运行时已知 OS → 直接用
- 否则尝试 `uname -s`：`Darwin` → macOS，`MINGW*`/`MSYS*` → Windows
- 命令不存在 → Windows（PowerShell 环境）

**路径拼接规则**：

```
skill_home = os.environ["HOME"] (macOS) / os.environ["USERPROFILE"] (Windows)
tender_search_md = os.path.join(skill_home, ".workbuddy", "skills", "tender-search", "SKILL.md")
```

#### 2.2 依赖检查

检查 WorkBuddy 用户技能目录中 `tender-search/SKILL.md` 是否存在：

**macOS**：

```bash
test -f "$HOME/.workbuddy/skills/tender-search/SKILL.md" && echo "FOUND" || echo "NOT_FOUND"
```

**Windows (PowerShell)**：

```powershell
$p = "$env:USERPROFILE\.workbuddy\skills\tender-search\SKILL.md"
if (Test-Path $p) { Write-Output "FOUND" } else { Write-Output "NOT_FOUND" }
```

- 若输出 `FOUND` → 依赖已满足，跳过安装，直接进入步骤3（验证可用性）
- 若输出 `NOT_FOUND` → **不要输出提示语让用户手动操作**，按以下流程主动安装：

##### 步骤A：检查 SkillHub CLI 是否已安装

macOS / Linux:

```bash
which skillhub || echo "NOT_FOUND"
```

Windows (PowerShell):

```powershell
Get-Command skillhub -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Source
# 输出为空表示未安装
```

若未安装，输出引导：

```
检测到 SkillHub CLI 尚未安装。

请参考 https://skillhub.cn/install/skillhub.md 完成安装（仅安装 CLI 即可）。
安装完成后告诉我，我来继续完成 tender-search 的安装。
```

若已安装，继续步骤B。

##### 步骤B：通过 SkillHub 安装 tender-search 到 WorkBuddy 技能目录

> ⚠️ **目标目录**：必须安装到 WorkBuddy 用户级技能目录（而非项目工作空间）：
> 
> - **macOS**: `$HOME/.workbuddy/skills/tender-search/`
> - **Windows**: `%USERPROFILE%\\.workbuddy\\skills\\tender-search\\`
> 
> `skillhub install` 在 WorkBuddy 工作空间内运行时，会检测到项目级 `skills/` 目录并优先安装到那里。需要通过以下方式确保安装到正确目录。

**macOS**：

```bash
# 1. 先切换到 HOME 目录（脱离项目工作空间）
cd ~
# 2. 安装 tender-search
skillhub install tender-search
# 3. 验证安装位置
test -f "$HOME/.workbuddy/skills/tender-search/SKILL.md" && echo "INSTALL_OK" || echo "NEED_FIX"
```

**Windows (PowerShell)**：

```powershell
# 1. 切换到用户目录
cd $env:USERPROFILE
# 2. 安装 tender-search
skillhub install tender-search
# 3. 验证安装位置
$targetPath = "$env:USERPROFILE\.workbuddy\skills\tender-search\SKILL.md"
if (Test-Path $targetPath) { Write-Output "INSTALL_OK" } else { Write-Output "NEED_FIX" }
```

**若验证结果为 NEED_FIX**，执行迁移（skillhub 安装到了项目工作空间）：

**macOS**：

```bash
# 从工作空间迁移到用户技能目录
cp -r "<workspace>/skills/tender-search" "$HOME/.workbuddy/skills/tender-search"
rm -rf "<workspace>/skills/tender-search"
test -f "$HOME/.workbuddy/skills/tender-search/SKILL.md" && echo "FIXED: tender-search → $HOME/.workbuddy/skills/"
```

**Windows (PowerShell)**：

```powershell
# 从工作空间迁移到用户技能目录
Copy-Item -Recurse "<workspace>\skills\tender-search" "$env:USERPROFILE\.workbuddy\skills\tender-search"
Remove-Item -Recurse -Force "<workspace>\skills\tender-search"
Write-Output "FIXED: tender-search → $env:USERPROFILE\.workbuddy\skills\"
```

安装完成后，进入步骤C。

##### 步骤C：API Key 初始化

tender-search 安装成功后，立即检查 API Key 配置：

按以下优先级依次检查，命中即停：

1. **环境变量** `$ZLBX_API_KEY` 是否已设置 → 读到则直接用
2. **配置文件** `~/.zlbx/config.json` 是否含 `api_key` 字段 → 读到则直接用
3. **以上都没有** → 向用户输出：

```
✅ tender-search 安装完成！标讯数据源已就绪。

现在需要初始化 API Key，两种方式：
1️⃣ 您提供 API Key（去 ai.zhiliaobiaoxun.com 注册获取）
2️⃣ 我帮您自动注册设备账号（免费，赠送基础调用额度）

您选择哪种方式？
```

- 用户选择 1️⃣ → 等待用户输入 API Key，写入 `~/.zlbx/config.json`（`source: "manual"`）
- 用户选择 2️⃣ → 按 tender-search SKILL.md 中 `references/auto-register.md` 的流程执行自动注册（采集设备特征 → POST auto-register → 保存 API Key）

### 3. 验证 tender-search 可用性

调用 `tender-search` Skill 执行轻量测试查询（例如 `search_bids` 带 `keywords: ["测试"]`, `page_size: 1`）。

返回错误的处理：

- `AUTHENTICATION_FAILED` → 提示检查 API Key，暂停
- `INSUFFICIENT_BALANCE` / `QUOTA_EXCEEDED` → 提示充值，暂停
- `RATE_LIMITED` → 提示稍后重试，暂停
- 网络超时/不可达 → 提示检查网络，暂停

全部通过后才进入正常业务流程。

## 意图识别与路由

根据用户输入，识别意图并路由到对应流程：

| 用户说法（示例）               | 意图      | 路由            |
| ---------------------- | ------- | ------------- |
| "帮我搭建招投标专家""初始化"       | 初始化企业画像 | → 初始化流程       |
| "帮我找项目""搜索标讯""看看有什么商机" | 标讯搜索    | → 检查依赖 → 搜索   |
| "哪些值得跟""筛选一下""生成商机表"   | 商机筛选    | → 基于已有结果生成筛选表 |
| "分析这个公告""解读这个项目"       | 标讯解读    | → 生成结构化摘要     |
| "能不能投""评分""评估一下"       | 投标评分    | → 生成投标机会评分    |
| "怎么准备投标""任务清单"         | 任务拆解    | → 生成投标准备任务清单  |
| "调整搜索偏好""更新画像"         | 配置更新    | → 修改对应配置      |
| 直接粘贴招标公告链接/正文          | 快速分析    | → 跳步处理        |

若意图不明确，列出可能的方向供用户选择。

## 核心流程

> **📌 双格式输出原则（所有流程通用，强制遵守）：**
> 每生成一份 `.md` 报告，必须同步生成对应的 `.html` 版本。
> 
> **HTML 生成强制规则（模板优先）：**
> 
> 1. **必须优先**使用 `scripts/html_generator.py` 的对应函数 + `assets/templates/output/` 下对应模板生成 HTML
> 2. **禁止绕过模板**：只要模板文件存在且对应函数存在，就绝对不允许手写内联 HTML
> 3. **唯一回退条件**：仅当 `_load_template()` 抛出 `FileNotFoundError` 或模板中缺少必要占位符时，才降级为手写内联 HTML
> 4. **MD 报告同理**：必须使用 `assets/templates/output/` 下对应 `.md` 模板（存在时），按 `{{占位符}}` 替换生成
> 5. **评分报告**：必须通过 `scripts/score_calculator.py` 的 `calculate_total_score()` 计算得分，再用 `html_generator.generate_bid_scoring_html()` 生成 HTML
> 6. 无论使用哪种方式，HTML 和 MD 文件名保持一致（仅后缀不同）

### 流程1：企业画像初始化

触发：用户主动要求 / 搜索结果后需要做企业与项目匹配分析 / 投标评分需要企业信息。

**启动语**（每次必须完整输出）：

```
⚠️ 您尚未完成企业画像初始化。

我需要先了解您的企业信息，这样才能做更精准的商机查询与处理。

请选择以下任一方式提供公司信息：
1️⃣ 发送公司介绍资料（宣传册、官网介绍、企查查截图、百度百科等任何材料）
2️⃣ 直接文字告诉我：公司名称、主营业务、所在城市等基础信息
```

**处理用户提供的材料**：

如果用户以任何格式发送公司资料（包括但不限于：文字段落、PDF、图片截图、链接、网页URL等）：

- 阅读/提取材料中的企业关键信息
- 结构化填充到 company_profile.json 的对应字段
- 信息不完整的部分标注"需人工确认"
- 向用户回显提取结果，确认是否准确

**主动对话引导**：

如果用户选择文字输入，按以下顺序自然引导，不要一次性抛出所有问题：

1. 先确认基础信息（公司名称、城市、主营业务）
2. 根据基础信息，自然追问资质（行业资质、软著、专利）
3. 根据业务类型，追问业绩和案例
4. 最后确认搜索偏好（区域、预算、排除项）

**信息确认与保存**：

- 所有收集到的信息需回显给用户确认
- 用户确认后保存 `company_profile.json` 到 `~/.workbuddy/userdata/skill/wx-bid-opportunity/config/`
- 使用 `scripts/profile_manager.py markdown` 生成 `company_profile.md` 到同目录
- 更新 `initialization_state.json`
- 使用 `scripts/profile_manager.py validate` 验证必填字段
- 输出完成引导语和下一步操作建议

**默认演示画像**：用户说"先用默认画像"时使用预设数据（见 `references/initialization_flow.md`），但必须追问公司名称。

### 流程2：标讯搜索

前置条件：tender-search 可用。

1. 确认搜索意图（关键词、区域、时间范围）
2. 如果企业画像已初始化，读取 `~/.workbuddy/userdata/skill/wx-bid-opportunity/config/search_topics.json` 辅助构建搜索参数
3. 调用 `tender-search` Skill 的 `search_bids` 或 `query_bids_advanced`
4. **接口调用必须记录日志**：调用前后使用 `scripts/api_logger.py` 记录输入参数和输出结果
5. 将结果通过 `scripts/bid_formatter.py` 转换为标准化结构（**保留所有可获得的字段**）
6. 使用 `scripts/html_generator.py` 生成精美 HTML 版本
7. 按规范保存到工作空间：

```
招投标商机/标讯搜索记录/YYYYMMDD-搜索主题-搜索结果.md
招投标商机/标讯搜索记录/YYYYMMDD-搜索主题-搜索结果.html
```

**记录字段要求**：必须包含但不限于以下字段（参考 `scripts/bid_formatter.py` 的 `format_single_bid()`）：

| 分类    | 字段                                                                                                   |
| ----- | ---------------------------------------------------------------------------------------------------- |
| 直达链接  | `direct_link` - 标讯直达查看链接，**每条记录必须有**                                                                 |
| 基础标识  | `source_id`, `notice_title`, `notice_type`, `bid_process_desc`                                       |
| 招标方信息 | `buyer`, `buyer_contact`, `buyer_phone`, `buyer_address`, `agency`, `agency_contact`, `agency_phone` |
| 区域与时间 | `region`, `city`, `district`, `publish_date`, `deadline`, `bid_open_time`                            |
| 金额信息  | `budget_amount`, `bid_amount`, `budget_original`, `bid_amount_original`                              |
| 中标信息  | `winner`, `winner_contact`, `winner_phone`                                                           |
| 项目分类  | `keywords`, `bid_type`, `industry_category`, `project_classification`                                |
| 原文    | `raw_content`, `summary`, `content_snippet`                                                          |

**HTML 生成要求**：

- 使用 `scripts/html_generator.py` 的 `generate_search_result_html()` 生成
- 该方法加载 `assets/templates/output/标讯搜索结果模板.html` 模板，替换占位符后输出
- HTML 包含：Hero头部（标题+日期+公司名）、统计概览卡片、按区域/类型分布条形图、每条标讯的卡片（含**直达链接**）
- 可选参数：`keywords`/`exclude_keywords`（数据概览区展示关键词标签）、`begin_date`/`end_date`（数据范围显示）
- HTML 使用响应式设计，兼容桌面和移动端
- 同时保存 `.md` 和 `.html` 两份文件

**搜索参数构建规则**：

- `keywords`：用户指定的关键词，或搜索主题的 keywords，或企业画像的 `primary_keywords`
- `match_modes`：搜索主题配置，默认 `["sm", "title", "fulltext"]`
- `provinces`：搜索主题的 regions，或企业画像的 `focus_regions`
- `bid_process`：搜索主题配置，默认 `[1, 2, 4]`（采购意向/预招标/招标）
- `exclude_keywords`：搜索主题配置，或企业画像配置
- `min_budget`：搜索主题配置，或企业画像的 `min_budget_amount`
- 分页：`page_size` 默认 20，翻页时递增 `page`

**搜索结果为空时**：建议调整关键词、扩大区域、延长日期范围。

**搜索完成后**：
- 如果企业未初始化且显示了搜索结果，主动询问用户是否需要对结果做进一步分析（商机筛选、项目解读、评分等）
- 如果需要，按"启动检查-步骤1"的规则，引导用户完成企业画像初始化，再继续后续分析

### 流程3：商机筛选与排序

基于搜索结果生成商机筛选表。**如果企业画像未初始化，在进入此流程前先引导用户完成初始化。**

1. 逐条标讯与企业画像匹配
2. 应用排除规则（`risk_rules.json` 中的 `auto_exclude`）
3. 快速评估业务匹配度（不展开完整评分，只做初筛）
4. 标注风险标签（保证金/付款/资质等）
5. 按推荐优先级排序：强烈建议 > 建议跟进 > 需核实 > 谨慎 > 不建议
6. 使用 `assets/templates/output/商机筛选表模板.md` 生成 MD 报告
7. 使用 `scripts/html_generator.py` 的 `generate_screening_table_html()` 生成 HTML 报告
8. 保存到工作空间：

```
招投标商机/商机筛选/YYYYMMDD-商机筛选表.md
招投标商机/商机筛选/YYYYMMDD-商机筛选表.html
```

**筛选表记录字段要求**：每条标讯记录必须包含但不限于：

| 字段                      | 说明                  |
| ----------------------- | ------------------- |
| `direct_link`           | **直达查看链接**，点击可跳转到原文 |
| `notice_title`          | 公告标题（含直达链接）         |
| `notice_type`           | 公告类型                |
| `buyer`                 | 招标方                 |
| `region` / `city`       | 区域信息                |
| `budget_amount`         | 预算金额                |
| `deadline`              | 截止日期                |
| `remaining_days`        | 剩余天数                |
| `business_match`        | 业务匹配度判断             |
| `score`                 | 快速评分                |
| `recommendation_level`  | 推荐级别                |
| `recommendation_reason` | 推荐理由                |
| `risk_flags`            | 风险标签列表              |

**HTML 生成要求**：

- 表格按推荐优先级排序，含直达链接
- 顶部统计卡片显示各推荐级别数量
- 响应式设计，表格可横向滚动

筛选维度：

- 业务匹配（产品/服务是否对口）
- 区域匹配（是否在关注区域）
- 预算匹配（是否满足最低阈值）
- 排除项（是否命中排除规则）
- 剩余时间（是否充裕）

### 流程4：单项目深度解读

1. 通过 `tender-search` Skill 的 `get_bid_detail` 获取公告全文
2. 提取并结构化呈现：
   - 快速事实（标题、买方、预算、截止时间等）
   - 资质要求（基本资格、特定资质、业绩要求）
   - 技术/商务要求（采购内容、技术规格、付款、质保等）
   - 关键时间节点
   - 风险初步识别
3. 使用 `assets/templates/output/标讯摘要模板.md` 生成 MD 版报告
4. 输出素材暂存，后续合并到项目分析报告中

### 流程5：投标机会评分

使用7维度加权评分模型，详见 `references/scoring_model_detail.md`。**如果企业画像未初始化，在进入此流程前先引导用户完成初始化。**

**评分计算**（使用 `scripts/score_calculator.py`）：

| 维度    | 权重  |
| ----- | --- |
| 业务匹配度 | 20% |
| 资质匹配度 | 20% |
| 业绩匹配度 | 15% |
| 商业价值  | 15% |
| 中标可能性 | 10% |
| 交付可行性 | 10% |
| 风险可控性 | 10% |

**评级阈值**：

- 85-100：🟢 强烈建议投标
- 70-84：🔵 建议重点跟进
- 60-69：🟡 需进一步核实
- 40-59：🟠 谨慎考虑
- 0-39：🔴 不建议投标

**评分输出要求**：

1. 总分和评级
2. 7个维度得分明细及简要依据（每个维度1-2句话）
3. 风险项清单
4. 需人工确认事项列表
5. 最终建议和核心理由

**信息缺失处理**：

- 优先使用企业画像已有信息
- 画像中也缺失的 → 使用默认值 50 分
- 在报告中标注"信息不足，使用默认值"
- 加入"需人工确认"列表

报告使用 `assets/templates/output/投标机会评分模板.md` 生成 MD 版。
使用 `scripts/html_generator.py` 的 `generate_bid_scoring_html()` 生成 HTML 版（内容片段，作为项目分析报告的一个章节）。
评分数据暂存，后续合并到项目分析报告中。

### 流程6：投标准备任务拆解

按六个角色拆分任务：

| 角色       | 职责范围           |
| -------- | -------------- |
| 销售负责人    | 客户沟通、踏勘、商务策略   |
| 售前/方案负责人 | 方案编写、技术应答      |
| 投标专员     | 标书制作、封装、递交     |
| 财务负责人    | 保证金、资信证明       |
| 交付负责人    | 资源评估、工期计划      |
| 老板/决策层   | 定价审批、风险评估、最终决策 |

每个任务包含：内容说明、截止时间（倒推计算）、所需资料、风险提醒。

检查清单包含：投标函、授权书、保证金、报价、方案、资格证明等。

使用 `assets/templates/output/投标准备任务清单模板.md` 生成 MD 版。
使用 `scripts/html_generator.py` 的 `generate_task_list_html()` 生成 HTML 版（内容片段，作为项目分析报告的一个章节）。
任务清单数据暂存，后续合并到项目分析报告中。

## 重点项目输出规范

当用户对某一项目进行深入分析（如标讯解读、评分、任务拆解等），且该项目的**评分 >= 70 分**或用户**明确要求"做一个完整方案"**时，输出一份完整的重点项目分析报告。

### 输出内容

所有内容合并到一个文件，使用 `scripts/html_generator.py` 的 `generate_project_report_html()` 生成。

```
招投标商机/重点项目/<项目名称>/
├── 项目分析报告.md        # Markdown 版本（全部内容合并）
└── 项目分析报告.html      # HTML 版本（左侧菜单 + 右侧内容布局）
```

### HTML 布局要求

使用**左侧菜单 + 右侧内容**的单页布局，纯静态，无动画效果：

```
┌───────────────────────────────────────┐
│  标题栏：项目分析报告 — <项目名称>          │
├──────────┬────────────────────────────┤
│  菜单导航   │  内容区域                     │
│           │  (滚动显示，锚点跳转)            │
│  📋 项目概览 │                             │
│  📄 标讯解读 │                             │
│  📊 投标评分 │                             │
│  ✅ 任务清单 │                             │
│  ⚠️ 风险分析 │                             │
│  💡 综合建议 │                             │
├──────────┴────────────────────────────┤
│  页脚：生成时间 · 数据来源 · 免责声明          │
└───────────────────────────────────────┘
```

- 左侧菜单固定宽度 220px，背景色 #f8f9fa
- 右侧内容区域自动填充，内边距 30px
- 菜单项悬浮高亮
- **无动画效果、无动态渐入**
- 点击菜单项通过 `id` 锚点跳转到对应章节
- 所有内容在一页内完整显示

### 报告内容章节

1. **项目概览** — 项目名称、招标方、预算、区域、关键时间
2. **标讯解读** — 快速事实、资质要求、商务条款、关键时间节点
3. **投标评分** — 7维度得分明细、总分、评级、风险项
4. **任务清单** — 6角色分工、检查清单、截止时间
5. **风险分析** — 风险清单、应对措施、需人工确认事项
6. **综合建议** — 最终建议、行动路线、决策时间表

### HTML 生成函数

使用 `scripts/html_generator.py` 的 `generate_project_report_html()`：

- 参数：`project_name`, `company_name`, `sections_data`（含6个章节的标题+HTML内容）、`bid_link`
- 自动生成左侧菜单 + 右侧内容的完整 HTML，不依赖模板文件
- 同时生成 `.md` 版保存

## 跳步处理规则

支持用户跳过前置步骤：

| 场景            | 处理                                    |
| ------------- | ------------------------------------- |
| 直接给出关键词要求搜索     | 直接搜索，不拦截。搜索完成后如果用户需要进一步分析，再引导初始化 |
| 直接粘贴公告问"能不能投" | 绕过搜索，直接基于公告内容解读和评分。缺失的企业画像字段标注"需人工确认" |
| 要求生成任务清单但无项目  | 要求提供项目名称/链接/公告正文或从已有列表中选择             |
| 搜索完想做商机筛选但尚未初始化 | 引导用户完成企业画像初始化，再进行筛选                   |

## 必须标注的事项

以下事项 AI 无法替代人工决策，输出时必须标注 **"需人工确认"**：

- 是否参与投标（最终决策）
- 投标报价金额
- 是否接受特定付款条件
- 是否满足特定资质要求
- 是否投入足够资源编制标书
- 是否承诺特定交付周期
- 最终定价策略
- 是否将某项目案例作为业绩证明

## 数据存储规范

### 持久化配置（Userdata 目录 — 跨平台兼容）

配置文件全部存放在 WorkBuddy 安装目录下的统一路径（由 `scripts/profile_manager.py` 的 `get_config_base_dir()` 解析）：

```
~/.workbuddy/userdata/skill/wx-bid-opportunity/
├── config/
│   ├── company_profile.json        # 企业画像 JSON
│   ├── company_profile.md          # 企业画像 Markdown 可读版
│   ├── search_topics.json          # 搜索主题配置
│   ├── scoring_model.json          # 评分模型权重
│   ├── risk_rules.json             # 风险规则
│   ├── output_preferences.json     # 输出偏好
│   └── initialization_state.json   # 初始化状态追踪
```

> ⚠️ **Skill 安装目录（`~/.workbuddy/skills/wx-bid-opportunity/`）为只读**。任何时候不得向此目录写入任何运行时文件。

### 工作空间业务目录

```
<workspace>/招投标商机/
├── .log/                          # API 接口调用日志（按日期分目录）
│   └── YYYY-MM-DD/                # 如 2026-06-17/
│       ├── tender-search.search_bids.jsonl
│       ├── tender-search.get_bid_detail.jsonl
│       └── ...
├── 标讯搜索记录/
│   ├── YYYYMMDD-搜索主题-搜索结果.md    # Markdown 版本
│   └── YYYYMMDD-搜索主题-搜索结果.html  # HTML 版本（与 MD 同步）
├── 商机筛选/
│   ├── YYYYMMDD-商机筛选表.md
│   └── YYYYMMDD-商机筛选表.html
└── 重点项目/
    └── <项目名称>/
        ├── 项目分析报告.md        # 完整项目分析（含所有章节）
        └── 项目分析报告.html      # 左侧菜单 + 右侧内容布局
```

## 日志记录

### API 接口调用日志（强制要求）

**所有通过 tender-search Skill 调用的接口，都必须记录输入参数和输出结果。**

使用 `scripts/api_logger.py` 的 `log_tender_search_call()` 方法，记录到：

```
<workspace>/招投标商机/.log/<YYYY-MM-DD>/<接口名>.jsonl
```

**记录格式**（JSONL，每行一条）：

| 字段           | 说明                                 |
| ------------ | ---------------------------------- |
| `timestamp`  | 调用时间（ISO 8601，含毫秒）                 |
| `interface`  | 接口全名，如 `tender-search.search_bids` |
| `elapsed_ms` | 调用耗时（毫秒）                           |
| `input`      | 输入参数（完整 JSON）                      |
| `output`     | 输出结果（截断到 100KB 以内）                 |
| `annotation` | 备注（可选）                             |

**触发时机**：

- `search_bids` / `query_bids_advanced` 调用完成时
- `get_bid_detail` 获取公告详情时
- `search_expiring_projects`、`find_competitors`、`get_top_suppliers` 等分析接口
- 任何 tender-search 接口返回错误时（记录错误信息）

**日志文件命名**：按接口名分开存储，每天一个 JSONL 文件。

### Skill 调用日志

每次 Skill 调用后记录到 `~/.workbuddy/userdata/skill/wx-bid-opportunity/logs/skill_call_log.md`：

- 调用时间
- 触发意图
- 执行步骤摘要
- 使用的工具/tender-search 调用
- 异常信息（如有）

### 画像更新日志

每次画像更新后记录到 `~/.workbuddy/userdata/skill/wx-bid-opportunity/logs/user_profile_update_log.md`：

- 更新时间
- 变更字段
- 变更前后值
- 用户确认状态

## 判断原则

- 区分"已知事实""AI判断""待确认信息""人工决策事项"
- 评分附带依据，不只给分数
- 生成文件包含时间戳和版本信息
- 画像更新前询问是否确认（避免自动覆盖）
- 所有涉及标讯的操作前必须通过 tender-search 健康检查

---

## Resources

### references/

- `initialization_flow.md` — 初始化四轮对话流程详解，包含引导语和默认画像
- `scoring_model_detail.md` — 7维度评分模型详细规则和计算逻辑
- `tender_search_integration.md` — 与 tender-search Skill 的集成规范和参数构建规则
- `error_handling.md` — 错误处理、容错策略、用户提示措辞规范
- `company_profile_fields.md` — 企业画像所有字段的含义和使用场景

### scripts/

- `init_check.py` — 检查初始化状态和依赖可用性
- `profile_manager.py` — 企业画像读取/验证/Markdown生成
- `score_calculator.py` — 7维度加权评分计算
- `bid_formatter.py` — tender-search 返回数据转内部标准化格式（含直达链接、联系方式等完整字段）
- `api_logger.py` — API 接口调用日志记录（JSONL 格式，按日期分目录）
- `html_generator.py` — HTML 报告生成，支持6种报告类型（标讯搜索/商机筛选/标讯解读/投标评分/任务清单/项目分析报告），通过模板替换和内联生成

### assets/templates/config/

- `company_profile.json` — 企业画像 JSON 模板
- `scoring_model.json` — 评分模型默认权重和阈值
- `search_topics.json` — 搜索主题默认配置
- `risk_rules.json` — 风险规则自动排除/标记规则
- `output_preferences.json` — 输出偏好配置
- `initialization_state.json` — 初始化状态追踪

### assets/templates/output/

- `标讯摘要模板.md` — 单项目结构化摘要
- `商机筛选表模板.md` — 商机筛选与推荐排序（含直达链接）
- `商机筛选表模板.html` — 商机筛选 HTML 模板
- `投标机会评分模板.md` — 7维度评分报告
- `投标机会评分模板.html` — 投标机会评分 HTML 模板
- `投标准备任务清单模板.md` — 六角色任务拆解+甘特图
- `投标准备任务清单模板.html` — 任务清单 HTML 模板
- `标讯搜索结果模板.html` — 标讯搜索结果 HTML 模板
