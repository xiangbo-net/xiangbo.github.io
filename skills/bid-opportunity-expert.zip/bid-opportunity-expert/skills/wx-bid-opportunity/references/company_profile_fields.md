# 企业画像字段说明

本参考文档详细说明 company_profile.json 中每个字段的含义和使用场景。

## company_basic（公司基本信息）

| 字段 | 类型 | 必填 | 说明 | 使用场景 |
|------|------|:---:|------|----------|
| company_name | string | ✅ | 公司全称 | 标讯搜索、报告抬头 |
| city | string | ✅ | 所在城市 | 区域筛选 |
| province | string | ✅ | 所在省份 | 区域筛选 |
| main_business | string | ✅ | 主营业务一句话描述 | 业务匹配判定 |
| business_scope | string[] | - | 业务范围标签 | 关键词生成 |
| industry_tags | string[] | - | 行业标签 | 行业匹配 |
| company_type | string | - | 企业类型 | 资质匹配 |
| established_year | number | - | 成立年份 | 业绩年限匹配 |
| employee_count | number | - | 员工数量 | 规模匹配 |
| annual_revenue_range | string | - | 年营收区间 | 规模匹配 |

## business_scope（经营范围）

| 字段 | 类型 | 说明 |
|------|------|------|
| primary_products_services | string[] | 核心产品/服务（用于关键词生成和业务匹配） |
| target_customer_types | string[] | 目标客户类型 |
| key_expansion_directions | string[] | 重点拓展方向 |
| excluded_business_areas | string[] | 排除的业务领域 |

## target_regions（目标区域）

| 字段 | 类型 | 说明 |
|------|------|------|
| primary_provinces | string[] | 主要目标省份 |
| primary_cities | string[] | 主要目标城市 |
| expandable_regions | string[] | 可拓展区域 |
| excluded_regions | string[] | 排除区域 |

## target_customers（目标客户）

| 字段 | 类型 | 说明 |
|------|------|------|
| industry_types | string[] | 目标客户行业 |
| organization_types | string[] | 组织类型（政府/国企/民企/外企等） |
| typical_customer_size | string | 典型客户规模 |
| key_accounts | string[] | 重点客户名单 |

## qualification_profile（资质画像）

| 字段 | 类型 | 说明 |
|------|------|------|
| bidding_entities | object[] | 投标主体列表 |
| bidding_entities[].entity_name | string | 主体名称 |
| bidding_entities[].unified_social_credit_code | string | 统一社会信用代码 |
| bidding_entities[].is_primary | boolean | 是否为主要投标主体 |
| industry_qualifications | string[] | 行业资质列表 |
| software_copyrights | string[] | 软件著作权 |
| patents | string[] | 专利 |
| certifications | string[] | 认证证书 |
| system_integration_level | string | 系统集成资质等级 |
| information_system_level | string | 信息化资质等级 |
| qualification_gaps | string[] | 资质短板 |
| qualification_notes | string | 补充说明 |

## performance_profile（业绩画像）

| 字段 | 类型 | 说明 |
|------|------|------|
| representative_projects | object[] | 代表性项目列表 |
| representative_projects[].project_name | string | 项目名称 |
| representative_projects[].customer_type | string | 客户类型 |
| representative_projects[].region | string | 项目区域 |
| representative_projects[].contract_amount | number | 合同金额（万元） |
| representative_projects[].project_type | string | 项目类型 |
| representative_projects[].available_as_reference | boolean | 是否可作为投标业绩 |
| industry_experience | string[] | 行业经验标签 |
| delivery_regions | string[] | 交付区域 |
| max_project_amount_range | string | 最大项目金额区间 |
| performance_gaps | string[] | 业绩短板 |
| performance_notes | string | 补充说明 |

## search_preferences（搜索偏好）

| 字段 | 类型 | 说明 |
|------|------|------|
| primary_keywords | string[] | 主要搜索关键词 |
| secondary_keywords | string[] | 辅助搜索关键词 |
| exclude_keywords | string[] | 排除关键词 |
| focus_regions | string[] | 关注区域 |
| min_budget_amount | number | 最低预算阈值（万元） |
| min_remaining_bid_days | number | 最小剩余投标天数 |
| excluded_project_types | string[] | 排除的项目类型 |
| default_page_size | number | 默认每页条数 |
| bid_process_filter | number[] | 标讯阶段筛选 |

## risk_preferences（风险偏好）

| 字段 | 类型 | 说明 |
|------|------|------|
| max_bid_deposit_ratio | number | 最大投标保证金比例（%） |
| max_payment_term_days | number | 最大接受付款账期（天） |
| auto_exclude_project_types | string[] | 自动排除的项目类型 |
| high_risk_keywords | string[] | 高风险关键词 |
| accepted_risk_levels | string[] | 接受的风险等级 |
| max_acceptable_risk_score | number | 最大接受风险分数 |

## output_preferences（输出偏好）

| 字段 | 类型 | 说明 |
|------|------|------|
| include_executive_summary | boolean | 是否包含老板摘要 |
| include_scoring_details | boolean | 是否包含详细评分 |
| include_task_checklist | boolean | 是否包含任务清单 |
| default_sort_by | string | 默认排序方式 |
| report_language | string | 报告语言 |
| auto_generate_weekly_report | boolean | 是否自动生成周报 |
| weekly_report_day | number | 周报生成日（1-7） |
