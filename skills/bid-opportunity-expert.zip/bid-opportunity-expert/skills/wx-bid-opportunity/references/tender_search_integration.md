# tender-search 接口集成规范

本参考文档说明招投标商机专家 Skill 如何与 tender-search Skill 集成。

## 依赖关系

```
招投标商机专家 Skill
    │
    ├── 业务逻辑层（用户交互、画像管理、评分计算、报告生成）
    │
    └── 数据层（标讯查询）
            │
            └── tender-search Skill（标讯 API 调用）
                    │
                    └── 知了标讯 AI 开放平台
```

## 启动检查流程

### 第1步：检查 tender-search 是否已安装

检查路径：`~/.workbuddy/skills/tender-search/SKILL.md` 是否存在

若不存在，输出安装引导：

```
检测到标讯接口依赖 tender-search Skill 尚未安装。

请按以下步骤安装：

1. 安装 Skillhub 商店（仅安装 CLI）：
   请参考 https://skillhub.cn/install/skillhub.md 完成安装

2. 通过 Skillhub 安装 tender-search 技能：
   skillhub install tender-search

安装完成后，请重新运行本 Skill。
```

### 第2步：检查 tender-search 是否可用

调用 tender-search Skill 执行一次轻量查询验证：

建议使用 `search_bids` 工具，参数简单且消耗最小：
```
keywords: ["测试"]
page_size: 1
```

检查返回结果：
- 成功（`success: true`）→ 继续
- 失败 → 根据错误码处理（见错误处理表）

### 第3步：更新依赖状态

将检查结果写入 `initialization_state.json`：
```json
{
  "dependency_checks": {
    "tender_search_installed": true/false,
    "tender_search_available": true/false,
    "last_api_check": "<ISO时间戳>"
  }
}
```

## 工具映射表

| 本 Skill 需求 | tender-search 工具 | 说明 |
|--------------|-------------------|------|
| 搜索招标公告 | `search_bids` | 主搜索工具 |
| 高级搜索（AND/OR） | `query_bids_advanced` | 关键词分组、排除词 |
| 获取单条标讯详情 | `get_bid_detail` | 完整公告内容 |
| 搜索临期项目 | `search_expiring_projects` | 紧急商机 |
| 搜索中标结果 | `search_bids` (bid_process: [7,8]) | 或使用 `search_awards` |
| 竞品分析 | `find_competitors` | 基于投标重叠度 |
| 推荐潜在供应商 | `find_potential_bidders` | 针对特定标讯 |
| Top采购单位 | `get_top_purchasers` | 市场分析 |
| Top中标单位 | `get_top_suppliers` | 竞品识别 |
| 价格趋势 | `get_price_trends` | 品牌+型号历史单价 |

## 搜索参数构建规则

### 从企业画像自动构建搜索参数

```python
# 伪代码示例
def build_search_params(company_profile, search_topic):
    params = {
        "keywords": search_topic.keywords or company_profile.search_preferences.primary_keywords,
        "match_modes": search_topic.match_modes or ["sm", "title", "fulltext"],
        "provinces": search_topic.regions or company_profile.target_regions.primary_provinces,
        "bid_process": search_topic.bid_process or [1, 2, 4],
        "bid_type": search_topic.bid_type or "招标",
        "page": 1,
        "page_size": search_topic.default_page_size or 20,
    }
    
    # 添加可选参数
    if search_topic.min_budget:
        params["min_budget"] = search_topic.min_budget
    elif company_profile.search_preferences.min_budget_amount:
        params["min_budget"] = company_profile.search_preferences.min_budget_amount
    
    if search_topic.exclude_keywords:
        params["exclude_keywords"] = search_topic.exclude_keywords
    elif company_profile.search_preferences.exclude_keywords:
        params["exclude_keywords"] = company_profile.search_preferences.exclude_keywords
    
    return params
```

## 结果标准化

tender-search 返回的原始数据需通过 `bid_formatter.py` 转换为内部标准化结构。完整的标准化字段如下（尽可能保留所有原始字段）：

```json
{
  "source": "tender-search",
  "source_id": "",
  "notice_title": "",
  "notice_type": "",
  "notice_type_id": 0,
  "bid_process_desc": "",

  "direct_link": "",
  "raw_url": "",
  "source_url": "",

  "buyer": "",
  "buyer_contact": "",
  "buyer_phone": "",
  "buyer_address": "",
  "agency": "",
  "agency_contact": "",
  "agency_phone": "",

  "region": "",
  "city": "",
  "district": "",
  "publish_date": "",
  "deadline": "",
  "bid_open_time": "",

  "budget_amount": null,
  "bid_amount": null,
  "budget_original": "",
  "bid_amount_original": "",

  "winner": "",
  "winner_contact": "",
  "winner_phone": "",

  "keywords": [],
  "bid_type": "",
  "industry_category": "",
  "project_classification": "",

  "raw_content": "",
  "summary": "",
  "content_snippet": "",

  "formatted_at": ""
}
```

**说明**：
- `direct_link` 字段为标讯直达查看链接，所有输出报告（MD/HTML）中都需包含此字段
- 所有价格字段标准单位：万元（浮动）
- `content_snippet` 为原文前300字符摘要
- 字段值为空时不显示对应行，避免表格中存在大量空白

## 错误处理

| 错误码 | 处理方式 |
|-------|---------|
| AUTHENTICATION_FAILED | 提示"API Key 无效或缺失，请检查 tender-search 配置"，暂停执行 |
| INSUFFICIENT_BALANCE / QUOTA_EXCEEDED | 提示"账户余额不足，请充值后重试"，暂停执行（引导充值链接） |
| RATE_LIMITED | 提示"请求过于频繁，请稍后重试"，暂停执行 |
| INVALID_REQUEST | 提示"搜索参数不合法：{具体错误}，请调整后重试"，暂停执行 |
| INTERNAL_ERROR | 提示"服务内部错误，请稍后重试"，暂停执行 |
| TOOL_EXECUTION_ERROR | 提示"工具执行失败，请检查参数或稍后重试"，暂停执行 |
| 网络超时/不可达 | 提示"标讯接口暂时不可用，请检查网络后重试"，暂停执行 |

## 重要原则

1. **不使用模拟数据**：接口不通时，暂停服务，不提供假数据
2. **不做 HTTP 直连**：所有标讯查询都通过 tender-search Skill，不自行调用 API
3. **错误即停止**：任何接口错误都暂停当前操作，引导用户恢复
4. **频率控制交由 tender-search**：本 Skill 不实施额外限流
