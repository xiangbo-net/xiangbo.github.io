# 初始化流程详解

本参考文档详细描述企业画像初始化的四轮对话流程。

## 触发条件

以下任一条件满足时，**严格拦截**并进入初始化流程：
1. `initialization_state.json` 中 `initialized` 为 `false`（包括文件不存在）
2. `company_profile.json` 文件不存在或为空
3. 用户明确说"帮我搭建招投标专家"、"初始化企业画像"、"重新配置"

## 启动语（必须完整输出，不可简略）

无论触发方式如何，进入初始化时必须先输出以下启动语：

```
⚠️ 您尚未完成企业画像初始化。

我需要先了解您的企业信息，这样才能做更精准的商机查询与处理。

请选择以下任一方式提供公司信息：
1️⃣ 发送公司介绍资料（宣传册、官网介绍、企查查截图、百度百科等任何材料）
2️⃣ 直接文字告诉我：公司名称、主营业务、所在城市等基础信息
```

## 处理用户提供的材料

如果用户以任何格式发送公司资料：

1. **材料类型判断**：
   - 文字段落 → 直接提取关键信息
   - 截图/图片 → 读取图片中的文字内容
   - PDF/文档 → 阅读并提取关键信息
   - 网页链接（官网/企查查/百度百科） → 读取页面内容
   - 混合形式 → 综合处理

2. **信息提取**：
   - 按 company_profile.json 的字段结构逐项提取
   - 能提取到的字段填入对应值
   - 无法提取的字段标记为"需人工确认"

3. **回显确认**：
   - 将提取结果以结构化方式展示给用户
   - 标注"需人工确认"的字段
   - 请用户确认是否正确，或补充缺失信息

## 主动对话引导（文字输入方式）

如果用户选择文字输入，按以下顺序自然引导，**不要一次性抛出所有问题**：

### 第1轮：公司基本情况

**目标**：收集公司名称、主营业务、目标客户、拓展方向

**引导语**：
```
欢迎使用「招投标商机专家」！我将帮你建立企业画像，以便精准匹配商机。

先了解一下贵公司的基本情况，你可以随口说，不用逐项填表。

比如：
- 公司叫什么名字？在哪座城市？
- 主营业务是做什么的？
- 主要服务哪些类型的客户？
- 最近想重点拓展什么方向？

或者直接告诉我一段话也行，我来提取关键信息。
```

**需提取的字段**：
- `company_basic.company_name`（必填）
- `company_basic.city` / `province`
- `company_basic.main_business`
- `business_scope.primary_products_services`
- `business_scope.target_customer_types`
- `business_scope.key_expansion_directions`

**验证**：完成本轮后，将提取的信息回显给用户确认。

### 第2轮：法人主体、资质和合规能力

**目标**：收集投标主体、行业资质、证书等

**引导语**：
```
接下来了解下贵司的投标资质能力：

- 通常用哪个法人主体去投标？
- 有哪些行业资质证书？（如系统集成、建筑智能化、信息安全等）
- 有没有软著、专利或其他认证？
- 在资质方面有没有短板需要规避的？
```

**需提取的字段**：
- `qualification_profile.bidding_entities[].entity_name`（至少一个）
- `qualification_profile.industry_qualifications`
- `qualification_profile.software_copyrights`
- `qualification_profile.patents`
- `qualification_profile.certifications`
- `qualification_profile.qualification_gaps`

### 第3轮：企业业绩和项目案例

**目标**：收集代表性项目、行业经验、交付区域

**引导语**：
```
再了解下贵司的项目经验，这对于匹配标讯业绩要求很重要：

- 近3-5年有哪些代表性项目？大致金额和客户类型？
- 哪些项目可以作为投标案例使用？
- 主要在哪些城市/省份交付过项目？
- 做过的最大项目金额大概在什么区间？
```

**需提取的字段**：
- `performance_profile.representative_projects`（至少1个）
- `performance_profile.industry_experience`
- `performance_profile.delivery_regions`
- `performance_profile.max_project_amount_range`

### 第4轮：搜索偏好和风险偏好

**目标**：确定搜索关键词、区域、预算阈值、排除项、输出偏好

**引导语**：
```
最后，设置一下商机匹配规则：

- 重点关注哪些区域？（省份/城市，可以多个）
- 最低接受的项目预算是多少？
- 有哪些关键词/项目类型绝对不想碰？
- 投标至少需要多少天准备时间？

这些偏好可以随时调整。
```

**需提取的字段**：
- `search_preferences.focus_regions`
- `search_preferences.min_budget_amount`
- `search_preferences.exclude_keywords`
- `search_preferences.excluded_project_types`
- `search_preferences.min_remaining_bid_days`
- `risk_preferences.*`
- `output_preferences.*`

## 默认演示画像

当用户说"先用默认画像"时，使用以下数据，但**必须追问公司名称**：

```json
{
  "company_basic": {
    "company_name": "（待用户确认）",
    "city": "深圳",
    "province": "广东",
    "main_business": "企业信息化系统集成与软件开发",
    "business_scope": ["ERP系统实施", "智慧办公解决方案", "IT运维外包", "信息安全服务"],
    "industry_tags": ["信息技术", "系统集成", "软件开发"],
    "company_type": "民营科技企业",
    "employee_count": 80,
    "annual_revenue_range": "3000万-5000万"
  },
  "business_scope": {
    "primary_products_services": ["企业管理系统", "智慧办公平台", "IT基础设施", "网络安全服务"],
    "target_customer_types": ["制造业企业", "政府部门", "教育机构", "医疗单位"],
    "key_expansion_directions": ["工业互联网", "智能制造系统", "政府数字化转型项目"]
  },
  "target_regions": {
    "primary_provinces": ["广东"],
    "primary_cities": ["深圳", "广州", "东莞", "佛山"],
    "expandable_regions": ["广西", "福建", "湖南"]
  },
  "qualification_profile": {
    "bidding_entities": [{"entity_name": "（待用户确认）", "is_primary": true}],
    "industry_qualifications": ["信息系统集成及服务资质（三级）", "ISO9001质量管理体系"],
    "software_copyrights": ["ERP管理系统V3.0", "智慧办公平台V2.0"],
    "certifications": ["高新技术企业", "科技型中小企业"],
    "qualification_gaps": ["无ISO27001信息安全认证", "系统集成资质等级偏低"]
  }
}
```

## 完成后的引导

四轮信息收集完成后，输出以下引导语：

```
✅ 企业画像初始化完成！

配置已保存到：
📁 userdata/skill/wx-bid-opportunity/config/company_profile.json
📁 userdata/skill/wx-bid-opportunity/config/company_profile.md

接下来你可以：
1️⃣ 说"帮我搜索项目" → 我会根据你的企业画像自动搜索匹配的商机
2️⃣ 说"调整搜索偏好" → 修改区域、预算、排除词等设置
3️⃣ 直接粘贴一个招标公告 → 我帮你分析能不能投

你也可以随时说"更新企业画像"来补充或修改信息。
```

## 初始化状态追踪

每次初始化步骤完成后，更新 `initialization_state.json` 中的对应 `completed` 字段。
全部完成后，将 `initialized` 设置为 `true`。
