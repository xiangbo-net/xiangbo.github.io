#!/usr/bin/env python3
"""
招投标商机专家 - 初始化状态检查脚本
检查企业画像初始化状态和依赖可用性
"""

import json
import os
import sys
from pathlib import Path
from datetime import datetime


def get_skill_data_dir():
    """获取 Skill 持久化配置目录（跨平台兼容）

    路径规则：
    - macOS/Linux: ~/.workbuddy/userdata/skill/wx-bid-opportunity/
    - Windows: %USERPROFILE%\\.workbuddy\\userdata\\skill\\wx-bid-opportunity\\
    """
    home = Path.home()
    skill_dir = home / ".workbuddy" / "userdata" / "skill" / "wx-bid-opportunity"
    return skill_dir


def check_init_state(skill_data_dir: Path) -> dict:
    """检查初始化状态"""
    state_file = skill_data_dir / "config" / "initialization_state.json"
    profile_file = skill_data_dir / "config" / "company_profile.json"

    result = {
        "initialized": False,
        "company_profile_exists": False,
        "init_steps": {},
        "issues": [],
        "actions": []
    }

    # Check initialization state file
    if state_file.exists():
        try:
            with open(state_file) as f:
                state = json.load(f)
            result["initialized"] = state.get("initialized", False)
            result["init_steps"] = state.get("steps", {})
        except (json.JSONDecodeError, KeyError) as e:
            result["issues"].append(f"初始化状态文件损坏: {e}")
    else:
        result["issues"].append("未找到初始化状态文件")
        result["actions"].append("需要完成企业画像初始化")

    # Check company profile
    if profile_file.exists():
        try:
            with open(profile_file) as f:
                profile = json.load(f)
            if profile.get("company_basic", {}).get("company_name"):
                result["company_profile_exists"] = True
            else:
                result["issues"].append("企业画像缺少公司名称")
                result["actions"].append("需要补充公司基本信息")
        except (json.JSONDecodeError, KeyError) as e:
            result["issues"].append(f"企业画像文件损坏: {e}")
    else:
        result["issues"].append("未找到企业画像文件")
        result["actions"].append("需要创建企业画像")

    # Check tender-search dependency
    tender_search_skill = Path.home() / ".workbuddy" / "skills" / "tender-search" / "SKILL.md"
    if tender_search_skill.exists():
        result["tender_search_installed"] = True
    else:
        result["tender_search_installed"] = False
        result["issues"].append("tender-search Skill 未安装")
        result["actions"].append("需要安装 tender-search Skill")

    # Check search topics
    topics_file = skill_data_dir / "config" / "search_topics.json"
    if topics_file.exists():
        try:
            with open(topics_file) as f:
                topics = json.load(f)
            enabled_topics = [t for t in topics.get("topics", []) if t.get("enabled")]
            result["search_topics_count"] = len(enabled_topics)
            if not enabled_topics:
                result["issues"].append("没有启用的搜索主题")
                result["actions"].append("需要配置搜索主题")
        except (json.JSONDecodeError, KeyError):
            result["issues"].append("搜索主题文件损坏")
    else:
        result["issues"].append("未找到搜索主题文件")
        result["actions"].append("需要生成搜索主题")

    return result


def main():
    skill_data_dir = get_skill_data_dir()
    result = check_init_state(skill_data_dir)
    
    # Add timestamp
    result["checked_at"] = datetime.now().isoformat()
    result["skill_data_dir"] = str(skill_data_dir)
    
    json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    return 0


if __name__ == "__main__":
    sys.exit(main())
