#!/usr/bin/env python3
"""PDF生成助手 - 用 pdfkit-py 将HTML标讯报告转为PDF"""
import subprocess, sys, os

PDFKIT_DIR = os.path.expanduser("~/.workbuddy/plugins/marketplaces/cb_teams_marketplace/plugins/document-skills/skills/pdfkit-py")

def html_to_pdf(html_path, pdf_path=None):
    if not pdf_path:
        pdf_path = html_path.replace('.html', '.pdf')
    
    venv_py = os.path.join(PDFKIT_DIR, "scripts/venv/bin/python3")
    script = os.path.join(PDFKIT_DIR, "scripts/pdfkit.py")
    
    if not os.path.exists(venv_py):
        return {"ok": False, "error": "pdfkit-py venv 未初始化，请先运行 setup.sh"}
    
    try:
        r = subprocess.run([venv_py, script, "convert", "--input", html_path, "--output", pdf_path, "--to_format", "pdf"],
                         capture_output=True, text=True, timeout=60)
        if os.path.exists(pdf_path):
            return {"ok": True, "path": pdf_path}
        return {"ok": False, "error": r.stderr[:200]}
    except Exception as e:
        return {"ok": False, "error": str(e)}

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("用法: python3 generate_pdf.py <html_path> [pdf_path]")
        sys.exit(1)
    result = html_to_pdf(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else None)
    print(result)
