#!/usr/bin/env python3
"""
招投标商机专家 - HTML 报告生成脚本

将标讯搜索记录、商机筛选表、重点项目方案等数据转换为精美 HTML 报告。
搜索记录 HTML 使用模板文件生成，其余使用内联方式（向后兼容）。

注意：中标复盘（market-analysis）和商机周报（weekly-report）功能已移除。
"""

import json
import os
import re
import sys
from datetime import datetime, date
from pathlib import Path
from typing import Dict, List, Optional, Any

# ============================================================
# 模板路径
# ============================================================

SKILL_DIR = Path(__file__).resolve().parent.parent
TEMPLATES_DIR = SKILL_DIR / "assets" / "templates" / "output"


def _get_template_path(template_name: str) -> Path:
    """获取模板文件路径"""
    path = TEMPLATES_DIR / template_name
    if not path.exists():
        raise FileNotFoundError(f"模板文件不存在: {path}")
    return path


def _load_template(template_name: str) -> str:
    """读取模板文件内容"""
    path = _get_template_path(template_name)
    with open(str(path), "r", encoding="utf-8") as f:
        return f.read()


# ============================================================
# 通用 HTML 样式（仅用于筛选项模板和重点项目方案模板）
# ============================================================

CSS_COMMON = """
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", "Helvetica Neue", Arial, sans-serif;
    background: #f5f7fa;
    color: #333;
    line-height: 1.6;
    padding: 20px;
}
.container {
    max-width: 1200px;
    margin: 0 auto;
    background: #fff;
    border-radius: 12px;
    box-shadow: 0 2px 12px rgba(0,0,0,0.08);
    padding: 30px 35px;
}
.header {
    border-bottom: 3px solid #1a73e8;
    padding-bottom: 20px;
    margin-bottom: 25px;
}
.header h1 {
    font-size: 24px;
    color: #1a1a1a;
    margin-bottom: 8px;
}
.header .meta {
    font-size: 13px;
    color: #888;
}
.header .meta span {
    margin-right: 20px;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin: 15px 0;
    font-size: 14px;
}
table th {
    background: #1a73e8;
    color: #fff;
    padding: 10px 12px;
    text-align: left;
    font-weight: 600;
    white-space: nowrap;
}
table td {
    padding: 10px 12px;
    border-bottom: 1px solid #e8ecf0;
}
table tr:hover { background: #f0f6ff; }
table tr:nth-child(even) { background: #fafbfc; }
table tr:nth-child(even):hover { background: #f0f6ff; }
.badge {
    display: inline-block;
    padding: 2px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 600;
}
.badge-green { background: #e6f7e6; color: #1a7d1a; }
.badge-blue { background: #e6f0ff; color: #1a5e8a; }
.badge-yellow { background: #fff7e6; color: #8a6d1a; }
.badge-orange { background: #fff0e6; color: #8a4a1a; }
.badge-red { background: #ffe6e6; color: #8a1a1a; }
.badge-gray { background: #f0f0f0; color: #666; }
a { color: #1a73e8; text-decoration: none; }
a:hover { text-decoration: underline; }
.section-title {
    font-size: 18px;
    font-weight: 600;
    color: #1a73e8;
    margin: 25px 0 15px;
    padding-bottom: 8px;
    border-bottom: 2px solid #e8ecf0;
}
.stat-row {
    display: flex;
    gap: 15px;
    flex-wrap: wrap;
    margin: 15px 0;
}
.stat-card {
    background: #f8f9fb;
    border: 1px solid #e8ecf0;
    border-radius: 8px;
    padding: 15px 20px;
    min-width: 120px;
    flex: 1;
}
.stat-card .num {
    font-size: 28px;
    font-weight: 700;
    color: #1a73e8;
}
.stat-card .label {
    font-size: 12px;
    color: #888;
    margin-top: 4px;
}
.project-card {
    background: #f8f9fb;
    border: 1px solid #e8ecf0;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 15px;
}
.project-card h3 { font-size: 16px; margin-bottom: 10px; }
.project-card h3 a { color: #1a73e8; }
.project-card .info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 8px 20px;
    font-size: 13px;
}
.project-card .info-grid .item { display: flex; }
.project-card .info-grid .item .label { color: #888; min-width: 70px; }
.project-card .info-grid .item .value { color: #333; }
.footer {
    margin-top: 30px;
    padding-top: 15px;
    border-top: 1px solid #e8ecf0;
    font-size: 12px;
    color: #aaa;
    text-align: center;
}
"""


# ============================================================
# 辅助函数
# ============================================================

BAR_COLORS_CYCLE = ["fill-green", "fill-blue", "fill-purple", "fill-orange", "fill-teal", "fill-rose", "fill-gray"]


def _generate_bars_html(data: Dict[str, int], max_key: str = "") -> str:
    """将 {label: count} 字典转换为条形图 HTML。

    data: 如 {"广州": 8, "深圳": 7}
    max_key: 可作为 100% 参考的键名（为空则用最大值自动计算）
    """
    if not data:
        return '<div style="color:#999;font-size:13px">暂无数据</div>'

    max_val = data.get(max_key, 0) if max_key else max(data.values())
    if max_val == 0:
        max_val = 1

    lines = []
    sorted_items = sorted(data.items(), key=lambda x: x[1], reverse=True)
    for i, (label, count) in enumerate(sorted_items):
        pct = round(count / max_val * 100, 1)
        color = BAR_COLORS_CYCLE[i % len(BAR_COLORS_CYCLE)]
        lines.append(f"""
            <div class="bar-row">
              <span class="bar-label">{label}</span>
              <div class="bar-track"><div class="bar-fill {color}" style="width:{pct}%">{count}</div></div>
            </div>""")
    return "\n".join(lines)


def _notice_type_badge(notice_type: str) -> str:
    """为公告类型生成 CSS 类名"""
    badge_map = {
        "采购意向": "badge-intent",
        "预招标": "badge-pre",
        "招标": "badge-bid",
        "招标公告": "badge-bid",
        "变更公告": "badge-change",
        "中标候选人公示": "badge-candidate",
        "中标候选人": "badge-candidate",
        "中标结果": "badge-winner",
        "中标": "badge-winner",
        "合同公告": "badge-contract",
        "验收公告": "badge-other",
        "废标公告": "badge-fail",
        "谈判": "badge-bid",
        "询价": "badge-pre",
    }
    return badge_map.get(notice_type, "badge-other")


def _parse_deadline_countdown(deadline_str: str) -> str:
    """解析截止日期，返回倒计时 HTML 标签（含剩余天数）"""
    if not deadline_str:
        return ""
    try:
        # 尝试匹配 YYYY-MM-DD
        m = re.search(r"(\d{4})-(\d{2})-(\d{2})", str(deadline_str))
        if not m:
            return ""
        target = date(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        today = date.today()
        delta = (target - today).days
        if delta < 0:
            return f'<span class="countdown expired">⏰ 已截止({abs(delta)}天前)</span>'
        elif delta == 0:
            return '<span class="countdown urgent">⏰ 今天截止!</span>'
        elif delta <= 3:
            return f'<span class="countdown urgent">⏰ 剩{delta}天</span>'
        elif delta <= 7:
            return f'<span class="countdown warning">⏰ 剩{delta}天</span>'
        else:
            return f'<span class="countdown normal">⏰ 剩{delta}天</span>'
    except Exception:
        return ""



def _generate_bid_cards_html(bids: List[Dict]) -> str:
    """将格式化的标讯列表转换为卡片 HTML"""
    if not bids:
        return '<div style="color:#999;font-size:13px;text-align:center;padding:20px;">未搜索到标讯</div>'

    cards = []
    for i, bid in enumerate(bids, 1):
        link = bid.get("direct_link") or bid.get("raw_url") or ""
        title = bid.get("notice_title", "未知")

        # 标题
        title_html = f'<a href="{link}" target="_blank">{title}</a>' if link else title

        # 公告类型标签
        notice_type = bid.get("notice_type", "")
        badge_class = _notice_type_badge(notice_type)
        badge_html = f'<span class="badge {badge_class}">{notice_type}</span>' if notice_type else ""

        # 信息
        region = bid.get("region", "")
        if bid.get("city"):
            region += f" · {bid['city']}"

        budget = bid.get("budget_amount")
        budget_str = f"{budget:.2f} 万元" if budget else "未公开"

        deadline = bid.get("deadline", "")
        countdown_html = _parse_deadline_countdown(deadline) if deadline else ""
        buyer = bid.get("buyer", "")
        agency = bid.get("agency", "")
        summary_text = bid.get("summary", "") or bid.get("content_snippet", "") or ""

        # 构建 meta 项
        meta_items = ""
        if region:
            meta_items += f'<span class="meta-item">📍 {region}</span>'
        meta_items += f'<span class="meta-item">💰 {budget_str}</span>'
        if countdown_html:
            meta_items += f'<span class="meta-item">{countdown_html}</span>'
        elif deadline:
            meta_items += f'<span class="meta-item">⏰ {deadline}</span>'
        if buyer:
            meta_items += f'<span class="meta-item">🏛️ {buyer}</span>'
        if agency:
            meta_items += f'<span class="meta-item">🤝 {agency}</span>'

        # 描述
        desc_html = f'<p class="card-desc">{summary_text}</p>' if summary_text else ""

        # 链接按钮
        link_html = f'<a class="card-link" href="{link}" target="_blank">🔗 查看原文 →</a>' if link else ""

        cards.append(f"""
        <div class="bid-card">
          <div class="card-top">
            <span class="idx">{i}</span>
            <span class="title">{title_html}</span>
            {badge_html}
          </div>
          <div class="card-meta">
            {meta_items}
          </div>
          {desc_html}
          {link_html}
        </div>""")

    return "\n".join(cards)


def _generate_scored_bid_cards_html(scored_bids: List[Dict]) -> str:
    """将打分后的标讯列表转换为推荐级联卡 HTML（含评分/推荐等级/匹配类别）"""
    if not scored_bids:
        return '<div style="color:#999;font-size:13px;text-align:center;padding:20px;">无符合条件的标讯</div>'

    level_cls_map = {"强烈建议": "hot", "建议跟进": "rec", "需核实": "chk", "谨慎": "caut"}
    level_emoji_map = {"强烈建议": "🔴", "建议跟进": "🔵", "需核实": "🟡", "谨慎": "🟠"}

    cards = []
    for i, bid in enumerate(scored_bids, 1):
        # 线路1: bid_formatter 格式化后的字段（notice_title / direct_link / buyer / city / region / budget_amount）
        title = bid.get("notice_title", bid.get("title", "未知"))
        link = bid.get("direct_link") or bid.get("raw_url") or bid.get("url", "")
        buyer = bid.get("buyer", bid.get("caller_name", ""))
        city = bid.get("city", "")
        money_val = bid.get("budget_amount")
        budget = f"{money_val:.2f}万" if money_val else "未公开"
        bid_type = bid.get("notice_type", bid.get("bid_process_desc", bid.get("bid_process", "")))
        pub_time = bid.get("publish_date", bid.get("pub_time", ""))

        # 线路2: 打分后的额外字段
        score = bid.get("score", 0)
        level = bid.get("recommendation_level", "谨慎")
        lvl_cls = level_cls_map.get(level, "caut")
        emoji = level_emoji_map.get(level, "🟠")
        matched_cats = bid.get("matched_categories", bid.get("matched_cats", []))
        if isinstance(matched_cats, str):
            matched_cats = [matched_cats]
        cat_labels = ", ".join(matched_cats) if matched_cats else "-"
        sm_names = bid.get("sm_names", bid.get("keywords", []))

        title_html = f'<a href="{link}" target="_blank">{title}</a>' if link else title

        cards.append(f"""
    <div class="bid-card level-{lvl_cls}">
      <div class="bid-header">
        <span class="rank">#{i}</span>
        <span class="level-badge {lvl_cls}">{emoji} {level}</span>
        <span class="city-tag">📍 {city}</span>
        <span class="score-badge">关联度 {score}分</span>
      </div>
      <h3 class="bid-title">{title_html}</h3>
      <div class="bid-meta">
        <div class="meta-item"><span class="key">招标方</span><span class="val">{buyer}</span></div>
        <div class="meta-item"><span class="key">预算金额</span><span class="val money">{budget}</span></div>
        <div class="meta-item"><span class="key">公告类型</span><span class="val">{bid_type}</span></div>
        <div class="meta-item"><span class="key">发布日期</span><span class="val">{pub_time}</span></div>
        <div class="meta-item"><span class="key">匹配类别</span><span class="val">{cat_labels}</span></div>
        <div class="meta-item"><span class="key">标的物</span><span class="val">{", ".join(sm_names[:5]) if sm_names else "-"}</span></div>
      </div>
      <a class="bid-link" href="{link}" target="_blank">🔗 查看原文 →</a>
    </div>""")

    return "\n".join(cards)


# ============================================================
# 报告生成函数
# ============================================================

def generate_search_result_html(
    search_topic: str,
    bids: List[Dict],
    summary: Dict,
    company_name: str = "",
    generated_at: Optional[str] = None,
    keywords: Optional[List[str]] = None,
    exclude_keywords: Optional[List[str]] = None,
    data_begin_date: str = "",
    data_end_date: str = "",
    # ---- 新增：筛选分析参数 ----
    scored_bids: Optional[List[Dict]] = None,
    filtered_total: int = 0,
    excluded_count: int = 0,
    overview_text: str = "",
    search_meta_tags_html: str = "",
    focus_items: Optional[List[Dict]] = None,
    city_distribution: Optional[Dict[str, int]] = None,
    category_distribution: Optional[Dict[str, int]] = None,
    category_labels: Optional[Dict[str, str]] = None,
) -> str:
    """从模板生成标讯搜索记录 HTML 报告（含业务筛选分析）

    bids: bid_formatter.py 格式化后的全部标讯列表（向后兼容，无 scored_bids 时使用）
    summary: generate_search_summary() 返回的摘要
    scored_bids: 打分后的标讯列表，每项含 score/level/matched_categories（可选，启用推荐级联卡）
    filtered_total: 关联度筛选后数量
    excluded_count: 硬性排除数量
    overview_text: 搜索概览描述文字
    search_meta_tags_html: Hero 区域搜索标签 HTML 片段
    focus_items: 重点关注项目列表 [{name, city, amount, desc}, ...]
    city_distribution: 城市分布 {city: count}
    category_distribution: 业务类别分布 {category_key: count}
    category_labels: 类别键名到中文的映射 {key: label}
    """
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    total = summary.get("total", 0)
    budget_range = summary.get("budget_range", {})
    has_link_count = summary.get("has_link_count", 0)
    has_deadline_count = summary.get("has_deadline_count", 0)
    by_type = summary.get("by_type", {})
    by_region = summary.get("by_region", {})

    # 预算字符串
    def _fmt_budget(v):
        if v is None:
            return "-"
        return f"{v:.0f}" if isinstance(v, (int, float)) else str(v)

    budget_min = budget_range.get("min") if budget_range else None
    budget_max = budget_range.get("max") if budget_range else None

    # 日期
    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at

    # 加载模板
    template = _load_template("标讯搜索结果模板.html")

    # ---- 推荐级统计 ----
    hot_count = rec_count = chk_count = caut_count = 0
    if scored_bids:
        for b in scored_bids:
            lvl = b.get("recommendation_level", "")
            if lvl in ("强烈建议",):
                hot_count += 1
            elif lvl in ("建议跟进",):
                rec_count += 1
            elif lvl in ("需核实",):
                chk_count += 1
            else:
                caut_count += 1

    # ---- 关键词标签 ----
    kw_tags_html = ""
    if keywords:
        kws_str = "".join(f'<span class="kw-tag">{kw}</span>' for kw in keywords)
        kw_tags_html = f'<div class="kw-tags">{kws_str}</div>'
    else:
        kw_tags_html = '<div class="kw-tags"><span style="color:#94a3b8;font-size:13px">（未指定）</span></div>'

    # ---- 排除词标签 ----
    exclude_tags_html = ""
    if exclude_keywords:
        ex_str = "".join(f'<span class="kw-tag exclude">{kw}</span>' for kw in exclude_keywords)
        exclude_tags_html = f'<div class="kw-tags">{ex_str}</div>'
    else:
        exclude_tags_html = '<div class="kw-tags"><span style="color:#94a3b8;font-size:13px">（无）</span></div>'

    # ---- 概览文字 ----
    if not overview_text:
        overview_text = f"共搜索到 <strong>{total}</strong> 条标讯，经过关联度筛选后保留 <strong>{filtered_total}</strong> 条，硬性排除 <strong>{excluded_count}</strong> 条"

    # ---- 重点关注区 ----
    focus_section = ""
    if focus_items and len(focus_items) > 0:
        items_html = "\n".join(
            f'<li><strong>{item["name"]}</strong> — {item.get("city","")}，<span class="money">{item.get("amount","")}</span> · {item.get("desc","")}</li>'
            for item in focus_items
        )
        focus_section = f"""<div class="section">
  <h2>🔥 重点关注（Top {len(focus_items)}）</h2>
  <div class="focus-box">
    <ol>
      {items_html}
    </ol>
  </div>
</div>"""

    # ---- 推荐级联卡（scored_bids） vs 普通卡（bids） ----
    if scored_bids:
        bid_cards = _generate_scored_bid_cards_html(scored_bids)
    else:
        bid_cards = _generate_bid_cards_html(bids)

    # ---- 城市分布柱状图 ----
    city_bars = ""
    if city_distribution:
        max_c = max(city_distribution.values()) if city_distribution else 1
        for city, cnt in sorted(city_distribution.items(), key=lambda x: -x[1]):
            pct = int(cnt / max_c * 100) if max_c else 0
            bar_text = f"{'█' * cnt} {cnt}条" if cnt else ""
            city_bars += f'<div class="bar-row"><span class="bar-label">{city}</span><div class="bar-track"><div class="bar-fill" style="width:{max(4,pct)}%"><span class="bar-text">{bar_text}</span></div></div></div>\n'
    else:
        city_bars = _generate_bars_html(dict(by_region))

    # ---- 业务类别分布柱状图 ----
    cat_bars = ""
    if category_distribution and category_labels:
        max_cat = max(category_distribution.values()) if category_distribution else 1
        for cat_key, cnt in sorted(category_distribution.items(), key=lambda x: -x[1]):
            label = category_labels.get(cat_key, cat_key)
            pct = int(cnt / max_cat * 100) if max_cat else 0
            bar_text = f"{'█' * cnt} {cnt}条" if cnt else ""
            cat_bars += f'<div class="bar-row"><span class="bar-label">{label}</span><div class="bar-track"><div class="bar-fill" style="width:{max(4,pct)}%"><span class="bar-text">{bar_text}</span></div></div></div>\n'
    else:
        cat_bars = '<div class="bar-row"><span style="color:#94a3b8;font-size:13px">（无分类数据）</span></div>'

    # ---- Hero meta tags ----
    if not search_meta_tags_html:
        search_meta_tags_html = ""

    # ---- 页脚 ----
    footer_text = f"报告生成时间：{generated_at} · 数据来源：知了标讯 ai.zhiliaobiaoxun.com · ⚠️ 以上分析为AI初步判断，最终投标决策需人工确认"

    # ---- 增强版统计（兼容旧调用） ----
    # 计算紧迫度、高价值、省份数
    from datetime import datetime as _dt_now
    _now = _dt_now.now()
    urgent_3 = urgent_7 = high_val = 0
    _provinces = set()
    for _b in bids:
        _dl = _b.get("deadline", "")
        if _dl:
            try:
                _dd = _dt_now.strptime(str(_dl)[:10], '%Y-%m-%d') if '-' in str(_dl) else None
                if _dd:
                    _left = (_dd - _dt_now.now()).days
                    if 0 <= _left <= 3: urgent_3 += 1
                    if 0 <= _left <= 7: urgent_7 += 1
            except: pass
        _ba = _b.get("budget_amount")
        if _ba and _ba >= 100: high_val += 1
        _reg = _b.get("region", "")
        if _reg: _provinces.add(_reg)
    prov_cnt = len(_provinces) if _provinces else "-"

    # 增强分析区HTML
    enhanced_analysis = ""
    if len(bids) > 0:
        # 预算分布
        budget_bins = {"50万以下":0,"50-200万":0,"200-500万":0,"500-1000万":0,"1000万以上":0,"未公开":0}
        for _b in bids:
            _ba = _b.get("budget_amount")
            if not _ba or _ba <= 0:
                budget_bins["未公开"] += 1
            elif _ba < 50: budget_bins["50万以下"] += 1
            elif _ba < 200: budget_bins["50-200万"] += 1
            elif _ba < 500: budget_bins["200-500万"] += 1
            elif _ba < 1000: budget_bins["500-1000万"] += 1
            else: budget_bins["1000万以上"] += 1
        _max_b = max(budget_bins.values()) if max(budget_bins.values()) else 1
        _budget_rows = ""
        _colors_b = {"50万以下":"#27ae60","50-200万":"#3498db","200-500万":"#f39c12","500-1000万":"#e67e22","1000万以上":"#e74c3c","未公开":"#95a5a6"}
        for _bk in ["50万以下","50-200万","200-500万","500-1000万","1000万以上","未公开"]:
            _bv = budget_bins[_bk]
            _bp = int(_bv/_max_b*100) if _max_b else 0
            if _bv > 0:
                _budget_rows += f'<div class="bar-row"><span class="bar-label">{_bk}</span><div class="bar-track"><div class="bar-fill fill-{_bk}" style="width:{max(4,_bp)}%;background:{_colors_b[_bk]}"><span class="bar-text">{_bv}条</span></div></div></div>\n'
        
        # 招标方式分布
        from collections import Counter as _Counter
        _methods = _Counter(_b.get("bid_type", "未知") for _b in bids if _b.get("bid_type"))
        _method_html = ""
        _mcolors = ["#3498db","#2ecc71","#e67e22","#9b59b6","#95a5a6"]
        _mtotal = max(sum(_methods.values()), 1)
        for _mi, (_mk, _mv) in enumerate(_methods.most_common()):
            _mp = int(_mv/_mtotal*100)
            _method_html += f'<div class="bar-row"><span class="bar-label">{_mk}</span><div class="bar-track"><div class="bar-fill" style="width:{_mp}%;background:{_mcolors[_mi%5]}"><span class="bar-text">{_mv}条</span></div></div></div>\n'
        
        _deadline_rows = ""
        _dcolors = {"3天内":"#e74c3c","7天内":"#f39c12","14天内":"#3498db","30天内":"#27ae60"}
        _dcounts = {"3天内":urgent_3, "7天内":urgent_7-urgent_3 if urgent_7>urgent_3 else 0, "14天内":0, "30天内":0}
        _max_d = max(_dcounts.values()) if max(_dcounts.values()) else 1
        for _dk, _dc in _dcounts.items():
            if _dc > 0:
                _dp = int(_dc/_max_d*100)
                _deadline_rows += f'<div class="bar-row"><span class="bar-label">{_dk}</span><div class="bar-track"><div class="bar-fill" style="width:{max(4,_dp)}%;background:{_dcolors[_dk]}"><span class="bar-text">{_dc}条</span></div></div></div>\n'

        enhanced_analysis = f"""<div class="section">
  <h3>💰 预算区间分布</h3>
  {_budget_rows}
</div>
<div class="section">
  <h3>📋 招标方式分布</h3>
  {_method_html}
</div>
<div class="section">
  <h3>⏰ 截止紧迫度分析</h3>
  {_deadline_rows if _deadline_rows else '<span style="color:#94a3b8;font-size:13px">暂无截止时间数据</span>'}
</div>"""

    # 评分统计区
    scored_stats_html = ""
    if scored_bids:
        scored_stats_html = f"""<div class="stats" style="margin-top:12px">
  <div class="stat-card accent-red"><div class="num">{hot_count}</div><div class="label">强烈建议 🔴</div></div>
  <div class="stat-card accent-blue"><div class="num">{rec_count}</div><div class="label">建议跟进 🔵</div></div>
  <div class="stat-card accent-amber"><div class="num">{chk_count}+{caut_count}</div><div class="label">需核实/谨慎</div></div>
</div>"""

    # ---- 替换占位符 ----
    replacements = {
        "{{SEARCH_TOPIC}}": search_topic,
        "{{HERO_SUBTITLE}}": f"招投标商机搜索结果 — {search_topic}",
        "{{COMPANY_NAME}}": company_name or "-",
        "{{SEARCH_DATE}}": search_date,
        "{{TOTAL_BIDS}}": str(total),
        "{{FILTERED_COUNT}}": str(filtered_total) if filtered_total else str(total),
        "{{EXCLUDED_COUNT}}": str(excluded_count),
        "{{HOT_COUNT}}": str(hot_count),
        "{{REC_COUNT}}": str(rec_count),
        "{{CHK_COUNT}}": str(chk_count),
        "{{CAUT_COUNT}}": str(caut_count),
        "{{URGENT_3_COUNT}}": str(urgent_3),
        "{{URGENT_7_COUNT}}": str(urgent_7),
        "{{HIGH_VALUE_COUNT}}": str(high_val),
        "{{PROVINCE_COUNT}}": str(prov_cnt),
        "{{SCORED_STATS}}": scored_stats_html,
        "{{ENHANCED_ANALYSIS_SECTION}}": enhanced_analysis,
        "{{ENHANCED_STATS_SECTION}}": "",
        "{{OVERVIEW_TEXT}}": overview_text,
        "{{KEYWORD_TAGS}}": kw_tags_html,
        "{{EXCLUDE_TAGS}}": exclude_tags_html,
        "{{FOCUS_SECTION}}": focus_section,
        "{{BID_CARDS}}": bid_cards,
        "{{CITY_BARS}}": city_bars,
        "{{CATEGORY_BARS}}": cat_bars,
        "{{SEARCH_META_TAGS}}": search_meta_tags_html,
        "{{FOOTER_TEXT}}": footer_text,
    }

    html = template
    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    return html


def generate_screening_table_html(
    search_topic: str,
    bids: List[Dict],
    company_name: str = "",
    generated_at: Optional[str] = None,
    excluded_bids: Optional[List[Dict]] = None,
) -> str:
    """从模板生成商机筛选表 HTML 报告

    加载 assets/templates/output/商机筛选表模板.html，
    填充统计数据和卡片列表后返回完整 HTML。

    bids: 已筛选后的有效标讯列表（含 recommendation_level, score 等字段）
    excluded_bids: 被排除的标讯列表（可选，用于展示排除原因）
    """
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 加载模板
    template = _load_template("商机筛选表模板.html")

    total = len(bids) + len(excluded_bids) if excluded_bids else len(bids)
    valid_count = len(bids)

    # 按级别统计
    level_counts = {"强烈建议": 0, "建议跟进": 0, "需核实": 0, "谨慎": 0, "不建议": 0}
    for b in bids:
        lvl = b.get("recommendation_level", "需核实")
        if lvl in level_counts:
            level_counts[lvl] += 1
    if excluded_bids:
        for b in excluded_bids:
            lvl = b.get("recommendation_level", "不建议")
            level_counts[lvl] = level_counts.get(lvl, 0) + 1

    strong_cnt = level_counts.get("强烈建议", 0)
    follow_cnt = level_counts.get("建议跟进", 0)
    verify_cnt = level_counts.get("需核实", 0)
    cautious_cnt = level_counts.get("谨慎", 0) + level_counts.get("不建议", 0)

    # 生成卡片
    cards = []
    for i, bid in enumerate(bids, 1):
        link = bid.get("direct_link") or bid.get("raw_url") or ""
        title = bid.get("notice_title", "未知")
        title_html = f'<a href="{link}" target="_blank">{title}</a>' if link else title

        level = bid.get("recommendation_level", "需核实")
        badge_cls = {"强烈建议": "bg-green", "建议跟进": "bg-blue", "需核实": "bg-yellow"}.get(level, "bg-gray")
        score = bid.get("score", "-")
        match = bid.get("business_match", "")
        reason = bid.get("recommendation_reason", "")
        region = bid.get("region", "")
        if bid.get("city"):
            region += f" · {bid['city']}"
        notice_type = bid.get("notice_type", "")
        buyer = bid.get("buyer", "")
        budget = bid.get("budget_amount")
        budget_str = f"💰 {budget:.2f}万" if budget else "💰 未公开"
        deadline = bid.get("deadline", "")
        countdown_html = _parse_deadline_countdown(deadline) if deadline else ""

        meta_items = ""
        if region:
            meta_items += f'<span class="meta-item">📍 {region}</span>'
        meta_items += f'<span class="meta-item">{budget_str}</span>'
        if countdown_html:
            meta_items += f'<span class="meta-item">{countdown_html}</span>'
        elif deadline:
            meta_items += f'<span class="meta-item">⏰ {deadline}</span>'
        if notice_type:
            meta_items += f'<span class="meta-item">📄 {notice_type}</span>'
        if buyer:
            meta_items += f'<span class="meta-item">🏛️ {buyer}</span>'

        # 匹配度详细说明
        match_detail = ""
        if match:
            match_detail += f'<div class="match-badge">{match}</div>'
        if reason:
            match_detail += f'<div class="match-reason">{reason}</div>'

        link_html = f'<a class="card-link" href="{link}" target="_blank">🔗 查看原文 →</a>' if link else ""

        cards.append(f"""
        <div class="bid-card">
          <div class="card-top">
            <span class="idx">{i}</span>
            <span class="title">{title_html}</span>
            <span class="badge {badge_cls}">{level} · {score}分</span>
          </div>
          <div class="card-meta">{meta_items}</div>
          {match_detail}
          {link_html}
        </div>""")

    screening_cards = "\n".join(cards)

    # 排除信息 — 更加详细
    excluded_summary = ""
    excluded_section = ""
    if excluded_bids and len(excluded_bids) > 0:
        excluded_summary = f"""<div class="card anim d2">
  <div class="card-body" style="padding:12px 20px;">
    <div class="summary-box">
      <strong>⚠️ 已排除 {len(excluded_bids)} 条标讯</strong> — 因业务方向不匹配、预算低于30万或属于排除类目（医疗/IT/食堂/保洁/土建等），详见下方列表。
    </div>
  </div>
</div>"""
        excluded_rows = ""
        for b in excluded_bids:
            et = b.get("notice_title", "?")
            eb = b.get("buyer", b.get("caller_name", ""))
            er = b.get("exclude_reason", b.get("recommendation_reason", "业务方向不匹配"))
            excluded_rows += f'<tr><td style="font-size:12px;">{et[:50]}…</td><td style="font-size:12px;color:#666;">{eb}</td><td style="font-size:12px;color:#e53935;">{er}</td></tr>'
        excluded_section = f"""<div class="card anim d3">
  <div class="card-header">
    <span class="icon">🚫</span>
    <h2>已排除项目</h2>
    <span class="tag tag-yellow">{len(excluded_bids)} 条</span>
  </div>
  <div class="card-body">
    <table style="width:100%;font-size:13px;border-collapse:collapse;">
      <tr><th style="text-align:left;padding:6px 8px;background:#f8f9fa;color:#666;">项目名称</th><th style="text-align:left;padding:6px 8px;background:#f8f9fa;color:#666;">招标方</th><th style="text-align:left;padding:6px 8px;background:#f8f9fa;color:#666;">排除原因</th></tr>
      {excluded_rows}
    </table>
  </div>
</div>"""

    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at

    # 替换占位符
    replacements = {
        "{{SEARCH_TOPIC}}": search_topic,
        "{{COMPANY_NAME}}": company_name or "-",
        "{{GENERATED_AT}}": search_date,
        "{{TOTAL_COUNT}}": str(total),
        "{{VALID_COUNT}}": str(valid_count),
        "{{STRONG_COUNT}}": str(strong_cnt),
        "{{FOLLOW_COUNT}}": str(follow_cnt),
        "{{VERIFY_COUNT}}": str(verify_cnt),
        "{{CAUTIOUS_COUNT}}": str(cautious_cnt),
        "{{SCREENING_CARDS}}": screening_cards,
        "{{EXCLUDED_SUMMARY}}": excluded_summary,
        "{{EXCLUDED_SECTION}}": excluded_section,
        "{{FUNNEL_SECTION}}": "",
        "{{SCORE_MODEL_SECTION}}": "",
    }

    html = template
    for placeholder, value in replacements.items():
        html = html.replace(placeholder, value)

    return html


def generate_bid_scoring_html(
    project_name: str,
    company_name: str = "",
    generated_at: Optional[str] = None,
    total_score: int = 0,
    score_label: str = "",
    score_desc: str = "",
    dimension_rows: str = "",
    risk_badges: str = "",
    final_title: str = "",
    final_desc: str = "",
    reasons: str = "",
    actions: str = "",
    bid_link: str = "",  # 标讯原文链接
) -> str:
    """从模板生成投标机会评分 HTML 报告"""
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    template = _load_template("投标机会评分模板.html")
    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at
    # 生成原文按钮
    bid_link_btn = f'<p style="margin-top:8px"><a href="{bid_link}" target="_blank" style="display:inline-block;padding:6px 16px;background:#1a73e8;color:#fff;border-radius:8px;text-decoration:none;font-size:13px;">🔗 查看标讯原文</a></p>' if bid_link else ""
    reps = {
        "{{PROJECT_NAME}}": project_name, "{{COMPANY_NAME}}": company_name or "-",
        "{{GENERATED_AT}}": search_date, "{{TOTAL_SCORE}}": str(total_score),
        "{{SCORE_LABEL}}": score_label, "{{SCORE_DESC}}": score_desc,
        "{{DIMENSION_ROWS}}": dimension_rows, "{{RISK_BADGES}}": risk_badges,
        "{{FINAL_TITLE}}": final_title, "{{FINAL_DESC}}": final_desc,
        "{{REASONS}}": reasons, "{{ACTIONS}}": actions,
        "{{BID_LINK_BUTTON}}": bid_link_btn,
    }
    html = template
    for p, v in reps.items():
        html = html.replace(p, v)
    return html



def generate_task_list_html(
    project_name: str,
    company_name: str = "",
    generated_at: Optional[str] = None,
    buyer: str = "",
    bid_no: str = "",
    deadline_text: str = "",
    warn_text: str = "",
    role_sections: str = "",
    risk_items: str = "",
    checklist: str = "",
    post_bid_tasks: str = "",
    bid_link: str = "",  # 标讯原文链接
) -> str:
    """从模板生成投标准备任务清单 HTML 报告"""
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    template = _load_template("投标准备任务清单模板.html")
    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at
    bid_link_btn = f'<p style="margin-top:8px"><a href="{bid_link}" target="_blank" style="display:inline-block;padding:6px 16px;background:#1a73e8;color:#fff;border-radius:8px;text-decoration:none;font-size:13px;">🔗 查看标讯原文</a></p>' if bid_link else ""
    reps = {
        "{{PROJECT_NAME}}": project_name, "{{COMPANY_NAME}}": company_name or "-",
        "{{GENERATED_AT}}": search_date, "{{BUYER}}": buyer, "{{BID_NO}}": bid_no,
        "{{DEADLINE_TEXT}}": deadline_text, "{{WARN_TEXT}}": warn_text,
        "{{ROLE_SECTIONS}}": role_sections, "{{RISK_ITEMS}}": risk_items,
        "{{CHECKLIST}}": checklist, "{{POST_BID_TASKS}}": post_bid_tasks,
        "{{BID_LINK_BUTTON}}": bid_link_btn,
    }
    html = template
    for p, v in reps.items():
        html = html.replace(p, v)
    return html



def generate_bid_analysis_html(
    project_name: str = "",
    company_name: str = "",
    generated_at: Optional[str] = None,
    hero_label: str = "标讯深度解读",
    project_subtitle: str = "",
    publish_date: str = "",
    deadline_date: str = "",
    project_region: str = "",
    bid_type: str = "",
    bid_link: str = "",
    snapshot_tag_cls: str = "green",
    snapshot_tag: str = "",
    info_grid: str = "",
    qual_tag_cls: str = "green",
    qual_tag: str = "",
    qual_content: str = "",
    match_tag_cls: str = "green",
    match_tag: str = "",
    match_grid: str = "",
    value_cards: str = "",
    deadline_tag_cls: str = "yellow",
    deadline_tag: str = "",
    timeline_items: str = "",
    score_tag_cls: str = "green",
    score_tag: str = "",
    summary_bg: str = "#f0fdf4",
    summary_border: str = "#a7f3d0",
    summary_title_color: str = "#065f46",
    summary_text_color: str = "#047857",
    summary_title: str = "",
    summary_desc: str = "",
    risk_and_confirm: str = "",
    action_tag_cls: str = "yellow",
    action_tag: str = "",
    action_items: str = "",
    footer_text: str = "",
) -> str:
    """从标讯解读报告模板生成精美标讯解读 HTML 报告

    所有参数均为预生成的HTML片段，函数直接填入模板占位符。
    """
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    template = _load_template("标讯解读报告模板.html")
    search_date = generated_at[:10] if len(generated_at) >= 10 else generated_at
    if not footer_text:
        footer_text = f"由招投标商机专家 Skill 自动生成 · 数据来源：知了标讯 AI 开放平台 · {search_date}"
    reps = {
        "{{HERO_LABEL}}": hero_label, "{{PROJECT_NAME}}": project_name,
        "{{PROJECT_SUBTITLE}}": project_subtitle, "{{PUBLISH_DATE}}": publish_date,
        "{{DEADLINE_DATE}}": deadline_date, "{{PROJECT_REGION}}": project_region,
        "{{BID_TYPE}}": bid_type, "{{COMPANY_NAME}}": company_name or "-",
        "{{BID_LINK}}": bid_link,
        "{{SNAPSHOT_TAG_CLS}}": snapshot_tag_cls, "{{SNAPSHOT_TAG}}": snapshot_tag,
        "{{INFO_GRID}}": info_grid,
        "{{QUAL_TAG_CLS}}": qual_tag_cls, "{{QUAL_TAG}}": qual_tag,
        "{{QUAL_CONTENT}}": qual_content,
        "{{MATCH_TAG_CLS}}": match_tag_cls, "{{MATCH_TAG}}": match_tag,
        "{{MATCH_GRID}}": match_grid,
        "{{VALUE_CARDS}}": value_cards,
        "{{DEADLINE_TAG_CLS}}": deadline_tag_cls, "{{DEADLINE_TAG}}": deadline_tag,
        "{{TIMELINE_ITEMS}}": timeline_items,
        "{{SCORE_TAG_CLS}}": score_tag_cls, "{{SCORE_TAG}}": score_tag,
        "{{SUMMARY_BG}}": summary_bg, "{{SUMMARY_BORDER}}": summary_border,
        "{{SUMMARY_TITLE_COLOR}}": summary_title_color,
        "{{SUMMARY_TEXT_COLOR}}": summary_text_color,
        "{{SUMMARY_TITLE}}": summary_title, "{{SUMMARY_DESC}}": summary_desc,
        "{{RISK_AND_CONFIRM}}": risk_and_confirm,
        "{{ACTION_TAG_CLS}}": action_tag_cls, "{{ACTION_TAG}}": action_tag,
        "{{ACTION_ITEMS}}": action_items,
        "{{FOOTER_TEXT}}": footer_text,
    }
    html = template
    for p, v in reps.items():
        html = html.replace(p, v)
    return html


def generate_project_plan_html(
    project_name: str,
    sections: Dict[str, str],
    company_name: str = "",
    generated_at: Optional[str] = None,
    bid_link: str = "",
) -> str:
    """生成重点项目方案 HTML 报告（内联生成，精美版见bid-analysis命令）

    sections: 章节内容字典，键为章节标题，值为 HTML 内容
    bid_link: 标讯原文链接（可选）
    """
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    section_html = ""
    for title, content in sections.items():
        section_html += f"""
    <h2 class="section-title">{title}</h2>
    <div style="margin-bottom:20px">{content}</div>"""

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>重点项目方案 - {project_name}</title>
<style>{CSS_COMMON}
.project-card {{ border-left: 4px solid #1a73e8; }}
.risk-high {{ border-left-color: #e53935; }}
.risk-mid {{ border-left-color: #fb8c00; }}
.risk-low {{ border-left-color: #43a047; }}
.info-table td:first-child {{ font-weight: 600; color: #555; width: 140px; }}
</style>
</head>
<body>
<div class="container">
    <div class="header">
        <h1>📌 重点项目方案</h1>
        <div class="meta">
            <span>项目：{project_name}</span>
            <span>企业：{company_name or '-'}</span>
            <span>生成时间：{generated_at}</span>
        </div>
    </div>
    {section_html}
    <div class="footer">
        <p>由招投标商机专家 Skill 自动生成 | ⚠️ 所有评分与分析仅供参考，最终决策请结合实际情况</p>
    </div>
</div>
</body>
</html>"""
    return html


def generate_project_report_html(
    project_name: str,
    sections_data: List[Dict[str, str]],
    company_name: str = "",
    generated_at: Optional[str] = None,
    bid_link: str = "",
) -> str:
    """生成重点项目分析报告 HTML（单栏居中布局，无侧边栏）

    sections_data: [{title: "章节标题", content: "HTML 内容"}, ...]
    bid_link: 标讯原文链接（可选）
    """
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    # 构建内容
    content_sections = ""
    for i, sec in enumerate(sections_data):
        title = sec["title"]
        content = sec["content"]
        anchor_id = f"sec-{i}"
        content_sections += f"""
    <section id="{anchor_id}" class="content-section">
      <h2 class="section-title">{title}</h2>
      {content}
    </section>"""

    link_html = f'<p style="margin-bottom:16px;"><a href="{bid_link}" target="_blank" class="bid-link">🔗 查看标讯原文</a></p>' if bid_link else ""

    css = """
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC", "Microsoft YaHei", Arial, sans-serif;
    background: #f5f7fa;
    color: #333;
    line-height: 1.7;
}
.header {
    background: linear-gradient(135deg, #1a56db 0%, #1e40af 100%);
    color: #fff;
    padding: 32px 40px;
    text-align: center;
    margin-bottom: 24px;
}
.header h1 { font-size: 22px; margin-bottom: 6px; }
.header .meta { font-size: 13px; opacity: 0.85; }
.container { max-width: 900px; margin: 0 auto; padding: 0 20px 40px; }
.content-section {
    background: #fff;
    border: 1px solid #e8ecf0;
    border-radius: 10px;
    padding: 24px 28px;
    margin-bottom: 20px;
    box-shadow: 0 1px 4px rgba(0,0,0,0.06);
}
.section-title {
    font-size: 18px;
    font-weight: 600;
    color: #1a56db;
    margin-bottom: 16px;
    padding-bottom: 10px;
    border-bottom: 2px solid #e8ecf0;
}
table {
    width: 100%;
    border-collapse: collapse;
    margin: 12px 0;
    font-size: 13px;
}
table th {
    background: #1a56db;
    color: #fff;
    padding: 8px 10px;
    text-align: left;
    font-weight: 600;
    white-space: nowrap;
}
table td {
    padding: 8px 10px;
    border-bottom: 1px solid #e8ecf0;
}
table tr:nth-child(even) { background: #fafbfc; }
.badge {
    display: inline-block;
    padding: 2px 10px;
    border-radius: 12px;
    font-size: 12px;
    font-weight: 600;
}
.badge-green { background: #e6f7e6; color: #1a7d1a; }
.badge-blue { background: #e6f0ff; color: #1a5e8a; }
.badge-yellow { background: #fff7e6; color: #8a6d1a; }
.badge-orange { background: #fff0e6; color: #8a4a1a; }
.badge-red { background: #ffe6e6; color: #8a1a1a; }
.badge-gray { background: #f0f0f0; color: #666; }
.bid-link { color: #1a73e8; text-decoration: none; font-size: 14px; }
.bid-link:hover { text-decoration: underline; }
.stat-row { display: flex; gap: 12px; flex-wrap: wrap; margin: 12px 0; }
.stat-card {
    background: #f8f9fb;
    border: 1px solid #e8ecf0;
    border-radius: 8px;
    padding: 14px 18px;
    min-width: 100px;
    flex: 1;
    text-align: center;
}
.stat-card .num { font-size: 26px; font-weight: 700; color: #1a56db; }
.stat-card .label { font-size: 12px; color: #888; margin-top: 4px; }
.footer {
    text-align: center;
    padding: 20px;
    font-size: 12px;
    color: #999;
    border-top: 1px solid #e0e0e0;
    background: #fff;
    margin-top: 24px;
}
"""

    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>项目分析报告 - {project_name}</title>
<style>{css}</style>
</head>
<body>
<div class="header">
  <h1>📋 项目分析报告</h1>
  <div class="meta">{company_name or '-'} · {generated_at}</div>
</div>
<div class="container">
  {link_html}
  {content_sections}
</div>
<div class="footer">
  <p>由招投标商机专家 Skill 自动生成 · 数据来源：知了标讯 ai.zhiliaobiaoxun.com · ⚠️ 以上分析为AI初步判断，最终投标决策需人工确认</p>
</div>
</body>
</html>"""
    return html


def _get_notice_badge(notice_type: str) -> str:
    """为公告类型生成标签（旧版，保留向后兼容）"""
    badge_map = {
        "采购意向": ("badge-blue", "采购意向"),
        "预招标": ("badge-yellow", "预招标"),
        "招标公告": ("badge-green", "招标公告"),
        "变更公告": ("badge-orange", "变更"),
        "中标候选人公示": ("badge-blue", "中标候选"),
        "中标结果": ("badge-green", "已中标"),
        "合同公告": ("badge-gray", "合同"),
        "验收公告": ("badge-gray", "验收"),
        "废标公告": ("badge-red", "废标"),
    }
    cls, label = badge_map.get(notice_type, ("badge-gray", notice_type))
    return f'<span class="badge {cls}">{label}</span>'


def save_html(content: str, file_path: str) -> str:
    """保存 HTML 文件"""
    path = Path(file_path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(str(path), "w", encoding="utf-8") as f:
        f.write(content)
    return str(path)


# ============================================================
# CLI 入口
# ============================================================

def main():
    if len(sys.argv) < 2:
        print("Usage: html_generator.py <command> [args]", file=sys.stderr)
        print("Commands: search-result, screening-table, project-plan, bid-scoring, task-list, bid-analysis, project-report", file=sys.stderr)
        sys.exit(1)

    command = sys.argv[1]
    input_data = json.load(sys.stdin)
    output_path = sys.argv[2] if len(sys.argv) > 2 else None

    if command == "search-result":
        html = generate_search_result_html(
            search_topic=input_data.get("search_topic", ""),
            bids=input_data.get("bids", []),
            summary=input_data.get("summary", {}),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            keywords=input_data.get("keywords"),
            exclude_keywords=input_data.get("exclude_keywords"),
            data_begin_date=input_data.get("begin_date", ""),
            data_end_date=input_data.get("end_date", ""),
            scored_bids=input_data.get("scored_bids"),
            filtered_total=input_data.get("filtered_total", 0),
            excluded_count=input_data.get("excluded_count", 0),
            overview_text=input_data.get("overview_text", ""),
            search_meta_tags_html=input_data.get("search_meta_tags_html", ""),
            focus_items=input_data.get("focus_items"),
            city_distribution=input_data.get("city_distribution"),
            category_distribution=input_data.get("category_distribution"),
            category_labels=input_data.get("category_labels"),
        )
    elif command == "screening-table":
        html = generate_screening_table_html(
            search_topic=input_data.get("search_topic", ""),
            bids=input_data.get("bids", []),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            excluded_bids=input_data.get("excluded_bids"),
        )
    elif command == "project-plan":
        html = generate_project_plan_html(
            project_name=input_data.get("project_name", ""),
            sections=input_data.get("sections", {}),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            bid_link=input_data.get("bid_link", ""),
        )
    elif command == "bid-analysis":
        html = generate_bid_analysis_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            hero_label=input_data.get("hero_label", "标讯深度解读"),
            project_subtitle=input_data.get("project_subtitle", ""),
            publish_date=input_data.get("publish_date", ""),
            deadline_date=input_data.get("deadline_date", ""),
            project_region=input_data.get("project_region", ""),
            bid_type=input_data.get("bid_type", ""),
            bid_link=input_data.get("bid_link", ""),
            snapshot_tag_cls=input_data.get("snapshot_tag_cls", "green"),
            snapshot_tag=input_data.get("snapshot_tag", ""),
            info_grid=input_data.get("info_grid", ""),
            qual_tag_cls=input_data.get("qual_tag_cls", "green"),
            qual_tag=input_data.get("qual_tag", ""),
            qual_content=input_data.get("qual_content", ""),
            match_tag_cls=input_data.get("match_tag_cls", "green"),
            match_tag=input_data.get("match_tag", ""),
            match_grid=input_data.get("match_grid", ""),
            value_cards=input_data.get("value_cards", ""),
            deadline_tag_cls=input_data.get("deadline_tag_cls", "yellow"),
            deadline_tag=input_data.get("deadline_tag", ""),
            timeline_items=input_data.get("timeline_items", ""),
            score_tag_cls=input_data.get("score_tag_cls", "green"),
            score_tag=input_data.get("score_tag", ""),
            summary_bg=input_data.get("summary_bg", "#f0fdf4"),
            summary_border=input_data.get("summary_border", "#a7f3d0"),
            summary_title_color=input_data.get("summary_title_color", "#065f46"),
            summary_text_color=input_data.get("summary_text_color", "#047857"),
            summary_title=input_data.get("summary_title", ""),
            summary_desc=input_data.get("summary_desc", ""),
            risk_and_confirm=input_data.get("risk_and_confirm", ""),
            action_tag_cls=input_data.get("action_tag_cls", "yellow"),
            action_tag=input_data.get("action_tag", ""),
            action_items=input_data.get("action_items", ""),
            footer_text=input_data.get("footer_text", ""),
        )
    elif command == "bid-scoring":
        html = generate_bid_scoring_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            total_score=input_data.get("total_score", 0),
            score_label=input_data.get("score_label", ""),
            score_desc=input_data.get("score_desc", ""),
            dimension_rows=input_data.get("dimension_rows", ""),
            risk_badges=input_data.get("risk_badges", ""),
            final_title=input_data.get("final_title", ""),
            final_desc=input_data.get("final_desc", ""),
            reasons=input_data.get("reasons", ""),
            actions=input_data.get("actions", ""),
        )
    elif command == "task-list":
        html = generate_task_list_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            buyer=input_data.get("buyer", ""),
            bid_no=input_data.get("bid_no", ""),
            deadline_text=input_data.get("deadline_text", ""),
            warn_text=input_data.get("warn_text", ""),
            role_sections=input_data.get("role_sections", ""),
            risk_items=input_data.get("risk_items", ""),
            checklist=input_data.get("checklist", ""),
            post_bid_tasks=input_data.get("post_bid_tasks", ""),
        )
    elif command == "bid-plan":
        html = generate_bid_plan_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            bid_link=input_data.get("bid_link", ""),
            buyer=input_data.get("buyer", ""),
            budget=input_data.get("budget", ""),
            deadline_text=input_data.get("deadline_text", ""),
            qual_checklist=input_data.get("qual_checklist", ""),
            technical_framework=input_data.get("technical_framework", ""),
            ref_projects=input_data.get("ref_projects", ""),
            price_strategy=input_data.get("price_strategy", ""),
            submit_checklist=input_data.get("submit_checklist", ""),
        )
    else:
        print(f"Unknown command: {command}", file=sys.stderr)
        sys.exit(1)

    if output_path:
        saved = save_html(html, output_path)
        print(f"HTML 已保存: {saved}")
    else:
        sys.stdout.write(html)


def generate_bid_plan_html(
    project_name: str,
    company_name: str = "",
    generated_at: Optional[str] = None,
    bid_link: str = "",
    buyer: str = "",
    budget: str = "",
    deadline_text: str = "",
    qual_checklist: str = "",
    technical_framework: str = "",
    ref_projects: str = "",
    price_strategy: str = "",
    submit_checklist: str = "",
) -> str:
    """生成投标方案模板 HTML（独立页面，深度分析后追问生成）

    包含：资质自查清单、技术方案框架、业绩对照表、报价策略、投标准备清单
    """
    if not generated_at:
        generated_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    link_html = f'<p style="margin-bottom:16px;"><a href="{bid_link}" target="_blank" style="color:#1a56db;text-decoration:none;font-size:14px;">🔗 查看标讯原文</a></p>' if bid_link else ""

    css = """
* { margin:0; padding:0; box-sizing:border-box; }
body { font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif; background:#f5f7fa; color:#333; line-height:1.7; }
.header { background:linear-gradient(135deg,#065f46 0%,#047857 100%); color:#fff; padding:32px 40px; text-align:center; margin-bottom:24px; }
.header h1 { font-size:22px; margin-bottom:6px; }
.header .meta { font-size:13px; opacity:0.85; }
.container { max-width:900px; margin:0 auto; padding:0 20px 40px; }
.plan-section { background:#fff; border:1px solid #e8ecf0; border-radius:10px; padding:24px 28px; margin-bottom:20px; box-shadow:0 1px 4px rgba(0,0,0,0.06); }
.plan-section h2 { font-size:18px; font-weight:600; color:#065f46; margin-bottom:16px; padding-bottom:10px; border-bottom:2px solid #e8ecf0; display:flex; align-items:center; gap:8px; }
table { width:100%; border-collapse:collapse; margin:12px 0; font-size:13px; }
table th { background:#065f46; color:#fff; padding:8px 10px; text-align:left; font-weight:600; white-space:nowrap; }
table td { padding:8px 10px; border-bottom:1px solid #e8ecf0; }
table tr:nth-child(even) { background:#fafbfc; }
.check-item { display:flex; align-items:flex-start; gap:8px; padding:8px 0; border-bottom:1px solid #f0f0f0; font-size:14px; }
.check-item .box { min-width:18px; height:18px; border:2px solid #94a3b8; border-radius:3px; margin-top:2px; flex-shrink:0; }
.tag { display:inline-block; padding:2px 10px; border-radius:12px; font-size:12px; font-weight:600; }
.tag-green { background:#d1fae5; color:#065f46; }
.tag-blue { background:#dbeafe; color:#1e40af; }
.tag-yellow { background:#fef3c7; color:#92400e; }
.tag-red { background:#fef2f2; color:#dc2626; }
.footer { text-align:center; padding:20px; font-size:12px; color:#999; border-top:1px solid #e0e0e0; background:#fff; margin-top:24px; }
.alert { background:#fffbeb; border:1px solid #fcd34d; border-radius:8px; padding:12px 16px; margin:12px 0; font-size:13px; color:#92400e; }
"""
    html = f"""<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>投标方案 — {project_name}</title>
<style>{css}</style></head>
<body>
<div class="header">
  <h1>📋 投标方案模板</h1>
  <div class="meta">{company_name or '-'} · {generated_at}</div>
</div>
<div class="container">
  {link_html}

  <div class="plan-section">
    <h2>📋 项目信息</h2>
    <table><tr><th style="width:140px;">项目</th><th>内容</th></tr>
    <tr><td>项目名称</td><td>{project_name}</td></tr>
    <tr><td>招标方</td><td>{buyer}</td></tr>
    <tr><td>预算</td><td>{budget}</td></tr>
    <tr><td>截止时间</td><td>{deadline_text}</td></tr>
    </table>
  </div>

  <div class="plan-section">
    <h2>🔍 资质自查清单</h2>
    {qual_checklist}
  </div>

  <div class="plan-section">
    <h2>📐 技术方案框架</h2>
    {technical_framework}
  </div>

  <div class="plan-section">
    <h2>🏆 业绩对照表</h2>
    {ref_projects}
  </div>

  <div class="plan-section">
    <h2>💰 报价策略</h2>
    {price_strategy}
  </div>

  <div class="plan-section">
    <h2>✅ 投标准备检查清单</h2>
    {submit_checklist}
  </div>

  <div class="alert">⚠️ 此模板为AI生成的投标方案框架，具体内容需根据实际招标文件要求调整，核心数据请人工复核确认。</div>
</div>
<div class="footer"><p>由招投标商机专家 Skill 自动生成 · {generated_at}</p></div>
</body></html>"""
    return html


def main():
    if len(sys.argv) < 2:
        print("Usage: html_generator.py <command> [args]", file=sys.stderr)
        print("Commands: search-result, screening-table, project-plan, bid-scoring, task-list, bid-analysis, project-report, bid-plan", file=sys.stderr)
        sys.exit(1)

    command = sys.argv[1]
    input_data = json.load(sys.stdin)
    output_path = sys.argv[2] if len(sys.argv) > 2 else None

    if command == "search-result":
        html = generate_search_result_html(
            search_topic=input_data.get("search_topic", ""),
            bids=input_data.get("bids", []),
            summary=input_data.get("summary", {}),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            keywords=input_data.get("keywords"),
            exclude_keywords=input_data.get("exclude_keywords"),
            data_begin_date=input_data.get("begin_date", ""),
            data_end_date=input_data.get("end_date", ""),
            scored_bids=input_data.get("scored_bids"),
            filtered_total=input_data.get("filtered_total", 0),
            excluded_count=input_data.get("excluded_count", 0),
            overview_text=input_data.get("overview_text", ""),
            search_meta_tags_html=input_data.get("search_meta_tags_html", ""),
            focus_items=input_data.get("focus_items"),
            city_distribution=input_data.get("city_distribution"),
            category_distribution=input_data.get("category_distribution"),
            category_labels=input_data.get("category_labels"),
        )
    elif command == "screening-table":
        html = generate_screening_table_html(
            search_topic=input_data.get("search_topic", ""),
            bids=input_data.get("bids", []),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            excluded_bids=input_data.get("excluded_bids"),
        )
    elif command == "project-plan":
        html = generate_project_plan_html(
            project_name=input_data.get("project_name", ""),
            sections=input_data.get("sections", {}),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            bid_link=input_data.get("bid_link", ""),
        )
    elif command == "bid-analysis":
        html = generate_bid_analysis_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            hero_label=input_data.get("hero_label", "标讯深度解读"),
            project_subtitle=input_data.get("project_subtitle", ""),
            publish_date=input_data.get("publish_date", ""),
            deadline_date=input_data.get("deadline_date", ""),
            project_region=input_data.get("project_region", ""),
            bid_type=input_data.get("bid_type", ""),
            bid_link=input_data.get("bid_link", ""),
            snapshot_tag_cls=input_data.get("snapshot_tag_cls", "green"),
            snapshot_tag=input_data.get("snapshot_tag", ""),
            info_grid=input_data.get("info_grid", ""),
            qual_tag_cls=input_data.get("qual_tag_cls", "green"),
            qual_tag=input_data.get("qual_tag", ""),
            qual_content=input_data.get("qual_content", ""),
            match_tag_cls=input_data.get("match_tag_cls", "green"),
            match_tag=input_data.get("match_tag", ""),
            match_grid=input_data.get("match_grid", ""),
            value_cards=input_data.get("value_cards", ""),
            deadline_tag_cls=input_data.get("deadline_tag_cls", "yellow"),
            deadline_tag=input_data.get("deadline_tag", ""),
            timeline_items=input_data.get("timeline_items", ""),
            score_tag_cls=input_data.get("score_tag_cls", "green"),
            score_tag=input_data.get("score_tag", ""),
            summary_bg=input_data.get("summary_bg", "#f0fdf4"),
            summary_border=input_data.get("summary_border", "#a7f3d0"),
            summary_title_color=input_data.get("summary_title_color", "#065f46"),
            summary_text_color=input_data.get("summary_text_color", "#047857"),
            summary_title=input_data.get("summary_title", ""),
            summary_desc=input_data.get("summary_desc", ""),
            risk_and_confirm=input_data.get("risk_and_confirm", ""),
            action_tag_cls=input_data.get("action_tag_cls", "yellow"),
            action_tag=input_data.get("action_tag", ""),
            action_items=input_data.get("action_items", ""),
            footer_text=input_data.get("footer_text", ""),
        )
    elif command == "bid-scoring":
        html = generate_bid_scoring_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            total_score=input_data.get("total_score", 0),
            score_label=input_data.get("score_label", ""),
            score_desc=input_data.get("score_desc", ""),
            dimension_rows=input_data.get("dimension_rows", ""),
            risk_badges=input_data.get("risk_badges", ""),
            final_title=input_data.get("final_title", ""),
            final_desc=input_data.get("final_desc", ""),
            reasons=input_data.get("reasons", ""),
            actions=input_data.get("actions", ""),
        )
    elif command == "task-list":
        html = generate_task_list_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            buyer=input_data.get("buyer", ""),
            bid_no=input_data.get("bid_no", ""),
            deadline_text=input_data.get("deadline_text", ""),
            warn_text=input_data.get("warn_text", ""),
            role_sections=input_data.get("role_sections", ""),
            risk_items=input_data.get("risk_items", ""),
            checklist=input_data.get("checklist", ""),
            post_bid_tasks=input_data.get("post_bid_tasks", ""),
        )
    elif command == "project-report":
        html = generate_project_report_html(
            project_name=input_data.get("project_name", ""),
            sections_data=input_data.get("sections_data", []),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            bid_link=input_data.get("bid_link", ""),
        )
    elif command == "bid-plan":
        html = generate_bid_plan_html(
            project_name=input_data.get("project_name", ""),
            company_name=input_data.get("company_name", ""),
            generated_at=input_data.get("generated_at"),
            bid_link=input_data.get("bid_link", ""),
            buyer=input_data.get("buyer", ""),
            budget=input_data.get("budget", ""),
            deadline_text=input_data.get("deadline_text", ""),
            qual_checklist=input_data.get("qual_checklist", ""),
            technical_framework=input_data.get("technical_framework", ""),
            ref_projects=input_data.get("ref_projects", ""),
            price_strategy=input_data.get("price_strategy", ""),
            submit_checklist=input_data.get("submit_checklist", ""),
        )
    else:
        print(f"Unknown command: {command}", file=sys.stderr)
        sys.exit(1)

    if output_path:
        saved = save_html(html, output_path)
        print(f"HTML 已保存: {saved}")
    else:
        sys.stdout.write(html)


if __name__ == "__main__":
    main()
