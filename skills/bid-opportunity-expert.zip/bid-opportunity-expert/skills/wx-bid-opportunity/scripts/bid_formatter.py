#!/usr/bin/env python3
"""
招投标商机专家 - 标讯数据格式化脚本
将 tender-search 返回的原始数据转换为内部标准化结构
"""

import json
import sys
from datetime import datetime
from typing import Dict, List, Optional


def format_single_bid(raw_bid: Dict) -> Dict:
    """将单条原始标讯数据转换为标准化结构（记录尽可能多的字段）

    兼容 tender-search API 的 caller_name / money / money_wan / signup_time / tender_time 等字段名。
    """
    raw_url = raw_bid.get("url", raw_bid.get("source_url", raw_bid.get("bid_url", "")))
    
    # --- 预处理：金额 ---
    # tender-search API 返回 money（元）和 money_wan（万元），优先用 money_wan（已是万元单位）
    budget_val = raw_bid.get("money_wan")  # API 直接返回的万元值
    if budget_val is None:
        budget_val = raw_bid.get("money")  # 元单位，会走 _parse_amount
    if budget_val is None:
        budget_val = raw_bid.get("budget") or raw_bid.get("budget_amount")
    
    # --- 预处理：招标方 ---
    buyer_name = (
        raw_bid.get("caller_name")               # tender-search API 实际字段
        or raw_bid.get("buyer") or raw_bid.get("purchaser") or ""
    )
    buyer_contact = (
        raw_bid.get("caller_contact")
        or raw_bid.get("buyer_contact") or raw_bid.get("contact_person") or ""
    )
    buyer_phone = (
        raw_bid.get("caller_phone")
        or raw_bid.get("buyer_phone") or raw_bid.get("contact_phone") or ""
    )
    
    # --- 预处理：代理 ---
    agency_name = (
        raw_bid.get("agency_name")
        or raw_bid.get("agency") or raw_bid.get("agent_org") or ""
    )
    
    # --- 预处理：时间 ---
    pub_date = (
        raw_bid.get("pub_time")                  # tender-search API 实际字段
        or raw_bid.get("publish_date") or raw_bid.get("publish_time") or ""
    )
    deadline_val = (
        raw_bid.get("signup_time")               # tender-search API 报名时间
        or raw_bid.get("tender_time")            # 开标时间作为备选
        or raw_bid.get("deadline") or raw_bid.get("bid_end_time") or raw_bid.get("end_date") or ""
    )
    open_time = (
        raw_bid.get("tender_time")               # tender-search API 开标时间
        or raw_bid.get("bid_open_time") or raw_bid.get("open_time") or ""
    )
    
    # --- 预处理：区域 ---
    region_val = (
        raw_bid.get("province")
        or raw_bid.get("region") or ""
    )
    city_val = (
        raw_bid.get("city")
        or raw_bid.get("county") or ""
    )
    
    return {
        # === 基础标识 ===
        "source": "tender-search",
        "source_id": raw_bid.get("uniq_key", raw_bid.get("id", "")),
        "notice_title": raw_bid.get("title", raw_bid.get("notice_title", "")).strip(),
        "notice_type": _map_notice_type(raw_bid),
        "notice_type_id": raw_bid.get("bid_process", raw_bid.get("notice_stage", 0)),
        "bid_process_desc": _map_bid_process(raw_bid.get("bid_process", "")),

        # === 直达查看链接 ===
        "direct_link": raw_url,
        "raw_url": raw_url,
        "source_url": raw_bid.get("source_url", raw_bid.get("bid_url", "")),

        # === 招标方信息 ===
        "buyer": buyer_name.strip(),
        "buyer_contact": buyer_contact.strip(),
        "buyer_phone": buyer_phone.strip(),
        "buyer_address": raw_bid.get("buyer_address", raw_bid.get("address", "")).strip(),
        "agency": agency_name.strip(),
        "agency_contact": raw_bid.get("agency_contact", raw_bid.get("agent_contact", "")).strip(),
        "agency_phone": raw_bid.get("agency_phone", raw_bid.get("agent_phone", "")).strip(),

        # === 区域与时间 ===
        "region": region_val.strip(),
        "city": city_val.strip(),
        "district": raw_bid.get("district", raw_bid.get("county", "")).strip(),
        "publish_date": pub_date,
        "deadline": deadline_val,
        "bid_open_time": open_time,

        # === 金额信息 ===
        "budget_amount": _parse_amount(budget_val),
        "bid_amount": _parse_amount(raw_bid.get("bid_amount", raw_bid.get("win_price"))),
        "budget_original": str(budget_val) if budget_val is not None else "",
        "bid_amount_original": raw_bid.get("bid_amount", raw_bid.get("win_price", "")),

        # === 中标信息 ===
        "winner": raw_bid.get("winner", raw_bid.get("win_company", "")).strip(),
        "winner_contact": raw_bid.get("winner_contact", "").strip(),
        "winner_phone": raw_bid.get("winner_phone", "").strip(),

        # === 项目分类与关键词 ===
        "keywords": raw_bid.get("keywords", []),
        "bid_type": raw_bid.get("bid_type", ""),
        "industry_category": raw_bid.get("industry_category", raw_bid.get("category", "")),
        "project_classification": raw_bid.get("project_classification", raw_bid.get("classification", "")),

        # === 原文内容 ===
        "raw_content": raw_bid.get("content", raw_bid.get("body", "")),
        "summary": raw_bid.get("summary", raw_bid.get("description", ""))[:500],
        "content_snippet": (raw_bid.get("content", raw_bid.get("body", "")) or "")[:300],

        # === 元数据 ===
        "bid_process": raw_bid.get("bid_process", raw_bid.get("notice_stage", 0)),
        "formatted_at": datetime.now().isoformat()
    }


def _map_bid_process(bid_process) -> str:
    """映射 bid_process 数字到中文描述"""
    mapping = {
        1: "采购意向",
        2: "预招标",
        4: "招标",
        5: "变更公告",
        6: "中标候选人公示",
        7: "中标结果",
        8: "合同公告",
        9: "验收公告",
        10: "废标公告"
    }
    if isinstance(bid_process, str):
        # 已经是对外显示文本，直接返回
        return bid_process
    return mapping.get(bid_process, str(bid_process))


def _map_notice_type(raw: Dict) -> str:
    """映射公告类型"""
    bid_process = raw.get("bid_process", raw.get("notice_stage", 0))
    mapping = {
        1: "采购意向",
        2: "预招标",
        4: "招标公告",
        5: "变更公告",
        6: "中标候选人公示",
        7: "中标结果",
        8: "合同公告",
        9: "验收公告",
        10: "废标公告"
    }
    return mapping.get(bid_process, raw.get("bid_type", raw.get("notice_type", "未知")))


def _parse_amount(value) -> Optional[float]:
    """解析金额，返回万元为单位的数值"""
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return round(float(value), 2)
    if isinstance(value, str):
        # 尝试解析 "XX万元" 格式
        value = value.replace(",", "").replace("，", "").strip()
        for unit, multiplier in [("亿元", 10000), ("万元", 1), ("元", 0.0001)]:
            if unit in value:
                try:
                    return round(float(value.replace(unit, "")) * multiplier, 2)
                except ValueError:
                    pass
        try:
            return round(float(value), 2)
        except ValueError:
            pass
    return None


def format_bid_list(raw_bids: List[Dict]) -> List[Dict]:
    """批量格式化标讯数据"""
    return [format_single_bid(bid) for bid in raw_bids]


def generate_search_summary(formatted_bids: List[Dict]) -> Dict:
    """生成搜索结果摘要统计（含直达链接统计）"""
    total = len(formatted_bids)
    if total == 0:
        return {"total": 0}
    
    types = {}
    regions = {}
    budgets = [b["budget_amount"] for b in formatted_bids if b["budget_amount"]]
    has_link = sum(1 for b in formatted_bids if b.get("direct_link"))
    has_deadline = sum(1 for b in formatted_bids if b.get("deadline"))
    
    for bid in formatted_bids:
        t = bid["notice_type"]
        types[t] = types.get(t, 0) + 1
        
        r = bid["region"]
        regions[r] = regions.get(r, 0) + 1
    
    return {
        "total": total,
        "by_type": types,
        "by_region": regions,
        "has_link_count": has_link,
        "has_deadline_count": has_deadline,
        "budget_range": {
            "min": min(budgets) if budgets else None,
            "max": max(budgets) if budgets else None,
            "avg": round(sum(budgets) / len(budgets), 2) if budgets else None
        },
        "earliest_deadline": min(
            (b["deadline"] for b in formatted_bids if b["deadline"]),
            default=None
        )
    }


def main():
    if len(sys.argv) > 1:
        with open(sys.argv[1]) as f:
            data = json.load(f)
    else:
        data = json.load(sys.stdin)
    
    # Handle both single bid and list
    if isinstance(data, dict):
        if "data" in data:
            # tender-search response wrapper
            raw_bids = data.get("data", [])
            if isinstance(raw_bids, dict):
                raw_bids = raw_bids.get("items", raw_bids.get("list", []))
        else:
            raw_bids = [data]
    elif isinstance(data, list):
        raw_bids = data
    else:
        raw_bids = []
    
    formatted = format_bid_list(raw_bids)
    summary = generate_search_summary(formatted)
    
    output = {
        "bids": formatted,
        "summary": summary,
        "formatted_at": datetime.now().isoformat()
    }
    
    json.dump(output, sys.stdout, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    main()
