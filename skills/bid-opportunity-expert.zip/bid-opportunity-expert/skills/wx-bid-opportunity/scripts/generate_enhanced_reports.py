#!/usr/bin/env python3
"""
标叔 - 增强版报告生成器 v2.0
从API数据生成丰富统计HTML + PDF
"""

import json, os, subprocess
from datetime import datetime
from collections import Counter

# ======== 配置 ========
BASE_DIR = '/Users/zhoupeng/WorkBuddy/Claw/2026-07-06-22-51-29/招投标商机'
PDFKIT_PY = '/Users/zhoupeng/.workbuddy/plugins/marketplaces/cb_teams_marketplace/plugins/document-skills/skills/pdfkit-py/scripts/venv/bin/python3'
PDFKIT_PY_SCRIPT = '/Users/zhoupeng/.workbuddy/plugins/marketplaces/cb_teams_marketplace/plugins/document-skills/skills/pdfkit-py/scripts/pdfkit.py'

# ======== 工具函数 ========
def load_items(filepath):
    with open(filepath) as f:
        data = json.load(f)
    return data['data']['items'], data['data']['total']

def format_money(val):
    if val and val > 0:
        return f'{val}万元'
    return '未公开'

def deadline_days(deadline_str):
    """计算距离截止还有多少天"""
    if not deadline_str:
        return None
    try:
        dt = datetime.strptime(deadline_str[:10], '%Y-%m-%d')
        return (dt - datetime.now()).days
    except:
        return None

def money_range(val):
    if not val or val <= 0:
        return '未公开'
    if val < 50: return '50万以下'
    if val < 200: return '50-200万'
    if val < 500: return '200-500万'
    if val < 1000: return '500-1000万'
    return '1000万以上'

# ======== 标讯搜索报告 ========
def generate_search_report(title, subtitle, items, total_all, file_prefix):
    """生成增强版标讯搜索报告 HTML + PDF"""
    
    # ---------- 统计计算 ----------
    budgets = [(i.get('money_wan',0) or 0) for i in items]
    methods = [i.get('bid_method','未分类') or '未分类' for i in items]
    buyer_types = [i.get('caller_type','未分类') or '未分类' for i in items]
    pub_dates = [i.get('pub_time','') for i in items if i.get('pub_time')]
    
    # 截止日期紧迫度
    urgent_3 = sum(1 for i in items if (d:=deadline_days(i.get('signup_time','') or i.get('tender_time',''))) is not None and 0 <= d <= 3)
    urgent_7 = sum(1 for i in items if (d:=deadline_days(i.get('signup_time','') or i.get('tender_time',''))) is not None and 0 <= d <= 7)
    urgent_14 = sum(1 for i in items if (d:=deadline_days(i.get('signup_time','') or i.get('tender_time',''))) is not None and 0 <= d <= 14)
    
    # 预算区间
    budget_bins = Counter(money_range(b) for b in budgets)
    # 招标方式
    method_dist = Counter(methods)
    # 买方行业
    buyer_dist = Counter(buyer_types)
    # 标的物
    sm_all = []
    for i in items:
        for s in (i.get('sm_names') or []):
            sm_all.append(s.strip())
    sm_top = Counter(sm_all).most_common(15)
    # 发布日期趋势
    date_trend = Counter(pub_dates)
    date_trend_sorted = sorted(date_trend.items())
    
    # 省份
    provinces = set(i.get('province','') for i in items if i.get('province'))
    
    # 有附件
    has_attach = sum(1 for i in items if i.get('exists_bid_file'))
    
    total_count = len(items)
    now_str = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    date_str = datetime.now().strftime('%Y%m%d')
    
    # 预算区间柱状图数据
    budget_order = ['50万以下','50-200万','200-500万','500-1000万','1000万以上','未公开']
    budget_bar_html = ''
    max_budget_count = max((budget_bins.get(k,0) for k in budget_order), default=1)
    for k in budget_order:
        v = budget_bins.get(k,0)
        pct = v/max_budget_count*100 if max_budget_count else 0
        color = '#27ae60' if k in ['50-200万','200-500万'] else '#f39c12' if k in ['500-1000万'] else '#e74c3c' if k=='1000万以上' else '#95a5a6'
        budget_bar_html += f'''
        <div class="chart-row">
          <span class="chart-label">{k}</span>
          <div class="chart-bar-wrap">
            <div class="chart-bar" style="width:{pct}%;background:{color}"></div>
          </div>
          <span class="chart-val">{v}条</span>
        </div>'''
    
    # 招标方式环形图 - 用CSS画
    total_m = max(sum(method_dist.values()), 1)
    method_donut_segments = ''
    method_legend = ''
    colors_m = ['#3498db','#2ecc71','#e67e22','#9b59b6','#95a5a6']
    for j, (k,v) in enumerate(method_dist.most_common()):
        pct = v/total_m*100
        method_donut_segments += f'<div class="seg" style="background:{colors_m[j%len(colors_m)]};width:{pct}%"></div>'
        method_legend += f'<span class="legend-item"><span class="dot" style="background:{colors_m[j%len(colors_m)]}"></span>{k}({v})</span>'
    
    # 买方行业
    buyer_bar_html = ''
    max_buyer = max(buyer_dist.values()) if buyer_dist else 1
    for k,v in buyer_dist.most_common(6):
        pct = v/max_buyer*100
        buyer_bar_html += f'''
        <div class="chart-row">
          <span class="chart-label">{k}</span>
          <div class="chart-bar-wrap">
            <div class="chart-bar" style="width:{pct}%;background:#8e44ad"></div>
          </div>
          <span class="chart-val">{v}条</span>
        </div>'''
    
    # 发行趋势（按天）
    trend_html = ''
    max_trend = max((v for _,v in date_trend_sorted), default=1)
    for d, v in date_trend_sorted:
        pct = v/max_trend*100
        trend_html += f'<div class="trend-bar" style="height:{pct*2}px;background:#1abc9c" title="{d}:{v}条">{v}</div>'
    
    # 标的物TOP
    sm_html = ''
    for name, cnt in sm_top:
        sm_html += f'<span class="tag">{name}({cnt})</span>'
    
    # ===== 标讯卡片 =====
    cards_html = ''
    for idx, item in enumerate(items):
        title = item.get('title','')
        caller = item.get('caller_name','')
        province = item.get('province','') or ''
        city = item.get('city','') or ''
        money = item.get('money_wan',0) or 0
        pub = item.get('pub_time','')
        deadline_raw = item.get('signup_time','') or item.get('tender_time','') or ''
        deadline_str = deadline_raw[:10] if deadline_raw else '未公布'
        url = item.get('url','')
        bid_method = item.get('bid_method','')
        
        # 标签
        tags = []
        days = deadline_days(deadline_raw)
        if days is not None:
            if days <= 3: tags.append('<span class="tag-danger">🔥 急件</span>')
            elif days <= 7: tags.append('<span class="tag-warning">⏰ 即将截止</span>')
        if money >= 500: tags.append('<span class="tag-gold">💎 高价值</span>')
        if item.get('exists_bid_file'): tags.append('<span class="tag-info">📎 有附件</span>')
        tags_str = ' '.join(tags) if tags else ''
        
        deadline_display = f'<span class="deadline-{"danger" if days is not None and days<=3 else "warning" if days is not None and days<=7 else ""}">{deadline_str}'
        if days is not None and days >= 0:
            deadline_display += f' (剩余{days}天)'
        elif days is not None and days < 0:
            deadline_display += f' (已过期{-days}天)'
        deadline_display += '</span>'
        
        # 紧迫度色条
        urgency_color = '#e74c3c' if days is not None and days <= 3 else '#f39c12' if days is not None and days <= 7 else '#3498db'
        
        link = f'<a href="{url}" target="_blank" class="bid-link">查看原文 →</a>' if url else ''
        
        cards_html += f'''
        <div class="bid-item" style="border-left:4px solid {urgency_color};">
          <div class="bid-header">
            <span class="bid-num">{idx+1}</span>
            <h3 class="bid-title">{title}</h3>
            {tags_str}
          </div>
          <div class="bid-meta">
            <div class="meta-row">
              <span class="meta-icon">🏢</span> {caller}
              <span class="meta-icon">📍</span> {province}/{city}
              <span class="meta-icon">💰</span> {format_money(money)}
            </div>
            <div class="meta-row">
              <span class="meta-icon">📅</span> 发布: {pub}
              <span class="meta-icon">⏰</span> 截止: {deadline_display}
              <span class="meta-icon">📋</span> {bid_method}
              {link}
            </div>
          </div>
        </div>'''
    
    # ===== 完整HTML =====
    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>{title}</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;background:#f0f2f5;color:#333;padding:24px}}
.container{{max-width:1280px;margin:0 auto}}
.header{{background:linear-gradient(135deg,#1a73e8,#4a9eff);border-radius:16px;padding:32px 40px;margin-bottom:24px;color:#fff}}
.header h1{{font-size:28px;margin-bottom:6px}}
.header p{{font-size:14px;opacity:.85;line-height:1.6}}

/* 统计卡片区 */
.stats-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin-bottom:24px}}
.stat-card{{background:#fff;border-radius:12px;padding:16px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06)}}
.stat-card .num{{font-size:32px;font-weight:700;color:#1a73e8;line-height:1.2}}
.stat-card .label{{font-size:13px;color:#888;margin-top:4px}}
.stat-card.danger .num{{color:#e74c3c}}
.stat-card.warning .num{{color:#f39c12}}
.stat-card.success .num{{color:#27ae60}}
.stat-card.purple .num{{color:#8e44ad}}

/* 图表区 */
.charts-grid{{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-bottom:24px}}
@media(max-width:800px){{.charts-grid{{grid-template-columns:1fr}}}}
.chart-card{{background:#fff;border-radius:12px;padding:20px;box-shadow:0 2px 8px rgba(0,0,0,.06)}}
.chart-card h3{{font-size:15px;margin-bottom:14px;color:#444;padding-bottom:8px;border-bottom:2px solid #f0f0f0}}
.chart-row{{display:flex;align-items:center;margin-bottom:6px;gap:8px}}
.chart-label{{width:90px;font-size:12px;color:#666;text-align:right}}
.chart-bar-wrap{{flex:1;height:20px;background:#f0f0f0;border-radius:10px;overflow:hidden}}
.chart-bar{{height:100%;border-radius:10px;transition:width .3s;min-width:4px}}
.chart-val{{width:40px;font-size:12px;color:#666}}

/* 环形图 */
.donut-wrap{{display:flex;align-items:center;gap:16px;margin-top:8px}}
.donut-bar{{flex:1;height:24px;border-radius:12px;display:flex;overflow:hidden}}
.donut-bar .seg{{transition:width .3s}}
.legend-wrap{{display:flex;flex-wrap:wrap;gap:8px;margin-top:10px}}
.legend-item{{font-size:12px;color:#666;display:flex;align-items:center;gap:4px}}
.dot{{width:10px;height:10px;border-radius:50%;display:inline-block}}

/* 趋势图 */
.trend-wrap{{display:flex;align-items:flex-end;gap:4px;height:120px;padding:8px 0;overflow-x:auto}}
.trend-bar{{flex:1;min-width:20px;border-radius:4px 4px 0 0;display:flex;align-items:flex-end;justify-content:center;font-size:10px;color:#888;padding-top:4px}}

/* 标的物标签 */
.tag-wrap{{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px}}
.tag{{display:inline-block;padding:3px 10px;background:#eef2ff;color:#4a6cf7;border-radius:12px;font-size:12px}}
.tag-danger{{display:inline-block;padding:2px 8px;background:#fce4e4;color:#e74c3c;border-radius:4px;font-size:11px;font-weight:600}}
.tag-warning{{display:inline-block;padding:2px 8px;background:#fef3cd;color:#f39c12;border-radius:4px;font-size:11px;font-weight:600}}
.tag-gold{{display:inline-block;padding:2px 8px;background:#fef9e7;color:#d4a017;border-radius:4px;font-size:11px;font-weight:600}}
.tag-info{{display:inline-block;padding:2px 8px;background:#e8f4fd;color:#3498db;border-radius:4px;font-size:11px;font-weight:600}}

/* 标讯列表 */
.bid-list{{display:flex;flex-direction:column;gap:10px}}
.bid-item{{background:#fff;border-radius:12px;padding:16px 20px;box-shadow:0 2px 8px rgba(0,0,0,.06);transition:transform .15s}}
.bid-item:hover{{transform:translateX(4px)}}
.bid-header{{display:flex;align-items:center;gap:10px;margin-bottom:8px}}
.bid-num{{width:28px;height:28px;background:#1a73e8;color:#fff;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;flex-shrink:0}}
.bid-title{{flex:1;font-size:15px;color:#222;font-weight:600}}
.bid-meta{{font-size:13px;color:#666;line-height:1.8;margin-left:38px}}
.meta-row{{margin-bottom:2px}}
.meta-icon{{margin-right:2px}}
.deadline-danger{{color:#e74c3c;font-weight:600}}
.deadline-warning{{color:#f39c12;font-weight:600}}
.bid-link{{color:#1a73e8;text-decoration:none;font-weight:600;margin-left:8px}}
.bid-link:hover{{text-decoration:underline}}

.footer{{text-align:center;padding:20px;font-size:12px;color:#999;margin-top:24px}}
</style>
</head>
<body>
<div class="container">

<div class="header">
  <h1>{title}</h1>
  <p>{subtitle}<br>生成时间：{now_str} | 共 <strong>{total_count}</strong> 条标讯 (平台总记录: {total_all}条)</p>
</div>

<!-- 统计卡片 -->
<div class="stats-grid">
  <div class="stat-card"><div class="num">{total_count}</div><div class="label">📋 去重标讯</div></div>
  <div class="stat-card success"><div class="num">{sum(1 for b in budgets if b>=100)}</div><div class="label">💰 百万级以上</div></div>
  <div class="stat-card purple"><div class="num">{len(provinces)}</div><div class="label">🗺️ 覆盖省份</div></div>
  <div class="stat-card"><div class="num">{sum(1 for i in items if i.get('signup_time','') or i.get('tender_time',''))}</div><div class="label">⏰ 有截止时间</div></div>
  <div class="stat-card danger"><div class="num">{urgent_3}</div><div class="label">🔴 3天内急件</div></div>
  <div class="stat-card warning"><div class="num">{urgent_7}</div><div class="label">🟡 7天内到期</div></div>
  <div class="stat-card"><div class="num">{has_attach}</div><div class="label">📎 有附件</div></div>
</div>

<!-- 图表区 -->
<div class="charts-grid">
  <div class="chart-card">
    <h3>💰 预算区间分布</h3>
    {budget_bar_html}
  </div>
  <div class="chart-card">
    <h3>📋 招标方式分布</h3>
    <div class="donut-bar">{method_donut_segments}</div>
    <div class="legend-wrap">{method_legend}</div>
  </div>
  <div class="chart-card">
    <h3>🏢 买方行业分析</h3>
    {buyer_bar_html}
  </div>
  <div class="chart-card">
    <h3>📈 每日发布趋势</h3>
    <div class="trend-wrap">{trend_html}</div>
  </div>
  <div class="chart-card" style="grid-column:1/-1">
    <h3>🏷️ 采购品类TOP</h3>
    <div class="tag-wrap">{sm_html}</div>
  </div>
</div>

<!-- 标讯列表 -->
<h2 style="font-size:16px;margin-bottom:12px;color:#444">📋 标讯清单（紧迫度排序）</h2>
<div class="bid-list">
{cards_html}
</div>

<div class="footer">数据来源：知了标讯 | 生成时间：{now_str} | ⚠️ 仅供参考，投标决策需人工确认</div>
</div>
</body>
</html>'''
    
    # 保存HTML
    html_path = f'{BASE_DIR}/标讯搜索记录/{file_prefix}.html'
    with open(html_path, 'w', encoding='utf-8') as f:
        f.write(html)
    print(f'✅ HTML: {os.path.basename(html_path)}')
    
    # 保存MD（简洁版）
    md = f'''# {title}

> {subtitle}
> 生成时间：{now_str}

---

## 统计概览
- **总条数**: {total_count} | **百万级以上**: {sum(1 for b in budgets if b>=100)} | **覆盖省份**: {len(provinces)}
- **🔴3天内急件**: {urgent_3} | **🟡7天内到期**: {urgent_7} | **📎有附件**: {has_attach}

## 预算区间
'''
    for k in ['50万以下','50-200万','200-500万','500-1000万','1000万以上','未公开']:
        v = budget_bins.get(k,0)
        if v: md += f'- {k}: {v}条\n'
    md += '\n## 标讯清单\n\n'
    for idx, item in enumerate(items):
        title_t = item.get('title','')
        caller = item.get('caller_name','')
        money = item.get('money_wan',0) or 0
        dl = (item.get('signup_time','') or item.get('tender_time','') or '')[:10]
        url = item.get('url','')
        link = f'[查看原文]({url})' if url else ''
        md += f'### [{idx+1}] {title_t}\n'
        md += f'- 招标方: {caller} | 预算: {format_money(money)} | 截止: {dl or "未公布"} | {link}\n\n'
    md += '\n---\n> ⚠️ AI整理，仅供参考。'
    md_path = f'{BASE_DIR}/标讯搜索记录/{file_prefix}.md'
    with open(md_path, 'w', encoding='utf-8') as f:
        f.write(md)
    print(f'✅ MD: {os.path.basename(md_path)}')
    
    return html_path


# ======== PDF 转换 ========
def generate_pdf(html_path):
    """用 pdfkit-py 将 HTML 转为 PDF"""
    pdf_path = html_path.replace('.html', '.pdf')
    cmd = [PDFKIT_PY_SCRIPT, 'convert', '--input', html_path, '--output', pdf_path, '--to_format', 'pdf']
    # Use venv python
    full_cmd = [PDFKIT_PY, PDFKIT_PY_SCRIPT, 'convert', '--input', html_path, '--output', pdf_path, '--to_format', 'pdf']
    try:
        r = subprocess.run(full_cmd, capture_output=True, text=True, timeout=60)
        if os.path.exists(pdf_path):
            print(f'✅ PDF: {os.path.basename(pdf_path)}')
            return pdf_path
        else:
            print(f'⚠️ PDF生成失败: {r.stderr[:200]}')
            return None
    except Exception as e:
        print(f'⚠️ PDF异常: {e}')
        return None


# ======== 主流程 ========
if __name__ == '__main__':
    print('='*60)
    print('🏙️ 标叔 v2.0 增强报告生成器')
    print('='*60)
    
    # ---- 报告1: 智慧城市解决方案(粤) ----
    print('\n--- 报告1: 智慧城市解决方案(广东) ---')
    items1, total1 = load_items('/tmp/bid_result.json')
    generate_search_report(
        title='🏙️ 智慧城市解决方案 · 广东区域标讯',
        subtitle='搜索范围：广东省 | 关键词：智慧城市 | 近30天',
        items=items1, total_all=total1,
        file_prefix='20260706-01-智慧城市(粤)'
    )
    
    # ---- 报告2: 智慧城市AI全国扩搜 ----
    print('\n--- 报告2: 智慧城市AI全国扩搜 ---')
    # 合并去重
    all_items = []
    seen = set()
    for fpath in ['/tmp/bid_brain.json', '/tmp/bid_ai_city.json', '/tmp/bid_ai_platform.json']:
        with open(fpath) as f:
            data = json.load(f)
        for item in data['data']['items']:
            bid_id = item.get('bid_id','')
            if bid_id not in seen:
                seen.add(bid_id)
                all_items.append(item)
    
    total_merged = sum(json.load(open(f))['data']['total'] for f in ['/tmp/bid_brain.json','/tmp/bid_ai_city.json','/tmp/bid_ai_platform.json'])
    
    generate_search_report(
        title='🏙️ 智慧城市+AI · 全国扩搜结果',
        subtitle='搜索范围：全国 | 关键词组合：城市大脑 / 智慧城市+人工智能 / AI平台+智能分析',
        items=all_items, total_all=total_merged,
        file_prefix='20260706-02-智慧城市AI全国扩搜'
    )
    
    # ---- 报告3: 提升商机筛选表 ----
    print('\n--- 报告3: allintoai商机筛选表(增强版) ---')
    
    # 筛选数据来源于合并的 all_items
    # 按评分排序的18个项目
    from collections import OrderedDict
    projects = OrderedDict([
        ('福田区数字化转型运维(892万)', {'score':100,'lvl':'🔥','reason':'AI/数字化匹配, 甲方对口, 广东本地','urgency':'8天','buyer':'福田区智慧城市建设中心'}),
        ('雷州市新型智慧城市一期(987万)', {'score':90,'lvl':'🔥','reason':'智慧城市匹配, 甲方对口','urgency':'采购意向','buyer':'雷州市政数局'}),
        ('裕安区城市大脑优化(120万)', {'score':85,'lvl':'🔥','reason':'城市大脑匹配, 甲方对口','urgency':'已截止','buyer':'裕安区数据资源局'}),
        ('鲁南AI协同数智基地(6124万)', {'score':75,'lvl':'⭐','reason':'AI匹配, 超高价值','urgency':'7月11日','buyer':'临沂沂蒙云谷'}),
        ('绍兴智慧城市大脑(630万)', {'score':75,'lvl':'⭐','reason':'城市大脑匹配','urgency':'7月21日','buyer':'绍兴袍江经开投'}),
        ('南昌城市大脑展示中心(77万)', {'score':75,'lvl':'⭐','reason':'城市大脑匹配, 甲方对口','urgency':'7月13日','buyer':'南昌市政数局'}),
        ('HG信息化(深智城3.79亿)', {'score':70,'lvl':'⭐','reason':'甲方对口(深智城)','urgency':'7月11日','buyer':'深智城集团'}),
        ('天翼物联多模态AI(375万)', {'score':70,'lvl':'⭐','reason':'AI匹配, 广东','urgency':'7月10日⏰','buyer':'天翼物联科技'}),
        ('深汕实景数据采集(98万)', {'score':70,'lvl':'⭐','reason':'甲方对口','urgency':'采购意向','buyer':'深汕智慧城市中心'}),
        ('武汉城市大脑APP(584万)', {'score':65,'lvl':'👀','reason':'城市大脑匹配','urgency':'未公布','buyer':'湖北数字产业集团'}),
        ('新余市城市大脑(180万)', {'score':65,'lvl':'👀','reason':'城市大脑匹配','urgency':'已截止','buyer':'新余数字产业'}),
        ('广西AI产业学院(991万)', {'score':65,'lvl':'👀','reason':'AI匹配','urgency':'7月26日','buyer':'广西现代职院'}),
        ('海关人车视频分析(271万)', {'score':60,'lvl':'👀','reason':'AI视频分析匹配','urgency':'7月13日','buyer':'深智城集团'}),
    ])
    
    high_c = sum(1 for p in projects.values() if p['score']>=80)
    mid_c = sum(1 for p in projects.values() if 60<=p['score']<80)
    
    items_html = ''
    for name, info in projects.items():
        score = info['score']
        lvl = info['lvl']
        cls = 'high' if score>=80 else 'mid' if score>=60 else 'low'
        bar_pct = score
        bar_color = '#e74c3c' if score>=85 else '#f39c12' if score>=70 else '#3498db' if score>=60 else '#95a5a6'
        
        items_html += f'''
        <div class="proj-item {cls}">
          <div class="proj-top">
            <span class="proj-lvl {cls}">{lvl} {["强烈推荐","建议跟进","需核实"][0 if score>=80 else 1 if score>=60 else 2]}</span>
            <span class="proj-name">{name}</span>
            <span class="proj-score" style="color:{bar_color}">{score}分</span>
          </div>
          <div class="proj-bar-wrap"><div class="proj-bar" style="width:{bar_pct}%;background:{bar_color}"></div></div>
          <div class="proj-info">
            <span>🏢 {info['buyer']}</span>
            <span>⏰ {info['urgency']}</span>
            <span>📌 {info['reason']}</span>
          </div>
        </div>'''
    
    score_dims = [
        ('业务匹配度',65,'#3498db'), ('资质匹配度',55,'#2ecc71'), ('业绩匹配度',45,'#9b59b6'),
        ('商业价值',85,'#f39c12'), ('中标可能性',50,'#1abc9c'), ('交付可行性',55,'#e67e22'), ('风险可控性',70,'#27ae60')
    ]
    score_bar = ''
    for dn, ds, dc in score_dims:
        score_bar += f'''
        <div class="chart-row">
          <span class="chart-label" style="width:80px">{dn}</span>
          <div class="chart-bar-wrap"><div class="chart-bar" style="width:{ds}%;background:{dc}"></div></div>
          <span class="chart-val">{ds}分</span>
        </div>'''
    
    now2 = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    screen_html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0">
<title>allintoai 智慧城市AI商机筛选表</title>
<style>
*{{margin:0;padding:0;box-sizing:border-box}}
body{{font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;background:#f0f2f5;color:#333;padding:24px}}
.container{{max-width:1100px;margin:0 auto}}
.header{{background:linear-gradient(135deg,#e67e22,#f39c12);border-radius:16px;padding:28px 36px;margin-bottom:24px;color:#fff}}
.header h1{{font-size:26px;margin-bottom:4px}}
.header p{{font-size:14px;opacity:.85}}

.stats-grid{{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px;margin-bottom:24px}}
.stat-card{{background:#fff;border-radius:12px;padding:16px;text-align:center;box-shadow:0 2px 8px rgba(0,0,0,.06)}}
.stat-card .num{{font-size:30px;font-weight:700;line-height:1.2}}
.stat-card .label{{font-size:13px;color:#888;margin-top:4px}}
.stat-card.danger .num{{color:#e74c3c}}
.stat-card.warning .num{{color:#f39c12}}

.chart-card{{background:#fff;border-radius:12px;padding:20px;margin-bottom:16px;box-shadow:0 2px 8px rgba(0,0,0,.06)}}
.chart-card h3{{font-size:15px;margin-bottom:14px;color:#444;padding-bottom:8px;border-bottom:2px solid #f0f0f0}}
.chart-row{{display:flex;align-items:center;margin-bottom:8px;gap:8px}}
.chart-label{{width:80px;font-size:12px;color:#666;text-align:right}}
.chart-bar-wrap{{flex:1;height:22px;background:#f0f0f0;border-radius:11px;overflow:hidden}}
.chart-bar{{height:100%;border-radius:11px;min-width:4px;transition:width .3s}}
.chart-val{{width:40px;font-size:12px;color:#666}}

.proj-item{{background:#fff;border-radius:12px;padding:14px 18px;margin-bottom:10px;box-shadow:0 2px 8px rgba(0,0,0,.06);border-left:4px solid #ddd}}
.proj-item.high{{border-left-color:#e74c3c}}
.proj-item.mid{{border-left-color:#f39c12}}
.proj-item.low{{border-left-color:#95a5a6}}
.proj-top{{display:flex;align-items:center;gap:10px;margin-bottom:6px}}
.proj-lvl{{padding:2px 8px;border-radius:4px;font-size:11px;font-weight:700;color:#fff;flex-shrink:0}}
.proj-lvl.high{{background:#e74c3c}}
.proj-lvl.mid{{background:#f39c12}}
.proj-lvl.low{{background:#95a5a6}}
.proj-name{{flex:1;font-size:14px;font-weight:600;color:#222}}
.proj-score{{font-size:18px;font-weight:700}}
.proj-bar-wrap{{height:6px;background:#f0f0f0;border-radius:3px;overflow:hidden;margin-bottom:6px}}
.proj-bar{{height:100%;border-radius:3px;transition:width .3s}}
.proj-info{{font-size:12px;color:#888;display:flex;flex-wrap:wrap;gap:12px}}

.footer{{text-align:center;padding:20px;font-size:12px;color:#999;margin-top:24px}}
</style></head><body>
<div class="container">
<div class="header">
  <h1>🏙️ allintoai 智慧城市AI商机筛选表</h1>
  <p>分析公司：allintoai（智慧城市AI解决方案） | 生成时间：{now2} | 共分析 {len(all_items)} 条标讯</p>
</div>

<div class="stats-grid">
  <div class="stat-card danger"><div class="num">{high_c}</div><div class="label">🔥 强烈推荐</div></div>
  <div class="stat-card warning"><div class="num">{mid_c}</div><div class="label">⭐ 建议跟进</div></div>
  <div class="stat-card"><div class="num">{sum(1 for p in projects.values() if p['score']<60)}</div><div class="label">👀 需核实</div></div>
  <div class="stat-card"><div class="num">{sum(1 for p in projects.values())}</div><div class="label">📋 筛选项目总计</div></div>
</div>

<div class="chart-card">
  <h3>📊 7维度评分模型（基于福田区项目计算）</h3>
  {score_bar}
  <div class="proj-info" style="margin-top:10px;border-top:1px solid #f0f0f0;padding-top:8px">
    <span>总分：61分 | 🟡 需进一步核实</span>
    <span>评分范围：0-100 | 权重：业务20%+资质20%+业绩15%+商业15%+中标10%+交付10%+风险10%</span>
  </div>
</div>

<div class="chart-card">
  <h3>📋 商机清单（按评分降序）</h3>
  {items_html}
</div>

<div class="footer">数据来源：知了标讯 | 评分模型：7维度加权 | ⚠️ 自动匹配仅供参考，最终决策需人工确认</div>
</div></body></html>'''
    
    date_str2 = datetime.now().strftime('%Y%m%d')
    date_str_for_screen = datetime.now().strftime('%Y%m%d')
    screen_html_path = f'{BASE_DIR}/商机筛选/{date_str_for_screen}-01-allintoai商机筛选表.html'
    with open(screen_html_path, 'w', encoding='utf-8') as f:
        f.write(screen_html)
    print(f'✅ 商机筛选 HTML: {os.path.basename(screen_html_path)}')
    
    # 筛选表MD
    screen_md = f'''# allintoai 智慧城市AI商机筛选表

> 生成时间：{now2}
> 分析公司：allintoai | 共分析 {len(all_items)} 条标讯

---

## 筛选结果
- 🔥 强烈推荐：{high_c}项 | ⭐ 建议跟进：{mid_c}项 | 👀 需核实：{sum(1 for p in projects.values() if p['score']<60)}项

## 商机清单
'''
    for name, info in projects.items():
        lvl_label = ['🔥 强烈推荐','⭐ 建议跟进','👀 需核实'][0 if info['score']>=80 else 1 if info['score']>=60 else 2]
        screen_md += f'- [{lvl_label}] **{name}** — {info["score"]}分\n'
        screen_md += f'  - 买方：{info["buyer"]} | 截止：{info["urgency"]} | 理由：{info["reason"]}\n\n'
    
    screen_md += '\n---\n> ⚠️ 自动匹配仅供参考。'
    screen_md_path = f'{BASE_DIR}/商机筛选/{date_str_for_screen}-01-allintoai商机筛选表.md'
    with open(screen_md_path, 'w', encoding='utf-8') as f:
        f.write(screen_md)
    print(f'✅ 商机筛选 MD: {os.path.basename(screen_md_path)}')
    
    print('\n🎉 全部报告生成完成！')
