#!/usr/bin/env python3
"""
生成评分明细 + 证据档案 Word 文档（.docx）
用法：python3 generate_docx.py dossier.json scores.json --output-dir ./output/ --company "儒卓力"
"""

import json
import os
import argparse
from datetime import datetime
from docx import Document
from docx.shared import Inches, Pt, Cm, RGBColor, Emu
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.section import WD_ORIENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement

# ============================================================
# 样式常量
# ============================================================
BRAND_GREEN = RGBColor(0x70, 0xAD, 0x47)
DARK_TEXT = RGBColor(0x32, 0x32, 0x32)
MID_TEXT = RGBColor(0x64, 0x64, 0x64)
LIGHT_BG = RGBColor(0xEA, 0xF3, 0xDE)
ACCENT_BLUE = RGBColor(0x44, 0x72, 0xC4)
WHITE = RGBColor(0xFF, 0xFF, 0xFF)
RED_ALERT = RGBColor(0xC0, 0x00, 0x00)
AMBER = RGBColor(0xFF, 0xC0, 0x00)


def set_cell_shading(cell, color):
    """设置单元格背景色"""
    tc = cell._tc
    tcPr = tc.get_or_add_tcPr()
    shading = OxmlElement('w:shd')
    shading.set(qn('w:val'), 'clear')
    shading.set(qn('w:color'), 'auto')
    shading.set(qn('w:fill'), '{:02X}{:02X}{:02X}'.format(color[0], color[1], color[2]))
    tcPr.append(shading)


def add_colored_heading(doc, text, level=1, color=BRAND_GREEN):
    """添加带颜色的标题"""
    heading = doc.add_heading(text, level=level)
    for run in heading.runs:
        run.font.color.rgb = color
    return heading


def add_info_paragraph(doc, label, value, label_width_cm=3.5):
    """添加标签:值 的信息段落"""
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(2)
    p.paragraph_format.space_before = Pt(1)
    run_label = p.add_run(f'{label}：')
    run_label.font.size = Pt(10)
    run_label.font.color.rgb = MID_TEXT
    run_value = p.add_run(str(value))
    run_value.font.size = Pt(10)
    run_value.font.color.rgb = DARK_TEXT
    return p


def add_bullet(doc, text, font_size=Pt(9), color=DARK_TEXT, indent_level=0):
    """添加项目符号段落"""
    p = doc.add_paragraph(style='List Bullet')
    p.clear()
    run = p.add_run(text)
    run.font.size = font_size
    run.font.color.rgb = color
    if indent_level > 0:
        p.paragraph_format.left_indent = Cm(indent_level * 1.0)
    return p


def add_source_line(doc, source_text, url=None, reliability=None):
    """添加来源引用行"""
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(1)
    p.paragraph_format.space_before = Pt(0)

    run_s = p.add_run('来源：')
    run_s.font.size = Pt(8)
    run_s.font.color.rgb = MID_TEXT

    run_t = p.add_run(source_text[:60])
    run_t.font.size = Pt(8)
    run_t.font.color.rgb = DARK_TEXT

    if reliability:
        run_r = p.add_run(f'  |  可靠性：{reliability}')
        run_r.font.size = Pt(8)
        run_r.font.color.rgb = ACCENT_BLUE

    if url:
        p2 = doc.add_paragraph()
        p2.paragraph_format.space_after = Pt(2)
        p2.paragraph_format.space_before = Pt(0)
        run_u = p2.add_run(url[:100])
        run_u.font.size = Pt(7)
        run_u.font.color.rgb = ACCENT_BLUE


def make_progress_bar_cell(cell, pct, width_cm=5.0):
    """在表格单元格中绘制简单进度条"""
    p = cell.paragraphs[0]
    p.clear()

    # 灰色底色
    run_bg = p.add_run(' ' * (int(width_cm * 3)))
    run_bg.font.size = Pt(2)

    # 彩色进度部分——用文字标识
    color = BRAND_GREEN if pct >= 80 else AMBER if pct >= 50 else RED_ALERT
    run_pct = p.add_run(f' {pct:.0f}% ')
    run_pct.font.size = Pt(9)
    run_pct.font.color.rgb = color
    run_pct.font.bold = True


# ============================================================
# 生成评分明细 DOCX
# ============================================================
def build_score_docx(scores, dossier, output_path, company_name):
    doc = Document()

    # 设置页面边距
    for section in doc.sections:
        section.top_margin = Cm(2.0)
        section.bottom_margin = Cm(2.0)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.5)

    # ===== 封面标题 =====
    title = doc.add_heading(f'客户价值与风险评分明细', level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in title.runs:
        run.font.color.rgb = BRAND_GREEN

    subtitle = doc.add_paragraph()
    subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_sub = subtitle.add_run(f'{company_name}  |  {dossier.get("buyer", {}).get("country", "")}  |  {datetime.now().strftime("%Y-%m-%d")}')
    run_sub.font.size = Pt(10)
    run_sub.font.color.rgb = MID_TEXT

    doc.add_paragraph()  # 空行

    # ===== 评分总览卡片（表格） =====
    add_colored_heading(doc, '一、评分总览', level=2)

    value_score = scores.get('value_score', 0)
    value_grade = scores.get('value_grade', 'A')
    risk_score = scores.get('risk_score', 0)
    risk_level = scores.get('risk_level', '低')
    confidence = scores.get('confidence_score', 0)
    priority = scores.get('priority', '')

    table = doc.add_table(rows=1, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.style = 'Table Grid'

    headers = ['客户价值分', '风险评分', '信息置信度', '跟进优先级']
    values = [f'{value_score:.0f} / 100', f'{risk_score:.0f} / 100', f'{confidence:.0f}%', priority]
    grades = [f'{value_grade} 级', f'{risk_level}风险', '高', '']

    # 表头行
    hdr_cells = table.rows[0].cells
    for i, header in enumerate(headers):
        hdr_cells[i].text = ''
        p = hdr_cells[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(header)
        run.font.size = Pt(9)
        run.font.color.rgb = WHITE
        run.font.bold = True
        set_cell_shading(hdr_cells[i], (0x70, 0xAD, 0x47))

    # 数值行
    row2 = table.add_row()
    for i, val in enumerate(values):
        row2.cells[i].text = ''
        p = row2.cells[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(val)
        run.font.size = Pt(16)
        run.font.bold = True
        run.font.color.rgb = BRAND_GREEN if i != 1 else (RED_ALERT if risk_score > 40 else BRAND_GREEN)
        set_cell_shading(row2.cells[i], (0xF5, 0xFA, 0xF0))

    # 等级行
    row3 = table.add_row()
    for i, grade in enumerate(grades):
        row3.cells[i].text = ''
        p = row3.cells[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p.add_run(grade)
        run.font.size = Pt(9)
        run.font.color.rgb = MID_TEXT
        set_cell_shading(row3.cells[i], (0xF5, 0xFA, 0xF0))

    doc.add_paragraph()

    # ===== 维度拆解 =====
    add_colored_heading(doc, '二、评分维度拆解', level=2)

    dims = scores.get('dimensions', {})
    for dim_name, dim_data in dims.items():
        score_val = dim_data.get('score', 0)
        max_val = dim_data.get('maximum', 1)
        pct = score_val / max_val * 100 if max_val > 0 else 0

        # 进度条颜色
        if pct >= 80:
            bar_color = BRAND_GREEN
            bar_label = '优秀'
        elif pct >= 50:
            bar_color = AMBER
            bar_label = '一般'
        else:
            bar_color = RED_ALERT
            bar_label = '不足'

        # 维度标题段落
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(1)
        run_dim = p.add_run(f'{dim_name}')
        run_dim.font.size = Pt(12)
        run_dim.font.bold = True
        run_dim.font.color.rgb = DARK_TEXT
        run_score = p.add_run(f'  {score_val:.0f} / {max_val}  ')
        run_score.font.size = Pt(11)
        run_score.font.color.rgb = bar_color
        run_pctl = p.add_run(f'（{pct:.0f}%） {bar_label}')
        run_pctl.font.size = Pt(9)
        run_pctl.font.color.rgb = MID_TEXT

        # 子项表格
        components = dim_data.get('components', {})
        if components:
            sub_table = doc.add_table(rows=1, cols=2)
            sub_table.style = 'Table Grid'
            sub_table.alignment = WD_TABLE_ALIGNMENT.CENTER
            hdr = sub_table.rows[0].cells
            hdr[0].text = '评估项'
            hdr[1].text = '得分'
            for p_h in hdr:
                p_h.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                for r in p_h.paragraphs[0].runs:
                    r.font.size = Pt(8)
                    r.font.bold = True
                set_cell_shading(p_h, (0xEA, 0xF3, 0xDE))

            for comp_name, comp_score in sorted(components.items(), key=lambda x: -x[1]):
                r = sub_table.add_row()
                r.cells[0].text = comp_name
                r.cells[0].paragraphs[0].runs[0].font.size = Pt(9)
                r.cells[1].text = f'{comp_score} 分'
                r.cells[1].paragraphs[0].runs[0].font.size = Pt(9)
                r.cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
                if comp_score == 0:
                    for c in r.cells:
                        for run_cc in c.paragraphs[0].runs:
                            run_cc.font.color.rgb = MID_TEXT

        doc.add_paragraph()

    # ===== 风险因素 =====
    add_colored_heading(doc, '三、风险因素', level=2)
    risk_factors = scores.get('risk_factors', [])
    if not risk_factors:
        p = doc.add_paragraph()
        run_ok = p.add_run('[OK] 未检测到风险信号 — 所有信号均为正面或中性')
        run_ok.font.size = Pt(10)
        run_ok.font.color.rgb = BRAND_GREEN
    else:
        for rf in risk_factors:
            add_bullet(doc, rf)

    doc.add_paragraph()

    # ===== 置信度明细 =====
    add_colored_heading(doc, '四、置信度明细', level=2)
    cd = scores.get('confidence_details', {})
    add_info_paragraph(doc, '已知信号', f"{cd.get('known_signals', 0)} / {cd.get('total_signals', 0)}")
    add_info_paragraph(doc, '附 URL 证据', f"{cd.get('evidence_with_url', 0)} 条")
    add_info_paragraph(doc, '独立域名来源', f"{cd.get('independent_domains', 0)} 个")
    add_info_paragraph(doc, '评分方法版本', scores.get('method_version', '-'))

    doc.add_paragraph()
    p_footer = doc.add_paragraph()
    p_footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_f = p_footer.add_run(f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}  |  本报告为初筛参考，不构成法律或金融意见')
    run_f.font.size = Pt(8)
    run_f.font.color.rgb = MID_TEXT

    doc.save(output_path)
    print(f'[OK] 评分明细 Word 文档已生成：{output_path}')


# ============================================================
# 生成证据档案 DOCX
# ============================================================
def build_dossier_docx(dossier, scores, output_path, company_name):
    doc = Document()

    for section in doc.sections:
        section.top_margin = Cm(2.0)
        section.bottom_margin = Cm(2.0)
        section.left_margin = Cm(2.5)
        section.right_margin = Cm(2.5)

    # ===== 封面 =====
    title = doc.add_heading('完整证据档案', level=0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER
    for run in title.runs:
        run.font.color.rgb = BRAND_GREEN

    p_sub = doc.add_paragraph()
    p_sub.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_sub = p_sub.add_run(f'{company_name}')
    run_sub.font.size = Pt(14)
    run_sub.font.color.rgb = DARK_TEXT

    p_date = doc.add_paragraph()
    p_date.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_d = p_date.add_run(f'调查日期：{datetime.now().strftime("%Y-%m-%d")}  |  来源类型：A=官方注册  B=官网  C=行业媒体  D=社媒')
    run_d.font.size = Pt(9)
    run_d.font.color.rgb = MID_TEXT

    doc.add_paragraph()

    buyer = dossier.get('buyer', {})
    profile = dossier.get('company_profile', {})

    # ===== 一、企业画像 =====
    add_colored_heading(doc, '一、企业画像', level=2)

    add_info_paragraph(doc, '法定名称', profile.get('legal_name', ''))
    add_info_paragraph(doc, '别称', ', '.join(profile.get('trading_names', [])))
    add_info_paragraph(doc, '国家', profile.get('country', ''))
    add_info_paragraph(doc, '地址', profile.get('address', ''))
    add_info_paragraph(doc, '成立年份', str(profile.get('founded_year', '')))
    add_info_paragraph(doc, '业务类型', profile.get('business_type', ''))
    add_info_paragraph(doc, '主营产品', '、'.join(profile.get('products', [])))
    add_info_paragraph(doc, '销售渠道', '、'.join(profile.get('channels', [])))
    add_info_paragraph(doc, '覆盖市场', '、'.join(profile.get('markets', [])))
    doc.add_paragraph()

    # 联系人
    add_colored_heading(doc, '联系人信息', level=3)
    add_info_paragraph(doc, '姓名', buyer.get('contact_person', ''))
    add_info_paragraph(doc, '职位', buyer.get('contact_title', ''))
    add_info_paragraph(doc, '邮箱', buyer.get('email', ''))
    domain_match = dossier['signals'].get('domain_email_match')
    add_info_paragraph(doc, '邮箱域名匹配', '[Y] 是' if domain_match else '[N] 否')
    doc.add_paragraph()

    # ===== 二、关键信号清单 =====
    add_colored_heading(doc, '二、关键信号清单', level=2)

    signals = dossier.get('signals', {})
    signal_map = [
        ('官网已核验', signals.get('official_website_verified')),
        ('邮箱域名匹配', signals.get('domain_email_match')),
        ('注册信息已核验', signals.get('registration_verified')),
        ('地址已核验', signals.get('address_verified')),
        ('团队或负责人存在', signals.get('leadership_or_employee_presence')),
        ('经营年限', f"{signals.get('operating_history_years', 0)} 年"),
        ('公司规模', signals.get('company_size', '')),
        ('市场覆盖', signals.get('market_presence', '')),
        ('采购证据', signals.get('procurement_evidence', '')),
        ('预计采购规模', signals.get('estimated_purchase_scale', '')),
        ('重复需求', signals.get('recurring_demand')),
        ('决策人匹配', signals.get('decision_maker_match')),
        ('产品匹配度', signals.get('product_relevance', '')),
        ('渠道匹配', signals.get('channel_fit', '')),
        ('市场匹配', signals.get('market_fit', '')),
        ('复购潜力', signals.get('repeat_potential', '')),
        ('战略匹配', signals.get('strategic_fit', '')),
        ('市场影响力', signals.get('market_influence', '')),
        ('询盘具体度', signals.get('inquiry_specificity', '')),
        ('数量明确', signals.get('quantity_clarity')),
        ('交期明确', signals.get('timeline_clarity')),
        ('条款明确', signals.get('terms_clarity')),
        ('联系人角色明确', signals.get('contact_role_clarity')),
    ]

    sig_table = doc.add_table(rows=1, cols=3)
    sig_table.style = 'Table Grid'
    hdr = sig_table.rows[0].cells
    for i, h in enumerate(['信号项', '状态', '评估']):
        hdr[i].text = h
        hdr[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in hdr[i].paragraphs[0].runs:
            r.font.size = Pt(9)
            r.font.bold = True
        set_cell_shading(hdr[i], (0x70, 0xAD, 0x47))
        for r in hdr[i].paragraphs[0].runs:
            r.font.color.rgb = WHITE

    for label, val in signal_map:
        r = sig_table.add_row()
        r.cells[0].text = label
        r.cells[0].paragraphs[0].runs[0].font.size = Pt(9)

        if isinstance(val, bool):
            status = '[Y]' if val else '[N]'
            color = BRAND_GREEN if val else MID_TEXT
            assess = '通过' if val else '未确认'
        else:
            status = str(val)
            color = DARK_TEXT
            assess = '-'

        r.cells[1].text = status
        r.cells[1].paragraphs[0].runs[0].font.size = Pt(9)
        r.cells[1].paragraphs[0].runs[0].font.color.rgb = color
        r.cells[1].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

        r.cells[2].text = assess
        r.cells[2].paragraphs[0].runs[0].font.size = Pt(9)
        r.cells[2].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

        for c in r.cells:
            if val is False or (isinstance(val, str) and val in ['', 'none', 'None', 'false']):
                for run_c in c.paragraphs[0].runs:
                    run_c.font.color.rgb = MID_TEXT

    doc.add_paragraph()

    # ===== 三、完整证据清单 =====
    add_colored_heading(doc, '三、完整证据清单（附来源链接）', level=2)

    evidence_list = dossier.get('evidence', [])
    rel_map = {'A': '政府/官方注册', 'B': '官网/自有文件', 'C': '行业媒体/综合', 'D': '社交媒体'}

    for i, ev in enumerate(evidence_list, 1):
        claim = ev.get('claim', '')
        title_text = ev.get('title', '')
        url = ev.get('url', '')
        rel = ev.get('reliability', 'C')
        notes = ev.get('notes', '')

        # 证据编号和主张
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(1)
        run_num = p.add_run(f'[{i}] ')
        run_num.font.size = Pt(10)
        run_num.font.bold = True
        run_num.font.color.rgb = BRAND_GREEN
        run_claim = p.add_run(claim)
        run_claim.font.size = Pt(10)
        run_claim.font.color.rgb = DARK_TEXT

        # 来源信息
        add_source_line(doc, title_text, url, rel_map.get(rel, rel))

        # 备注
        if notes:
            p_note = doc.add_paragraph()
            p_note.paragraph_format.space_after = Pt(4)
            run_n = p_note.add_run(f'备注：{notes[:150]}')
            run_n.font.size = Pt(8)
            run_n.font.color.rgb = MID_TEXT

        doc.add_paragraph()  # 间距

    # ===== 四、社媒矩阵 =====
    add_colored_heading(doc, '四、社交媒体存在', level=2)

    sm = dossier.get('social_media_presence', {})
    for platform, data in sm.items():
        if data.get('found'):
            p = doc.add_paragraph()
            p.paragraph_format.space_after = Pt(1)
            run_plat = p.add_run(f'[{platform.title()}] ')
            run_plat.font.size = Pt(10)
            run_plat.font.bold = True
            followers = data.get('followers', '') or data.get('subscribers', '')
            run_detail = p.add_run(f'关注者：{followers}  |  {data.get("notes", "")}')
            run_detail.font.size = Pt(9)
            run_detail.font.color.rgb = MID_TEXT

    doc.add_paragraph()

    # ===== 五、关键发现 =====
    add_colored_heading(doc, '五、关键发现', level=2)
    for f in dossier.get('key_findings', []):
        add_bullet(doc, f, indent_level=0)

    doc.add_paragraph()

    # ===== 六、风险发现 =====
    add_colored_heading(doc, '六、风险发现', level=2)
    for f in dossier.get('risk_findings', []):
        add_bullet(doc, f, indent_level=0)

    doc.add_paragraph()

    # ===== 七、报价策略 =====
    if 'pricing_strategy' in dossier:
        add_colored_heading(doc, '七、报价策略', level=2)
        ps = dossier['pricing_strategy']
        add_info_paragraph(doc, '报价档位', ps.get('pricing_level', ''))
        add_info_paragraph(doc, '议价空间', ps.get('negotiation_space', ''))
        add_info_paragraph(doc, '付款建议', ps.get('payment_guidance', ''))

        p_cond = doc.add_paragraph()
        run_c = p_cond.add_run('条件交换：')
        run_c.font.size = Pt(10)
        run_c.font.bold = True
        run_c.font.color.rgb = DARK_TEXT

        for c in ps.get('conditions', []):
            add_bullet(doc, c, font_size=Pt(9))

    doc.add_paragraph()

    # ===== 八、跟进行动 =====
    add_colored_heading(doc, '八、建议跟进行动', level=2)
    for a in dossier.get('follow_up_actions', []):
        add_bullet(doc, a, font_size=Pt(9))

    doc.add_paragraph()

    # ===== 九、待核验 =====
    add_colored_heading(doc, '九、待核验问题', level=2)
    for q in dossier.get('verification_questions', []):
        add_bullet(doc, q, font_size=Pt(9), color=MID_TEXT)

    doc.add_paragraph()

    # ===== 十、来源与限制 =====
    add_colored_heading(doc, '十、来源与限制', level=2)
    for lim in dossier.get('limitations', []):
        p = doc.add_paragraph()
        p.paragraph_format.space_after = Pt(2)
        run_lim = p.add_run(f'· {lim}')
        run_lim.font.size = Pt(9)
        run_lim.font.color.rgb = MID_TEXT

    doc.add_paragraph()
    p_footer = doc.add_paragraph()
    p_footer.alignment = WD_ALIGN_PARAGRAPH.CENTER
    run_f = p_footer.add_run(f'生成时间：{datetime.now().strftime("%Y-%m-%d %H:%M")}  |  本证据档案为初筛参考，不构成法律或金融意见')
    run_f.font.size = Pt(8)
    run_f.font.color.rgb = MID_TEXT

    doc.save(output_path)
    print(f'[OK] 证据档案 Word 文档已生成：{output_path}')


# ============================================================
# 主流程
# ============================================================
def main():
    parser = argparse.ArgumentParser(description='生成评分明细 + 证据档案 Word 文档')
    parser.add_argument('dossier', help='dossier.json 路径')
    parser.add_argument('scores', help='scores.json 路径')
    parser.add_argument('--output-dir', default='./output/', help='输出目录')
    parser.add_argument('--company', default='未命名', help='公司中文简称')
    args = parser.parse_args()

    with open(args.dossier, 'r', encoding='utf-8') as f:
        dossier = json.load(f)
    with open(args.scores, 'r', encoding='utf-8') as f:
        scores = json.load(f)

    # 如果没有传 --company，尝试从 dossier 提取中文名
    company = args.company
    if company == '未命名':
        buyer = dossier.get('buyer', {})
        company = buyer.get('company_name_zh', '') or buyer.get('company_name', '') or '未命名'
        # 截断过长的名字
        if len(company) > 20:
            company = buyer.get('company_name', company[:20])

    os.makedirs(args.output_dir, exist_ok=True)

    score_path = os.path.join(args.output_dir, f'评分明细_{company}.docx')
    dossier_path = os.path.join(args.output_dir, f'证据档案_{company}.docx')

    build_score_docx(scores, dossier, score_path, company)
    build_dossier_docx(dossier, scores, dossier_path, company)

    # 双写到 userdata
    import shutil
    userdata_dir = os.path.expanduser('~/.workbuddy/userdata/wxskill/global-buyer-intelligence/output/')
    os.makedirs(userdata_dir, exist_ok=True)
    shutil.copy2(score_path, os.path.join(userdata_dir, f'评分明细_{company}.docx'))
    shutil.copy2(dossier_path, os.path.join(userdata_dir, f'证据档案_{company}.docx'))
    print(f'[OK] 文件已双写到 {userdata_dir}')


if __name__ == '__main__':
    main()
