#!/usr/bin/env python3
"""Render a readable Chinese Markdown report from dossier and score JSON."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from datetime import date
from pathlib import Path
from typing import Any

# ---- 产物输出目录（用户数据隔离） ----
OUTPUT_DIR = Path.home() / ".workbuddy" / "userdata" / "wxskill" / "global-buyer-intelligence" / "output"


def load_object(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path} 顶层必须是 JSON 对象。")
    return data


def text(value: Any, default: str = "未确认") -> str:
    if value in (None, "", [], {}):
        return default
    if isinstance(value, list):
        return "、".join(str(item) for item in value) if value else default
    return str(value)


def bullet_list(items: Any, empty: str = "- 暂无可确认信息。") -> str:
    if not isinstance(items, list) or not items:
        return empty
    rendered = []
    for item in items:
        if isinstance(item, dict):
            label = item.get("finding") or item.get("claim") or item.get("action") or json.dumps(item, ensure_ascii=False)
        else:
            label = str(item)
        rendered.append(f"- {label}")
    return "\n".join(rendered)


def render_dimensions(dimensions: Any) -> str:
    lines = ["| 维度 | 得分 | 满分 |", "|---|---:|---:|"]
    if not isinstance(dimensions, dict) or not dimensions:
        lines.append("| 未计算 | — | — |")
        return "\n".join(lines)
    for name, item in dimensions.items():
        if isinstance(item, dict):
            lines.append(f"| {name} | {item.get('score', '—')} | {item.get('maximum', '—')} |")
    return "\n".join(lines)


def render_evidence(evidence: Any) -> str:
    if not isinstance(evidence, list) or not evidence:
        return "- 本次未形成可引用证据，报告只能作为低置信度线索。"
    lines = []
    labels = {"fact": "事实", "inference": "推断", "unconfirmed": "未确认"}
    for index, item in enumerate(evidence, start=1):
        if not isinstance(item, dict):
            continue
        claim_type = labels.get(str(item.get("claim_type", "")).lower(), "未分类")
        claim = text(item.get("claim"))
        title = text(item.get("title"), "来源")
        url = item.get("url") or ""
        source = f"[{title}]({url})" if url else title
        lines.append(
            f"{index}. **{claim_type}**：{claim}  \n"
            f"   来源：{source}；发布日期：{text(item.get('published_at'))}；"
            f"访问日期：{text(item.get('accessed_at'))}；可靠性：{text(item.get('reliability'))}。"
        )
    return "\n".join(lines) or "- 暂无格式正确的证据。"


def render_sources(evidence: Any, limitations: Any) -> str:
    source_lines = []
    seen = set()
    if isinstance(evidence, list):
        for item in evidence:
            if not isinstance(item, dict):
                continue
            url = item.get("url")
            if not url or url in seen:
                continue
            seen.add(url)
            source_lines.append(f"- [{text(item.get('title'), '来源')}]({url})")
    if not source_lines:
        source_lines.append("- 未提供可访问来源。")
    source_lines.append("\n### 调查限制")
    source_lines.append(bullet_list(limitations, "- 未声明额外限制。"))
    source_lines.append(
        "\n> 本报告基于查询时可访问的公开资料和用户提供信息，不构成法律、金融、制裁合规或商业征信意见。"
    )
    return "\n".join(source_lines)


def render_report(dossier: dict[str, Any], scores: dict[str, Any]) -> str:
    buyer = dossier.get("buyer") if isinstance(dossier.get("buyer"), dict) else {}
    profile = dossier.get("company_profile") if isinstance(dossier.get("company_profile"), dict) else {}
    pricing = dossier.get("pricing_strategy") if isinstance(dossier.get("pricing_strategy"), dict) else {}
    evidence = dossier.get("evidence")

    profile_lines = [
        f"- 法定/核验名称：{text(profile.get('legal_name') or buyer.get('company_name'))}",
        f"- 国家/地区：{text(profile.get('country') or buyer.get('country'))}",
        f"- 地址：{text(profile.get('address'))}",
        f"- 成立年份：{text(profile.get('founded_year'))}",
        f"- 企业类型：{text(profile.get('business_type'))}",
        f"- 产品：{text(profile.get('products'))}",
        f"- 渠道：{text(profile.get('channels'))}",
        f"- 市场：{text(profile.get('markets'))}",
    ]

    pricing_lines = [
        f"- 报价档位：{text(pricing.get('pricing_level'))}",
        f"- 建议议价空间：{text(pricing.get('negotiation_space'))}",
        f"- 付款风控：{text(pricing.get('payment_guidance'))}",
        "- 条件交换：" + text(pricing.get("conditions")),
    ]

    risk_factors = scores.get("risk_factors")
    if isinstance(risk_factors, list) and risk_factors:
        risk_text = "\n".join(
            f"- {text(item.get('factor'))}（+{item.get('points', 0)}）"
            for item in risk_factors
            if isinstance(item, dict)
        )
    else:
        risk_text = "- 本次结构化信号未触发明确加分项；仍需执行标准交易风控。"
    additional_risks = bullet_list(dossier.get("risk_findings"), "")
    if additional_risks:
        risk_text = risk_text + "\n" + additional_risks

    key_findings = dossier.get("key_findings")
    summary = text(key_findings[0] if isinstance(key_findings, list) and key_findings else None)

    return f"""# 海外客户智能背调报告

> 报告日期：{date.today().isoformat()}  
> 客户：{text(profile.get('legal_name') or buyer.get('company_name'))}  
> 调查范围：公开信息初筛，不构成法律、金融或商业征信意见。

## 一、执行摘要

- 客户价值：{scores.get('value_score', '—')}/100（{scores.get('value_grade', '—')}）
- 风险：{scores.get('risk_score', '—')}/100（{scores.get('risk_level', '—')}）
- 信息置信度：{scores.get('confidence_score', '—')}/100（{scores.get('confidence_level', '—')}）
- 建议优先级：{text(scores.get('priority'))}
- 核心结论：{summary}

## 二、主体身份核验

{bullet_list(dossier.get('identity_findings'), '- 尚未提供独立的主体身份核验结论。')}

## 三、企业画像与采购潜力

{chr(10).join(profile_lines)}

## 四、评分拆解

{render_dimensions(scores.get('dimensions'))}

## 五、事实、推断与未确认事项

{render_evidence(evidence)}

## 六、风险与交易控制

{risk_text}

## 七、报价与谈判策略

{chr(10).join(pricing_lines)}

## 八、销售跟进计划

{bullet_list(dossier.get('follow_up_actions'))}

## 九、待核验问题

{bullet_list(dossier.get('verification_questions'))}

## 十、来源与限制

{render_sources(evidence, dossier.get('limitations'))}
"""


def main() -> int:
    parser = argparse.ArgumentParser(description="生成海外客户背调 Markdown 报告。")
    parser.add_argument("dossier", help="dossier JSON")
    parser.add_argument("scores", help="评分 JSON")
    parser.add_argument(
        "--output",
        default=str(OUTPUT_DIR / "buyer-report.md"),
        help=f"Markdown 输出路径（默认：{OUTPUT_DIR / 'buyer-report.md'}）",
    )
    parser.add_argument(
        "--workspace",
        default=None,
        help="工作区目录（显式指定才复制到这里；不传则不复制，避免污染调用方 cwd）",
    )
    args = parser.parse_args()

    try:
        dossier = load_object(Path(args.dossier))
        scores = load_object(Path(args.scores))

        # 确保输出目录存在
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        output_path = Path(args.output)
        output_path.write_text(render_report(dossier, scores), encoding="utf-8")
        sys.stdout.write(f"报告已生成：{output_path}\n")

        # 仅在显式指定 --workspace 时才复制（绝不用 os.getcwd()，避免污染专家目录）
        if args.workspace:
            workspace_dir = Path(args.workspace)
            workspace_dir.mkdir(parents=True, exist_ok=True)
            workspace_copy = workspace_dir / output_path.name
            if workspace_copy.resolve() == output_path.resolve():
                # 主输出已落在工作区，无需复制
                sys.stdout.write(f"提示：--output 与 --workspace 目标相同，跳过复制。\n")
            else:
                shutil.copy2(output_path, workspace_copy)
                sys.stdout.write(f"已同步到工作区：{workspace_copy}\n")
        else:
            sys.stdout.write("提示：未指定 --workspace，跳过工作区复制（产物仅落在主存储）。\n")
        return 0
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        sys.stderr.write(f"报告生成失败：{exc}\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

