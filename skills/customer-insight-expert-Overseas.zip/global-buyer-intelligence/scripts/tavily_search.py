#!/usr/bin/env python3
"""Call Tavily Search through its fixed HTTPS endpoint using only stdlib."""

from __future__ import annotations

import argparse
import json
import os
import sys
from datetime import date
from pathlib import Path
from typing import Any
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen


ENDPOINT = "https://api.tavily.com/search"


def split_domains(values: list[str]) -> list[str]:
    domains: list[str] = []
    for value in values:
        domains.extend(item.strip() for item in value.split(",") if item.strip())
    return domains


def search(args: argparse.Namespace) -> dict[str, Any]:
    api_key = os.environ.get("TAVILY_API_KEY", "").strip()
    if not api_key:
        raise ValueError("未配置 TAVILY_API_KEY；请改用 WorkBuddy 内置网页搜索或在环境中配置密钥。")

    payload: dict[str, Any] = {
        "query": args.query,
        "search_depth": args.search_depth,
        "topic": args.topic,
        "max_results": args.max_results,
        "include_answer": False,
        "include_raw_content": False,
    }
    include_domains = split_domains(args.include_domains)
    exclude_domains = split_domains(args.exclude_domains)
    if include_domains:
        payload["include_domains"] = include_domains
    if exclude_domains:
        payload["exclude_domains"] = exclude_domains
    if args.time_range:
        payload["time_range"] = args.time_range

    request = Request(
        ENDPOINT,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "User-Agent": "global-buyer-intelligence/1.0",
        },
        method="POST",
    )
    with urlopen(request, timeout=args.timeout) as response:
        raw = json.loads(response.read().decode("utf-8"))

    results = []
    for item in raw.get("results", []):
        if not isinstance(item, dict):
            continue
        results.append(
            {
                "title": item.get("title", ""),
                "url": item.get("url", ""),
                "content": item.get("content", ""),
                "score": item.get("score"),
                "published_date": item.get("published_date"),
                "accessed_at": date.today().isoformat(),
                "source": "tavily",
            }
        )

    return {
        "query": args.query,
        "results": results,
        "request_id": raw.get("request_id"),
        "response_time": raw.get("response_time"),
        "usage": raw.get("usage"),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="使用 Tavily 补强海外客户公开信息检索。")
    parser.add_argument("query", help="搜索查询词")
    parser.add_argument("--search-depth", choices=["basic", "advanced", "fast", "ultra-fast"], default="basic")
    parser.add_argument("--topic", choices=["general", "news", "finance"], default="general")
    parser.add_argument("--max-results", type=int, choices=range(1, 11), default=5)
    parser.add_argument("--time-range", choices=["day", "week", "month", "year"])
    parser.add_argument("--include-domains", action="append", default=[])
    parser.add_argument("--exclude-domains", action="append", default=[])
    parser.add_argument("--timeout", type=int, default=30)
    parser.add_argument("--output", default="-", help="输出路径，默认输出到终端")
    args = parser.parse_args()

    try:
        result = search(args)
        rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
        if args.output == "-":
            sys.stdout.write(rendered)
        else:
            Path(args.output).write_text(rendered, encoding="utf-8")
        return 0
    except ValueError as exc:
        sys.stderr.write(f"Tavily 配置错误：{exc}\n")
        return 2
    except HTTPError as exc:
        # Do not print request headers or the API key.
        sys.stderr.write(f"Tavily 请求失败：HTTP {exc.code}\n")
        return 3
    except (URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
        sys.stderr.write(f"Tavily 请求失败：{exc}\n")
        return 3


if __name__ == "__main__":
    raise SystemExit(main())

