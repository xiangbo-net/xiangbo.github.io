#!/usr/bin/env python3
"""Validate and normalize buyer input without performing network requests."""

from __future__ import annotations

import argparse
import json
import re
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse


ALIASES = {
    "公司名称": "company_name",
    "国家": "country",
    "官网": "website",
    "邮箱": "email",
    "联系人": "contact_name",
    "联系人职位": "contact_role",
    "产品": "product",
    "采购数量": "purchase_quantity",
    "规格": "specifications",
    "目标市场": "target_market",
    "贸易术语": "incoterm",
    "交期": "delivery_timeline",
    "询盘": "inquiry",
    "附件": "attachments",
    "备注": "notes",
}

KNOWN_FIELDS = {
    "company_name",
    "country",
    "website",
    "email",
    "contact_name",
    "contact_role",
    "product",
    "purchase_quantity",
    "specifications",
    "target_market",
    "incoterm",
    "delivery_timeline",
    "inquiry",
    "attachments",
    "notes",
}

PUBLIC_EMAIL_DOMAINS = {
    "gmail.com",
    "hotmail.com",
    "outlook.com",
    "yahoo.com",
    "icloud.com",
    "qq.com",
    "163.com",
    "126.com",
    "proton.me",
    "protonmail.com",
}

EMAIL_RE = re.compile(r"^[^\s@]+@[^\s@]+\.[^\s@]+$")


def load_json(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("输入 JSON 顶层必须是对象。")
    return data


def clean_value(value: Any) -> Any:
    if isinstance(value, str):
        return value.strip()
    if isinstance(value, list):
        return [clean_value(item) for item in value]
    return value


def normalize(data: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    normalized: dict[str, Any] = {}
    warnings: list[str] = []

    for original_key, value in data.items():
        key = ALIASES.get(original_key, original_key)
        if key not in KNOWN_FIELDS:
            warnings.append(f"未识别字段已保留在 notes 之外：{original_key}")
            continue
        if key in normalized and normalized[key] not in (None, "", []):
            warnings.append(f"字段 {key} 同时使用了别名和标准名，采用后出现的值。")
        normalized[key] = clean_value(value)

    for key in KNOWN_FIELDS:
        if key == "attachments":
            normalized.setdefault(key, [])
        else:
            normalized.setdefault(key, "")

    return normalized, warnings


def domain_from_website(website: str) -> tuple[str, str]:
    if not website:
        return "", ""
    candidate = website if "://" in website else f"https://{website}"
    parsed = urlparse(candidate)
    domain = (parsed.hostname or "").lower().removeprefix("www.")
    return candidate, domain


def validate(normalized: dict[str, Any]) -> dict[str, Any]:
    errors: list[str] = []
    warnings: list[str] = []

    if not any(normalized.get(key) for key in ("company_name", "website", "email")):
        errors.append("至少需要公司名称、官网或邮箱中的一项。")

    email = str(normalized.get("email") or "").lower()
    email_domain = ""
    if email:
        if not EMAIL_RE.match(email):
            errors.append("邮箱格式无效。")
        else:
            email_domain = email.rsplit("@", 1)[1]

    normalized_website, website_domain = domain_from_website(
        str(normalized.get("website") or "")
    )
    if normalized.get("website"):
        if not website_domain or "." not in website_domain:
            errors.append("官网域名格式无效。")
        else:
            normalized["website"] = normalized_website

    if email_domain and email_domain in PUBLIC_EMAIL_DOMAINS:
        warnings.append("联系人使用公共邮箱；这是核验提示，不代表客户存在欺诈。")

    domain_email_match: bool | None = None
    if email_domain and website_domain and email_domain not in PUBLIC_EMAIL_DOMAINS:
        domain_email_match = (
            email_domain == website_domain
            or email_domain.endswith(f".{website_domain}")
            or website_domain.endswith(f".{email_domain}")
        )
        if not domain_email_match:
            warnings.append("企业邮箱域名与官网域名不一致，需要核验关联关系。")

    recommended = [
        ("country", "国家/地区"),
        ("product", "询价产品"),
        ("inquiry", "询盘原文"),
    ]
    for field, label in recommended:
        if not normalized.get(field):
            warnings.append(f"建议补充{label}，否则分析置信度会下降。")

    attachments = normalized.get("attachments")
    if not isinstance(attachments, list):
        errors.append("attachments 必须是数组。")

    return {
        "valid": not errors,
        "errors": errors,
        "warnings": warnings,
        "normalized": normalized,
        "derived": {
            "website_domain": website_domain or None,
            "email_domain": email_domain or None,
            "is_public_email": email_domain in PUBLIC_EMAIL_DOMAINS if email_domain else None,
            "domain_email_match": domain_email_match,
        },
    }


def write_result(result: dict[str, Any], output: str) -> None:
    rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    if output == "-":
        sys.stdout.write(rendered)
    else:
        Path(output).write_text(rendered, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description="校验并规范化海外买家输入 JSON。")
    parser.add_argument("input", help="输入 JSON 文件")
    parser.add_argument("--output", default="-", help="输出路径，默认输出到终端")
    args = parser.parse_args()

    try:
        raw = load_json(Path(args.input))
        normalized, alias_warnings = normalize(raw)
        result = validate(normalized)
        result["warnings"] = alias_warnings + result["warnings"]
        write_result(result, args.output)
        return 0 if result["valid"] else 2
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        sys.stderr.write(f"输入校验失败：{exc}\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

