#!/usr/bin/env python3
"""Generate a self-contained HTML dashboard from dossier and score JSON."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from datetime import date
from pathlib import Path
from typing import Any

OUTPUT_DIR = Path.home() / ".workbuddy" / "userdata" / "wxskill" / "global-buyer-intelligence" / "output"


def load_object(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError(f"{path} 顶层必须是 JSON 对象。")
    return data


# ---------- 字段中文化与字段名兼容 ----------
# dossier 写入时如果某些字段缺失，下面的回退逻辑会用这些标签
FIELD_LABEL_ZH = {
    "legal_name": "法定名称",
    "trading_names": "商业名称",
    "country": "国家/地区",
    "address": "注册地址",
    "founded_year": "成立年份",
    "business_type": "企业类型",
    "products": "主营产品",
    "channels": "销售渠道",
    "markets": "目标市场",
    "website": "官网",
    "email": "联系邮箱",
    "contact_name": "联系人",
    "contact_role": "联系人职位",
    "inquiry_date": "询盘日期",
    "inquiry_source": "询盘来源",
    "inquiry_text": "询盘原文",
    "registration_number": "注册号",
    "registration_court": "注册法院",
    "vat_number": "VAT 号",
    "duns_number": "DUNS 号",
    "certifications": "认证",
    "employees_approx": "员工数（约）",
    "revenue_fy2025": "营收（财年 2025）",
    "revenue_fy2023": "营收（财年 2023）",
    "customers_approx": "客户数（约）",
    "global_offices": "全球办事处数",
    "warehouse_locations": "仓库分布",
    "asia_offices": "亚洲办事处",
    "management": "管理团队",
    "key_connector_suppliers": "核心连接器供应商",
    "signals": "关键信号",
    "evidence": "证据清单",
    "key_findings": "关键发现",
    "risk_findings": "风险发现",
    "follow_up_actions": "跟进计划",
    "verification_questions": "待核验问题",
    "limitations": "调查限制",
    "pricing_strategy": "报价策略",
    "social_media_presence": "社媒矩阵",
}

# 风险/跟进项字段名兼容（dossier 中可能用 risk_type / description / mitigation / action / priority）
RISK_FIELD_ALIASES = {
    "name": ["risk", "risk_type", "name", "title", "category", "风险"],
    "detail": ["detail", "description", "desc", "summary", "note", "详情"],
    "mitigation": ["mitigation", "recommendation", "suggestion", "action", "处置建议"],
    "severity": ["severity", "level", "score", "严重度"],
}

ACTION_FIELD_ALIASES = {
    "action": ["action", "task", "name", "title", "事项"],
    "priority": ["priority", "level", "urgency", "优先级"],
    "description": ["description", "desc", "detail", "summary", "note", "详情"],
}

# 证据类型中文化
EVIDENCE_TYPE_ZH = {
    "fact": "📌 事实",
    "inference": "🔍 推断",
    "unconfirmed": "❓ 未确认",
    "risk": "⚠️ 风险",
    "evidence": "📎 证据",
}

# 来源类型中文化
SOURCE_TYPE_ZH = {
    "official_website": "官方网站",
    "official_document": "官方文档",
    "official_press_release": "官方新闻稿",
    "company_official_document": "公司官方文件",
    "partner_directory": "合作伙伴目录",
    "industry_media": "行业媒体",
    "business_database": "商业数据库",
    "social_media": "社交媒体",
    "search_synthesis": "搜索综合",
    "inference": "推断",
    "third_party_verification": "第三方核验",
    "government_registry": "政府注册机构",
    "court_records": "法院记录",
    "sanctions_list": "制裁名单",
    "news_article": "新闻报道",
    "trade_data": "贸易数据",
    "exhibition_catalog": "展会目录",
}

# 严重度中文化
SEVERITY_ZH = {
    "low": "低",
    "medium": "中",
    "high": "高",
    "critical": "严重",
    "info": "提示",
    "none": "无",
}

# 优先级中文化
PRIORITY_ZH = {
    "high": "高",
    "medium": "中",
    "low": "低",
    "critical": "紧急",
    "urgent": "紧急",
    "normal": "常规",
}


def pick_field(obj: dict[str, Any], aliases: list[str], default: Any = "") -> Any:
    """从 dict 中按多个候选键名取首个非空值。"""
    if not isinstance(obj, dict):
        return default
    for k in aliases:
        if k in obj and obj[k] not in (None, "", [], {}):
            return obj[k]
    return default


# ---------- 英文→中文轻量转写（用于兜底） ----------
# 关键短语中英对照（dossier 写入英文时，脚本自动转写为中文显示）
EN_TO_ZH_PHRASES = [
    (r"\bGmbH\b", "有限责任公司（GmbH）"),
    (r"\bHRB\s+(\w+)", r"商业登记号 HRB \1"),
    (r"\bVAT\s+(DE\s*\d+)", r"增值税号 \1"),
    (r"\bDUNS\s+([\d\-]+)", r"邓白氏编码 \1"),
    (r"\bAmtsgericht\s+(\w+)", r"\1 地方法院"),
    (r"\bISO\s+(\d+(?::\d+)?)", r"ISO \1"),
    (r"\bFounded in (\d{4})\b", r"成立于 \1 年"),
    (r"\bemployees?\b", "员工"),
    (r"\brevenue\b", "营收"),
    (r"\bturnover\b", "营业额"),
    (r"\bbillion\b", "十亿"),
    (r"\bmillion\b", "百万"),
    (r"\bsubsidiar(y|ies)\b", "子公司"),
    (r"\boffices?\b", "办事处"),
    (r"\bwarehouses?\b", "仓库"),
    (r"\bauthorized distributor\b", "授权分销商"),
    (r"\bIntel Authorized Distributor\b", "英特尔授权分销商"),
    (r"\bcircular connectors?\b", "圆形连接器"),
    (r"\bcable assembl(y|ies)\b", "电缆组件"),
    (r"\binterconnect solutions?\b", "互连解决方案"),
    (r"\bindustrial automation\b", "工业自动化"),
    (r"\bautomotive\b", "汽车"),
    (r"\bmedical\b", "医疗"),
    (r"\blighting\b", "照明"),
    (r"\bhome appliance\b", "家电"),
    (r"\benergy\b", "能源"),
    (r"\bsemiconductors?\b", "半导体"),
    (r"\bpassive components?\b", "无源元件"),
    (r"\belectromechanical components?\b", "机电组件"),
    (r"\bembedded boards?\b", "嵌入式板卡"),
    (r"\bdisplays?\b", "显示器"),
    (r"\bwireless technologies?\b", "无线技术"),
    (r"\bCode of Conduct\b", "行为准则"),
    (r"\bwhistleblower system\b", "举报人制度"),
    (r"\banonymous reporting\b", "匿名举报"),
    (r"\bSenior Procurement Manager\b", "高级采购经理"),
    (r"\bProcurement Manager\b", "采购经理"),
    (r"\bMarkus Schmidt\b", "Markus Schmidt（德国常见姓名）"),
    (r"\bRutronik\b", "Rutronik（儒卓力）"),
    (r"\bAmphenol\b", "Amphenol（安费诺）"),
    (r"\bMolex\b", "Molex（莫仕）"),
    (r"\bPhoenix Contact\b", "Phoenix Contact（菲尼克斯）"),
    (r"\bTE Connectivity\b", "TE Connectivity（泰科电子）"),
    (r"\bLumberg\b", "Lumberg（兰贝格）"),
    (r"\bJAE\b", "JAE（日本航空电子）"),
    (r"\bLinkedIn\b", "LinkedIn（领英）"),
    (r"\bFacebook\b", "Facebook（脸书）"),
    (r"\bInstagram\b", "Instagram"),
    (r"\bYouTube\b", "YouTube"),
    (r"\bXing\b", "Xing（德国职业社交）"),
    (r"\bself-disclosure\b", "自披露文件"),
    (r"\bSelf-Disclosure\b", "自披露"),
    (r"\bDeutsche Bank\b", "德意志银行"),
    (r"\bno evidence of\b", "未发现"),
    (r"\bNo evidence of\b", "未发现"),
    (r"\bsanctions?\b", "制裁"),
    (r"\bfraud\b", "欺诈"),
    (r"\blawsuits?\b", "诉讼"),
    (r"\bbankruptcy\b", "破产"),
    (r"\bregulatory actions?\b", "监管处罚"),
    (r"\bconfirmed\b", "已确认"),
    (r"\bverif(y|ied|ication)\b", "核验"),
    (r"\bofficial\b", "官方"),
    (r"\b50th anniversary\b", "50 周年"),
    (r"\bEstablished\b", "成立"),
    (r"\belectromechanical\b", "机电"),
    (r"\bconnectors?\b", "连接器"),
    (r"\brelays?\b", "继电器"),
    (r"\bswitches?\b", "开关"),
    (r"\bterminal blocks?\b", "端子排"),
    (r"\bM12\b", "M12 工业连接器"),
    (r"\bM8\b", "M8 工业连接器"),
    (r"\b7/8\"\b", "7/8 英寸"),
    (r"\bRMB\b", "人民币"),
    (r"\bAsia\b", "亚洲"),
    (r"\bChina\b", "中国"),
    (r"\bShenzhen\b", "深圳"),
    (r"\bShanghai\b", "上海"),
    (r"\bChengdu\b", "成都"),
    (r"\bTianjin\b", "天津"),
    (r"\bHong Kong\b", "香港"),
    (r"\bTaiwan\b", "台湾"),
    (r"\bThailand\b", "泰国"),
    (r"\bSingapore\b", "新加坡"),
    (r"\bGermany\b", "德国"),
    (r"\bMannheim\b", "曼海姆"),
    (r"\bIspringen\b", "伊斯普林根"),
    (r"\bEisingen\b", "艾辛根"),
    (r"\bAustin\b", "奥斯汀"),
    (r"\bfollowers?\b", "关注者"),
    (r"\bsubscribers?\b", "订阅者"),
    (r"\bcareers?\b", "招聘"),
    (r"\binquiry\b", "询盘"),
    (r"\bRFQ\b", "询价单"),
    (r"\bpo\b", "采购订单"),
    (r"\bPO\b", "采购订单"),
    (r"\bIncoterms?\b", "贸易术语"),
    (r"\bFOB Shanghai\b", "FOB 上海"),
    (r"\bCIF\b", "CIF"),
    (r"\bsamples?\b", "样品"),
    (r"\bproduction\b", "生产"),
    (r"\bdelivery\b", "交货"),
    (r"\blead time\b", "交期"),
    (r"\bcertifications?\b", "认证"),
    (r"\bquality\b", "质量"),
    (r"\bmanagement\b", "管理"),
    (r"\bcompany\b", "公司"),
    (r"\bbusiness\b", "业务"),
    (r"\bglobal\b", "全球"),
    (r"\bpresence\b", "存在/布局"),
    (r"\bwarehouse\b", "仓库"),
    (r"\bsupply chain\b", "供应链"),
    (r"\bprocurement\b", "采购"),
    (r"\bsourcing\b", "采购"),
    (r"\bpurchasing\b", "采购"),
    (r"\bmarket\b", "市场"),
    (r"\bcustomer\b", "客户"),
    (r"\bclients?\b", "客户"),
    (r"\bdistributor\b", "分销商"),
    (r"\bmanufactur(er|ing)\b", "制造"),
    (r"\bdesign-in\b", "设计导入"),
    (r"\bDesign-In\b", "设计导入"),
    (r"\bvideo call\b", "视频会议"),
    (r"\bphone\b", "电话"),
    (r"\bemail\b", "邮件"),
    (r"\bdomain\b", "域名"),
    (r"\bregistered\b", "已注册"),
    (r"\bverifying\b", "核验中"),
]


def rephrase_to_zh(text: str) -> str:
    """将英文 claim 轻量转写为中文（保留关键数字、专有名词）。"""
    if not text:
        return text
    import re
    out = text
    for pattern, repl in EN_TO_ZH_PHRASES:
        out = re.sub(pattern, repl, out)
    return out


def esc(value: Any) -> str:
    if value is None:
        return ""
    return str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")


def js_str(value: Any) -> str:
    if value is None:
        return "null"
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    return json.dumps(str(value), ensure_ascii=False)


def render_gauge_svg(score: float, label: str, color: str, size: int = 140) -> str:
    """Render a circular gauge SVG."""
    r = 52
    cx = size // 2
    cy = size // 2 + 6
    circumference = 2 * 3.14159 * r
    offset = circumference * (1 - score / 100)
    return f'''<svg width="{size}" height="{size}" viewBox="0 0 {size} {size}">
  <circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="#e8e8e8" stroke-width="10"/>
  <circle cx="{cx}" cy="{cy}" r="{r}" fill="none" stroke="{color}" stroke-width="10"
    stroke-dasharray="{circumference}" stroke-dashoffset="{offset}"
    stroke-linecap="round" transform="rotate(-90 {cx} {cy})"/>
  <text x="{cx}" y="{cy - 4}" text-anchor="middle" font-size="28" font-weight="700" fill="#1a1a1a">{int(score)}</text>
  <text x="{cx}" y="{cy + 18}" text-anchor="middle" font-size="11" fill="#888">{label}</text>
</svg>'''


def render_score_card(title: str, score: float, max_score: int, grade: str, color: str, sub: str = "") -> str:
    grade_colors = {"A": "#22c55e", "B": "#3b82f6", "C": "#f59e0b", "D": "#ef4444",
                    "低": "#22c55e", "中": "#f59e0b", "高": "#ef4444", "严重": "#dc2626"}
    gc = grade_colors.get(grade, "#888")
    sub_html = f'<div class="card-sub">{esc(sub)}</div>' if sub else ""
    return f'''<div class="score-card">
  <div class="card-header">{esc(title)}</div>
  <div class="gauge-wrap">{render_gauge_svg(score, f"{int(score)}/{max_score}", color)}</div>
  <div class="card-grade" style="color:{gc}">{esc(grade)}</div>
  {sub_html}
</div>'''


def render_section(title: str, content: str, icon: str = "") -> str:
    icon_html = f'<span class="section-icon">{icon}</span>' if icon else ""
    return f'''<div class="section">
  <h2>{icon_html}{esc(title)}</h2>
  <div class="section-body">{content}</div>
</div>'''


def render_table(headers: list[str], rows: list[list[str]]) -> str:
    thead = "<tr>" + "".join(f"<th>{esc(h)}</th>" for h in headers) + "</tr>"
    tbody = "\n".join(
        "<tr>" + "".join(f"<td>{esc(c)}</td>" for c in row) + "</tr>"
        for row in rows
    )
    return f'<table class="data-table"><thead>{thead}</thead><tbody>{tbody}</tbody></table>'


def render_badge(text: str, color: str) -> str:
    return f'<span class="badge" style="background:{color}10;color:{color};border:1px solid {color}30">{esc(text)}</span>'


def build_html(dossier: dict[str, Any], scores: dict[str, Any]) -> str:
    buyer = dossier.get("buyer", {}) or {}
    profile = dossier.get("company_profile", {}) or {}
    pricing = dossier.get("pricing_strategy", {}) or {}
    evidence = dossier.get("evidence", []) or []
    key_findings = dossier.get("key_findings", []) or []
    identity_findings = dossier.get("identity_findings", []) or []
    risk_findings = dossier.get("risk_findings", []) or []
    follow_ups = dossier.get("follow_up_actions", []) or []
    verifications = dossier.get("verification_questions", []) or []
    limitations = dossier.get("limitations", []) or []
    signals = dossier.get("signals", {}) or {}

    company_name = profile.get("legal_name") or buyer.get("company_name", "未知")
    company_name_cn = profile.get("legal_name_cn") or buyer.get("company_name_cn") or ""

    # --- Score cards ---
    value_score = scores.get("value_score", 0)
    value_grade = scores.get("value_grade", "-")
    risk_score = scores.get("risk_score", 0)
    risk_level = scores.get("risk_level", "-")
    confidence_score = scores.get("confidence_score", 0)
    confidence_level = scores.get("confidence_level", "-")
    priority = scores.get("priority", "-")
    dimensions = scores.get("dimensions", {}) or {}

    # 选第一条以 ✅ 开头的关键发现作为摘要（如果存在），否则用第一条
    summary_text = "暂无摘要"
    for kf in key_findings:
        if isinstance(kf, str) and ("✅" in kf or "极高" in kf or "高企业" in kf):
            summary_text = kf
            break
    if summary_text == "暂无摘要" and key_findings:
        summary_text = key_findings[0] if isinstance(key_findings[0], str) else str(key_findings[0])

    score_cards = f'''<div class="cards-row">
  {render_score_card("客户价值", value_score, 100, value_grade, "#22c55e", f"跟进优先级：{priority}")}
  {render_score_card("风险评分", risk_score, 100, risk_level, "#ef4444", "")}
  {render_score_card("信息置信度", confidence_score, 100, confidence_level, "#3b82f6", "")}
</div>'''

    # --- Summary ---
    summary = f'''<div class="summary-box">
  <div class="summary-label">📋 核心结论</div>
  <div class="summary-text">{esc(summary_text)}</div>
</div>'''

    # --- Identity (主体身份核验) ---
    # 兼容策略：先看 identity_findings；否则从 key_findings 提取带 ✅ 的；否则从 signals + 证据构造
    identity_items: list[str] = []
    if identity_findings:
        for it in identity_findings:
            identity_items.append(rephrase_to_zh(str(it)) if isinstance(it, str) else str(it))
    else:
        # 从 key_findings 抽取"真实性/主体/注册/邮箱/官网/成立/历史"相关结论
        identity_keywords = ("真实性", "注册", "成立", "官网", "邮箱", "身份", "历史", "家族", "GmbH", "HRB")
        for kf in key_findings:
            if not isinstance(kf, str):
                continue
            if any(kw in kf for kw in identity_keywords):
                identity_items.append(kf)
        # 兜底：再从 signals 中找真实性相关布尔信号
        if not identity_items and signals:
            for k, v in signals.items():
                if isinstance(v, bool) and v and any(kw in k for kw in ("verified", "match", "presence")):
                    label = FIELD_LABEL_ZH.get(k, k)
                    identity_items.append(f"✅ {label}：已确认")
    identity_rows = "\n".join(f"<li>{esc(it)}</li>" for it in identity_items)
    identity_html = f'<ul class="checklist">{identity_rows}</ul>' if identity_items else '<p class="empty">暂无核验结论</p>'

    # --- Profile ---
    profile_fields = [
        ("法定名称", profile.get("legal_name") or buyer.get("company_name")),
        ("中文名称", profile.get("legal_name_cn") or buyer.get("company_name_cn") or company_name_cn),
        ("商业名称", ", ".join(profile.get("trading_names", [])) if isinstance(profile.get("trading_names"), list) else profile.get("trading_names")),
        ("国家/地区", profile.get("country") or buyer.get("country")),
        ("注册地址", profile.get("address")),
        ("成立年份", profile.get("founded_year")),
        ("企业类型", profile.get("business_type")),
        ("注册号", profile.get("registration_number")),
        ("注册法院", profile.get("registration_court")),
        ("VAT 号", profile.get("vat_number")),
        ("DUNS 号", profile.get("duns_number")),
        ("员工数（约）", profile.get("employees_approx")),
        ("营收（财年 2025）", profile.get("revenue_fy2025")),
        ("营收（财年 2023）", profile.get("revenue_fy2023")),
        ("客户数（约）", profile.get("customers_approx")),
        ("全球办事处", profile.get("global_offices")),
        ("仓库分布", ", ".join(profile.get("warehouse_locations", [])) if isinstance(profile.get("warehouse_locations"), list) else profile.get("warehouse_locations")),
        ("亚洲办事处", ", ".join(profile.get("asia_offices", [])) if isinstance(profile.get("asia_offices"), list) else profile.get("asia_offices")),
        ("主营产品", ", ".join(profile.get("products", [])) if isinstance(profile.get("products"), list) else profile.get("products")),
        ("销售渠道", ", ".join(profile.get("channels", [])) if isinstance(profile.get("channels"), list) else profile.get("channels")),
        ("目标市场", ", ".join(profile.get("markets", [])) if isinstance(profile.get("markets"), list) else profile.get("markets")),
        ("认证", ", ".join(profile.get("certifications", [])) if isinstance(profile.get("certifications"), list) else profile.get("certifications")),
        ("核心连接器供应商", ", ".join(profile.get("key_connector_suppliers", [])) if isinstance(profile.get("key_connector_suppliers"), list) else profile.get("key_connector_suppliers")),
        ("官网", buyer.get("website")),
        ("联系邮箱", buyer.get("email")),
        ("联系人", buyer.get("contact_name")),
        ("联系人职位", buyer.get("contact_role")),
        ("询盘日期", buyer.get("inquiry_date")),
        ("询盘来源", buyer.get("inquiry_source")),
    ]
    profile_rows = "\n".join(
        f"<tr><td class=\"field-label\">{esc(label)}</td><td>{esc(val)}</td></tr>"
        for label, val in profile_fields if val not in (None, "", [], {})
    )
    profile_html = f'<table class="info-table"><tbody>{profile_rows}</tbody></table>'

    # --- Score breakdown ---
    dim_rows = []
    for name, dim in dimensions.items():
        if isinstance(dim, dict):
            score_v = dim.get("score", 0)
            max_v = dim.get("maximum", 0)
            pct = int(score_v / max_v * 100) if max_v else 0
            bar_color = "#22c55e" if pct >= 80 else "#3b82f6" if pct >= 60 else "#f59e0b" if pct >= 40 else "#ef4444"
            # 子项（如有）
            sub_items_html = ""
            sub_items = dim.get("sub_scores") or dim.get("items") or []
            if isinstance(sub_items, list) and sub_items:
                sub_li = "".join(
                    f"<li><span class=\"sub-label\">{esc(s.get('label', s.get('name', '')) if isinstance(s, dict) else str(s))}</span>"
                    f"<span class=\"sub-score\">{esc(str(s.get('score', '-')) if isinstance(s, dict) else '-')}</span></li>"
                    for s in sub_items
                )
                sub_items_html = f'<ul class="sub-scores">{sub_li}</ul>'
            dim_rows.append(f'''<tr>
    <td><div class="dim-name">{esc(name)}</div>{sub_items_html}</td>
    <td class="score-cell">{score_v}<span class="score-max">/{max_v}</span></td>
    <td>
      <div class="progress-bar">
        <div class="progress-fill" style="width:{pct}%;background:{bar_color}"></div>
      </div>
    </td>
  </tr>''')
    dim_table = f'<table class="score-table"><thead><tr><th>评分维度</th><th>得分</th><th>占比</th></tr></thead><tbody>{"".join(dim_rows)}</tbody></table>'

    # --- Evidence ---
    evidence_rows = []
    for i, item in enumerate(evidence, 1):
        if not isinstance(item, dict):
            continue
        claim_type = str(item.get("claim_type", "")).lower()
        ct = EVIDENCE_TYPE_ZH.get(claim_type, "📎 证据")
        # claim 兼容 claim / description / text 字段
        claim_raw = pick_field(item, ["claim", "description", "text", "statement", "finding"], "")
        claim_zh = rephrase_to_zh(claim_raw) if claim_raw else ""
        claim = esc(claim_zh)
        title = esc(item.get("title", "来源"))
        url = item.get("url", "")
        src_text = title
        if url:
            src_text = f'<a href="{esc(url)}" target="_blank">{title}</a>'
        reliability = item.get("reliability", "")
        rel_badge = f'<span class="rel-badge rel-{reliability.lower()}">{esc(reliability)}</span>' if reliability else ""
        # 来源类型中文化
        src_type = item.get("source_type", "")
        src_type_zh = SOURCE_TYPE_ZH.get(str(src_type).lower(), src_type)
        # 备注
        notes = item.get("notes", "")
        notes_zh = rephrase_to_zh(notes) if notes else ""
        notes_html = f'<div class="ev-notes">备注：{esc(notes_zh)}</div>' if notes_zh else ""
        evidence_rows.append(
            f'<div class="evidence-item"><span class="ev-num">#{i}</span>'
            f'<span class="ev-type">{ct}</span>{rel_badge}'
            f'<span class="ev-srctype">{esc(src_type_zh)}</span>'
            f'<div class="ev-claim">{claim}</div>'
            f'<div class="ev-source">来源：{src_text}</div>'
            f'{notes_html}'
            f'</div>'
        )
    evidence_html = "\n".join(evidence_rows) if evidence_rows else '<p class="empty">暂无可引用证据</p>'

    # --- Risk ---
    risk_factors = scores.get("risk_factors", []) or []
    risk_items: list[str] = []
    # 1) scores.risk_factors（脚本级风险扣分项）
    for rf in risk_factors:
        if isinstance(rf, dict):
            name = pick_field(rf, RISK_FIELD_ALIASES["name"], "风险")
            detail = pick_field(rf, RISK_FIELD_ALIASES["detail"], "")
            pts = rf.get("points", rf.get("score", 0))
            risk_items.append(
                f'<li class="risk-item risk-high"><strong>{esc(rephrase_to_zh(str(name)))}</strong> (+{pts} 分) — {esc(rephrase_to_zh(str(detail)))}</li>'
            )
    # 2) dossier.risk_findings（专家级风险发现）
    for rf in risk_findings:
        if isinstance(rf, dict):
            name = pick_field(rf, RISK_FIELD_ALIASES["name"], "风险")
            detail = pick_field(rf, RISK_FIELD_ALIASES["detail"], "")
            mitigation = pick_field(rf, RISK_FIELD_ALIASES["mitigation"], "")
            severity = str(pick_field(rf, RISK_FIELD_ALIASES["severity"], "low")).lower()
            sev_zh = SEVERITY_ZH.get(severity, severity)
            sev_class = "risk-low" if severity == "low" else "risk-mid" if severity == "medium" else "risk-high"
            name_zh = rephrase_to_zh(str(name))
            detail_zh = rephrase_to_zh(str(detail))
            mitig_html = f'<div class="risk-mitig"><strong>处置建议：</strong>{esc(rephrase_to_zh(str(mitigation)))}</div>' if mitigation else ""
            risk_items.append(f'''<li class="risk-item {sev_class}">
  <div class="risk-head"><strong>{esc(name_zh)}</strong><span class="sev-badge sev-{severity}">{esc(sev_zh)}</span></div>
  <div class="risk-detail">{esc(detail_zh)}</div>
  {mitig_html}
</li>''')
    if not risk_items:
        # 真正零风险：给一段正面陈述
        risk_items.append(
            '<li class="risk-item risk-low"><strong>未触发明确风险信号</strong> — '
            '未发现制裁、欺诈、诉讼、破产、监管处罚等权威负面记录；'
            '仍建议执行标准 KYC 与合同审核流程。</li>'
        )
    risk_html = f'<ul class="risk-list">{"".join(risk_items)}</ul>'

    # --- Pricing ---
    pricing_rows = []
    for label, key in [("报价档位", "pricing_level"), ("建议议价空间", "negotiation_space"), ("付款风控", "payment_guidance"), ("备注", "note"), ("备注", "notes")]:
        v = pricing.get(key)
        if v:
            pricing_rows.append(f"<tr><td class=\"field-label\">{label}</td><td>{esc(rephrase_to_zh(str(v)))}</td></tr>")
    conditions = pricing.get("conditions", [])
    if isinstance(conditions, list) and conditions:
        cond_html = "<ul>" + "".join(f"<li>{esc(rephrase_to_zh(str(c)))}</li>" for c in conditions) + "</ul>"
        pricing_rows.append(f"<tr><td class=\"field-label\">条件交换</td><td>{cond_html}</td></tr>")
    pricing_html = f'<table class="info-table"><tbody>{"".join(pricing_rows)}</tbody></table>' if pricing_rows else '<p class="empty">暂无报价策略</p>'

    # --- Follow-up (兼容 dict / str) ---
    follow_items: list[str] = []
    for a in follow_ups:
        if isinstance(a, dict):
            action = pick_field(a, ACTION_FIELD_ALIASES["action"], "跟进项")
            priority = pick_field(a, ACTION_FIELD_ALIASES["priority"], "MEDIUM")
            description = pick_field(a, ACTION_FIELD_ALIASES["description"], "")
            prio_zh = PRIORITY_ZH.get(str(priority).lower(), str(priority))
            prio_class = "prio-high" if str(priority).lower() in ("high", "critical", "urgent") else "prio-mid" if str(priority).lower() == "medium" else "prio-low"
            follow_items.append(
                f'<li class="follow-item {prio_class}">'
                f'<div class="follow-head"><span class="follow-action">{esc(rephrase_to_zh(str(action)))}</span>'
                f'<span class="prio-badge {prio_class}">{esc(prio_zh)}</span></div>'
                f'<div class="follow-desc">{esc(rephrase_to_zh(str(description)))}</div>'
                f'</li>'
            )
        else:
            follow_items.append(f"<li>{esc(rephrase_to_zh(str(a)))}</li>")
    follow_html = f'<ol class="follow-list">{"".join(follow_items)}</ol>' if follow_items else '<p class="empty">暂无跟进计划</p>'

    # --- Verification ---
    verify_items = [f"<li>{esc(rephrase_to_zh(str(q)))}</li>" for q in verifications]
    verify_html = f"<ul class=\"verify-list\">{' '.join(verify_items)}</ul>" if verify_items else '<p class="empty">暂无待核验问题</p>'

    # --- Sources ---
    seen: set = set()
    source_links: list[str] = []
    for item in evidence:
        if not isinstance(item, dict):
            continue
        url = item.get("url")
        if url and url not in seen:
            seen.add(url)
            title = item.get("title", "来源")
            source_links.append(f'<li><a href="{esc(url)}" target="_blank">{esc(rephrase_to_zh(str(title)))}</a></li>')
    sources_html = "<ul>" + "".join(source_links) + "</ul>" if source_links else '<p>无可访问来源</p>'

    limits_html = "<ul>" + "".join(f"<li>{esc(rephrase_to_zh(str(l)))}</li>" for l in limitations) + "</ul>" if limitations else ""

    # --- Full HTML ---
    return f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>海外客户背调报告 — {esc(company_name)}</title>
<style>
* {{ margin:0; padding:0; box-sizing:border-box; }}
body {{
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, "PingFang SC", "Microsoft YaHei", sans-serif;
  background: #f5f6f8; color: #1a1a2e; line-height:1.6;
}}
.container {{ max-width: 1100px; margin:0 auto; padding:24px 20px 60px; }}
/* Header */
.header {{
  background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
  color: #fff; padding: 40px 48px; border-radius: 16px; margin-bottom: 24px;
  position: relative; overflow: hidden;
}}
.header::after {{
  content:''; position:absolute; top:-50%; right:-10%;
  width:300px; height:300px; background:rgba(255,255,255,0.03);
  border-radius:50%; pointer-events:none;
}}
.header h1 {{ font-size:28px; font-weight:700; margin-bottom:6px; }}
.header .meta {{ font-size:14px; opacity:0.7; }}
.header .company {{ font-size:36px; font-weight:800; margin:12px 0 4px; letter-spacing:-0.5px; }}
.header .company-cn {{ font-size:18px; opacity:0.85; margin-bottom:4px; font-weight:500; }}
.header .disclaimer {{ font-size:12px; opacity:0.5; margin-top:12px; }}
/* Score cards */
.cards-row {{ display:grid; grid-template-columns:repeat(3,1fr); gap:18px; margin-bottom:24px; }}
@media (max-width:768px) {{ .cards-row {{ grid-template-columns:1fr; }} }}
.score-card {{
  background:#fff; border-radius:14px; padding:24px 20px; text-align:center;
  box-shadow:0 1px 3px rgba(0,0,0,0.06); transition:transform 0.2s;
}}
.score-card:hover {{ transform:translateY(-2px); box-shadow:0 4px 12px rgba(0,0,0,0.1); }}
.card-header {{ font-size:13px; color:#888; margin-bottom:8px; text-transform:uppercase; letter-spacing:1px; }}
.gauge-wrap {{ display:flex; justify-content:center; margin:8px 0; }}
.card-grade {{ font-size:24px; font-weight:800; margin:4px 0; }}
.card-sub {{ font-size:12px; color:#666; margin-top:4px; }}
/* Summary */
.summary-box {{
  background:linear-gradient(135deg,#eaf3de 0%,#f0f7e6 100%);
  border-left:4px solid #7cb342; border-radius:10px; padding:20px 24px; margin-bottom:24px;
}}
.summary-label {{ font-size:13px; color:#7cb342; font-weight:600; margin-bottom:6px; }}
.summary-text {{ font-size:16px; color:#2e3b23; font-weight:600; }}
/* Sections */
.section {{
  background:#fff; border-radius:14px; padding:28px 32px; margin-bottom:20px;
  box-shadow:0 1px 3px rgba(0,0,0,0.05);
}}
.section h2 {{
  font-size:18px; font-weight:700; margin-bottom:18px; padding-bottom:12px;
  border-bottom:2px solid #f0f0f0; display:flex; align-items:center; gap:8px;
}}
.section-icon {{ font-size:20px; }}
.section-body {{ }}
/* Tables */
.info-table {{ width:100%; border-collapse:collapse; }}
.info-table td {{ padding:10px 14px; border-bottom:1px solid #f5f5f5; font-size:14px; }}
.info-table .field-label {{ color:#888; width:140px; font-weight:500; white-space:nowrap; }}
.score-table {{ width:100%; border-collapse:collapse; }}
.score-table th {{ text-align:left; padding:10px 14px; font-size:12px; color:#888; text-transform:uppercase; letter-spacing:0.5px; border-bottom:2px solid #f0f0f0; }}
.score-table td {{ padding:12px 14px; border-bottom:1px solid #f5f5f5; font-size:14px; }}
.score-cell {{ font-weight:700; font-size:18px; }}
.score-max {{ font-size:13px; color:#aaa; font-weight:400; }}
.progress-bar {{ width:100%; height:8px; background:#f0f0f0; border-radius:4px; overflow:hidden; }}
.progress-fill {{ height:100%; border-radius:4px; transition:width 0.6s ease; }}
.data-table {{ width:100%; border-collapse:collapse; font-size:13px; }}
.data-table th {{ text-align:left; padding:10px 12px; background:#f9fafb; border-bottom:2px solid #e5e7eb; font-weight:600; color:#555; }}
.data-table td {{ padding:10px 12px; border-bottom:1px solid #f5f5f5; }}
/* Evidence */
.evidence-item {{
  padding:14px 16px; border-left:3px solid #e0e0e0; margin-bottom:8px;
  background:#fafafa; border-radius:0 8px 8px 0; transition:border-color 0.2s;
}}
.evidence-item:hover {{ border-left-color:#3b82f6; }}
.ev-num {{ display:inline-block; width:28px; height:28px; line-height:28px; text-align:center; background:#3b82f6; color:#fff; border-radius:6px; font-size:12px; font-weight:700; margin-right:10px; }}
.ev-type {{ font-size:12px; color:#888; margin-right:8px; }}
.ev-claim {{ font-size:14px; margin-top:6px; color:#333; }}
.ev-source {{ font-size:12px; color:#888; margin-top:4px; }}
.ev-source a {{ color:#3b82f6; text-decoration:none; }}
.ev-source a:hover {{ text-decoration:underline; }}
.rel-badge {{ display:inline-block; padding:2px 8px; border-radius:4px; font-size:11px; font-weight:600; }}
.rel-a {{ background:#e3f2fd; color:#1565c0; }}
.rel-b {{ background:#e8f5e9; color:#2e7d32; }}
.rel-c {{ background:#fff3e0; color:#e65100; }}
.rel-d {{ background:#fce4ec; color:#c62828; }}
/* Risk */
.risk-list {{ list-style:none; padding-left:0; }}
.risk-item {{
  padding:12px 16px; margin-bottom:8px; border-radius:8px; font-size:14px;
  border-left:4px solid;
}}
.risk-low {{ background:#f0fdf4; border-color:#22c55e; color:#166534; }}
.risk-mid {{ background:#fffbeb; border-color:#f59e0b; color:#92400e; }}
.risk-high {{ background:#fef2f2; border-color:#ef4444; color:#991b1b; }}
.risk-head {{ display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; gap:8px; }}
.risk-detail {{ color:inherit; opacity:0.95; line-height:1.6; }}
.risk-mitig {{ margin-top:8px; padding:8px 10px; background:rgba(255,255,255,0.55); border-radius:6px; font-size:13px; }}
.sev-badge {{ display:inline-block; padding:2px 8px; border-radius:10px; font-size:11px; font-weight:700; }}
.sev-low, .sev-info, .sev-none {{ background:#dcfce7; color:#166534; }}
.sev-medium {{ background:#fef3c7; color:#92400e; }}
.sev-high, .sev-critical {{ background:#fee2e2; color:#991b1b; }}
/* Follow-up */
.follow-list {{ list-style:none; padding-left:0; counter-reset:follow-counter; }}
.follow-item {{
  padding:12px 16px; margin-bottom:8px; border-radius:8px; background:#fafafa;
  border-left:4px solid #e0e0e0; counter-increment:follow-counter; position:relative;
}}
.follow-item::before {{
  content:counter(follow-counter); position:absolute; left:-22px; top:14px;
  width:22px; height:22px; line-height:22px; text-align:center; background:#3b82f6; color:#fff;
  border-radius:50%; font-size:12px; font-weight:700;
}}
.follow-item.prio-high {{ border-left-color:#ef4444; background:#fef2f2; }}
.follow-item.prio-mid {{ border-left-color:#f59e0b; background:#fffbeb; }}
.follow-item.prio-low {{ border-left-color:#22c55e; background:#f0fdf4; }}
.follow-head {{ display:flex; justify-content:space-between; align-items:center; gap:8px; margin-bottom:4px; }}
.follow-action {{ font-weight:700; font-size:15px; color:#1a1a2e; }}
.follow-desc {{ font-size:13px; color:#555; line-height:1.6; }}
.prio-badge {{ display:inline-block; padding:2px 10px; border-radius:10px; font-size:11px; font-weight:700; }}
.prio-badge.prio-high {{ background:#fee2e2; color:#991b1b; }}
.prio-badge.prio-mid {{ background:#fef3c7; color:#92400e; }}
.prio-badge.prio-low {{ background:#dcfce7; color:#166534; }}
/* Sub-scores */
.sub-scores {{ list-style:none; padding-left:0; margin-top:6px; font-size:12px; }}
.sub-scores li {{ display:flex; justify-content:space-between; padding:3px 0; color:#666; border-bottom:1px dashed #eee; }}
.sub-scores li:last-child {{ border-bottom:none; }}
.sub-label {{ }}
.sub-score {{ font-weight:600; color:#3b82f6; }}
.dim-name {{ font-weight:600; }}
/* Evidence extras */
.ev-srctype {{ display:inline-block; padding:2px 8px; background:#f0f0f0; color:#555; border-radius:4px; font-size:11px; margin-left:6px; }}
.ev-notes {{ font-size:12px; color:#777; margin-top:4px; padding:6px 10px; background:#fff; border-left:2px solid #e0e0e0; border-radius:4px; }}
/* Verify */
.verify-list {{ padding-left:0; list-style:none; }}
.verify-list li {{ padding:8px 12px 8px 28px; position:relative; font-size:14px; color:#333; background:#fafafa; border-radius:6px; margin-bottom:6px; }}
.verify-list li::before {{ content:'❓'; position:absolute; left:8px; top:8px; }}
/* Checklist */
.checklist {{ list-style:none; }}
.checklist li {{ padding:6px 0 6px 24px; position:relative; font-size:14px; }}
.checklist li::before {{ content:'✓'; position:absolute; left:0; color:#22c55e; font-weight:700; }}
/* Lists */
ul, ol {{ padding-left:20px; }}
li {{ font-size:14px; margin-bottom:4px; }}
/* Empty */
.empty {{ color:#aaa; font-style:italic; font-size:14px; }}
/* Badge */
.badge {{ display:inline-block; padding:3px 10px; border-radius:12px; font-size:12px; font-weight:600; }}
/* Footer */
.footer {{
  text-align:center; padding:30px 0; color:#aaa; font-size:12px;
  border-top:1px solid #eee; margin-top:20px;
}}
/* Links */
a {{ color:#3b82f6; text-decoration:none; }}
a:hover {{ text-decoration:underline; }}
/* Print */
@media print {{
  body {{ background:#fff; }}
  .section {{ box-shadow:none; border:1px solid #eee; break-inside:avoid; }}
  .header {{ background:#1a1a2e !important; -webkit-print-color-adjust:exact; }}
}}
</style>
</head>
<body>
<div class="container">

<div class="header">
  <div class="meta">海外客户智能背调报告 · {date.today().isoformat()}</div>
  <div class="company">{esc(company_name)}</div>
  {f'<div class="company-cn">{esc(company_name_cn)}</div>' if company_name_cn else ''}
  <div>{esc(profile.get("country") or buyer.get("country", ""))}</div>
  <div class="disclaimer">基于公开信息初筛，不构成法律、金融或商业征信意见。</div>
</div>

{score_cards}

{summary}

{render_section("主体身份核验", identity_html, "🔐")}

{render_section("企业画像", profile_html, "🏢")}

{render_section("评分拆解", dim_table, "📊")}

{render_section("证据清单", evidence_html, "📎")}

{render_section("风险评估", risk_html, "⚠️")}

{render_section("报价与谈判策略", pricing_html, "💰")}

{render_section("销售跟进计划", follow_html, "🎯")}

{render_section("待核验问题", verify_html, "❓")}

{render_section("调查来源与限制", f"<h3 style=\"font-size:15px;margin-bottom:10px;\">信息来源</h3>{sources_html}<h3 style=\"font-size:15px;margin:20px 0 10px;\">调查限制</h3>{limits_html}", "📚")}

<div class="footer">
  本报告由 全球买家智审 自动生成 · 仅供参考 · 不构成法律意见<br>
  生成日期：{date.today().isoformat()}
</div>

</div>
</body>
</html>'''


def main() -> int:
    parser = argparse.ArgumentParser(description="生成海外客户背调 HTML 看板。")
    parser.add_argument("dossier", help="dossier JSON")
    parser.add_argument("scores", help="评分 JSON")
    parser.add_argument(
        "--output",
        default=str(OUTPUT_DIR / "buyer-dashboard.html"),
        help=f"HTML 输出路径",
    )
    parser.add_argument(
        "--workspace",
        default=None,
        help="工作区目录（显式指定才复制到这里；不传则不复制，避免污染调用方 cwd）",
    )
    args = parser.parse_args()

    try:
        dossier = load_object(Path(args.dossier))
        scores = load_object(Path(args.scores))
        html = build_html(dossier, scores)

        # Save to primary output
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        output_path = Path(args.output)
        output_path.write_text(html, encoding="utf-8")
        sys.stdout.write(f"HTML 看板已生成：{output_path}\n")

        # 仅在显式指定 --workspace 时才复制（绝不用 os.getcwd()，避免污染专家目录）
        if args.workspace:
            workspace_dir = Path(args.workspace)
            workspace_dir.mkdir(parents=True, exist_ok=True)
            workspace_copy = workspace_dir / output_path.name
            if workspace_copy.resolve() == output_path.resolve():
                # 主输出已落在工作区，无需复制
                sys.stdout.write(f"提示：--output 与 --workspace 目标相同，跳过复制。\n")
            else:
                shutil.copy2(output_path, workspace_copy)
                sys.stdout.write(f"已同步到工作区：{workspace_copy}\n")
        else:
            sys.stdout.write("提示：未指定 --workspace，跳过工作区复制（产物仅落在主存储）。\n")

        return 0
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        sys.stderr.write(f"看板生成失败：{exc}\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
