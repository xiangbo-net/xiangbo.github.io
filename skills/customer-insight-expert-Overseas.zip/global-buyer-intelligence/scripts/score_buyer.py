#!/usr/bin/env python3
"""Calculate reproducible buyer value, risk, and evidence-confidence scores."""

from __future__ import annotations

import argparse
import json
import os
import shutil
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

# ---- 产物输出目录（用户数据隔离） ----
OUTPUT_DIR = Path.home() / ".workbuddy" / "userdata" / "wxskill" / "global-buyer-intelligence" / "output"


BOOL_SIGNAL_NAMES = {
    "official_website_verified",
    "domain_email_match",
    "registration_verified",
    "address_verified",
    "leadership_or_employee_presence",
    "recurring_demand",
    "decision_maker_match",
    "quantity_clarity",
    "timeline_clarity",
    "terms_clarity",
    "contact_role_clarity",
    "free_email",
    "domain_age_under_1_year",
    "identity_mismatch",
    "suspicious_payment_request",
    "urgency_pressure",
    "third_party_payment_request",
    "sanctions_or_high_risk_hit",
}


def load_object(path: Path) -> dict[str, Any]:
    data = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("dossier 顶层必须是 JSON 对象。")
    return data


def as_bool(value: Any) -> bool | None:
    return value if isinstance(value, bool) else None


def bool_points(value: Any, maximum: float, unknown_ratio: float = 0.35) -> float:
    parsed = as_bool(value)
    if parsed is True:
        return maximum
    if parsed is False:
        return 0.0
    return maximum * unknown_ratio


def level_points(value: Any, mapping: dict[str, float], default: float) -> float:
    key = str(value or "unknown").strip().lower()
    return mapping.get(key, default)


def add_dimension(
    dimensions: dict[str, dict[str, Any]],
    name: str,
    maximum: float,
    components: dict[str, float],
) -> None:
    score = min(max(sum(components.values()), 0.0), maximum)
    dimensions[name] = {
        "score": round(score, 1),
        "maximum": maximum,
        "components": {key: round(value, 1) for key, value in components.items()},
    }


def calculate_value(signals: dict[str, Any]) -> tuple[float, dict[str, dict[str, Any]]]:
    dimensions: dict[str, dict[str, Any]] = {}

    years = signals.get("operating_history_years")
    if isinstance(years, (int, float)) and not isinstance(years, bool):
        history_points = 4.0 if years >= 10 else 3.0 if years >= 3 else 2.0 if years > 0 else 0.0
    else:
        history_points = 1.5

    add_dimension(
        dimensions,
        "企业真实性",
        25,
        {
            "官网已核验": bool_points(signals.get("official_website_verified"), 5),
            "邮箱域名匹配": bool_points(signals.get("domain_email_match"), 4),
            "注册信息已核验": bool_points(signals.get("registration_verified"), 6),
            "地址已核验": bool_points(signals.get("address_verified"), 3),
            "团队或负责人存在": bool_points(
                signals.get("leadership_or_employee_presence"), 3
            ),
            "经营年限": history_points,
        },
    )

    add_dimension(
        dimensions,
        "企业实力",
        20,
        {
            "公司规模": level_points(
                signals.get("company_size"),
                {"none": 0, "micro": 3, "small": 6, "medium": 9, "large": 12},
                4,
            ),
            "市场覆盖": level_points(
                signals.get("market_presence"),
                {"none": 0, "local": 3, "national": 6, "international": 8},
                2,
            ),
        },
    )

    add_dimension(
        dimensions,
        "采购潜力",
        20,
        {
            "采购证据": level_points(
                signals.get("procurement_evidence"),
                {"none": 0, "weak": 2, "moderate": 5, "strong": 8},
                2,
            ),
            "预计采购规模": level_points(
                signals.get("estimated_purchase_scale"),
                {"none": 0, "micro": 1, "small": 2, "medium": 3.5, "large": 5},
                1.5,
            ),
            "重复需求": bool_points(signals.get("recurring_demand"), 4),
            "联系人接近决策链": bool_points(signals.get("decision_maker_match"), 3),
        },
    )

    common_fit = {"none": 0, "low": 1, "medium": 2, "high": 3}
    add_dimension(
        dimensions,
        "产品匹配度",
        15,
        {
            "产品相关性": level_points(
                signals.get("product_relevance"),
                {"none": 0, "low": 3, "medium": 6, "high": 9},
                3,
            ),
            "渠道匹配": level_points(signals.get("channel_fit"), common_fit, 1),
            "市场匹配": level_points(signals.get("market_fit"), common_fit, 1),
        },
    )

    add_dimension(
        dimensions,
        "长期合作价值",
        10,
        {
            "复购潜力": level_points(
                signals.get("repeat_potential"),
                {"none": 0, "low": 1, "medium": 2.5, "high": 4},
                1.2,
            ),
            "战略匹配": level_points(
                signals.get("strategic_fit"),
                {"none": 0, "low": 1, "medium": 2.5, "high": 4},
                1.2,
            ),
            "市场影响力": level_points(
                signals.get("market_influence"),
                {"none": 0, "low": 0.5, "medium": 1.2, "high": 2},
                0.6,
            ),
        },
    )

    add_dimension(
        dimensions,
        "询盘质量",
        10,
        {
            "询盘具体度": level_points(
                signals.get("inquiry_specificity"),
                {"none": 0, "low": 1.5, "medium": 3, "high": 4},
                1,
            ),
            "数量明确": bool_points(signals.get("quantity_clarity"), 2),
            "交期明确": bool_points(signals.get("timeline_clarity"), 2),
            "贸易条款明确": bool_points(signals.get("terms_clarity"), 1),
            "联系人角色明确": bool_points(signals.get("contact_role_clarity"), 1),
        },
    )

    total = round(sum(item["score"] for item in dimensions.values()), 1)
    return total, dimensions


def calculate_risk(signals: dict[str, Any]) -> tuple[int, list[dict[str, Any]]]:
    factors: list[dict[str, Any]] = []

    def add_if_true(key: str, points: int, label: str) -> None:
        if as_bool(signals.get(key)) is True:
            factors.append({"factor": label, "points": points, "signal": key})

    add_if_true("free_email", 8, "使用公共邮箱")
    add_if_true("domain_age_under_1_year", 10, "域名注册不足一年")
    add_if_true("identity_mismatch", 25, "主体身份存在明显不一致")
    add_if_true("suspicious_payment_request", 20, "存在异常付款要求")
    add_if_true("urgency_pressure", 7, "存在不合理紧迫施压")
    add_if_true("third_party_payment_request", 25, "要求向无关第三方收付款")
    add_if_true("sanctions_or_high_risk_hit", 40, "疑似命中制裁或重大高风险记录")

    adverse = str(signals.get("adverse_records") or "unknown").lower()
    adverse_points = {"none": 0, "weak": 10, "moderate": 25, "strong": 40}.get(adverse, 0)
    if adverse_points:
        factors.append(
            {"factor": f"公开负面记录：{adverse}", "points": adverse_points, "signal": "adverse_records"}
        )

    return min(sum(item["points"] for item in factors), 100), factors


def calculate_confidence(signals: dict[str, Any], evidence: Any) -> tuple[int, dict[str, Any]]:
    known = 0
    total = 0
    for key, value in signals.items():
        total += 1
        if key in BOOL_SIGNAL_NAMES:
            known += int(isinstance(value, bool))
        else:
            known += int(value not in (None, "", "unknown"))

    signal_completeness = known / total if total else 0.0
    valid_urls: list[str] = []
    if isinstance(evidence, list):
        for item in evidence:
            if isinstance(item, dict) and isinstance(item.get("url"), str):
                url = item["url"].strip()
                if urlparse(url).scheme in {"http", "https"} and urlparse(url).netloc:
                    valid_urls.append(url)
    domains = {urlparse(url).netloc.lower().removeprefix("www.") for url in valid_urls}

    source_coverage = min(len(valid_urls) / 6, 1.0)
    domain_diversity = min(len(domains) / 4, 1.0)
    score = round((signal_completeness * 0.60 + source_coverage * 0.25 + domain_diversity * 0.15) * 100)
    return score, {
        "known_signals": known,
        "total_signals": total,
        "evidence_with_url": len(valid_urls),
        "independent_domains": len(domains),
    }


def value_grade(score: float) -> str:
    return "A" if score >= 80 else "B" if score >= 65 else "C" if score >= 50 else "D"


def risk_level(score: int) -> str:
    return "严重" if score >= 70 else "高" if score >= 40 else "中" if score >= 20 else "低"


def confidence_level(score: int) -> str:
    return "高" if score >= 75 else "中" if score >= 45 else "低"


def priority(grade: str, risk: str) -> str:
    if risk == "严重":
        return "暂停并升级人工审查"
    if risk == "高":
        return "身份与风险澄清后再报价"
    if risk == "中":
        return "条件式跟进，优先补齐关键核验"
    return {
        "A": "重点优先跟进",
        "B": "正常优先跟进",
        "C": "资格确认后跟进",
        "D": "低优先级培育或暂缓",
    }[grade]


def main() -> int:
    parser = argparse.ArgumentParser(description="计算客户价值、风险和信息置信度。")
    parser.add_argument("dossier", help="结构化 dossier JSON")
    parser.add_argument(
        "--output",
        default=str(OUTPUT_DIR / "scores.json"),
        help=f"输出路径，默认输出到 {OUTPUT_DIR / 'scores.json'}",
    )
    args = parser.parse_args()

    try:
        dossier = load_object(Path(args.dossier))
        signals = dossier.get("signals")
        if not isinstance(signals, dict):
            raise ValueError("dossier.signals 必须是对象。")

        score, dimensions = calculate_value(signals)
        risk_score, risk_factors = calculate_risk(signals)
        confidence_score, confidence_details = calculate_confidence(
            signals, dossier.get("evidence")
        )
        grade = value_grade(score)
        risk = risk_level(risk_score)
        result = {
            "value_score": score,
            "value_grade": grade,
            "risk_score": risk_score,
            "risk_level": risk,
            "confidence_score": confidence_score,
            "confidence_level": confidence_level(confidence_score),
            "priority": priority(grade, risk),
            "dimensions": dimensions,
            "risk_factors": risk_factors,
            "confidence_details": confidence_details,
            "method_version": "1.0.0",
        }

        rendered = json.dumps(result, ensure_ascii=False, indent=2) + "\n"

        # 确保输出目录存在
        OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
        output_path = Path(args.output)
        output_path.write_text(rendered, encoding="utf-8")
        sys.stdout.write(f"评分已生成：{output_path}\n")

        # 双写：同步复制一份到当前工作区目录
        workspace_dir = Path(os.getcwd())
        workspace_copy = workspace_dir / output_path.name
        shutil.copy2(output_path, workspace_copy)
        sys.stdout.write(f"已同步到工作区：{workspace_copy}\n")
        return 0
    except (OSError, json.JSONDecodeError, ValueError) as exc:
        sys.stderr.write(f"评分失败：{exc}\n")
        return 2


if __name__ == "__main__":
    raise SystemExit(main())

