# 海外客户智能背调报告

> 报告日期：{{report_date}}  
> 客户：{{company_name}}  
> 调查范围：公开信息初筛，不构成法律、金融或商业征信意见。

## 一、执行摘要

- 客户价值：{{value_score}}/100（{{value_grade}}）
- 风险：{{risk_score}}/100（{{risk_level}}）
- 信息置信度：{{confidence_score}}/100（{{confidence_level}}）
- 建议优先级：{{priority}}
- 核心结论：{{executive_summary}}

## 二、主体身份核验

{{identity_verification}}

## 三、企业画像与采购潜力

{{company_profile}}

## 四、评分拆解

{{score_breakdown}}

## 五、事实、推断与未确认事项

{{evidence_findings}}

## 六、风险与交易控制

{{risk_findings}}

## 七、报价与谈判策略

{{pricing_strategy}}

## 八、销售跟进计划

{{follow_up_actions}}

## 九、待核验问题

{{verification_questions}}

## 十、来源与限制

{{sources_and_limitations}}

