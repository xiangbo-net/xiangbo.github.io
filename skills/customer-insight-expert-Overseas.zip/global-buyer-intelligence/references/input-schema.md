# 输入结构

使用 UTF-8 JSON。允许字段为空，但至少提供 `company_name`、`website` 或 `email` 之一。

```json
{
  "company_name": "ABC Trading LLC",
  "country": "United States",
  "website": "https://example.com",
  "email": "buyer@example.com",
  "contact_name": "John Smith",
  "contact_role": "Purchasing Manager",
  "product": "Outdoor furniture",
  "purchase_quantity": "500 sets",
  "specifications": "Aluminium frame",
  "target_market": "United States",
  "incoterm": "FOB Shanghai",
  "delivery_timeline": "2026 Q4",
  "inquiry": "Please quote 500 sets...",
  "attachments": [],
  "notes": "First contact from trade show"
}
```

## 输入判断

- `company_name`：保留用户原文，不擅自翻译法定名称。
- `website`：保留完整 URL；只有域名时补 `https://` 用于规范化，不代表已验证 HTTPS 可用。
- `email`：区分企业域名邮箱与公共邮箱，但公共邮箱仅是需核验信号，不是诈骗结论。
- `inquiry`：保留原文，分析时另行提取数量、规格、交期和贸易术语。
- `attachments`：记录文件名和类型，不在 JSON 中嵌入大文件内容。
- `notes`：不得把销售人员主观描述自动转成已证实事实。

## 可接受的中文别名

校验脚本同时识别：`公司名称`、`国家`、`官网`、`邮箱`、`联系人`、`联系人职位`、`产品`、`采购数量`、`规格`、`目标市场`、`贸易术语`、`交期`、`询盘`、`附件`、`备注`。

