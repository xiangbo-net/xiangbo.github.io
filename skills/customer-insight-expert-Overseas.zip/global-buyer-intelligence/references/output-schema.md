# Dossier 输出结构

`score_buyer.py` 读取以下核心字段。未确认值使用 `null` 或 `"unknown"`，不得猜测。

```json
{
  "buyer": {},
  "company_profile": {
    "legal_name": "",
    "trading_names": [],
    "country": "",
    "address": "",
    "founded_year": null,
    "business_type": "",
    "products": [],
    "channels": [],
    "markets": []
  },
  "signals": {
    "official_website_verified": null,
    "domain_email_match": null,
    "registration_verified": null,
    "address_verified": null,
    "leadership_or_employee_presence": null,
    "operating_history_years": null,
    "company_size": "unknown",
    "market_presence": "unknown",
    "procurement_evidence": "unknown",
    "estimated_purchase_scale": "unknown",
    "recurring_demand": null,
    "decision_maker_match": null,
    "product_relevance": "unknown",
    "channel_fit": "unknown",
    "market_fit": "unknown",
    "repeat_potential": "unknown",
    "strategic_fit": "unknown",
    "market_influence": "unknown",
    "inquiry_specificity": "unknown",
    "quantity_clarity": null,
    "timeline_clarity": null,
    "terms_clarity": null,
    "contact_role_clarity": null,
    "free_email": null,
    "domain_age_under_1_year": null,
    "identity_mismatch": null,
    "adverse_records": "unknown",
    "suspicious_payment_request": null,
    "urgency_pressure": null,
    "third_party_payment_request": null,
    "sanctions_or_high_risk_hit": null
  },
  "evidence": [
    {
      "claim": "",
      "claim_type": "fact",
      "title": "",
      "url": "",
      "published_at": null,
      "accessed_at": "2026-07-14",
      "source_type": "official_website",
      "reliability": "B",
      "notes": ""
    }
  ],
  "social_media_presence": {
    "linkedin": { "found": null, "url": "", "followers": null, "last_active": "", "notes": "" },
    "facebook": { "found": null, "url": "", "followers": null, "last_active": "", "notes": "" },
    "instagram": { "found": null, "url": "", "followers": null, "last_active": "", "notes": "" },
    "twitter": { "found": null, "url": "", "followers": null, "last_active": "", "notes": "" },
    "youtube": { "found": null, "url": "", "subscribers": null, "last_active": "", "notes": "" },
    "tiktok": { "found": null, "url": "", "followers": null, "last_active": "", "notes": "" }
  },
  "key_findings": [],
  "risk_findings": [],
  "pricing_strategy": {
    "pricing_level": "",
    "negotiation_space": "",
    "payment_guidance": "",
    "conditions": []
  },
  "follow_up_actions": [],
  "verification_questions": [],
  "limitations": []
}
```

布尔信号只允许 `true`、`false`、`null`。等级信号使用各脚本支持的英文枚举；无法判断时统一为 `unknown`。

### social_media_presence 字段说明

每个平台记录以下字段：
- `found`：`true`（确认存在）/ `false`（确认不存在）/ `null`（未搜索或无法判断）
- `url`：账号链接，未找到为空字符串
- `followers` / `subscribers`：粉丝/订阅数量级（`<1K` / `1K-10K` / `10K-100K` / `>100K`），无法获取时为 `null`
- `last_active`：最近活跃日期（YYYY-MM-DD 或 "未知"）
- `notes`：补充说明（如企业名与账号名不一致、疑似个人账号等）

如果某平台因目标市场特性（如 TikTok 在部分国家不可用）无需搜索，标记 `found: null` 并在 notes 中注明原因。

