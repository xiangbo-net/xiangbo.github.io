# 合规要求参考

## 适用法规

| 法规 | 适用地区 | 核心要求 |
|---|---|---|
| PIPL (个人信息保护法) | 中国 | 明确告知、最小必要、退出机制 |
| CAN-SPAM Act | 美国 | 退订入口、发件人真实地址、主题真实性 |
| GDPR | 欧盟 | 明确同意（opt-in）、数据可携权、被遗忘权 |

## 强制要求

### 1. 退订机制
- 每封邮件必须包含退订入口
- 退订方式：退订邮箱 或 退订页面 URL
- 配置位置：`config.json` → `compliance.unsubscribe_contact`

### 2. 退订名单过滤
- 发送前必须用 `suppression_list.txt` 过滤
- 名单格式：一行一个邮箱地址
- 路径：`~/.email-marketing-assistant/suppression_list.txt`

### 3. 硬退信过滤
- 发送前用 `bounce_list.txt` 过滤
- 由报告脚本自动回写
- 路径：`~/.email-marketing-assistant/bounce_list.txt`

### 4. 发件人可识别
- 页脚必须包含真实公司名称
- 不得伪造发件人身份
- 发件邮箱与配置一致

### 5. 发送同意
- 仅面向已获取发送同意的客户数据
- 若无法确认数据来源合法，应提示合规风险

## 名单维护

### 退订名单 (suppression_list.txt)
- **维护方式**：用户手动追加
- **触发场景**：收件人回复退订请求后
- **格式示例**：
```
user1@example.com
user2@example.com
user3@example.com
```

### 硬退信名单 (bounce_list.txt)
- **维护方式**：报告脚本自动回写 + 用户手动维护
- **触发场景**：发送失败且错误信息包含 bounce/rejected/not exist 等
- **格式同退订名单**

## 合规页脚示例

```
---
此邮件由 Hanhp Tech 发送。
如不愿再收到此类邮件，请回复本邮件或发送邮件至 unsubscribe@example.com 申请退订。
发件人：Hanhp Tech
地址：广东省东莞市xxx
```

## 速率建议

| 邮箱服务商 | 建议每分钟发送量 | 每日上限 |
|---|---|---|
| QQ 邮箱 | ≤ 10 | ≤ 500 |
| 163/126 | ≤ 8 | ≤ 200 |
| 腾讯企业邮 | ≤ 15 | ≤ 1000 |
| Gmail | ≤ 5 | ≤ 100 |
| Outlook | ≤ 5 | ≤ 100 |

> 新邮箱建议先小批量 2-5 封测试，逐步增加。
