# 邮件模板编写指南

## 基本格式

邮件模板使用 Markdown 格式，第一行为主题行，空行后为正文：

```markdown
Subject: {{sender_company}} - 产品推荐 for {{company}}

尊敬的 {{name}}，

您好！我是 {{sender_company}} 的 {{contact_person}}。

我们注意到 {{company}} 在 {{country}} 的 {{product}} 领域有着丰富的经验...

如感兴趣，欢迎随时联系我（{{contact_phone}}）。

此致
{{contact_person}}
```

## 占位符规则

- 格式：`{{字段名}}` 或 `{{ 字段名 }}`
- 字段名不区分大小写
- 支持中英文字段名
- 未匹配的占位符会用中性值替换（如 `Product_Name` -> `Product Name`）

## 常用占位符

### 收件人相关（来自客户数据）
| 占位符 | 说明 | 常见数据表头 |
|---|---|---|
| `{{name}}` | 收件人姓名 | name, 姓名, 联系人 |
| `{{email}}` | 收件人邮箱 | email, 邮箱 |
| `{{company}}` | 收件人公司 | company, 公司, company_name |
| `{{country}}` | 国家/国籍 | country, 国家, 国籍 |
| `{{city}}` | 城市 | city, 城市 |
| `{{phone}}` | 电话 | phone, 电话, mobile |
| `{{position}}` | 职位 | position, 职位, title |
| `{{product}}` | 产品名 | product, 产品 |

### 发件人相关（来自配置）
| 占位符 | 说明 |
|---|---|
| `{{sender_name}}` | 发件人姓名 |
| `{{company_name}}` | 发件公司名称 |
| `{{contact_person}}` | 联系人 |
| `{{contact_phone}}` | 联系电话 |
| `{{website}}` | 网站 |
| `{{address}}` | 地址 |

## 国籍/语言翻译

- 如果客户数据含 `国籍`/`国家` 字段，正文会自动翻译为目标语言
- 主题行始终保持模板原语言
- 翻译失败的条目回退为模板原文并标注

## 合规页脚

每封邮件末尾会自动追加合规页脚（不需要在模板中手动写）：

```
---
{footer_text}
```

页脚内容来自配置文件的 `compliance.footer_text`。

## 模板示例

### 中文模板

```markdown
Subject: 【{{company_name}}】合作意向 - {{product}}

{{name}} 您好，

我是 {{company_name}} 的 {{contact_person}}，了解到 {{company}} 在 {{country}} {{city}} 从事 {{product}} 相关业务，我们认为双方有较大的合作空间。

我们提供以下优势：
1. 丰富行业经验
2. 灵活定制方案
3. 快速交付能力

期待与您进一步交流。

{{contact_person}}
{{company_name}}
电话：{{contact_phone}}
```

### 英文模板

```markdown
Subject: Partnership Opportunity - {{product}} for {{company}}

Hi {{name}},

I'm {{contact_person}} from {{company_name}}. We noticed that {{company}} is involved in the {{product}} industry in {{country}}, and we believe there's significant potential for collaboration.

Here's what we offer:
1. Extensive industry experience
2. Flexible customization
3. Fast delivery

Looking forward to hearing from you.

Best regards,
{{contact_person}}
{{company_name}}
Tel: {{contact_phone}}
```
