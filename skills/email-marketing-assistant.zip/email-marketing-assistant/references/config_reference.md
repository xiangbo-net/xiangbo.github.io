# 配置文件结构参考

## 完整配置示例

```json
{
  "sender_info": {
    "company_name": "Hanhp Tech",
    "contact_person": "Hanhp",
    "contact_phone": "13800000000",
    "website": "https://example.com",
    "address": "广东省东莞市xxx"
  },
  "compliance": {
    "unsubscribe_contact": "unsubscribe@example.com",
    "footer_text": "此邮件由 Hanhp Tech 发送。如不愿再收到此类邮件，请回复本邮件申请退订。"
  },
  "data_source": {
    "type": "local_excel",
    "source_name": "/path/to/customers.xlsx",
    "runtime_prompt": false
  },
  "template_source": {
    "type": "local_md",
    "source_name": "",
    "runtime_prompt": true
  },
  "send_channel": {
    "type": "smtp",
    "smtp_config": {
      "service": "qq",
      "host": "smtp.qq.com",
      "port": 465,
      "username": "sender@qq.com",
      "password": "authorization_code",
      "password_env": "",
      "use_ssl": true
    },
    "mcp_service_config": {}
  },
  "send_rules": {
    "emails_per_minute": 10,
    "max_per_task": 500,
    "delay_seconds_between_emails": 0,
    "retry_times_on_failure": 3
  }
}
```

## 字段说明

### sender_info
| 字段 | 说明 | 必填 |
|---|---|---|
| company_name | 公司名称（用于页脚） | 是 |
| contact_person | 联系人姓名 | 是 |
| contact_phone | 联系电话 | 否 |
| website | 网站 | 否 |
| address | 地址（用于合规页脚） | 否 |

### compliance
| 字段 | 说明 | 必填 |
|---|---|---|
| unsubscribe_contact | 退订联系方式（邮箱或URL） | 是 |
| footer_text | 页脚落款文案 | 是 |

### data_source
| 字段 | 说明 | 可选值 |
|---|---|---|
| type | 数据源类型 | `local_excel` / `lekai_kb` / `mcp_service` |
| source_name | 固定数据源路径/名称 | - |
| runtime_prompt | 每次运行时手动指定 | `true` / `false` |

### template_source
| 字段 | 说明 | 可选值 |
|---|---|---|
| type | 模板源类型 | `local_md` / `lekai_kb` |
| source_name | 固定模板路径/名称 | - |
| runtime_prompt | 每次运行时手动指定 | `true` / `false` |

### send_channel.smtp_config
| 字段 | 说明 |
|---|---|
| service | 服务商标识 |
| host | SMTP 服务器地址 |
| port | 端口（SSL 通常 465，STARTTLS 通常 587） |
| username | 发件邮箱 |
| password | 授权码（非登录密码） |
| password_env | 环境变量名（设置后优先从环境变量读取） |
| use_ssl | 是否使用 SSL |

### send_rules
| 字段 | 默认值 | 说明 |
|---|---|---|
| emails_per_minute | 10 | 每分钟发送上限 |
| max_per_task | 500 | 单任务最大发送量 |
| delay_seconds_between_emails | 0 | 邮件间额外延迟（秒） |
| retry_times_on_failure | 3 | 失败重试次数 |

## SMTP 服务商预设

| 服务商 | host | port | use_ssl |
|---|---|---|---|
| QQ | smtp.qq.com | 465 | true |
| 163 | smtp.163.com | 465 | true |
| 126 | smtp.126.com | 465 | true |
| 腾讯企业邮 | smtp.exmail.qq.com | 465 | true |
| Gmail | smtp.gmail.com | 587 | false (STARTTLS) |
| Outlook | smtp-mail.outlook.com | 587 | false (STARTTLS) |
| 阿里企业邮 | smtp.qiye.aliyun.com | 465 | true |
