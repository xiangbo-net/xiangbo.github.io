---
name: email-marketing-assistant
description: >-
  企业邮件营销助手。根据客户数据（Excel/CSV/乐享知识库/MCP 服务）和邮件模板，
  批量生成个性化邮件内容，并通过 SMTP 或 MCP 服务群发。核心链路：数据获取与清洗 →
  模板学习（占位符智能匹配、国籍语言翻译）→ 交互式预览与批量修改 → 速率受控发送
  （支持暂停/续传）→ 统计报告。所有对外发送遵守合规要求（退订机制、发送同意、退订名单过滤）。
  触发词：批量发邮件、邮件营销、群发邮件、个性化邮件、邮件群发、发送开发信、邮件自动化。
agent_created: true
---

# 企业邮件营销助手

## 核心能力

1. **客户数据获取**：支持本地 Excel/CSV、乐享知识库和 MCP 服务三种数据源，智能解析客户字段（姓名、邮箱、公司、国籍等）
2. **模板智能学习**：逐字分析邮件模板中的占位符，与客户数据表头和发件人信息交叉比对，自动建立映射关系或给出中性替换方案
3. **个性化渲染与多语言翻译**：根据模板学习结果逐条渲染个性化邮件内容；若客户数据含国籍字段，自动按国籍翻译为目标语言
4. **SMTP 批量发送**：支持 QQ/163/126/腾讯企业邮/Gmail/Outlook/阿里企业邮等主流邮箱服务商，严格速率控制和失败重试机制
5. **发送报告生成**：自动生成 Excel 发送清单和 HTML 可视化统计报告（含饼图、速率曲线等）
6. **交互式可视化展示**：使用可视化组件（show_widget）在对话中实时展示模板学习映射关系、邮件内容预览、发送进度等关键信息
7. **灵活的多阶段确认机制**：支持草稿模式、发送前批量修改、发送中暂停与撤销
8. **可扩展的发送渠道架构**：插件化设计，当前内置 SMTP 驱动，预留标准化通道接口规范，可对接 AWS SES、SendGrid、Mailgun、阿里云邮件推送等

## 目录结构（三目录分离原则）

运行过程严格遵循三目录分离，**禁止跨目录写入**：

| 目录 | 路径 | 用途 | 规则 |
|---|---|---|---|
| **配置目录** | `~/.email-marketing-assistant/` | 存放 `config.json`、`suppression_list.txt`（全局退订/黑名单）、`bounce_list.txt`（硬退信名单） | 仅放配置与长期名单，不存放运行时产物 |
| **中间产物目录** | `{task_root}/email-marketing-assistant/{任务标识}/` | 存放单次任务所有中间文件（含 `sent_log.jsonl`） | 任务结束后保留供复查 |
| **最终交付目录** | `{task_root}/发送计划/{任务标识}/` | 存放 Excel 清单 + HTML 报告 | 交付给用户的可读产出 |

- `{任务标识}` 格式: `YYYYMMDD_HHMMSS_` + 6 位随机 ID
- `{task_root}` 取值：优先用当前工作空间根目录；若未打开工作空间，回退到 `~/.email-marketing-assistant/tasks/`，并在任务开始时告知用户实际落盘位置
- `{task_dir}` 指中间产物目录；正文中 `{task_dir}/emails/`、`{task_dir}/drafts/`、`{task_dir}/sent_log.jsonl` 均在此目录下

## 工作流程

### 执行前检查（任务触发时，仅验证静态可确定项）

1. 验证 `~/.email-marketing-assistant/config.json` 存在且 JSON 格式正确；不存在则进入步骤 0
2. 验证发送通道可用性（SMTP 连通性测试 / MCP 健康检查）——认证信息在 config 中，此处即可验证
3. **数据源 / 模板可访问性不在此验证**：当对应 `runtime_prompt = true` 时路径尚未提供，延后到步骤 1 / 步骤 2 拿到路径后再校验。仅当 `runtime_prompt = false` 且已配置固定 `source_name` 时，在此顺带做一次连接性检查（不拉取数据）
4. 生成任务标识，创建中间产物目录 `{task_dir}`，初始化空的 `{task_dir}/sent_log.jsonl`

### 步骤 0：配置初始化（首次运行或用户要求时执行）

**前置检查**：

1. 检查 `~/.email-marketing-assistant/config.json` 是否存在
2. 不存在：创建 `~/.email-marketing-assistant/` 目录，进入交互式配置
3. 已存在：告知用户已有配置，询问「重新配置」还是「只修改特定部分」

**交互式配置（逐项询问，不可跳过）**：

- **发件人信息**：公司名称、联系人、电话、网站（选填）、地址（选填，用于合规页脚）
- **数据源配置**：`local_excel`（推荐，最灵活）/ `lekai_kb`（乐享知识库）/ `mcp_service`；并询问每次发送时是否手动指定文件（`runtime_prompt`）
- **模板数据源配置**：同数据源类型，默认推荐 `local_md` + `runtime_prompt: true`
- **发送渠道配置**：
  - SMTP：选择服务商（QQ/163/126/腾讯企业邮/Gmail/Outlook/阿里企业邮）→ 填写邮箱与授权码 → 自动填充 host/port。授权码优先支持从环境变量读取
  - MCP 服务：填写服务标识、API Key、端点 URL
- **合规配置**：退订联系方式（退订邮箱或退订页 URL，必填）、页脚落款文案
- **发送规则确认**（展示默认值，可修改）：`emails_per_minute: 10`、`max_per_task: 500`、`delay_seconds_between_emails: 0`、`retry_times_on_failure: 3`

完成后写入 config.json，展示摘要供确认，提醒用户 `chmod 600 ~/.email-marketing-assistant/config.json` 保护凭据。

### 步骤 1：获取客户数据并清洗

**1.1 获取原始数据**

- `local_excel` + `runtime_prompt = true`：直接询问用户提供文件路径
- `local_excel` + `runtime_prompt = false`：使用 `source_name` 指定路径
- `lekai_kb`：通过乐享知识库 MCP 搜索并下载
- `mcp_service`：通过对应 MCP 获取

**1.2 数据清洗（发送合规与送达率的前提，不可跳过）**

按顺序执行并统计每步剔除量：

1. **邮箱格式校验**：剔除格式非法地址
2. **去重**：按邮箱地址去重（保留首条）
3. **退订名单过滤**：剔除命中 `~/.email-marketing-assistant/suppression_list.txt` 的地址
4. **硬退信过滤**：剔除命中 `~/.email-marketing-assistant/bounce_list.txt` 的地址

脚本：`scripts/data_cleaner.py`

**1.3 预览**：生成 `email_queue_preview.md`，展示总记录数、清洗前后数量与各步剔除明细、缺失字段统计、前 5 行示例，请求用户确认。

### 步骤 2：模板选择、学习与内容生成

**2.1 获取模板**

- `runtime_prompt = true`：直接询问用户提供模板路径
- 配置了固定模板：使用指定来源
- **禁止扫描工作空间猜测模板位置**

**2.2 模板学习（关键步骤，不可跳过）**

1. 提取模板中所有 `{{占位符}}`
2. 逐字段与客户数据表头 + 发件人信息交叉比对
3. 分类标记：精确匹配 → 正常替换；模糊可匹配 → 自动映射；无法匹配 → 给出中性替换方案
4. 生成 `template_learning_report.md`
5. 若有无法匹配项，列出建议替换词请用户确认

**2.3 国籍/语言自动翻译**

- 客户数据含 `国籍`/`国家` 字段 → 自动按国籍翻译邮件正文
- 主题行始终保持模板原语言
- 翻译失败或不确定的条目回退为模板原文，并标注「已翻译」

**2.4 生成邮件内容队列**

- 逐条渲染，每封保存为独立 `.md` 到 `{task_dir}/emails/`
- **合规页脚强制注入**：每封正文末尾自动追加退订入口 + 发件人落款
- 生成队列概览，请求用户最终确认

### 步骤 3：交互式预览与批量修改

**3.1 可视化展示**

- 按收件人分组展示每封邮件主题与正文预览
- 展示模板学习映射（占位符 → 数据字段）
- 展示统计概览（总数、各语言分布、收件人域名分布、已翻译条目数）

**3.2 发送前批量修改**

- 统一替换特定文案，支持正则全局替换、批量追加/删除头尾内容、按收件人群组单独调整
- 每次批量修改需展示 diff 并请用户确认后才生效

**3.3 草稿模式**

- 默认生成草稿（不实际发送），逐封或批量确认后才进入发送队列
- 草稿存于 `{task_dir}/drafts/`，下次任务可载入续处理
- 用户可随时退出草稿模式进入发送

### 步骤 4：执行邮件发送

运行发送脚本，严格遵守速率与重试规则。

**发送速率语义**

- 实际发送间隔 = `max(60 / emails_per_minute, delay_seconds_between_emails)` 秒/封
- 单任务发送量不超过 `max_per_task`
- 单封失败按 `retry_times_on_failure` 重试

**幂等与断点续传**

- 每封发送后，向 `{task_dir}/sent_log.jsonl` 追加一条记录：`{email, status, message_id, timestamp, error?}`
- 任务中断后重跑：读取 `sent_log.jsonl`，跳过已 `status=success` 的地址

脚本：`scripts/smtp_sender.py`

### 步骤 5：生成报告

- Excel 发送清单 `email_send_report_*.xlsx`（依赖 `openpyxl`）
- HTML 可视化统计报告 `email_send_statistics_*.html`（成功/失败饼图、发送速率曲线、失败原因分布等）
- **名单闭环回写**：将本次判定为 hard bounce 的地址去重追加到 `~/.email-marketing-assistant/bounce_list.txt`

脚本：`scripts/report_generator.py`

## 核心纪律

| 纪律 | 说明 |
|---|---|
| **初始化只做初始化** | 收集完配置后立即停止，不扫描工作空间、不猜测数据源、不预加载模板 |
| **步骤不可跳跃** | 必须按 1→2→3→4→5 顺序执行 |
| **不自动发现文件** | 即使工作空间下有 `customers.xlsx` 或 `template.md`，也不主动使用 |
| **不提前渲染发送** | 步骤 1 只做数据获取与清洗，步骤 2 只做模板学习与内容生成，步骤 3 默认草稿不发送 |
| **确认后方可发送** | 草稿模式须用户显式确认；批量修改须展示 diff 并确认 |
| **合规不可绕过** | 每封邮件必须含退订入口，命中退订名单的地址必须剔除 |
| **配置怎么说就怎么做** | 严格按 config.json 执行，不猜测、不"顺便帮用户找数据" |

## 合规要求

- **退订机制**：每封邮件正文强制含退订入口（退订邮箱或退订页），来源于合规配置
- **退订名单过滤**：发送前用 `suppression_list.txt` 过滤
- **名单维护边界**：本助手只负责发送，不接收邮件，无法自动捕获退订请求。退订地址需由用户手动追加到 `suppression_list.txt`；硬退信名单 `bounce_list.txt` 则由步骤 5 自动回写
- **发送同意**：仅面向已获取发送同意的客户数据
- **发件人可识别**：页脚含真实公司名与联系方式，不伪造发件人身份

## 配置文件结构

```json
{
  "sender_info": {
    "company_name": "", "contact_person": "", "contact_phone": "",
    "website": "", "address": ""
  },
  "compliance": {
    "unsubscribe_contact": "",
    "footer_text": ""
  },
  "data_source": {
    "type": "local_excel", "source_name": "", "runtime_prompt": false
  },
  "template_source": {
    "type": "local_md", "source_name": "", "runtime_prompt": true
  },
  "send_channel": {
    "type": "smtp",
    "smtp_config": {
      "service": "qq", "host": "", "port": 465,
      "username": "", "password": "", "password_env": "", "use_ssl": true
    },
    "mcp_service_config": {
      "service_name": "", "api_key": "", "endpoint": ""
    }
  },
  "send_rules": {
    "emails_per_minute": 10, "max_per_task": 500,
    "delay_seconds_between_emails": 0,
    "retry_times_on_failure": 3
  }
}
```

## 异常处理

- **SMTP 连接中断**：自动重试 `retry_times_on_failure` 次，仍失败则暂停并保存 `sent_log.jsonl`
- **用户中途终止**：保留所有中间文件，提示已发送/未发送数量
- **翻译失败**：回退模板原文并标注，不阻断发送

## 安全

- SMTP 密码 / API Key 存于 `~/.email-marketing-assistant/config.json`，提醒用户 `chmod 600`
- 优先支持环境变量读取凭据：`smtp_config.password_env` 指定环境变量名时，从该环境变量读取授权码，config 中不落明文
- 配置密码时使用授权码而非邮箱登录密码（QQ/163/126 等）

## 发送渠道扩展架构

插件化设计，当前内置 SMTP 驱动。新增渠道需实现统一接口：

| 方法 | 功能 |
|---|---|
| `send(email)` | 发送单封，返回成功/失败 + 消息 ID |
| `test_connection()` | 测试连通性 |
| `get_quota()` | 查询剩余配额/速率限制 |
| `validate_config(config)` | 校验认证信息有效性 |

## 脚本说明

| 脚本 | 路径 | 功能 |
|---|---|---|
| `data_cleaner.py` | `scripts/data_cleaner.py` | 客户数据清洗：邮箱校验、去重、退订/退信过滤、预览生成 |
| `smtp_sender.py` | `scripts/smtp_sender.py` | SMTP 批量发送：速率控制、断点续传、失败重试、sent_log 记录 |
| `report_generator.py` | `scripts/report_generator.py` | 发送报告：Excel 清单 + HTML 可视化统计 |
| `config_initializer.py` | `scripts/config_initializer.py` | 配置初始化：交互式收集配置、写入 config.json |
| `template_learner.py` | `scripts/template_learner.py` | 模板学习：占位符提取、字段映射、内容渲染 |

## 依赖

- Python 3.10+
- `openpyxl`（Excel 报告生成）
- 标准库：`smtplib`、`ssl`、`email`、`json`、`csv`、`re`、`pathlib`、`time`、`datetime`
