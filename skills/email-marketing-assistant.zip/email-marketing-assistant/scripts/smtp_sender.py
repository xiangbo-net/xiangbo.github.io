#!/usr/bin/env python3
"""
smtp_sender.py - SMTP 批量发送脚本
功能：速率控制、断点续传、失败重试、sent_log.jsonl 记录

用法:
  python smtp_sender.py --emails-dir <邮件目录> --config <config.json> --task-dir <任务目录>

依赖: 标准库 smtplib, ssl, email
"""

import argparse
import json
import os
import smtplib
import ssl
import sys
import time
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path


def load_config(config_path):
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_sent_log(sent_log_path):
    """加载已发送记录，返回已成功发送的邮箱集合"""
    sent_emails = set()
    if os.path.exists(sent_log_path):
        with open(sent_log_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                    if record.get('status') == 'success':
                        sent_emails.add(record['email'].lower())
                except json.JSONDecodeError:
                    continue
    return sent_emails


def append_sent_log(sent_log_path, record):
    """追加一条发送记录到 sent_log.jsonl"""
    with open(sent_log_path, 'a', encoding='utf-8') as f:
        f.write(json.dumps(record, ensure_ascii=False) + '\n')
        f.flush()


def parse_email_file(filepath):
    """
    解析邮件 Markdown 文件
    格式: 第一行为 Subject: xxx，空行后为正文
    """
    with open(filepath, 'r', encoding='utf-8') as f:
        content = f.read()

    lines = content.split('\n')
    subject = ''
    body_start = 0

    for i, line in enumerate(lines):
        if line.lower().startswith('subject:') or line.lower().startswith('主题:'):
            subject = line.split(':', 1)[1].strip()
            body_start = i + 1
            break

    # 跳过 subject 后的空行
    while body_start < len(lines) and not lines[body_start].strip():
        body_start += 1

    body = '\n'.join(lines[body_start:]).strip()
    return subject, body


def find_recipient_from_filename(filepath, cleaned_data):
    """从文件名推断收件人邮箱，或从 cleaned_data 匹配"""
    filename = Path(filepath).stem
    # 尝试直接匹配邮箱
    for record in cleaned_data:
        for key, val in record.items():
            if val and val.lower() == filename.lower():
                # 找到邮箱字段
                for k2, v2 in record.items():
                    if any(kw in k2.lower() for kw in ['email', '邮箱', 'e-mail', 'mail']):
                        return v2.strip()
    return filename


def create_smtp_connection(smtp_config):
    """创建 SMTP 连接"""
    host = smtp_config['host']
    port = smtp_config['port']
    username = smtp_config['username']

    # 密码：优先从环境变量读取
    password_env = smtp_config.get('password_env', '')
    if password_env and os.environ.get(password_env):
        password = os.environ[password_env]
    else:
        password = smtp_config.get('password', '')

    use_ssl = smtp_config.get('use_ssl', True)

    if use_ssl:
        context = ssl.create_default_context()
        server = smtplib.SMTP_SSL(host, port, context=context, timeout=30)
    else:
        server = smtplib.SMTP(host, port, timeout=30)
        server.starttls()

    server.login(username, password)
    return server


def send_single_email(server, smtp_config, recipient, subject, body):
    """发送单封邮件"""
    username = smtp_config['username']

    msg = MIMEMultipart('alternative')
    msg['From'] = username
    msg['To'] = recipient
    msg['Subject'] = subject

    # 纯文本版本
    msg.attach(MIMEText(body, 'plain', 'utf-8'))

    # 简易 HTML 版本（保留换行）
    html_body = body.replace('\n', '<br>\n')
    msg.attach(MIMEText(html_body, 'html', 'utf-8'))

    server.sendmail(username, [recipient], msg.as_string())
    return msg['Message-ID'] or ''


def main():
    parser = argparse.ArgumentParser(description='SMTP 批量邮件发送')
    parser.add_argument('--emails-dir', required=True, help='邮件内容目录 (.md 文件)')
    parser.add_argument('--config', default=os.path.expanduser('~/.email-marketing-assistant/config.json'),
                        help='配置文件路径')
    parser.add_argument('--task-dir', required=True, help='任务中间产物目录')
    parser.add_argument('--cleaned-data', required=True, help='清洗后数据 JSON 路径')
    parser.add_argument('--dry-run', action='store_true', help='仅预演，不实际发送')
    args = parser.parse_args()

    config = load_config(args.config)
    smtp_config = config['send_channel']['smtp_config']
    send_rules = config['send_rules']

    # 加载清洗后数据
    with open(args.cleaned_data, 'r', encoding='utf-8') as f:
        cleaned_data = json.load(f)

    # 加载已发送记录
    sent_log_path = os.path.join(args.task_dir, 'sent_log.jsonl')
    sent_emails = load_sent_log(sent_log_path)
    print(f'已发送记录: {len(sent_emails)} 条')

    # 收集待发送邮件文件
    email_files = sorted(Path(args.emails_dir).glob('*.md'))
    print(f'邮件文件: {len(email_files)} 个')

    # 过滤已发送的
    pending = []
    for ef in email_files:
        recipient = find_recipient_from_filename(str(ef), cleaned_data)
        if recipient.lower() in sent_emails:
            continue
        pending.append((ef, recipient))

    print(f'待发送: {len(pending)} 封')

    # 检查 max_per_task
    max_per_task = send_rules.get('max_per_task', 500)
    if len(pending) > max_per_task:
        print(f'警告: 待发送 {len(pending)} 封超过单任务上限 {max_per_task}，仅发送前 {max_per_task} 封')
        pending = pending[:max_per_task]

    if args.dry_run:
        print('\n=== Dry Run 预演 ===')
        for ef, recipient in pending[:5]:
            subject, body = parse_email_file(str(ef))
            print(f'  收件人: {recipient}')
            print(f'  主题: {subject}')
            print(f'  正文前50字: {body[:50]}...')
            print()
        print(f'共 {len(pending)} 封待发送（dry-run 模式不实际发送）')
        summary = {'success': True, 'dry_run': True, 'total': len(pending)}
        print(f'__JSON_SUMMARY__{json.dumps(summary, ensure_ascii=False)}')
        return

    # 计算发送间隔
    emails_per_minute = send_rules.get('emails_per_minute', 10)
    delay_seconds = send_rules.get('delay_seconds_between_emails', 0)
    interval = max(60.0 / emails_per_minute, delay_seconds)
    retry_times = send_rules.get('retry_times_on_failure', 3)

    print(f'发送间隔: {interval:.1f} 秒/封')
    print(f'重试次数: {retry_times}')

    # 连接 SMTP
    print('\n正在连接 SMTP 服务器...')
    try:
        server = create_smtp_connection(smtp_config)
        print(f'连接成功: {smtp_config["host"]}:{smtp_config["port"]}')
    except Exception as e:
        print(f'SMTP 连接失败: {e}')
        summary = {'success': False, 'error': str(e)}
        print(f'__JSON_SUMMARY__{json.dumps(summary, ensure_ascii=False)}')
        sys.exit(1)

    # 开始发送
    success_count = 0
    fail_count = 0
    results = []

    try:
        for i, (ef, recipient) in enumerate(pending):
            print(f'\n[{i+1}/{len(pending)}] 发送至: {recipient}')

            subject, body = parse_email_file(str(ef))

            # 发送（含重试）
            sent = False
            last_error = ''
            for attempt in range(retry_times + 1):
                try:
                    msg_id = send_single_email(server, smtp_config, recipient, subject, body)
                    sent = True
                    print(f'  ✅ 成功 (attempt {attempt+1})')
                    break
                except Exception as e:
                    last_error = str(e)
                    print(f'  ❌ 失败 (attempt {attempt+1}/{retry_times+1}): {e}')
                    if attempt < retry_times:
                        time.sleep(2)

            # 记录结果
            record = {
                'email': recipient,
                'status': 'success' if sent else 'failed',
                'message_id': msg_id if sent else '',
                'timestamp': datetime.now().isoformat(),
            }
            if not sent:
                record['error'] = last_error

            append_sent_log(sent_log_path, record)
            results.append(record)

            if sent:
                success_count += 1
            else:
                fail_count += 1

            # 速率控制
            if i < len(pending) - 1:
                time.sleep(interval)

    except KeyboardInterrupt:
        print('\n\n⚠️ 用户中断发送！已发送记录已保存。')
    finally:
        try:
            server.quit()
        except:
            pass

    # 输出摘要
    print(f'\n=== 发送完成 ===')
    print(f'成功: {success_count}')
    print(f'失败: {fail_count}')
    print(f'总计: {success_count + fail_count}')

    summary = {
        'success': True,
        'total': success_count + fail_count,
        'success_count': success_count,
        'fail_count': fail_count,
        'sent_log_path': sent_log_path,
        'results': results,
    }
    print(f'__JSON_SUMMARY__{json.dumps(summary, ensure_ascii=False)}')


if __name__ == '__main__':
    main()
