#!/usr/bin/env python3
"""
report_generator.py - 发送报告生成脚本
功能：Excel 发送清单 + HTML 可视化统计报告（饼图、速率曲线、失败原因分布）
      + 硬退信名单回写

用法:
  python report_generator.py --sent-log <sent_log.jsonl> --config <config.json> --task-dir <任务目录> --output-dir <输出目录>
"""

import argparse
import json
import os
import sys
from datetime import datetime
from pathlib import Path

try:
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
except ImportError:
    openpyxl = None


def load_sent_log(sent_log_path):
    """加载发送日志"""
    records = []
    if os.path.exists(sent_log_path):
        with open(sent_log_path, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    records.append(json.loads(line))
                except json.JSONDecodeError:
                    continue
    return records


def generate_excel_report(records, output_path):
    """生成 Excel 发送清单"""
    if openpyxl is None:
        print('警告: openpyxl 未安装，跳过 Excel 报告生成')
        return None

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = '发送清单'

    # 样式
    header_font = Font(bold=True, color='FFFFFF', size=11)
    header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
    success_fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
    fail_fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
    thin_border = Border(
        left=Side(style='thin'),
        right=Side(style='thin'),
        top=Side(style='thin'),
        bottom=Side(style='thin')
    )

    # 表头
    headers = ['序号', '收件人邮箱', '发送状态', '消息ID', '发送时间', '错误信息']
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col, value=h)
        cell.font = header_font
        cell.fill = header_fill
        cell.alignment = Alignment(horizontal='center')
        cell.border = thin_border

    # 数据
    for i, record in enumerate(records, 2):
        ws.cell(row=i, column=1, value=i - 1).border = thin_border
        ws.cell(row=i, column=2, value=record.get('email', '')).border = thin_border
        status_cell = ws.cell(row=i, column=3, value=record.get('status', ''))
        status_cell.border = thin_border
        status_cell.alignment = Alignment(horizontal='center')
        if record.get('status') == 'success':
            status_cell.fill = success_fill
        else:
            status_cell.fill = fail_fill
        ws.cell(row=i, column=4, value=record.get('message_id', '')).border = thin_border
        ws.cell(row=i, column=5, value=record.get('timestamp', '')).border = thin_border
        ws.cell(row=i, column=6, value=record.get('error', '')).border = thin_border

    # 列宽
    ws.column_dimensions['A'].width = 6
    ws.column_dimensions['B'].width = 35
    ws.column_dimensions['C'].width = 12
    ws.column_dimensions['D'].width = 30
    ws.column_dimensions['E'].width = 25
    ws.column_dimensions['F'].width = 40

    # 统计 Sheet
    ws2 = wb.create_sheet('统计摘要')
    success_count = sum(1 for r in records if r.get('status') == 'success')
    fail_count = sum(1 for r in records if r.get('status') != 'success')
    total = len(records)

    stats_data = [
        ['指标', '数值'],
        ['总发送数', total],
        ['成功数', success_count],
        ['失败数', fail_count],
        ['成功率', f'{success_count / total * 100:.1f}%' if total else 'N/A'],
        ['报告生成时间', datetime.now().strftime('%Y-%m-%d %H:%M:%S')],
    ]
    for row_idx, row_data in enumerate(stats_data, 1):
        for col_idx, val in enumerate(row_data, 1):
            cell = ws2.cell(row=row_idx, column=col_idx, value=val)
            if row_idx == 1:
                cell.font = header_font
                cell.fill = header_fill
            cell.border = thin_border

    ws2.column_dimensions['A'].width = 20
    ws2.column_dimensions['B'].width = 30

    wb.save(output_path)
    return output_path


def generate_html_report(records, output_path):
    """生成 HTML 可视化统计报告"""
    success_count = sum(1 for r in records if r.get('status') == 'success')
    fail_count = sum(1 for r in records if r.get('status') != 'success')
    total = len(records)
    success_rate = success_count / total * 100 if total else 0

    # 失败原因分布
    error_groups = {}
    for r in records:
        if r.get('status') != 'success':
            err = r.get('error', 'Unknown')
            # 简化错误信息
            if 'timeout' in err.lower() or 'timed out' in err.lower():
                err_type = '连接超时'
            elif 'auth' in err.lower() or 'login' in err.lower() or 'credential' in err.lower():
                err_type = '认证失败'
            elif 'refused' in err.lower() or 'connection' in err.lower():
                err_type = '连接被拒'
            elif 'bounce' in err.lower() or 'rejected' in err.lower():
                err_type = '被收件方拒绝'
            else:
                err_type = '其他错误'
            error_groups[err_type] = error_groups.get(err_type, 0) + 1

    # 发送时间线（按时间排序）
    timeline = sorted(records, key=lambda r: r.get('timestamp', ''))
    timeline_labels = []
    timeline_success = 0
    timeline_data = []
    for r in timeline:
        if r.get('status') == 'success':
            timeline_success += 1
        timeline_data.append(timeline_success)
        ts = r.get('timestamp', '')
        if ts:
            try:
                dt = datetime.fromisoformat(ts)
                timeline_labels.append(dt.strftime('%H:%M:%S'))
            except:
                timeline_labels.append(str(len(timeline_labels) + 1))

    # 域名分布
    domain_groups = {}
    for r in records:
        email = r.get('email', '')
        if '@' in email:
            domain = email.split('@')[1].lower()
            domain_groups[domain] = domain_groups.get(domain, 0) + 1

    # 错误分布数据
    error_labels = list(error_groups.keys()) or ['无失败']
    error_values = list(error_groups.values()) or [0]

    # 域名分布数据
    domain_labels = list(domain_groups.keys())[:10]
    domain_values = [domain_groups[d] for d in domain_labels]

    html = f'''<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>邮件发送统计报告</title>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif; background: #f5f7fa; color: #333; padding: 24px; }}
  .header {{ text-align: center; margin-bottom: 32px; }}
  .header h1 {{ font-size: 28px; color: #1a1a2e; margin-bottom: 8px; }}
  .header p {{ color: #666; font-size: 14px; }}
  .stats-grid {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 32px; }}
  .stat-card {{ background: #fff; border-radius: 12px; padding: 24px; text-align: center; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }}
  .stat-card .label {{ font-size: 13px; color: #888; margin-bottom: 8px; }}
  .stat-card .value {{ font-size: 32px; font-weight: 700; }}
  .stat-card.success .value {{ color: #52c41a; }}
  .stat-card.fail .value {{ color: #ff4d4f; }}
  .stat-card.total .value {{ color: #1890ff; }}
  .stat-card.rate .value {{ color: #722ed1; }}
  .chart-container {{ display: grid; grid-template-columns: 1fr 1fr; gap: 24px; margin-bottom: 24px; }}
  .chart-card {{ background: #fff; border-radius: 12px; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.06); }}
  .chart-card h3 {{ font-size: 16px; margin-bottom: 16px; color: #1a1a2e; }}
  .chart-card.full {{ grid-column: 1 / -1; }}
  canvas {{ max-height: 280px; }}
  .footer {{ text-align: center; margin-top: 32px; color: #999; font-size: 12px; }}
</style>
</head>
<body>
<div class="header">
  <h1>邮件发送统计报告</h1>
  <p>生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
</div>

<div class="stats-grid">
  <div class="stat-card total">
    <div class="label">总发送数</div>
    <div class="value">{total}</div>
  </div>
  <div class="stat-card success">
    <div class="label">成功</div>
    <div class="value">{success_count}</div>
  </div>
  <div class="stat-card fail">
    <div class="label">失败</div>
    <div class="value">{fail_count}</div>
  </div>
  <div class="stat-card rate">
    <div class="label">成功率</div>
    <div class="value">{success_rate:.1f}%</div>
  </div>
</div>

<div class="chart-container">
  <div class="chart-card">
    <h3>发送结果分布</h3>
    <canvas id="pieChart"></canvas>
  </div>
  <div class="chart-card">
    <h3>失败原因分布</h3>
    <canvas id="errorChart"></canvas>
  </div>
  <div class="chart-card full">
    <h3>发送进度曲线</h3>
    <canvas id="timelineChart"></canvas>
  </div>
  <div class="chart-card full">
    <h3>收件人域名分布 (Top 10)</h3>
    <canvas id="domainChart"></canvas>
  </div>
</div>

<div class="footer">
  企业邮件营销助手 · 自动生成报告
</div>

<script>
const pieData = {{
  labels: ['成功', '失败'],
  datasets: [{{
    data: [{success_count}, {fail_count}],
    backgroundColor: ['#52c41a', '#ff4d4f'],
    borderWidth: 0
  }}]
}};
new Chart(document.getElementById('pieChart'), {{
  type: 'doughnut',
  data: pieData,
  options: {{ plugins: {{ legend: {{ position: 'bottom' }} }} }}
}});

const errorData = {{
  labels: {json.dumps(error_labels, ensure_ascii=False)},
  datasets: [{{
    data: {json.dumps(error_values)},
    backgroundColor: ['#ff4d4f', '#fa8c16', '#faad14', '#13c2c2', '#1890ff', '#722ed1'],
    borderWidth: 0
  }}]
}};
new Chart(document.getElementById('errorChart'), {{
  type: 'pie',
  data: errorData,
  options: {{ plugins: {{ legend: {{ position: 'right' }} }} }}
}});

const timelineData = {{
  labels: {json.dumps(timeline_labels)},
  datasets: [{{
    label: '累计成功发送数',
    data: {json.dumps(timeline_data)},
    borderColor: '#1890ff',
    backgroundColor: 'rgba(24,144,255,0.1)',
    fill: true,
    tension: 0.3
  }}]
}};
new Chart(document.getElementById('timelineChart'), {{
  type: 'line',
  data: timelineData,
  options: {{ plugins: {{ legend: {{ display: false }} }}, scales: {{ y: {{ beginAtZero: true }} }} }}
}});

const domainData = {{
  labels: {json.dumps(domain_labels)},
  datasets: [{{
    data: {json.dumps(domain_values)},
    backgroundColor: '#1890ff',
    borderRadius: 4
  }}]
}};
new Chart(document.getElementById('domainChart'), {{
  type: 'bar',
  data: domainData,
  options: {{ indexAxis: 'y', plugins: {{ legend: {{ display: false }} }} }}
}});
</script>
</body>
</html>'''

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(html)
    return output_path


def update_bounce_list(records, bounce_list_path):
    """将硬退信地址回写到 bounce_list.txt"""
    existing = set()
    if os.path.exists(bounce_list_path):
        with open(bounce_list_path, 'r', encoding='utf-8') as f:
            existing = set(line.strip().lower() for line in f if line.strip())

    new_bounces = []
    for r in records:
        if r.get('status') != 'success':
            err = r.get('error', '').lower()
            # 判定是否为 hard bounce
            if any(kw in err for kw in ['bounce', 'rejected', 'does not exist', 'user not found',
                                         'no such user', 'invalid recipient', 'mailbox unavailable']):
                email = r.get('email', '').lower()
                if email and email not in existing:
                    new_bounces.append(email)
                    existing.add(email)

    if new_bounces:
        with open(bounce_list_path, 'a', encoding='utf-8') as f:
            for email in new_bounces:
                f.write(email + '\n')
        print(f'硬退信回写: {len(new_bounces)} 条')
        for e in new_bounces:
            print(f'  {e}')
    else:
        print('无新增硬退信地址')

    return new_bounces


def main():
    parser = argparse.ArgumentParser(description='发送报告生成')
    parser.add_argument('--sent-log', required=True, help='sent_log.jsonl 路径')
    parser.add_argument('--config', default=os.path.expanduser('~/.email-marketing-assistant/config.json'),
                        help='配置文件路径')
    parser.add_argument('--task-dir', required=True, help='任务目录')
    parser.add_argument('--output-dir', required=True, help='输出目录')
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)

    records = load_sent_log(args.sent_log)
    print(f'加载发送记录: {len(records)} 条')

    if not records:
        print('无发送记录，跳过报告生成')
        summary = {'success': False, 'error': 'no records'}
        print(f'__JSON_SUMMARY__{json.dumps(summary)}')
        return

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')

    # Excel 报告
    excel_path = os.path.join(args.output_dir, f'email_send_report_{timestamp}.xlsx')
    generate_excel_report(records, excel_path)
    print(f'Excel 报告: {excel_path}')

    # HTML 报告
    html_path = os.path.join(args.output_dir, f'email_send_statistics_{timestamp}.html')
    generate_html_report(records, html_path)
    print(f'HTML 报告: {html_path}')

    # 硬退信回写
    bounce_list_path = os.path.expanduser('~/.email-marketing-assistant/bounce_list.txt')
    new_bounces = update_bounce_list(records, bounce_list_path)

    success_count = sum(1 for r in records if r.get('status') == 'success')
    fail_count = sum(1 for r in records if r.get('status') != 'success')

    summary = {
        'success': True,
        'total': len(records),
        'success_count': success_count,
        'fail_count': fail_count,
        'excel_path': excel_path,
        'html_path': html_path,
        'new_bounces': new_bounces,
    }
    print(f'__JSON_SUMMARY__{json.dumps(summary, ensure_ascii=False)}')


if __name__ == '__main__':
    main()
