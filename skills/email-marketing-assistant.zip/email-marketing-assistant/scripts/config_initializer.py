#!/usr/bin/env python3
"""
config_initializer.py - 配置初始化脚本
功能：交互式收集配置信息，写入 config.json

用法:
  python config_initializer.py
"""

import json
import os
import sys
from pathlib import Path


# SMTP 服务商预设
SMTP_PRESETS = {
    'qq': {'host': 'smtp.qq.com', 'port': 465, 'use_ssl': True},
    '163': {'host': 'smtp.163.com', 'port': 465, 'use_ssl': True},
    '126': {'host': 'smtp.126.com', 'port': 465, 'use_ssl': True},
    'tencent_enterprise': {'host': 'smtp.exmail.qq.com', 'port': 465, 'use_ssl': True},
    'gmail': {'host': 'smtp.gmail.com', 'port': 587, 'use_ssl': False},
    'outlook': {'host': 'smtp-mail.outlook.com', 'port': 587, 'use_ssl': False},
    'ali_enterprise': {'host': 'smtp.qiye.aliyun.com', 'port': 465, 'use_ssl': True},
}


def collect_sender_info():
    """收集发件人信息"""
    print('\n=== 发件人信息 ===')
    return {
        'company_name': input('公司名称: ').strip(),
        'contact_person': input('联系人姓名: ').strip(),
        'contact_phone': input('联系电话: ').strip(),
        'website': input('网站 (选填): ').strip(),
        'address': input('地址 (选填): ').strip(),
    }


def collect_compliance():
    """收集合规配置"""
    print('\n=== 合规配置 ===')
    unsubscribe = input('退订联系方式 (退订邮箱或退订页URL，必填): ').strip()
    while not unsubscribe:
        print('退订联系方式为必填项！')
        unsubscribe = input('退订联系方式: ').strip()

    footer = input('页脚落款文案 (选填，留空使用默认): ').strip()
    if not footer:
        footer = '此邮件由发件人发送。如不愿再收到此类邮件，请通过上方退订方式申请退订。'

    return {
        'unsubscribe_contact': unsubscribe,
        'footer_text': footer,
    }


def collect_data_source():
    """收集数据源配置"""
    print('\n=== 数据源配置 ===')
    print('可选类型:')
    print('  1. local_excel - 本地 Excel/CSV (推荐)')
    print('  2. lekai_kb    - 乐享知识库')
    print('  3. mcp_service - MCP 服务')
    choice = input('选择 (1/2/3) [默认1]: ').strip() or '1'

    type_map = {'1': 'local_excel', '2': 'lekai_kb', '3': 'mcp_service'}
    ds_type = type_map.get(choice, 'local_excel')

    source_name = ''
    if ds_type == 'local_excel':
        source_name = input('默认数据文件路径 (选填，运行时可再指定): ').strip()
    elif ds_type == 'lekai_kb':
        source_name = input('乐享知识库空间名称: ').strip()

    runtime_prompt = input('每次发送时手动指定文件? (y/n) [默认y]: ').strip().lower()
    runtime_prompt = runtime_prompt != 'n'

    config = {
        'type': ds_type,
        'source_name': source_name,
        'runtime_prompt': runtime_prompt,
    }

    if ds_type == 'lekai_kb':
        config['lekai_config'] = {
            'team_id': input('团队 ID: ').strip(),
            'space_id': input('空间 ID: ').strip(),
            'team_name': input('团队名称: ').strip(),
            'space_name': input('空间名称: ').strip(),
        }

    return config


def collect_template_source():
    """收集模板源配置"""
    print('\n=== 模板数据源配置 ===')
    print('可选类型:')
    print('  1. local_md  - 本地 Markdown (推荐)')
    print('  2. lekai_kb  - 乐享知识库')
    choice = input('选择 (1/2) [默认1]: ').strip() or '1'

    type_map = {'1': 'local_md', '2': 'lekai_kb'}
    ts_type = type_map.get(choice, 'local_md')

    source_name = ''
    if ts_type == 'local_md':
        source_name = input('默认模板文件路径 (选填): ').strip()
    elif ts_type == 'lekai_kb':
        source_name = input('乐享知识库空间名称: ').strip()

    runtime_prompt = input('每次发送时手动指定模板? (y/n) [默认y]: ').strip().lower()
    runtime_prompt = runtime_prompt != 'n'

    config = {
        'type': ts_type,
        'source_name': source_name,
        'runtime_prompt': runtime_prompt,
    }

    if ts_type == 'lekai_kb':
        config['lekai_config'] = {
            'team_id': input('团队 ID: ').strip(),
            'space_id': input('空间 ID: ').strip(),
            'team_name': input('团队名称: ').strip(),
            'space_name': input('空间名称: ').strip(),
        }

    return config


def collect_send_channel():
    """收集发送渠道配置"""
    print('\n=== 发送渠道配置 ===')
    print('可选类型:')
    print('  1. SMTP       - 直接 SMTP 发送')
    print('  2. MCP 服务   - 通过 MCP 服务发送')
    choice = input('选择 (1/2) [默认1]: ').strip() or '1'

    if choice == '1':
        print('\nSMTP 服务商:')
        for i, name in enumerate(SMTP_PRESETS.keys(), 1):
            preset = SMTP_PRESETS[name]
            print(f'  {i}. {name} ({preset["host"]}:{preset["port"]})')

        name_list = list(SMTP_PRESETS.keys())
        svc_choice = input(f'选择 (1-{len(name_list)}) [默认1]: ').strip() or '1'
        try:
            idx = int(svc_choice) - 1
            service = name_list[idx]
        except (ValueError, IndexError):
            service = name_list[0]

        preset = SMTP_PRESETS[service]
        username = input('发件邮箱: ').strip()
        password = input('授权码 (非登录密码): ').strip()
        password_env = input('环境变量名 (选填，设置后从环境变量读取授权码): ').strip()

        return {
            'type': 'smtp',
            'smtp_config': {
                'service': service,
                'host': preset['host'],
                'port': preset['port'],
                'username': username,
                'password': password,
                'password_env': password_env,
                'use_ssl': preset['use_ssl'],
            },
            'mcp_service_config': {}
        }
    else:
        return {
            'type': 'mcp',
            'smtp_config': {},
            'mcp_service_config': {
                'service_name': input('服务标识: ').strip(),
                'api_key': input('API Key: ').strip(),
                'endpoint': input('端点 URL: ').strip(),
            }
        }


def collect_send_rules():
    """收集发送规则"""
    print('\n=== 发送规则 ===')
    print('(直接回车使用默认值)')

    return {
        'emails_per_minute': int(input('每分钟发送上限 [10]: ').strip() or '10'),
        'max_per_task': int(input('单任务最大发送量 [500]: ').strip() or '500'),
        'delay_seconds_between_emails': int(input('邮件间额外延迟(秒) [0]: ').strip() or '0'),
        'retry_times_on_failure': int(input('失败重试次数 [3]: ').strip() or '3'),
    }


def main():
    config_dir = os.path.expanduser('~/.email-marketing-assistant')
    config_path = os.path.join(config_dir, 'config.json')

    # 检查已有配置
    if os.path.exists(config_path):
        print(f'检测到已有配置: {config_path}')
        choice = input('重新配置? (y/n) [n]: ').strip().lower()
        if choice != 'y':
            print('保持现有配置不变。')
            return

    os.makedirs(config_dir, exist_ok=True)

    print('=' * 50)
    print('  企业邮件营销助手 - 配置初始化')
    print('=' * 50)

    config = {
        'sender_info': collect_sender_info(),
        'compliance': collect_compliance(),
        'data_source': collect_data_source(),
        'template_source': collect_template_source(),
        'send_channel': collect_send_channel(),
        'send_rules': collect_send_rules(),
    }

    # 写入配置
    with open(config_path, 'w', encoding='utf-8') as f:
        json.dump(config, f, ensure_ascii=False, indent=2)

    # 设置权限
    os.chmod(config_path, 0o600)

    print('\n' + '=' * 50)
    print('  配置完成！')
    print('=' * 50)
    print(f'配置文件: {config_path}')
    print(f'文件权限: 600 (仅所有者可读写)')
    print('\n请确认以上配置无误。如需修改，可重新运行配置或手动编辑配置文件。')


if __name__ == '__main__':
    main()
