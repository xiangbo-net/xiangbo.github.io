#!/usr/bin/env python3
"""
data_cleaner.py - 客户数据清洗脚本
功能：邮箱格式校验、去重、退订名单过滤、硬退信过滤、预览生成

用法:
  python data_cleaner.py --input <客户数据文件> --config <config.json路径> --task-dir <任务目录>

支持格式: .xlsx, .csv
"""

import argparse
import csv
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path

try:
    import openpyxl
except ImportError:
    openpyxl = None


# 邮箱格式正则（RFC 5322 简化版）
EMAIL_REGEX = re.compile(
    r'^[a-zA-Z0-9.!#$%&\'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?'
    r'(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$'
)


def load_config(config_path):
    """加载配置文件"""
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_suppression_list(filepath):
    """加载退订名单（一行一邮箱）"""
    if not os.path.exists(filepath):
        return set()
    with open(filepath, 'r', encoding='utf-8') as f:
        return set(line.strip().lower() for line in f if line.strip())


def load_bounce_list(filepath):
    """加载硬退信名单"""
    if not os.path.exists(filepath):
        return set()
    with open(filepath, 'r', encoding='utf-8') as f:
        return set(line.strip().lower() for line in f if line.strip())


def read_excel(filepath):
    """读取 Excel 文件，返回表头+数据行列表"""
    if openpyxl is None:
        raise RuntimeError("openpyxl 未安装，请运行: pip install openpyxl")
    wb = openpyxl.load_workbook(filepath, read_only=True, data_only=True)
    ws = wb.active
    rows = list(ws.iter_rows(values_only=True))
    wb.close()
    if not rows:
        return [], []
    headers = [str(h).strip() if h else '' for h in rows[0]]
    data = []
    for row in rows[1:]:
        record = {}
        for i, val in enumerate(row):
            if i < len(headers):
                record[headers[i]] = str(val).strip() if val is not None else ''
        data.append(record)
    return headers, data


def read_csv(filepath):
    """读取 CSV 文件"""
    with open(filepath, 'r', encoding='utf-8-sig') as f:
        reader = csv.DictReader(f)
        headers = reader.fieldnames or []
        data = [dict(row) for row in reader]
    return list(headers), data


def find_email_field(record):
    """在记录中查找邮箱字段（不区分大小写）"""
    for key, val in record.items():
        if key and any(kw in key.lower() for kw in ['email', '邮箱', 'e-mail', 'mail', '电邮']):
            return key, val
    return None, None


def clean_data(data, suppression_set, bounce_set):
    """
    数据清洗主流程
    返回: (cleaned_records, stats_dict)
    """
    stats = {
        'total': len(data),
        'invalid_email': 0,
        'duplicated': 0,
        'suppressed': 0,
        'bounced': 0,
        'cleaned': 0,
    }

    seen_emails = set()
    cleaned = []
    removed_details = {
        'invalid_email': [],
        'duplicated': [],
        'suppressed': [],
        'bounced': [],
    }

    for record in data:
        email_key, email_val = find_email_field(record)
        if not email_key or not email_val:
            stats['invalid_email'] += 1
            removed_details['invalid_email'].append(record)
            continue

        email = email_val.strip()
        email_lower = email.lower()

        # 1. 邮箱格式校验
        if not EMAIL_REGEX.match(email):
            stats['invalid_email'] += 1
            removed_details['invalid_email'].append(record)
            continue

        # 2. 去重
        if email_lower in seen_emails:
            stats['duplicated'] += 1
            removed_details['duplicated'].append(record)
            continue
        seen_emails.add(email_lower)

        # 3. 退订名单过滤
        if email_lower in suppression_set:
            stats['suppressed'] += 1
            removed_details['suppressed'].append(record)
            continue

        # 4. 硬退信过滤
        if email_lower in bounce_set:
            stats['bounced'] += 1
            removed_details['bounced'].append(record)
            continue

        cleaned.append(record)

    stats['cleaned'] = len(cleaned)
    return cleaned, stats, removed_details


def generate_preview(cleaned, stats, removed_details, task_dir, headers):
    """生成预览 Markdown 文件"""
    preview_path = os.path.join(task_dir, 'email_queue_preview.md')

    with open(preview_path, 'w', encoding='utf-8') as f:
        f.write('# 邮件发送队列预览\n\n')
        f.write(f'生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n\n')

        # 清洗统计
        f.write('## 数据清洗统计\n\n')
        f.write('| 步骤 | 剔除数量 | 说明 |\n')
        f.write('|---|---:|---|\n')
        f.write(f'| 原始记录 | {stats["total"]} | 导入的总记录数 |\n')
        f.write(f'| 邮箱格式校验 | {stats["invalid_email"]} | 邮箱格式非法或为空 |\n')
        f.write(f'| 去重 | {stats["duplicated"]} | 邮箱地址重复 |\n')
        f.write(f'| 退订名单过滤 | {stats["suppressed"]} | 命中退订/黑名单 |\n')
        f.write(f'| 硬退信过滤 | {stats["bounced"]} | 命中硬退信名单 |\n')
        f.write(f'| **最终可用** | **{stats["cleaned"]}** | **进入发送队列** |\n\n')

        # 缺失字段统计
        f.write('## 字段完整性统计\n\n')
        f.write('| 字段 | 非空数量 | 缺失数量 | 缺失率 |\n')
        f.write('|---|---:|---:|---:|\n')
        for h in headers:
            non_empty = sum(1 for r in cleaned if r.get(h, '').strip())
            missing = len(cleaned) - non_empty
            missing_rate = f'{missing / len(cleaned) * 100:.1f}%' if cleaned else 'N/A'
            f.write(f'| {h} | {non_empty} | {missing} | {missing_rate} |\n')

        # 前5行示例
        f.write('\n## 前 5 行示例\n\n')
        for i, record in enumerate(cleaned[:5]):
            f.write(f'### {i+1}. ')
            email_key, email_val = find_email_field(record)
            f.write(f'{email_val}\n\n')
            f.write('| 字段 | 值 |\n|---|---|\n')
            for h in headers:
                val = record.get(h, '')
                if val:
                    f.write(f'| {h} | {val} |\n')
            f.write('\n')

        f.write('---\n')
        f.write('请确认以上数据无误后回复「确认」，即可继续模板学习与内容生成。\n')

    return preview_path


def main():
    parser = argparse.ArgumentParser(description='客户数据清洗')
    parser.add_argument('--input', required=True, help='客户数据文件路径 (.xlsx/.csv)')
    parser.add_argument('--config', default=os.path.expanduser('~/.email-marketing-assistant/config.json'),
                        help='配置文件路径')
    parser.add_argument('--task-dir', required=True, help='任务中间产物目录')
    args = parser.parse_args()

    # 加载配置
    config = load_config(args.config)

    # 创建任务目录
    os.makedirs(args.task_dir, exist_ok=True)

    # 加载名单
    suppression_path = os.path.expanduser('~/.email-marketing-assistant/suppression_list.txt')
    bounce_path = os.path.expanduser('~/.email-marketing-assistant/bounce_list.txt')
    suppression_set = load_suppression_list(suppression_path)
    bounce_set = load_bounce_list(bounce_path)

    print(f'退订名单: {len(suppression_set)} 条')
    print(f'硬退信名单: {len(bounce_set)} 条')

    # 读取数据
    input_path = args.input
    if input_path.endswith('.xlsx') or input_path.endswith('.xls'):
        headers, data = read_excel(input_path)
    elif input_path.endswith('.csv'):
        headers, data = read_csv(input_path)
    else:
        print(f'错误: 不支持的文件格式: {input_path}')
        sys.exit(1)

    print(f'读取到 {len(data)} 条原始记录')

    # 清洗
    cleaned, stats, removed_details = clean_data(data, suppression_set, bounce_set)

    print(f'清洗结果:')
    print(f'  原始: {stats["total"]}')
    print(f'  邮箱非法: {stats["invalid_email"]}')
    print(f'  重复: {stats["duplicated"]}')
    print(f'  退订: {stats["suppressed"]}')
    print(f'  退信: {stats["bounced"]}')
    print(f'  最终可用: {stats["cleaned"]}')

    # 保存清洗后数据为 JSON
    cleaned_path = os.path.join(args.task_dir, 'cleaned_data.json')
    with open(cleaned_path, 'w', encoding='utf-8') as f:
        json.dump(cleaned, f, ensure_ascii=False, indent=2)
    print(f'清洗后数据已保存: {cleaned_path}')

    # 生成预览
    preview_path = generate_preview(cleaned, stats, removed_details, args.task_dir, headers)
    print(f'预览文件已生成: {preview_path}')

    # 输出 JSON 摘要供调用方解析
    summary = {
        'success': True,
        'stats': stats,
        'cleaned_count': stats['cleaned'],
        'cleaned_data_path': cleaned_path,
        'preview_path': preview_path,
        'headers': headers,
    }
    print(f'\n__JSON_SUMMARY__{json.dumps(summary, ensure_ascii=False)}')


if __name__ == '__main__':
    main()
