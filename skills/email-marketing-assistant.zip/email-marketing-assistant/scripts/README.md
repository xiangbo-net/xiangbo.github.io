# 企业邮件营销助手 - 脚本说明

## 脚本列表

| 脚本 | 功能 | 依赖 |
|---|---|---|
| `config_initializer.py` | 交互式配置初始化 | 标准库 |
| `data_cleaner.py` | 客户数据清洗（邮箱校验、去重、退订/退信过滤） | openpyxl (Excel读取) |
| `template_learner.py` | 模板学习（占位符提取、字段映射、内容渲染） | 标准库 |
| `smtp_sender.py` | SMTP 批量发送（速率控制、断点续传、重试） | 标准库 smtplib |
| `report_generator.py` | 发送报告生成（Excel + HTML 可视化） | openpyxl |

## 典型工作流

```
步骤 0: python config_initializer.py          # 首次配置
步骤 1: python data_cleaner.py --input customers.xlsx --task-dir {task_dir}
步骤 2: python template_learner.py --template template.md --data {task_dir}/cleaned_data.json --task-dir {task_dir}
步骤 3: (人工预览确认)
步骤 4: python smtp_sender.py --emails-dir {task_dir}/emails --cleaned-data {task_dir}/cleaned_data.json --task-dir {task_dir}
步骤 5: python report_generator.py --sent-log {task_dir}/sent_log.jsonl --task-dir {task_dir} --output-dir {output_dir}
```

## 配置文件

路径: `~/.email-marketing-assistant/config.json`

权限建议: `chmod 600 ~/.email-marketing-assistant/config.json`

## 名单文件

- `~/.email-marketing-assistant/suppression_list.txt` - 退订名单（一行一邮箱）
- `~/.email-marketing-assistant/bounce_list.txt` - 硬退信名单（一行一邮箱，由报告脚本自动回写）

## 依赖安装

```bash
pip install openpyxl  # Excel 读取与报告生成
```

## SMTP 速率规则

- 实际发送间隔 = `max(60 / emails_per_minute, delay_seconds_between_emails)` 秒/封
- 单任务发送量不超过 `max_per_task`
- 单封失败按 `retry_times_on_failure` 重试

## 断点续传

`sent_log.jsonl` 为 append-only 日志，每行一条 JSON 记录：
```json
{"email": "xxx@xxx.com", "status": "success", "message_id": "...", "timestamp": "2025-01-01T12:00:00"}
```

重跑时自动跳过 `status=success` 的地址。
