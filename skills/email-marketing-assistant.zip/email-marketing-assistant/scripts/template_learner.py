#!/usr/bin/env python3
"""
template_learner.py - 模板学习与内容渲染脚本
功能：占位符提取、字段映射、个性化内容渲染

用法:
  python template_learner.py --template <模板文件> --data <cleaned_data.json> --config <config.json> --task-dir <任务目录>
"""

import argparse
import json
import os
import re
import sys
from datetime import datetime
from pathlib import Path


# 占位符正则：匹配 {{字段名}} 或 {{ 字段名 }}
PLACEHOLDER_REGEX = re.compile(r'\{\{\s*([^}]+?)\s*\}\}')

# 字段别名映射表（用于模糊匹配）
FIELD_ALIASES = {
    'name': ['name', '姓名', '客户名', '联系人', 'contact_name', 'customer_name', 'recipient_name'],
    'email': ['email', '邮箱', 'e-mail', 'mail', '电邮', 'email_address', 'email_address_'],
    'company': ['company', '公司', '公司名称', 'company_name', 'org', 'organization', '企业'],
    'phone': ['phone', '电话', '手机', 'mobile', 'tel', 'contact_phone', 'telephone'],
    'country': ['country', '国家', '国籍', 'nation', 'nationality', 'region'],
    'city': ['city', '城市', 'city_name'],
    'product': ['product', '产品', '产品名', 'product_name', 'item'],
    'position': ['position', '职位', 'title', 'job_title', 'role'],
    'website': ['website', '网址', '官网', 'site', 'url', 'homepage'],
    'address': ['address', '地址', 'addr'],
    'date': ['date', '日期', 'today', '当前日期'],
    'sender_name': ['sender_name', '发件人', 'sender', 'from_name'],
    'company_name': ['company_name', '发件公司', 'sender_company', 'our_company', '我方公司'],
    'contact_person': ['contact_person', '发件人姓名', 'sender_person'],
    'contact_phone': ['contact_phone', '发件人电话', 'sender_phone'],
}


def load_config(config_path):
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def load_template(template_path):
    with open(template_path, 'r', encoding='utf-8') as f:
        return f.read()


def load_data(data_path):
    with open(data_path, 'r', encoding='utf-8') as f:
        return json.load(f)


def extract_placeholders(template_content):
    """提取模板中所有占位符"""
    matches = PLACEHOLDER_REGEX.findall(template_content)
    # 去重保持顺序
    seen = set()
    placeholders = []
    for m in matches:
        key = m.strip()
        if key not in seen:
            seen.add(key)
            placeholders.append(key)
    return placeholders


def normalize_field_name(name):
    """标准化字段名用于比较"""
    return name.lower().strip().replace(' ', '_').replace('-', '_')


def match_placeholder(placeholder, data_headers, sender_info):
    """
    将占位符与数据字段/发件人信息匹配
    返回: (match_type, source, field_name)
      match_type: 'exact' | 'fuzzy' | 'unmatched'
      source: 'data' | 'sender'
      field_name: 匹配到的字段名
    """
    ph_norm = normalize_field_name(placeholder)

    # 1. 精确匹配数据表头
    for header in data_headers:
        if normalize_field_name(header) == ph_norm:
            return 'exact', 'data', header

    # 2. 精确匹配发件人信息
    for key, val in sender_info.items():
        if normalize_field_name(key) == ph_norm:
            return 'exact', 'sender', key

    # 3. 模糊匹配 - 通过别名表
    for canonical, aliases in FIELD_ALIASES.items():
        if ph_norm in [normalize_field_name(a) for a in aliases]:
            # 在数据表头中找对应字段
            for header in data_headers:
                header_norm = normalize_field_name(header)
                if header_norm in [normalize_field_name(a) for a in aliases]:
                    return 'fuzzy', 'data', header
            # 在发件人信息中找
            for key in sender_info:
                key_norm = normalize_field_name(key)
                if key_norm in [normalize_field_name(a) for a in aliases]:
                    return 'fuzzy', 'sender', key

    # 4. 模糊匹配 - 包含关系
    for header in data_headers:
        if ph_norm in normalize_field_name(header) or normalize_field_name(header) in ph_norm:
            return 'fuzzy', 'data', header

    return 'unmatched', None, None


def learn_template(template_content, data_headers, sender_info):
    """
    模板学习主函数
    返回: (mappings, report_text)
    """
    placeholders = extract_placeholders(template_content)

    mappings = {}
    exact_count = 0
    fuzzy_count = 0
    unmatched_count = 0
    unmatched_list = []

    for ph in placeholders:
        match_type, source, field_name = match_placeholder(ph, data_headers, sender_info)
        mappings[ph] = {
            'type': match_type,
            'source': source,
            'field': field_name,
        }
        if match_type == 'exact':
            exact_count += 1
        elif match_type == 'fuzzy':
            fuzzy_count += 1
        else:
            unmatched_count += 1
            unmatched_list.append(ph)

    # 生成学习报告
    report_lines = [
        '# 模板学习报告',
        '',
        f'生成时间: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}',
        '',
        '## 占位符映射结果',
        '',
        f'- 总占位符数: {len(placeholders)}',
        f'- 精确匹配: {exact_count}',
        f'- 模糊匹配: {fuzzy_count}',
        f'- 无法匹配: {unmatched_count}',
        '',
        '## 详细映射',
        '',
        '| 占位符 | 匹配类型 | 来源 | 映射字段 |',
        '|---|---|---|---|',
    ]

    for ph in placeholders:
        m = mappings[ph]
        type_emoji = {'exact': 'OK', 'fuzzy': '~', 'unmatched': 'X'}[m['type']]
        report_lines.append(f'| `{{{{{ph}}}}}` | {type_emoji} {m["type"]} | {m["source"] or "-"} | {m["field"] or "-"} |')

    if unmatched_list:
        report_lines.append('')
        report_lines.append('## 无法匹配的占位符')
        report_lines.append('')
        report_lines.append('以下占位符未找到对应数据字段，建议提供替换值：')
        report_lines.append('')
        for ph in unmatched_list:
            # 中性替换建议
            suggestion = ph.replace('_', ' ').title()
            report_lines.append(f'- `{{{{{ph}}}}}` -> 建议替换为: "{suggestion}"')

    report_lines.append('')
    report_lines.append('---')
    report_lines.append('请确认以上映射无误。如有无法匹配的占位符，请提供替换值。')

    return mappings, '\n'.join(report_lines)


def get_field_value(record, sender_info, mapping):
    """根据映射获取字段值"""
    if mapping['type'] == 'unmatched':
        # 使用占位符本身作为默认值
        return None

    if mapping['source'] == 'data':
        return record.get(mapping['field'], '')
    elif mapping['source'] == 'sender':
        return sender_info.get(mapping['field'], '')
    return None


def render_email(template_content, record, sender_info, mappings, compliance):
    """
    渲染单封邮件
    返回: (subject, body_with_footer)
    """
    # 替换占位符
    rendered = template_content
    for ph, mapping in mappings.items():
        value = get_field_value(record, sender_info, mapping)
        if value is None:
            # 无法匹配的占位符，用中性值替换
            value = ph.replace('_', ' ').title()
        rendered = rendered.replace(f'{{{{{ph}}}}}', str(value))

    # 分离主题和正文
    lines = rendered.split('\n')
    subject = ''
    body_start = 0
    for i, line in enumerate(lines):
        if line.lower().startswith('subject:') or line.lower().startswith('主题:'):
            subject = line.split(':', 1)[1].strip()
            body_start = i + 1
            break

    while body_start < len(lines) and not lines[body_start].strip():
        body_start += 1

    body = '\n'.join(lines[body_start:]).strip()

    # 注入合规页脚
    footer = f'\n\n---\n{compliance["footer_text"]}'
    body_with_footer = body + footer

    return subject, body_with_footer


def main():
    parser = argparse.ArgumentParser(description='模板学习与内容渲染')
    parser.add_argument('--template', required=True, help='模板文件路径')
    parser.add_argument('--data', required=True, help='清洗后数据 JSON')
    parser.add_argument('--config', default=os.path.expanduser('~/.email-marketing-assistant/config.json'),
                        help='配置文件路径')
    parser.add_argument('--task-dir', required=True, help='任务目录')
    args = parser.parse_args()

    config = load_config(args.config)
    sender_info = config.get('sender_info', {})
    compliance = config.get('compliance', {'footer_text': '', 'unsubscribe_contact': ''})

    template_content = load_template(args.template)
    data = load_data(args.data)

    if not data:
        print('错误: 无可用数据')
        sys.exit(1)

    # 获取数据表头
    headers = list(data[0].keys())

    # 模板学习
    mappings, report_text = learn_template(template_content, headers, sender_info)

    # 保存学习报告
    report_path = os.path.join(args.task_dir, 'template_learning_report.md')
    with open(report_path, 'w', encoding='utf-8') as f:
        f.write(report_text)
    print(f'模板学习报告: {report_path}')

    # 创建邮件输出目录
    emails_dir = os.path.join(args.task_dir, 'emails')
    os.makedirs(emails_dir, exist_ok=True)

    # 渲染邮件
    rendered_count = 0
    for record in data:
        # 查找邮箱
        email = ''
        for key, val in record.items():
            if key and any(kw in key.lower() for kw in ['email', '邮箱', 'e-mail', 'mail']):
                email = val.strip()
                break

        if not email:
            continue

        subject, body = render_email(template_content, record, sender_info, mappings, compliance)

        # 保存为 .md 文件
        safe_email = email.replace('/', '_').replace('\\', '_')
        email_path = os.path.join(emails_dir, f'{safe_email}.md')
        with open(email_path, 'w', encoding='utf-8') as f:
            f.write(f'Subject: {subject}\n\n{body}')

        rendered_count += 1

    print(f'已渲染 {rendered_count} 封邮件到: {emails_dir}')

    # 统计映射
    exact = sum(1 for m in mappings.values() if m['type'] == 'exact')
    fuzzy = sum(1 for m in mappings.values() if m['type'] == 'fuzzy')
    unmatched = sum(1 for m in mappings.values() if m['type'] == 'unmatched')

    summary = {
        'success': True,
        'total_placeholders': len(mappings),
        'exact_matches': exact,
        'fuzzy_matches': fuzzy,
        'unmatched': unmatched,
        'rendered_emails': rendered_count,
        'emails_dir': emails_dir,
        'report_path': report_path,
        'mappings': mappings,
    }
    print(f'__JSON_SUMMARY__{json.dumps(summary, ensure_ascii=False)}')


if __name__ == '__main__':
    main()
