---
name: wx-customer-insight-report
description: 客户洞察与售前报告助手。输入目标公司名称，自动完成企业调研（企查查 MCP 优先）、工商信息核验、风险扫描、痛点分析、ToB 售前匹配方案与沟通策略，输出MD+HTML双格式报告。触发词：客户洞察、售前报告、客户分析、企业调研、售前备战、客户调研、背调、背景调查、customer insight、pre-sales report
author: wx
agent_created: true
version: 4.0.0
---

# 客户洞察与售前报告（wx-customer-insight-report）

## 概述

**售前客户洞察与匹配分析工具。** 输入目标公司名称，自动完成企业工商信息调研、司法风险扫描、线上表现分析、客户与合作伙伴分析、技术能力评估、资质与专利盘点、业务痛点分析、合作机会洞察、解决方案匹配、竞争格局对比、投入产出预估及售前沟通策略，输出完整的客户洞察 + 售前报告（16 章节 + 可选模块）。

数据源优先走企查查 MCP（股东结构、司法风险、税务异常、行政处罚等），断连时自动降级为网页搜索。

**核心流程**：配置检查 → 目标公司调研+风险扫描 → 报告内容生成 → 文件输出 → 交付与后续引导

---

## 跨平台兼容约定

本 Skill 需要在 macOS 和 Windows 上同等工作。以下规则须严格遵守：

### 路径写法规则

| 场景 | 处理方式 |
|------|---------|
| SKILL.md 中的路径引用 | 使用 Unix 风格 `/` 作为文档路径写法（如 `~/.workbuddy/userdata/`），WorkBuddy 统一处理路径映射 |
| 脚本调用命令 | macOS 用 `python3`，Windows 用 `python`。在 SKILL.md 指令中以 `python3` 为默认写法，但在代码块注释中标注 `// Windows 下将 python3 替换为 python` |
| Python 脚本内路径拼接 | 全部使用 `os.path.join()`，**禁止**硬编码 `/` 或 `\\` 分隔符 |
| 用户目录展开 | 使用 `os.path.expanduser("~/.workbuddy/...")` 而非硬编码绝对路径 |
| 临时目录 | 使用 `tempfile.gettempdir()` 跨平台临时目录，**禁止**硬写 `/tmp/` |
| 文件名过滤 | 同时过滤 Windows + macOS 非法字符：`\/:*?"<>|` |

### 脚本执行兼容

```python
# macOS:
python3 scripts/generate_report.py data.json config.json ./output

# Windows (PowerShell):
python scripts\generate_report.py data.json config.json .\output

# Windows (CMD):
python scripts\generate_report.py data.json config.json .\output
```

### 文件打开编码

所有文件读写均使用 `encoding="utf-8"`（Python 默认在 Windows 上可能使用系统编码，必须显式指定）。

---

## P0 — 触发条件与入口话术

**触发条件**：用户输入"帮我研究一下/调研一下/分析一下 XX公司"、"做一份关于 XX 的客户洞察报告"、"准备 XX 的售前材料"、或类似意图。

**入口话术**：
- 自动执行 Phase 1 配置检查
- 如果用户只给了公司名，直接进入 Phase 1 调研
- 如果用户除了公司名还给出了具体要求（如"重点看他们的采购系统"），记录该偏好并在报告中体现

---

## P1 — 配置检查与首次配置

### 流程

1. **检查 config.json**
   - 路径：`~/.workbuddy/userdata/skill/wx-customer-insight-report/config.json`（跨平台，`os.path.expanduser()` 解析）（跨平台，WorkBuddy 统一处理 `~` 和 `.workbuddy` 的映射）
   - 实际文件路径使用 Python 的 `os.path.expanduser()` 解析，确保 macOS 和 Windows 均能正确展开
   - 存在且有效 → 读取配置，跳过首次配置
   - 不存在或关键字段为空 → 执行首次配置流程

2. **首次配置（一次性收拢）**
   - **原则**：一次性收集所有信息，不分步追问
   - 输出以下信息收集请求：

```
首次使用需要配置你的公司/产品信息，以后无需重复。

请一次性提供以下信息（可以直接写，也可以上传公司介绍文档/官网链接等，我来提取）：

① 你的公司/团队名称
② 一句话介绍你们是做什么的
③ 核心产品/服务清单
   每个产品请包含：名称 + 它能解决什么问题 + 适用场景
   示例：
     · 智能客服系统：自动化处理80%客户咨询，适合电商/服务行业
     · 数据分析平台：一键数据看板+AI洞察，适合零售/制造企业
④ 典型客户案例（可选）
⑤ 联系方式
⑥ 除了默认报告内容外，还有没有特别想了解的客户信息？
   可选模块：技术栈评估
   也可以自定义其他模块

以上信息将保存至配置文件，后续使用无需重复输入。
```

3. **用户回复后执行**
   - 一次性解析提取结构化数据
   - 如果信息不足，**只补充追问一次**，不再反复
   - 解析完成后询问用户确认
   - 确认后写入 `config.json`

4. **用户上传文档/链接时的处理**
   - 用户上传公司介绍文档或官网链接 → 读取并自动提取关键信息（公司名、产品、客户等）
   - 将提取结果展示给用户确认后写入配置

### config.json 结构

路径：`~/.workbuddy/userdata/skill/wx-customer-insight-report/config.json`（跨平台，`os.path.expanduser()` 解析）

```json
{
  "my_company": {
    "name": "",
    "tagline": "",
    "products": [
      {
        "name": "",
        "description": "",
        "core_value": "",
        "target_scenario": ""
      }
    ],
    "typical_clients": "",
    "contact": "",
    "positioning_summary": "一句话定位描述，用于竞争格局章节"
  },
  "custom_modules": [
    {
      "id": "tech_stack",
      "name": "技术栈评估",
      "description": "客户使用的技术平台、开发语言、云服务等",
      "enabled": false
    }
  ],
  "report_preferences": {
    "language": "zh-CN",
    "always_pdf": false
  },
  "_version": 1
}
```

### 用户操作接口（使用中随时触发）

| 用户说 | 响应 |
|--------|------|
| "更新一下我的公司信息" | 重新执行配置收集流程 |
| "帮我加一个看xx的模块" | 询问模块名称和描述，写入 config.custom_modules，告知下次生效 |
| "我要启用xx模块" / "取消xx模块" | 修改对应模块 `enabled` 状态 |
| "看看我有哪些自定义模块" | 列出所有模块及启用状态 |
| "帮我加一个看xx的模块，这次就要" | 写入配置 + 在当前报告中即时生效 |
| "以后xx行业的报告都自动加xx" | 记录规则到 memory.md |

---

## P2 — 记忆文件读取与应用

### 路径

`~/.workbuddy/userdata/skill/wx-customer-insight-report/memory.md`（跨平台，`os.path.expanduser()` 解析）

### 每次启动时的操作

1. 检测 memory.md 是否存在
2. 存在 → 读取并加载所有记忆记录
3. 在 Phase 1 开始前输出："检测到记忆文件，共有 N 条记忆记录"
4. 自动应用记忆中的偏好和规则（如默认启用的模块、行业偏好等）
5. 在合适环节提示"根据记忆，已启用xx模块"

### memory.md 结构

```markdown
# 客户洞察 Skill 记忆库

## 行业偏好
- （自动记录，AI 主动发现后询问用户确认）

## 客户分析偏好
- （自动记录，AI 主动发现后询问用户确认）

## 常用自定义模块
- （用户已启用哪些模块）

## 使用习惯
- （输出格式偏好、是否总生成 PDF 等）

## 重要经验
- （沟通过程中用户明确让记住的事项）
```

---

## P3 — 目标公司调研 + 风险扫描

### 执行流程

```
1. 检测 qcc-company 和 qcc-risk connector 状态
   ├── 已连接 → 执行 A（企查查全量调研）
   └── 断开 → 执行 B（网页搜索降级）

2. 合并调研数据与风险数据
3. 输出统一的数据汇总 JSON（report_data.json）
```

### A — 企查查 MCP 全量调研（connector 已连接时）

先通过 `mcp__qcc-company__get_company_by_query` 搜索公司，获取准确的公司名和 ID，再调用以下接口：

| 类别 | MCP 接口 | 获取内容 |
|------|----------|---------|
| 工商信息 | `mcp__qcc-company__get_company_profile` | 基本概况 |
| 工商信息 | `mcp__qcc-company__get_company_registration_info` | 注册信息 |
| 股权信息 | `mcp__qcc-company__get_shareholder_info` | 股东结构 |
| 人员信息 | `mcp__qcc-company__get_key_personnel` | 核心团队 |
| 分支机构 | `mcp__qcc-company__get_branches` | 分公司/子公司 |
| 对外投资 | `mcp__qcc-company__get_external_investments` | 投资布局 |
| 📌 风险 | `mcp__qcc-risk__get_company_risk_scan` | 风险全览 |
| 📌 风险 | `mcp__qcc-risk__get_judicial_documents` | 司法文书 |
| 📌 风险 | `mcp__qcc-risk__get_dishonest_info` | 失信信息 |
| 📌 风险 | `mcp__qcc-risk__get_administrative_penalty` | 行政处罚 |
| 📌 风险 | `mcp__qcc-risk__get_tax_abnormal` | 税务异常 |
| 📌 风险 | `mcp__qcc-risk__get_equity_freeze` | 股权冻结 |
| 年报 | `mcp__qcc-company__get_annual_reports` | 年报（参考纳税评级）|

**并行调用策略**：工商信息类调用可并行，风险类可并行，两类之间可并行。一次性发出所有 MCP 调用，等待结果合并。

### B — 网页搜索降级（connector 断开时）

走 WebSearch 替代，搜索词如下：

**调研搜索**（4 组，尽可能并行）：
| S1 | `<公司全称> 工商信息 主营业务 注册` |
| S2 | `<公司全称> 产品 客户 合作` |
| S3 | `<公司全称> 招聘 员工 团队` |
| S4 | `<公司全称> 新闻 最新动态 2026` |

**风险搜索**（3 组，尽可能并行）：
| R1 | `<公司全称> 诉讼 被执行人 失信` |
| R2 | `<公司全称> 行政处罚 税务 异常` |
| R3 | `<公司全称> 负面新闻 投诉 纠纷` |

**线上表现搜索**（3 组，尽可能并行，与调研/风险搜索并行执行）：
| O1 | `<公司全称> 官网` |
| O2 | `<公司全称> 微信公众号 抖音 社交媒体` |
| O3 | `<公司全称> 客户评价 口碑 媒体报道` |

尝试用 WebFetch 抓取**百度百科**、**爱企查/企查查公开页**、**BOSS直聘/拉勾**等招聘网站、**中国裁判文书网**、**信用中国**等详情页补充信息。

若有发现官网链接，用 WebFetch 抓取官网首页及"关于我们"页面，提取定位描述、产品服务、联系方式等信息。

**重要**：降级模式下，信息可能不完整，需在报告中备注"本报告信息来源于有限公开渠道，部分数据可能不完整"。

### C — 双重兜底

- 基于已有信息继续生成报告
- 在报告中标注："*本报告信息来源于有限公开渠道，数据可能不完整，建议进一步核实*"

### 调研数据汇总格式

调研+风险合并后，构建以下 JSON 结构（后续供报告生成脚本使用）：

```json
{
  "company_name": "目标公司全称",
  "research_source": "qichacha | websearch | limited",
  "basic_info": { "公司名称": "", "统一社会信用代码": "", "法定代表人": "", "注册资本": "", "成立日期": "", "注册地址": "" },
  "business": { "主营业务": "...", "行业分类": "...", "竞争格局": "..." },
  "shareholder_structure": "",
  "key_personnel": [],
  "branches": [],
  "swto": { "S": [], "W": [], "O": [], "T": [] },
  "risks": {
    "overall_level": "🟢",
    "suggestion": "",
    "source": "qichacha | websearch",
    "items": [
      { "category": "司法风险", "item": "诉讼记录", "level": "🟡", "detail": "...", "source": "..." }
    ]
  },

  "--- 以下为默认模块数据（调研数据 + AI 分析） ---": "",

  "patent_info": [
    { "type": "专利|商标|资质|认证", "name": "名称", "number": "编号/申请号", "status": "有效|无效|审查中", "date": "获取日期" }
  ],
  "client_partners": {
    "major_clients": ["主要客户名称"],
    "upstream_partners": ["上游供应商"],
    "downstream_partners": ["下游客户"],
    "strategic_partners": ["战略合作伙伴"]
  },
  "brand_reputation": {
    "overall_sentiment": "正面|中性|负面",
    "media_coverage": "媒体覆盖情况描述",
    "customer_reviews": "客户评价摘要",
    "notable_events": ["重要舆情事件"]
  },

  "--- 以下为通用分析字段（AI 基于调研数据动态生成，skill 中无业务预设） ---": "",

  "online_presence": {
    "website": {
      "url": "官网地址",
      "positioning": "官网定位描述",
      "features": ["核心产品/服务"],
      "tech_tags": ["官网技术栈"]
    },
    "social_media": [
      { "platform": "微信|抖音|小红书|微博", "account": "账号名", "active": true }
    ],
    "search_visibility": "搜索引擎可见度描述",
    "reputation_summary": "线上口碑综合评价"
  },
  "tech_assessment": [
    {
      "dimension": "能力维度名（如硬件设计 / 企业IT / AI人才等）",
      "level": 3,
      "max_level": 5,
      "ai_space": "AI 赋能方向描述"
    }
  ],
  "collaboration_opportunities": [
    {
      "title": "机会标题",
      "description": "详细分析",
      "impact_level": "high|medium|low",
      "applicable_roles": "适用岗位"
    }
  ],
  "competitive_landscape": {
    "our_positioning": "从 config.json 的 positioning_summary 读取，用于对比表",
    "dimensions": [
      {
        "name": "对比维度名",
        "us": "我方优势描述",
        "competitor_a": "竞品A特点",
        "competitor_b": "竞品B特点"
      }
    ]
  },
  "implementation_roadmap": [
    {
      "phase": "P0",
      "name": "阶段名称",
      "color": "green|blue|orange",
      "timeline": "时间线",
      "details": ["工作项1", "工作项2"],
      "target_roles": "涉及岗位",
      "investment": "投入/定价"
    }
  ],
  "roi_estimation": {
    "total_investment": "总投入",
    "annual_savings": "预计年化节省",
    "items": [
      { "project": "项目名", "description": "说明", "effect": "预期效果" }
    ]
  },
  "cover_meta": {
    "report_id": "报告编号",
    "classification": "密级",
    "subtitle": "副标题（含英文名/定位）"
  },
  "innovation_ideas": [
    {
      "title": "想法标题",
      "category": "业务创新 | 技术融合 | 商业模式 | 行业颠覆",
      "description": "创意详细描述，基于行业趋势+我方能力进行扩展性构想",
      "innovation_level": "渐进式 | 突破式 | 颠覆式",
      "rationale": "为什么这个想法值得考虑（行业趋势/我方优势/竞品动态等）",
      "feasibility": "高 | 中 | 低",
      "timeframe": "短期（3-6月）| 中期（6-18月）| 长期（18月+）"
    }
  ],

  "--- 以下为原有字段 ---": "",

  "pain_points": [
    {"scenario": "场景名称", "pain": "痛点详细描述", "impact": "高|中|低", "need": "需求描述"}
  ],
  "solution_matches": [
    {"pain": "痛点摘要", "solution": "对应方案", "value": "预期价值/效果"}
  ],
  "sales_strategy": {},
  "faq": [],
  "next_steps": [],
  "custom_sections": [],
  "notes": ""
}
```

**注意**：`tech_assessment`、`collaboration_opportunities`、`competitive_landscape`、`implementation_roadmap`、`roi_estimation`、`cover_meta`、`innovation_ideas`、`online_presence` 这 8 个字段为分析模块，由 AI 基于调研数据 + 行业知识动态生成，skill 本身不包含任何业务预设内容。`competitive_landscape.our_positioning` 从 config.json 的 `positioning_summary` 字段读取。`patent_info`、`client_partners`、`brand_reputation` 为默认模块数据，来源于调研数据 + 网页搜索。

以上所有分析内容（swto、patent_info、client_partners、brand_reputation、online_presence、pain_points、solution_matches、sales_strategy、faq、next_steps 以及新增字段）均由 AI 基于调研数据 + 用户产品信息综合分析生成，无需从外部数据源获取。

---

## P4 — 报告内容生成

### 章节结构（16 章）

在前一步的汇总 JSON 基础上，AI 综合分析生成以下内容：

| # | 章节 | 生成方式 |
|---|------|---------|
| 1 | 客户概览 | 从 basic_info + cover_meta 映射，含核心指标一览表 |
| 2 | 股东与集团背景 | 从 shareholder_structure + key_personnel 分析，含股权结构图 |
| 3 | 行业与业务分析 | 从 business + 行业知识分析 |
| 4 | 线上表现分析 | 从 online_presence 字段生成，含官网分析、社交媒体活跃度、搜索可见度、线上口碑 |
| 5 | 客户与合作伙伴 | 从 client_partners 字段生成，含主要客户/上下游/战略合作伙伴 |
| 6 | 技术能力评估 | 从 tech_assessment 字段生成星级评分 + AI赋能空间表 |
| 7 | SWTO 分析 | AI 基于调研数据综合分析，各 3-5 条 |
| 8 | 资质与专利 | 从 patent_info 字段生成知识产权/专利/资质一览表 |
| 9 | 客户风险扫描 | 从 risks + brand_reputation 数据生成风险矩阵表 + 品牌舆情分析 |
| 10 | 痛点与需求分析 | AI 逐环节分析客户业务痛点，产出场景卡片 |
| 11 | 合作机会洞察 | 从 collaboration_opportunities 字段生成，基于我方产品/服务能力匹配客户需求的机会卡片 |
| 12 | 建议方案 | 从 solution_matches + implementation_roadmap + roi_estimation 生成，含分阶段路线图+ROI表 |
| 13 | 创新机会探索 | 从 innovation_ideas 生成，基于行业趋势+我方能力进行扩展性创意输出 |
| 14 | 竞争格局与差异化定位 | 从 competitive_landscape 字段生成对比表（我们 vs 竞品A vs 竞品B）|
| 15 | 售前常见问答 | 10-15 个客户可能问的问题+回答 |
| 16 | 下一步行动 | 拜访/演示/跟进推进步骤 |

### 可选模块插入

检查 config.json 中 `custom_modules` 已启用的模块，以及用户添加的自定义模块，**统一追加至报告末尾**（第 16 章之后），与默认章节分离。

| 模块 id | 章节位置 | 内容来源 |
|---------|---------|---------|
| tech_stack | 追加至末尾 | AI 分析 / 网页搜索 |
| 用户自定义模块 | 追加至末尾 | 用户自行定义 |

**即时启用**：如果用户说"这次就要"，即使在 config 中未启用，也为本次报告生成该模块。

---

## P5 — 脚本调用与文件生成

### 流程

```
AI 完成分析 → 整理 report_data.json（写入系统临时目录 tempfile.gettempdir()，跨平台）
           → 调用 scripts/generate_report.py
           → 输出 MD + HTML 文件
```

### 脚本调用命令

```bash
# macOS
python3 scripts/generate_report.py <report_data.json路径> <config.json路径> <输出目录>
```

```powershell
# Windows (PowerShell)
python scripts\generate_report.py <report_data.json路径> <config.json路径> <输出目录>
```

- macOS 使用 `python3`，Windows 使用 `python`（或 `py`）
- 路径参数在 Windows 下使用 `\` 分隔或使用双引号包裹含空格的路径

- `<report_data.json>`：AI 构建的完整报告数据 JSON（保存在临时目录，报告生成后可清理）
- `<config.json>`：用户配置（用于获取公司产品信息等）
- `<输出目录>`：当前工作空间根目录（即用户执行任务的目录）

**脚本路径**：使用相对于 SKILL.md 的路径，即 `scripts/generate_report.py`

### 输出文件

- `{公司名}-客户洞察与售前报告.md` — Markdown 完整报告
- `{公司名}-客户洞察与售前报告.html` — HTML 精美排版报告

### HTML 样式规范

| 元素 | 样式 |
|------|------|
| 封面 | 蓝色渐变（#1a73e8 → #0d47a1），白字 |
| 风险表 | 三色等级标识（🟢🟡🔴） |
| 章节编号 | 蓝色圆形数字标 |
| 卡片 | 白底圆角 12px，浅阴影 |
| 表格 | 蓝色表头，斑马纹行 |
| 标签 | 圆角 15px 多色系 |

---

## P6 — 交付展示与 PDF 询问

### 交付流程

1. 脚本执行完成后，确认 MD + HTML 文件已生成
2. 调用 `present_files` 展示 HTML 文件（或两个文件一起展示）
3. 展示后输出 PDF 询问：

```
"是否需要将这份报告导出为 PDF 版本？
- 是 → 调用 md2pdf 生成 PDF（需已安装 md2pdf skill；macOS 用 python3，Windows 用 python）
- 否 → 跳过"
```

---

## P7 — 预测后续问题引导

### 节点设置

整个流程中设置 2 个预测节点：

**节点 1 — 调研完成后（Phase 3 结束后）：**

```
"调研完成，已获取目标公司的基础信息。
接下来你可以：
① 深入分析他们最近正在推进的项目（深入调研）
② 直接生成完整报告（继续生成）
③ 看看他们的主要竞争对手是谁（竞品分析）
你想先做哪个？"
```

**节点 2 — 报告交付后（Phase 6 结束后）：**

```
"报告已生成。
接下来你可以：
① 生成一份针对这次拜访的沟通邮件模板
② 输出一份竞品对比分析
③ 基于这个客户，帮你模拟一次沟通演练
④ 开始研究下一个客户
你想做什么？"
```

### 设计原则

- 每次 3-4 个选项，不超过 5 个
- 选项递进关系：信息 → 分析 → 行动
- 用户回答后进入对应子流程

---

## P8 — 记忆写入触发检查

### 触发规则

报告生成并交付后，检查以下场景是否值得记录：

| 触发场景 | 检查逻辑 | 询问话术 |
|----------|---------|---------|
| 用户表达了关注偏好 | 用户多次问某类问题或强调某方面 | "我发现你关注目标公司的xx方面，要记录为偏好吗？" |
| 用户对某章节反馈特别 | 用户说"这个不要/这个加多些" | "下次报告我会调整xx部分的深度，是否要存为默认偏好？" |
| 用户建立了某种规则 | "以后xx行业的报告都自动加xx" | "已记录规则：xx行业默认启用xx模块。" |
| 有用信息用户明确说要记 | 用户说"记住/存一下/这个重要" | "已记下，已写入记忆文件。" |

### 写入操作

- 写入路径：`~/.workbuddy/userdata/skill/wx-customer-insight-report/memory.md`（跨平台，`os.path.expanduser()` 解析）
- 始终先获取用户确认再写入
- 写入后告知用户
- 用户可随时主动要求查看/修改/删除记忆

---

## 资源文件

### scripts/generate_report.py

客户洞察与售前报告生成 Python 脚本。读取 AI 构建的 `report_data.json` 和 `config.json`，生成 `{公司名}-客户洞察与售前报告.md` 和 `{公司名}-客户洞察与售前报告.html` 双格式报告。

**调用方式**：
```bash
# macOS
python3 scripts/generate_report.py <report_data.json> <config.json> <output_dir>
```
```powershell
# Windows
python scripts\generate_report.py <report_data.json> <config.json> <output_dir>
```
所有路径参数在脚本内部使用 `os.path.join()` 处理，自动适配平台分隔符。

### assets/config.example.json

示例配置文件，展示完整的配置结构，供用户参考。首次配置时 AI 自动创建 config.json，无需用户手动编辑此文件。
