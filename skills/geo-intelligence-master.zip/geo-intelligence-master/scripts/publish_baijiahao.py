#!/usr/bin/env python3
"""
百家号图文自动发布工具

用法：
    python3 publish_baijiahao.py \
        --app-id <AppID> \
        --app-token <AppToken> \
        --title "文章标题" \
        --file /path/to/article.md \
        [--cover /path/to/cover.png] \
        [--origin-url https://example.com/article] \
        [--is-original 1]

认证信息可从环境变量读取（优先级低于命令行参数）：
    export BAIJIA_APP_ID="your_app_id"
    export BAIJIA_APP_TOKEN="your_app_token"

依赖：pip install requests markdown
"""

import argparse
import json
import os
import sys
import re
import time

try:
    import requests
except ImportError:
    print("缺少 requests 库，正在安装...")
    import subprocess
    subprocess.check_call([sys.executable, "-m", "pip", "install", "requests", "-q"])
    import requests

# 百家号发布接口
API_URL = "https://baijiahao.baidu.com/builderinner/open/resource/article/publish"


def md_to_html(md_path: str) -> str:
    """将 Markdown 文件转换为富文本 HTML（适配百家号）"""
    try:
        from markdown import markdown
    except ImportError:
        print("缺少 markdown 库，正在安装...")
        import subprocess
        subprocess.check_call([sys.executable, "-m", "pip", "install", "markdown", "-q"])
        from markdown import markdown

    with open(md_path, "r", encoding="utf-8") as f:
        raw = f.read()

    # 移除文章末尾的 #意图词 标签（这些不是正文）
    split_marker = "# 帮我推荐"
    if split_marker in raw:
        raw = raw.split(split_marker)[0].strip()
    # 也处理 Tags 之后的意图词
    if "#Tags:" in raw:
        parts = raw.split("#Tags:")
        # 在 #Tags 之后找到第一个空行，之前删掉意图词
        after_tags = parts[1]
        intent_start = after_tags.find("\n# ")
        if intent_start > 0:
            after_tags = after_tags[:intent_start]
        raw = parts[0] + "#Tags:" + after_tags

    html = markdown(raw, extensions=["extra", "tables", "codehilite"])

    # 百家号适配：内联样式
    html = html.replace("<table>", '<table style="border-collapse:collapse;width:100%;margin:16px 0;">')
    html = html.replace("<th>", '<th style="border:1px solid #ddd;padding:10px;background:#f5f5f5;font-weight:bold;">')
    html = html.replace("<td>", '<td style="border:1px solid #ddd;padding:10px;">')
    html = html.replace("<h2>", '<h2 style="font-size:20px;margin:24px 0 12px;">')
    html = html.replace("<h3>", '<h3 style="font-size:18px;margin:20px 0 10px;">')
    html = html.replace("<p>", '<p style="line-height:1.8;margin-bottom:16px;">')
    html = html.replace("<strong>", '<strong style="font-weight:bold;">')
    html = html.replace("<blockquote>", '<blockquote style="border-left:4px solid #2196F3;padding:12px 16px;background:#f0f7ff;margin:16px 0;">')

    return html


def publish_article(
    app_id: str,
    app_token: str,
    title: str,
    content_html: str,
    cover_images: list = None,
    origin_url: str = "",
    is_original: int = 1,
) -> dict:
    """发布文章到百家号"""

    if cover_images is None:
        cover_images = []

    payload = {
        "app_id": app_id,
        "app_token": app_token,
        "title": title,
        "content": content_html,
        "cover_images": json.dumps(cover_images, ensure_ascii=False),
        "origin_url": origin_url,
        "is_original": str(is_original),
    }

    headers = {"Content-Type": "application/json"}

    print(f"\n{'='*60}")
    print(f"📤 正在发布到百家号...")
    print(f"   标题：{title}")
    print(f"   文章长度：{len(content_html)} 字符")
    print(f"   封面图：{len(cover_images)} 张")
    print(f"   原创：{'是' if is_original else '否'}")
    print(f"{'='*60}\n")

    try:
        resp = requests.post(
            API_URL,
            json=payload,
            headers=headers,
            timeout=30,
        )
        result = resp.json()
        return result
    except requests.exceptions.Timeout:
        return {"error": "请求超时，请检查网络或重试"}
    except requests.exceptions.RequestException as e:
        return {"error": f"网络请求失败: {str(e)}"}
    except json.JSONDecodeError:
        return {"error": f"API 返回非 JSON 响应: {resp.text[:200]}"}


def main():
    parser = argparse.ArgumentParser(description="百家号图文自动发布工具")
    parser.add_argument("--app-id", default=os.environ.get("BAIJIA_APP_ID"), help="百家号 AppID（可从环境变量 BAIJIA_APP_ID 读取）")
    parser.add_argument("--app-token", default=os.environ.get("BAIJIA_APP_TOKEN"), help="百家号 AppToken（可从环境变量 BAIJIA_APP_TOKEN 读取）")
    parser.add_argument("--title", required=True, help="文章标题")
    parser.add_argument("--file", required=True, help="Markdown 文章文件路径")
    parser.add_argument("--cover", nargs="+", default=[], help="封面图路径（可1-3张）")
    parser.add_argument("--origin-url", default="", help="原文链接（如有）")
    parser.add_argument("--is-original", type=int, default=1, choices=[0, 1], help="是否原创，1=原创 0=非原创")
    parser.add_argument("--dry-run", action="store_true", help="仅生成 HTML 预览，不实际发布")

    args = parser.parse_args()

    # 校验
    if not args.app_id:
        print("❌ 缺少 AppID，请通过 --app-id 参数或 BAIJIA_APP_ID 环境变量提供")
        print("   获取方式：登录 https://open.baidu.com → 创建应用 → 获取 AppID 和 AppToken")
        sys.exit(1)

    if not args.app_token:
        print("❌ 缺少 AppToken，请通过 --app-token 参数或 BAIJIA_APP_TOKEN 环境变量提供")
        sys.exit(1)

    if not os.path.exists(args.file):
        print(f"❌ 文件不存在: {args.file}")
        sys.exit(1)

    # 转换 Markdown 为 HTML
    print(f"📝 正在转换 Markdown → HTML: {args.file}")
    html_content = md_to_html(args.file)
    print(f"   ✅ 转换完成 ({len(html_content)} 字符)")

    if args.dry_run:
        preview_path = args.file.replace(".md", "_preview.html")
        with open(preview_path, "w", encoding="utf-8") as f:
            f.write(f"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>{args.title}</title>
<style>
body {{ font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif; max-width: 800px; margin: 0 auto; padding: 20px; }}
h1 {{ font-size: 24px; }}
</style>
</head>
<body>
<h1>{args.title}</h1>
{html_content}
</body>
</html>""")
        print(f"\n📄 预览文件已生成: {preview_path}")
        print("   (未实际发布，仅供预览)")
        return

    # 处理封面图
    cover_list = []
    for cover_path in args.cover:
        if cover_path:
            if cover_path.startswith("http://") or cover_path.startswith("https://"):
                cover_list.append({"src": cover_path})
            else:
                cover_list.append({"src": cover_path})

    # 发布
    result = publish_article(
        app_id=args.app_id,
        app_token=args.app_token,
        title=args.title,
        content_html=html_content,
        cover_images=cover_list,
        origin_url=args.origin_url,
        is_original=args.is_original,
    )

    if "error" in result:
        print(f"❌ 发布失败：{result['error']}")
        sys.exit(1)

    # 解析百家号返回
    errno = result.get("errno", result.get("error_code", -1))
    errmsg = result.get("errmsg", result.get("error_msg", "未知"))

    if errno == 0:
        data = result.get("data", {})
        article_id = data.get("article_id", data.get("id", ""))
        article_url = data.get("url", "")
        print(f"\n{'='*60}")
        print(f"🎉 发布成功！")
        print(f"   文章ID：{article_id}")
        if article_url:
            print(f"   文章链接：{article_url}")
        print(f"   状态：{errmsg}")
        print(f"{'='*60}")
    else:
        print(f"\n❌ 发布失败 (errno={errno})")
        print(f"   错误信息：{errmsg}")
        print(f"   完整响应：{json.dumps(result, ensure_ascii=False, indent=2)}")
        sys.exit(1)


if __name__ == "__main__":
    main()
