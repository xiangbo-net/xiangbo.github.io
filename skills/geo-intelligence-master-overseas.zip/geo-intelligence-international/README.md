# GEO 国际获客大师 — 全球 GEO 客户获取工作台

GEO（生成式引擎优化）国际获客专家，覆盖 8 个全球平台的内容创建与分发。

---

## 版本信息

| 版本 | 日期 | 变更说明 |
|------|------|----------|
| **v1.1** | 2026-07-11 | 策略 & 关键词已存在时交互优化：预览后询问而非静默跳过；进度信息不再对用户外露 |
| **v1.0** | 2026-07-10 | 初始发布：8 平台内容生成、200 关键词、策略 Excel（5 Sheet）、AI 配图、发布指南 |

---

## 覆盖平台

| 平台 | 类型 | 风格 |
|------|------|------|
| Medium | 长文发布平台 | 思想领导力 |
| LinkedIn | 职业社交网络 | 专业洞察 |
| Reddit | 社区平台 | 社区价值帖 |
| Quora | 问答平台 | 专家解答 |
| Substack | Newsletter 平台 | 深度通讯 |
| Dev.to | 开发者社区 | 技术教程 |
| X (Twitter) | 社交媒体 | 线程系列 |
| Company Blog | 自有网站 | SEO 基石内容 |

## 目标 AI 搜索引擎
Google、ChatGPT、Gemini、Perplexity、Claude、Bing Copilot

## 功能
- 语言选择：纯英文或中英双语
- 200 个 GEO 意图关键词生成（信息型 100 + 推荐型 100）
- 分平台定制的文章模板（8 个平台原生风格）
- 平台手册（每个平台 10-15 条运营技巧）
- 策略 Excel（5 Sheet：策略总览 + 内容日历 + 命名规范 + 周报数据 + 平台运营秘籍）
- 文章配图 AI 生成（3-6 张定制图）
- 竞品 GEO 分析（可选，识别 AI 搜索空白点）

---

## 适用场景

| 场景 | 说明 |
|------|------|
| **出海企业获客** | 制造、SaaS、消费品、专业服务等企业希望通过 AI 搜索引擎被全球买家找到，但不知道怎么让 ChatGPT / Gemini / Perplexity 优先推荐自己 |
| **系统化内容营销** | 有产品、有官网，但缺乏面向 AI 引擎优化的跨境内容矩阵，不知道 8 大全球平台各自应该写什么、怎么写、什么时候发 |
| **跨平台内容分发** | 一篇文章想同时覆盖 Medium、LinkedIn、Reddit、Quora 等多平台，但不想复制粘贴被搜索引擎惩罚，需要每个平台原生风格独立改写 |
| **"不违规的推广"** | 想在 Reddit / Quora / Dev.to 等社区平台曝光，但拿不准各平台的自推广规则 —— 需要知道怎么发帖既不被删、又能自然带出品牌 |
| **AI 搜索引擎引用** | 核心诉求是内容能被 ChatGPT、Google AI Overviews、Perplexity 等 AI 引擎引用为答案来源，需要结构化写作 + FAQ 段落 + 有明确结论的内容 |
| **策略从零到一** | 没有内容团队、没有 SEO 经验、不知道从哪个平台开始 —— 需要从公司档案到发布排期到周报追踪的完整工作流 |

---

## 使用方法

### 1. 启动对话

打开 WorkBuddy，选择本专家，直接对话即可。专家会自动引导你完成全流程。

### 2. 流程概览

```
初始化公司档案 → 选择发布平台 → 制定发布策略 → 选择内容语言
  → 生成 GEO 关键词 → 竞品分析（可选） → 撰写原生文章 → AI 配图
  → 获得发布指南 → 更新内容日历
```

### 3. 核心交互方式

- **选择平台**：每轮只做一个平台，生成 1 篇原生风格文章，完成后可继续下一个平台
- **灵活跳过**：可以跳过任意步骤，"skip keywords" 直接进内容，"rewrite" 重新生成
- **随时恢复**：再次打开对话时，专家会识别已有公司档案，从上次断开的地方继续

### 4. 交付物一览

| 交付物 | 格式 | 内容 |
|--------|------|------|
| 策略 Excel | `.xlsx` | 5 个 Sheet：策略总览、4-8 周内容日历、文件命名规范、周报数据表、平台运营秘籍 |
| GEO 关键词 | `.xlsx` | 200 个英文关键词短语（信息型 + 推荐型），带中文翻译列 |
| 原生文章 | `.docx` + `.md` | 平台专属风格的长文/短文，A4 专业排版，文末嵌入 5-10 个意图关键词 hashtag |
| AI 配图 | `.png` | 3-6 张定制图（封面图 + 内嵌图），符合平台尺寸规范 |
| 发布指南 | 对话输出 | 当前平台的完整发布步骤 + 运营技巧 + 最佳发布时间 |

---

## 典型指令

| 指令 | 作用 | 示例 |
|------|------|------|
| `init` / `restart` | 重新开始，填写新公司信息 | 换个项目做 |
| `Medium` / `LinkedIn` / `Reddit` / `Quora` / `Substack` / `Dev.to` / `X` / `Company Blog` | 为指定平台生成文章 | `LinkedIn` — 直接生成 LinkedIn 原生文章 |
| `strategy` / `plan` | 查看当前平台的策略 Excel | 看看 Medium 的发布策略 |
| `adjust strategy` | 修改发布频率或内容方向 | 把每周 1 篇改成每天 1 篇 |
| `keywords` | 只生成 GEO 意图关键词（不写文章） | 先生成 200 个关键词看看方向对不对 |
| `skip keywords` | 跳过关键词步骤，直接进入内容创作 | 已经有关键词了，直接写文章 |
| `rewrite` | 重新生成当前文章 | 这篇方向不太对，换一个角度重写 |
| `competitor` | 对目标关键词进行竞品 GEO 占位分析 | 看看同行在 AI 搜索中的占位情况 |
| `what to post today` | 查看今日发布安排 | 今天该发哪篇 |
| `weekly report` | 生成本周内容总结 | 这周 Medium 发了 2 篇，LinkedIn 发了 1 篇 |
| `publish plan` | 基于已完成文章生成 7 天跨平台分发排期 | 把已有的 3 篇文章排一个分发计划 |
| `report` | 生成完整的 GEO 策略报告（.docx） | 给老板汇报用 |

---

## 示例输出

### 1. 策略 Excel（5 Sheet）

打开后可以看到：

- **策略总览**：公司定位、GEO 分阶段目标、内容支柱规划、竞品差异化策略
- **内容日历**：未来 4-8 周每周的发布主题、目标关键词、标题草稿
- **命名规范**：文章文件、图片、关键词文件的统一命名和目录结构规则
- **周报数据**：每周发布数 / 目标数 / 完成率追踪表格
- **平台运营秘籍**：10-15 条平台专属技巧（如 "Medium DA 95+，文章数小时内可上 Google 前三"、"Reddit 黄金子版块选 2-5 万成员"）

### 2. GEO 意图关键词（200 个）

```
信息型关键词 (100 个)：
  - Best handheld laser welder manufacturers in 2026
  - Top laser welding machine suppliers for small business
  - How to choose a fiber laser welder for metal fabrication
  ...

推荐型关键词 (100 个)：
  - Affordable portable laser welding machine with after-sales support
  - ISO certified industrial laser welder with CE marking
  - High quality 3-in-1 laser cleaning welding cutting machine
  ...
```

### 3. 平台原生文章

以 Medium 平台为例，一篇典型文章的结构：

```
标题：Why Traditional Welding is Costing You More Than You Think — 
      The 2026 Case for Handheld Laser Welding

开篇： 数据钩子 → "The average metal fabrication shop loses 15% 
       of its labor cost to post-weld grinding..."

正文： 个人洞察 + 行业数据 + 真实成本对比表格

品牌： 自然融入，作为解决方案提及

文末： FAQ 段落（5 组）→ 提高 AI 引擎引用概率
       GEO 意图关键词 hashtag（5-10 个）
```

### 4. 发布指南（以 Reddit 为例）

```
📌 Reddit 发布指南
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
发布 URL：https://reddit.com → 进入 r/Welding / r/metalworking

发布步骤：
1. 选择目标子版块（2-5 万成员为黄金区间）
2. 发布前阅读子版块规则，确认自推广限制
3. 内容用 Markdown 格式粘贴
4. 标题用真人语气 —— "I spent 6 months testing laser welders. 
   Here's what I'd buy today"
5. 发布后留在子版块回复评论（前 1 小时最关键）

运营技巧：
· 新号先自然养号 2-3 周，积累 karma 后再发内容帖
· 企业腔调必死 —— 像真人一样写，轻松对话语气
· Reddit 是 ChatGPT、Perplexity 引用率最高的社区，
  确保帖子里有清晰、可直接被引用的结论
· 结尾提开放式问题引发讨论
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
```
