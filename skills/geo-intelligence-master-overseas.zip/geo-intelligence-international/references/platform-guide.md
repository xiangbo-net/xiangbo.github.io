# 平台指南 — 图片规格 & 发布操作指引

## 各平台图片规格

| 平台 | 封面/头图 | 内嵌图片 | 最多张数 | 格式 |
|------|----------|---------|---------|------|
| Medium | 1400 x 700 px | 1200 x 800 px | 不限 | JPG, PNG, GIF |
| LinkedIn | 1200 x 627 px（文章）/ 1200 x 1200 px（动态） | 1200 x 627 px | 5-8 | JPG, PNG |
| Reddit | —（视子版块而定） | 1200 x 628 px | 1-3 | JPG, PNG |
| Quora | — | 1200 x 800 px | 每回答 3-5 | JPG, PNG |
| Substack | 1200 x 600 px（邮件头图） | 1200 x 800 px | 每篇 3-5 | JPG, PNG |
| Dev.to | 1000 x 420 px（封面） | 880 x 自适应 | 适量 | JPG, PNG, GIF |
| X (Twitter) | — | 1200 x 675 px（单图）/ 900 x 1600 px（竖图） | 每条 1-4 | JPG, PNG, GIF |
| Company Blog | 1200 x 630 px（OG 分享图） | 800-1200 px 宽 | 每 300 字 1 张 | WebP（首选）, JPG, PNG |

### 图片最佳实践

- 公司博客优先用 WebP 格式（体积更小、加载更快）
- 所有图片压缩至 200KB 以内
- 每张图片必须写 alt 替代文本 — 描述性文字，自然地嵌入关键词
- 封面图加文字叠加可提高点击率
- 所有平台图片保持一致的品牌色彩和风格

---

## 各平台发布步骤

### Medium
1. 打开 https://medium.com → 登录
2. 点击头像 →「Write a story」或直接访问 https://medium.com/new-story
3. 粘贴文章内容
4. 添加封面图：+ 按钮 → 相机图标 → 上传
5. 添加标签（最多 5 个）：选择精准的主题标签
6. 若投稿至出版物：「Add to publication」
7. SEO 设置：「...」→「More settings」→ 自定义 SEO 标题和描述
8. 点击「Publish」→ 选择免费或付费会员可见

### LinkedIn
1. 打开 https://linkedin.com → 登录
2. 点击「写文章」或直接访问 https://www.linkedin.com/article/new
3. 粘贴文章内容
4. 添加封面图：鼠标悬浮顶部区域 → 图片图标
5. 用 LinkedIn 内置编辑器排版
6. 发布前用手机预览
7. 点击「发布」

### Reddit
1. 打开 https://reddit.com → 登录
2. 进入目标子版块
3. 点击「Create Post」→ 选择「Text」类型
4. 粘贴内容（Reddit 支持 Markdown）
5. 写一个能引发讨论的描述性标题
6. 如有要求，选择合适的帖子分类（flair）
7. 点击「Post」
8. 关注并回复评论

### Quora
1. 打开 https://quora.com → 登录
2. 搜索目标问题
3. 点击「Answer」
4. 撰写或粘贴回答
5. 添加图片：工具栏中的图片图标
6. 用 Quora 编辑器排版
7. 如需添加身份说明：「...」→「Add credential」
8. 点击「Submit」

### Substack
1. 打开 https://substack.com → 登录你的出版物
2. 在仪表盘点击「New post」
3. 撰写或粘贴内容
4. 添加图片：拖拽或点击图片按钮
5. 设置发布范围：免费、仅付费或免费预览
6. 添加社交媒体预览图和描述
7. 点击「Publish」或「Schedule」

### Dev.to
1. 打开 https://dev.to → 登录
2. 点击「Create Post」
3. 撰写或粘贴内容（Markdown 格式）
4. 代码块：三个反引号 + 语言名称
5. Liquid 标签：`{% embed_url %}` 用于富媒体嵌入
6. 添加封面图
7. 添加标签（最多 4 个）：选择相关技术/主题标签
8. 如果是跨平台发布：设置 canonical URL 指向原始博客
9. 点击「Publish」

### X (Twitter)
1. 打开 https://x.com → 登录
2. 点击「发帖」或撰写按钮
3. 写第一条推文（钩子）
4. 点击「+」添加后续推文到线程
5. 逐条撰写后续推文
6. 给特定推文添加图片：图片图标
7. 检查整条线程
8. 点击「全部发布」

### Company Blog
- **WordPress**：文章 → 新建 → 粘贴内容 → 设置封面图 → 分类/标签 → 配置 Yoast/RankMath SEO → 发布
- **Webflow**：CMS 集合 → 新增条目 → 粘贴内容 → 设置封面图 → 配置 SEO 设置 → 发布
- **Ghost**：Posts → New Post → 粘贴内容 → 设置封面图 → 配置 meta → 添加标签 → 发布或定时

---

## 图片设计指南

### 封面图最佳实践

**思想领导力内容（Medium、LinkedIn、公司博客）**：专业简洁设计，品牌色系，标题文字叠加，避免烂大街的 stock photo，用定制插画或数据可视化。

**社区内容（Reddit、Quora、Dev.to）**：截图和数据可视化，前后对比，流程图，避免营销风格的图。

**社交内容（X、Substack）**：大胆吸睛的视觉，高对比度便于信息流中突出，令人惊讶的数据发现可视化，个人照片（X 上）可提高互动。

### AI 图片 Prompt 模板

```
[风格描述] [主题] 在 [背景/场景] 中，[配色方案]，[氛围]，[构图细节]，专业商务插画，简洁设计，[平台] 适配风格
```

### 跨平台发布推荐流程

1. **公司博客** — 先发布完整的规范版本
2. **Medium** — 24-48 小时后同步，设置 canonical URL
3. **LinkedIn** — 发布摘录/改编版，链接到完整文章
4. **Dev.to** — 交叉发布（如果是技术内容），设置 canonical URL
5. **Substack** — 在下期 Newsletter 中包含，附个人点评
6. **X** — 发布关键洞察线程，链接放在最后一条推文
7. **Quora** — 回答相关问题，引用文章
8. **Reddit** — 在相关社区分享，以洞察增加价值

**时间线**：分散在 5-7 天内发布，形成持续的内容声浪而非单日爆发。
