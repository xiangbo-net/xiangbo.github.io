# WX Mail Sender — 安装说明

## 概述

海外邮件营销智能体专家，基于 SMTP 批量发送邮件，支持三种场景：
- **场景 A**：对话式智能邮件发送（推荐，首位）— 收集发件方画像 + 匹配模板 + 对话看板确认后发送
- **场景 B**：使用之前搜到的客户名单 — 消费「海外地图获客」专家产出的客户数据（已修复跨 skill 索引定位）
- **场景 C**：手动导入 Excel/CSV/粘贴邮箱列表

## 目录结构

```
wx-mail-sender-skill/
├── .codebuddy-plugin/
│   └── plugin.json                ← 专家配置（名称、描述、头像、分类等）
├── agents/
│   └── wx-mail-sender-skill.md    ← AI 行为定义
├── avatars/
│   └── expert.png                 ← 专家头像
├── README.md                      ← 本文件
└── skills/
    └── mail-sender-skill/         ← 技能主体
        ├── SKILL.md               ← 技能说明（v0.8.0）
        ├── README_SETUP.md        ← 技能安装说明
        └── scripts/
            ├── requirements.txt   ← Python 依赖
            ├── mail_server.py     ← 邮件发送 HTTP 服务（含 /api/templates、/api/conversation-board）
            ├── email_templates.py ← 预设邮件模板（营销/祝福/会议/其它，中英文）
            ├── cross_skill_index.py ← 跨 skill 数据共享索引（v0.8.0 修复定位）
            ├── smtp_providers.py  ← SMTP 提供商映射表 + 授权码引导
            ├── refresh_data.py
            ├── smtp_test.py
            └── dashboard.html
```

## 安装步骤

1. 解压 `wx-mail-sender-skill.zip` 到 WorkBuddy 专家目录
2. 在聊天界面调用：「帮我发邮件」
3. 系统会引导你完成首次 SMTP 邮箱配置

## 详细使用说明

参见 `docs/WXMailSender-用户使用手册.md` 或 [在线文档](https://docs.example.com)。

## 反馈与支持

- 版本：v0.8.0
- 适用 WorkBuddy 版本：3.x 及以上
- Python 环境：3.10+
- 主要依赖：flask、openpyxl、dnspython
