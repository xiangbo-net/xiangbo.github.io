# Mail Sender Skill — 安装说明

## 概述

本 Skill 是「海外邮件营销智能体」专家的核心执行单元，基于 SMTP 批量发送邮件。

## 三种使用场景

### 场景 A：消费已有客户名单
配合「海外地图获客」专家使用，自动扫描并导入客户数据。

### 场景 B：手动导入
用户自行准备邮箱列表（Excel/CSV/纯文本），手动导入系统。

### 场景 C：对话式智能邮件发送（推荐）
对话引导输入发件方信息 → AI 自动生成话术 → 一键发送。

## 安装步骤

1. 确认 Python 3.10+ 可用
2. 安装依赖：`pip install -r scripts/requirements.txt`
3. 启动服务：`python scripts/mail_server.py`

## 端口

默认监听 5678，可在启动时通过 `--port` 参数修改。

## 数据存储

- 运行数据：`~/.workbuddy/userdata/wxskill/mail-sender-skill/output/`
- 同步副本：项目根目录的 `output/`
- 不包含构建产物（zip、logo）

## 详细使用

参见父目录的 README.md 和 SKILL.md 文档。
