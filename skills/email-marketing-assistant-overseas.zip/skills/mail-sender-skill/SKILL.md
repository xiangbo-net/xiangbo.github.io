---
name: mail-sender
version: 0.9.3
description: 基于 SMTP 的邮件批量发送技能，配合海外地图获客专家使用，支持手动导入 Excel/CSV/粘贴邮箱列表进行群发，内嵌 AI 话术自动生成流程
author: agent_created
expert:
  name: 邮件开发信群发专家
  description: 基于 SMTP 的邮件批量发送专家，支持导入客户名单、配置邮箱、AI 生成话术、实时看板控制发送
  category: 客户触达
  tags: [邮件群发, 开发信, SMTP, 批量发送, 外贸营销]
instructions:
  - 用户调用 mail-sender-skill 后，先弹窗确认发送场景：「对话式智能邮件发送」「使用之前搜到的客户名单」「手动导入新客户邮箱」（顺序即 A/B/C）
  - 场景 A（对话式智能，推荐）：先导入收件方邮箱（对话粘贴/上传文件），再收集发件方画像（公司名+业务类型+发送目的），按目的匹配模板（预设/自定义/沿用导入文件/AI生成），在对话中渲染蓝白灰看板确认后发送
  - 场景 B（搜到的客户名单）：通过跨 skill 索引四级递进定位历史客户数据（v0.8.0 已修复 Tier0 返回最新有效记录），合并后直接进 SMTP 配置与发送
  - 场景 C（手动导入）：通过 HTML 看板「手动导入」导入 Excel/CSV/粘贴，随后复用与场景 A 相同的画像+目的+模板+看板流程
  - 读取并验证数据后，引导用户进行 SMTP 配置（选提供商→看图文指引→填授权码→测试验证→自动保存）
  - 启动 mail_server.py 本地 HTTP 服务（Agent 自动处理 venv + 安装 + 启动）
  - 引导用户打开 HTML 看板进行勾选和发送（场景 B 也可直接发送）
trigger:
  - 发送邮件
  - 批量发邮件
  - 邮件群发
  - 发送开发信
  - 发邮件
  - 开发信
  - 邮件营销
  - email send
  - 更新客户数据
  - 刷新客户列表
  - 重新导入
  - batch email
  - 手动导入
  - 导入邮箱
  - 导入客户
  - 对话发送
  - 智能发送
  - AI 发送
  - 批量智能邮件
  - 智能群发
  - 对话式发送
  - 写邮件并发送
  - 生成邮件并发送
  - 批量开发信
---

# Mail Sender Skill

## 概述

本 Skill 用于**批量发送开发信邮件**，覆盖三个场景：

- **场景 A（推荐）**：对话式智能邮件发送 — 导入收件方邮箱，收集发件方画像，AI/预设生成个性化开发信，对话看板确认后发送
- **场景 B**：使用之前搜到的客户名单（海外地图获客专家产出），四级递进定位历史数据后发送
- **场景 C**：手动导入新客户邮箱（Excel/CSV/粘贴），随后复用场景 A 的画像+目的+模板+看板流程

> 场景 A 与场景 C 共用「收集画像 → 选择发送目的 → 匹配模板 → 对话看板确认 → 发送」主流程，仅收件方导入入口不同（A=对话粘贴/上传，C=HTML 看板导入）。

## 前置依赖

- 场景 B 需要：海外地图获客专家产出的 `*_搜索结果.json` 文件
- SMTP 邮箱（用户自备，支持授权码模式）
- 浏览器（用于打开 HTML 看板，场景 B 也可直接发送无需看板）

> Python 环境和 Flask 依赖由 Agent 自动处理，用户无需安装任何软件。

## 调用流程

### 第 1 步：确认发送场景

```python
AskUserQuestion(
    question="请选择邮件发送方式：",
    options=[
        {
            "label": "对话式智能邮件发送 (推荐)",
            "description": "导入收件方邮箱，收集贵司画像，AI/预设生成开发信，对话看板确认后发送"
        },
        {
            "label": "使用之前搜到的客户名单",
            "description": "读取海外获客专家的历史客户数据，含公司名+个性化话术"
        },
        {
            "label": "手动导入新客户邮箱",
            "description": "导入自己的 Excel/CSV 或直接粘贴邮箱列表，随后走画像+模板流程"
        }
    ]
)
```

> **对话式智能邮件发送**作为推荐选项排首位（场景 A），引导用户优先使用智能化流程。

### 第 2 步：获取客户数据（按场景分支）

#### 场景 A — 对话式智能（推荐，首位）

进入「共享主流程」（见下方第 2.5 节）：先导入收件方邮箱（对话粘贴或上传文件），再走画像/目的/模板/看板。

#### 场景 B — 使用之前搜到的客户名单（四级递进定位，v0.8.0 已修复）

**Tier 0：跨 skill 共享索引（最快路径，v0.8.0 已修复定位）**

读取 `~/.workbuddy/skill_data_index.json`，调用 `resolve_data_source("customer-list")`：

```python
from cross_skill_index import resolve_data_source
source = resolve_data_source("customer-list")
# v0.8.0 索引修复（补丁）：合并「索引记录 + 实时扫描全部候选」，统一按「获取日期最新（同日期按邮箱数降序）」
# 选取真实客户清单；扫描时排除消费者自身（mail-sender-skill）避免自引用；文件存在性校验通过后回写索引自愈。
if source and os.path.isfile(source["json_file"]):
    json_path = source["json_file"]   # 定位到「最近一次搜索」的真实历史数据
```

> **修复说明（before/after）**：
> - v0.7.0 及之前：`get_latest_run("tavily-customer-miner")` 因索引 producer 已改名 `overseas-customer-miner` 返回 `None`；v2 索引 `latest` 指向陈旧的 2026-07-09 桂林 `.intermediate` 记录（customer/email=0/0）。
> - v0.8.0 初版修复：不再信任 `ds["latest"]`，改为在 `runs` 中按时间戳取"文件仍存在"的最新记录——但实测仍不充分，`runs` 本身是 v2 迁移后的陈旧子集（仅含该 `.intermediate` 一条），故仍返回 0 客户数据。
> - v0.8.0 补丁（最终）：① `get_data_source` 额外过滤 `.intermediate` 临时文件与 0 客户/邮箱的无效记录；② `resolve_data_source` 不再盲信索引，改为合并「已过滤的索引记录 + 实时扫描全部候选（排除自身）」，取「获取日期最新」者并校验文件存在，回写索引自愈。场景 B 现在稳定返回最近一次搜索的真实客户清单。

**Tier 1：自动扫描 + 弹窗选择（兜底 / 多结果）**

- 扫描路径：`~/.workbuddy/userdata/wxskill/`（各 skill 的 output）、`~/.workbuddy/skills`、`~/workbuddyproject`
- 命中多个有效数据源时，调用 `scan_for_data_source("customer-list", return_all=True)` 列出候选（公司/国家/客户数/邮箱数/日期），弹窗让用户选择
- 找到一个 → 直接使用，并自动写入共享索引

**Tier 2：用户手动指定路径** — 弹窗输入完整路径，验证文件有效后写入索引

**Tier 3：会话上下文记忆** — 检查 workspace memory 中最近一次 `output_dir`（仅同会话有效）

找到数据源后合并进客户池，直接进入 SMTP 配置（场景 B 不需要收集发件方画像，因为历史数据已自带公司名与话术）。

#### 场景 C — 手动导入

用户选择「手动导入新客户邮箱」后，引导通过 HTML 看板「📤 手动导入」模态框导入 Excel/CSV/粘贴。解析预览确认后导入客户池，**随后进入与场景 A 相同的「共享主流程」**（收集画像 → 目的 → 模板 → 看板）。

---

### 第 2.5 节：共享主流程（场景 A 与场景 C 共用）

> 以下流程在「已导入收件方邮箱」之后执行。

#### Step 0：检查用户配置文件

Agent 检查 `~/.workbuddy/userdata/wxskill/mail-sender-skill/output/user_profile.json`：

- 存在 → 弹窗「沿用上次配置 / 重新配置」
- 沿用 → 跳过 Step 1-3，直接加载已有画像与目的
- 重新配置 → 进入 Step 1

#### Step 1：收集发件方画像（形成客户画像）

对话引导输入**公司名称**，并弹窗确认**业务类型**（AI 根据公司名自动推荐），随后弹窗选择**本次发送目的**：

```python
AskUserQuestion(
    question="本次邮件的发送目的是？",
    options=[
        {"label": "营销推广", "description": "推介产品/服务，争取合作意向"},
        {"label": "问候祝福", "description": "节日/日常问候，维护客户关系"},
        {"label": "会议邀约", "description": "邀请对方参加线上/线下会议"},
        {"label": "其它", "description": "其他沟通目的（手动输入）"}
    ]
)
```

画像字段（保存至 `user_profile.json`）：`company_name`、`business_type`、`purpose`。

#### Step 2：匹配邮件模板（四种来源，用户任选）

根据 `purpose` 调用 `POST /api/templates` 获取对应预设模板，随后弹窗让用户选择模板来源：

```python
AskUserQuestion(
    question="邮件内容使用哪种模板？",
    options=[
        {"label": "使用系统预设模板", "description": "采用该目的对应的官方预设（含 {{company}} 占位）"},
        {"label": "自定义内容", "description": "您自己撰写邮件正文，所有收件人统一使用"},
        {"label": "沿用导入文件的邮件内容", "description": "导入的 Excel/CSV 中已含话术列，直接使用"},
        {"label": "AI 生成", "description": "AI 根据画像+目的为每封/统一生成个性化内容"}
    ]
)
```

- **系统预设**：Agent 调用 `POST /api/templates` 取预设，将 `[发件方公司名]`/`[主营业务]` 等占位替换为画像，并展示预览
- **自定义**：用户在对话中输入正文
- **沿用导入文件**：读取客户池中已有 `pitch_email`（导入时解析的话术列）
- **AI 生成**：Agent 调用 AI 能力生成（统一模板含 `{{company}}` 或逐封个性化）

无论哪种来源，最终话术通过 `POST /api/customers/batch-update-pitch` 回写客户池。模板选择记录到 `user_profile.json` 的 `template_choice`。

#### Step 3：对话看板（蓝 / 白 / 灰，直接在对话中显示）

Agent 调用 `GET /api/conversation-board` 获取结构化数据（画像 + 收件人预览 + 选定模板），在对话中按**蓝(主色)/白(内容)/灰(分隔)**视觉语言渲染看板，例如：

```
╔════════════════════════════════════════════════╗
║           邮件发送 · 对话看板（请确认）           ║
╠════════════════════════════════════════════════╣
║  【发件方画像】  (蓝色标题)                       ║
║   公司名称：Shenzhen Xinyi Technology Co., Ltd    ║
║   业务类型：Software Development & AI             ║
║   发送目的：营销推广                              ║
║  【邮件模板】  (蓝色标题)                         ║
║   来源：系统预设（营销推广）                      ║
║   主题：Partnership Inquiry — {{company}}         ║
║   正文：Dear {{company}}, ...（预览前 200 字）     ║
║  【收件人】  (蓝色标题)                           ║
║   共 50 位，示例：                               ║
║   - abc@company.com (ABC GmbH)                    ║
║   - xyz@corp.com (XYZ Corp)                       ║
╚════════════════════════════════════════════════╝
```

> 看板不单独开网页，直接在对话中渲染；分隔线用灰色、标题用蓝色、正文用白色（浅色）呈现。

**弹窗前必须在会话中完整展示邮件内容**：Agent 先调用 `GET /api/conversation-board` 取模板与首位客户数据，在对话中渲染 **1 封已套用占位变量的完整示例邮件（主题 + 正文全文）**，必要时附 2–3 条收件人清单，供用户核对主题与正文。无需打开任何网页，用户确认无误后再弹出下方确认弹窗。

随后弹窗确认是否发送：

```python
AskUserQuestion(
    question="邮件内容已准备就绪，共 50 封，是否立即发送？",
    options=[
        {"label": "立即发送", "description": "启动本地服务开始批量发送"},
        {"label": "暂不发送", "description": "保存状态到客户池，稍后在对话中重新发起发送"},
        {"label": "存进邮箱草稿箱", "description": "通过 IMAP 将邮件写入发件方邮箱的草稿文件夹，不消耗配额，稍后在邮件客户端手动发送"}
    ]
)
```

> **三选项行为说明（Agent 据此执行）**：
> - **立即发送**：复用 SMTP 三段式配置 → 启动服务 → 自动发送 → 结果看板（详见 Step 4）。
> - **暂不发送**：仅保存状态到客户池（status 保持 `unsent`），稍后在对话中重新发起发送。
> - **存进邮箱草稿箱（v0.9.0 新增）**：将每封编排好的邮件通过 IMAP（993/SSL）写入发件方邮箱的「草稿」文件夹，**不消耗发送配额**；客户池状态标记为 `draft`，可在结果看板「草稿箱」筛选查看。需先完成 SMTP 配置（草稿箱复用同一邮箱 + 授权码登录 IMAP）。部分邮箱需在网页端开启 IMAP 服务，个别服务商 IMAP 使用独立密码。

#### Step 4：发送执行 + 反馈看板

选择「立即发送」后：① 自动执行 SMTP 配置流程（复用现有三段式） ② 启动 `mail_server.py` ③ 自动执行发送队列 ④ 在聊天中输出结果看板（总数/已发送/退信/失败/失败明细）。

---

### 第 3 步：SMTP 配置（三段式引导，用户零门槛）

> **设计原则**：用户只需要知道自己的邮箱号和授权码。SMTP 服务器、端口、协议（SSL/TLS）全部由系统自动处理。后端已提供 `/api/config/detect`（邮箱识别）和 `/api/config/auto-test`（自动试连+落库）两个 API 支撑此流程。该流程对场景 A/B/C 均适用。

#### 阶段一：邮箱识别（双入口弹窗）

```python
AskUserQuestion(
    header="邮箱类型",
    question="您是否知道自己邮箱属于哪家服务商？",
    options=[
        {"label": "我知道邮箱类型", "description": "从列表中选择您的邮箱服务商"},
        {"label": "我不确定", "description": "直接输入您的邮箱地址，系统自动识别"}
    ]
)
```

- **分支 A（已知类型）**：弹窗列出服务商列表（由 `smtp_providers.quick_provider_list()` 动态返回，覆盖主流国内外邮箱服务商，当前含 18 家），并在末位追加「手工输入邮箱地址」兜选项；选中后 Agent 提示用户输入完整邮箱地址，调用 `/api/config/detect` 自动识别服务商（与分支 B 同源），再获取 SMTP 服务器与端口
- **分支 B（不确定）**：用户输入邮箱后，Agent 调用 `/api/config/detect` 自动识别，并同时返回该提供商的授权码图文引导；匹配不到则尝试 MX 查询或引导咨询 IT

#### 阶段二：授权码引导（含"不会获取"分支）

识别出提供商后弹窗询问有无授权码：

- **有** → 直接输入
- **不知道怎么获取** → Agent 按提供商输出专属授权码图文（来自 `smtp_providers.AUTH_GUIDES`），全程强调 ⚠️ 授权码 ≠ 登录密码

#### 阶段三：自动适配端口/协议 + 测试 + 落库（用户零感知）

Agent 调用 `POST /api/config/auto-test`（邮箱+授权码），后端自动试 465-SSL 与 587-STARTTLS，成功即用并落库 `smtp_config.json`、发确认邮件。全部失败才弹窗引导。

---

### 第 4 步：启动本地服务（Agent 自动执行）

Agent 使用 WorkBuddy 自带的 Python 运行时（无需用户安装），自动：① 创建 venv ② 安装 Flask ③ 启动 `mail_server.py` 监听 `http://localhost:5678`。

### 第 5 步：引导用户操作 HTML 看板

打开邮件发送看板，包含：实时时钟、SMTP 配置区、客户勾选区、手动导入模态框、发送控制区、进度展示区。（场景 B 也可不经看板直接发送。）

## 输出产物

### 主数据目录（运行数据）

```ini
路径：~/.workbuddy/userdata/wxskill/mail-sender-skill/output/
```

```
├── customers.json         ← 全局客户池（含发送状态）
├── smtp_config.json       ← SMTP 邮箱配置
├── send_stats.json        ← 日/月配额统计
├── send_log.json          ← 发送日志（含退信记录）
├── user_profile.json       ← 场景 A/C 用户配置（公司名、业务类型、语言、发送目的、模板选择等）
└── runs/                  ← 每次发送的历史记录归档
```

### 工作区同步副本

```ini
路径：{项目根目录}/output/
```

```
├── customers.json / smtp_config.json / send_stats.json / send_log.json / user_profile.json  ← 同步副本
├── WX-mail-sender-skill.zip       ← Skill 打包文件（构建产物，不同步）
└── WX-mail-sender-skill-logo.png  ← 专家 Logo（构建产物，不同步）
```

## 发送核心逻辑

```python
SEND_INTERVAL = 10   # 默认间隔（秒）
BATCH_SIZE = 50      # 每批最多勾选 50 家

queue = list(selected_customers)
for i, customer in enumerate(queue):
    # 1. DNS 预校验：目标域名无效时直接标记退信
    if not has_valid_domain(customer.get("email", "")):
        mark_bounced(customer)
        continue
    # 2. 配额检查
    if daily_sent >= daily_limit or monthly_sent >= monthly_limit:
        break
    # 3. 已发送的不再发
    if customer["status"] == "sent":
        continue
    # 4. 发送
    success = smtp_send(...)
    # 5. 记录日志 + 更新状态
    save_log(customer, success)
    update_status(customer, "sent" if success else "bounced"/"failed")
    # 6. 间隔等待
    if i < len(queue) - 1:
        time.sleep(SEND_INTERVAL)
```

## 注意事项

- **授权码 ≠ 登录密码**，务必区分
- **企业邮箱优先**，信誉更高、配额更宽松、海外到达率更好
- **首次发测试邮件**，配置完成后自动发送
- **不要用尽配额**，建议日发送量控制在配额的 60%-70%
- **退信不自动重试**，记录在日志中由用户人工处理
- **DNS 预校验**：发送前自动检查目标域名是否存在，无效域名直接标记退信（不消耗配额）
- **SMTP 配置默认保存**，用户说"我要修改邮箱"时进入修改流程
- **对话看板视觉**：蓝(主色)/白(内容)/灰(分隔)，直接在对话中渲染，不单独开网页
- **存进邮箱草稿箱（v0.9.0 新增）**：通过 IMAP 写入发件方邮箱「草稿」文件夹，不消耗发送配额；需先在网页端开启邮箱 IMAP 服务，且复用 SMTP 同一授权码登录（个别服务商 IMAP 需独立密码）。未识别 IMAP 服务器的邮箱会提示无法存入
- **场景 B 索引已修复（v0.8.0 补丁）**：`resolve_data_source` 合并索引记录与实时扫描（排除自身），按获取日期取最新真实客户清单并自愈索引，场景 B 稳定返回最近一次搜索数据（初版「按时间戳取 runs 最新」实测仍返回 0 客户数据，已补充修复）

## 场景 C / 场景 A API 参考（v0.8.0 新增）

### 预设模板（按发送目的）

```http
POST /api/templates
Content-Type: application/json

{ "purpose": "marketing", "language": "English" }
→ 200 { "ok": true, "purpose": "marketing", "language": "English",
        "subject": "Partnership Inquiry — {{company}}", "body": "Dear {{company}}, ..." }

{ "purpose": "list" }
→ 200 { "purposes": [ {"key":"marketing","label_zh":"营销推广"}, ... ] }
```

### 对话看板数据

```http
GET /api/conversation-board
→ 200 {
  "profile": { "company_name": "...", "business_type": "...", "purpose": "marketing", ... },
  "recipient_count": 50,
  "recipient_preview": [ {"email":"a@b.com","company_name":"ABC GmbH"}, ... ],
  "template": { "purpose":"marketing", "subject":"...", "body":"..." }   // 仅当 profile.purpose 存在
}
```

### 用户配置（含发送目的与模板选择）

```http
POST /api/config/user-profile
Content-Type: application/json

{
  "company_name": "Shenzhen Xinyi Technology Co., Ltd",
  "business_type": "Software Development & AI",
  "email_language": "English",
  "content_strategy": "unified_template",
  "placeholder_variable": "{{company}}",
  "purpose": "marketing",            // v0.8.0 新增
  "template_choice": "preset"       // v0.8.0 新增：preset / custom / reuse / ai
}
```

### 存进邮箱草稿箱（v0.9.0 新增）

将编排好的邮件写入发件方邮箱的「草稿」文件夹（IMAP APPEND），**不消耗发送配额**。

```http
POST /api/drafts/save
Content-Type: application/json

{ "customers": [ {"email":"contact@abc.de","company_name":"ABC GmbH","pitch_email":"Dear ABC GmbH,..."}, ... ],
  "draft_task_id": "可选：任务级幂等标识" }
→ 200 {
  "ok": true,
  "draft_task_id": "task-A-123",
  "draft_count": 12, "failed_count": 0, "skipped_count": 0,
  "results": [ {"email":"contact@abc.de","status":"draft","reason":""}, ... ]
}

# 省略 customers 时，对全部客户池执行（受 batch 上限约束）
# 省略 draft_task_id 时自动生成（仅保证单次调用内不重复，跨调用无幂等保护）
# 幂等（v0.9.3）：同一 draft_task_id 内同一收件人只写一次草稿；不同 id（不同场景/新任务）允许重存
# 入参去重：单次调用内同一收件人只处理一次（防合并名单重复导致 20→40）
# 在途守卫：并发/重复触发返回 409「正在存入草稿箱，请等待当前任务完成」
# 前置：需先完成 SMTP 配置（草稿箱复用同一邮箱 + 授权码登录 IMAP）
# 返回 400 示例：{"error":"请先完成 SMTP 配置...","need_config":true}
#              {"error":"未识别到邮箱 user@x.com 的 IMAP 服务器...","email":"user@x.com"}
# 返回 409 示例：{"error":"正在存入草稿箱，请等待当前任务完成"}
```

## 场景 B API 参考（手动导入 / 历史数据）

### 解析文件

```http
POST /api/customers/parse-file
{ "file_path": "C:/path/to/customers.xlsx", "email_column": "email", "company_column": "company_name" }
→ 200 { "ok": true, "total_parsed": 12, "customers": [ {"email":"a@b.com","company_name":"ABC GmbH"}, ... ] }
```

### 解析粘贴

```http
POST /api/customers/parse-paste
{ "content": "contact@abc.de, ABC GmbH\ninfo@xyz.com" }
→ 200 { "ok": true, "total_parsed": 2, "customers": [...] }
```

### 批量更新话术（Agent AI 生成后回写）

```http
POST /api/customers/batch-update-pitch
{ "updates": [ {"email":"contact@abc.de","pitch_email":"Dear ABC GmbH,..."}, ... ] }
→ 200 { "ok": true, "updated_count": 2, "not_found_count": 0, "not_found_emails": [] }
```

### 历史数据定位（场景 B）

```http
POST /api/customers/refresh
→ 200 { "ok": true, "added": N, "updated": M, "source": {...} }
```

## 版本变更记录

| 版本 | 日期 | 变更 |
|:----|:----|:------|
| v0.9.3 | 2026-07-15 | **草稿箱防重复（任务级幂等）**：`POST /api/drafts/save` 新增 `draft_task_id` 参数（调用方对「同一次发送任务」传相同 id、对「不同场景/新任务」传新 id）；同一 id 内同一收件人仅写入草稿箱一次，杜绝「同任务重复触发导致 20→40」；不同 id（不同场景）允许给同一收件人重存；新增三项防护——① 入参按 email 去重、② 在途守卫 `state._drafting`（并发/重复触发返回 409）、③ 客户池记录 `drafted_in_tasks` 持久化本任务已存标记；响应体新增 `draft_task_id` 回传；`customers.json` 每客户新增 `drafted_in_tasks` 列表 |
| v0.9.1 | 2026-07-14 | 取消「发送前确认」弹窗的【先预览再发】选项（该路径依赖打开 HTML 看板网页，且看板缺草稿箱页面，实际无法打开）；改为 Step 3 在会话中直接渲染 1 封已套用占位变量的完整示例邮件（主题 + 正文全文）+ 收件人清单供用户核对，随后弹出三选项确认（立即发送 / 暂不发送 / 存进邮箱草稿箱）；同步更新根 SKILL.md、dist 打包 SKILL.md、智能体 agents.md、设计方案.md、用户使用手册.md |
| v0.9.2 | 2026-07-14 | 分支 A「邮箱识别」弹框新增「手工输入邮箱地址」兜选项：在 `smtp_providers.quick_provider_list()` 返回列表末位追加常量项（name=manual、label=手工输入邮箱地址、description=直接输入完整邮箱地址系统自动识别服务商），覆盖企业自建/学校邮箱等不在固定列表内的情况；选中后用户输入完整邮箱并走 `/api/config/detect` 自动识别（与分支 B 同源）；同步更新根/dist/已注册 SKILL.md、agents.md、设计方案.md、plugin.json，重新打包 zip |
| v0.9.0 | 2026-07-14 | 「发送前确认」弹窗新增第 4 选项【存进邮箱草稿箱】：通过 IMAP（993/SSL）将编排好的邮件写入发件方邮箱的「草稿」文件夹，不消耗发送配额；`smtp_providers.py` 新增 `IMAP_BY_PROVIDER` 与 `get_imap_server()`；`mail_server.py` 新增 `imap_save_draft()`/`_detect_drafts_folder()` 与 `POST /api/drafts/save` 路由；客户池状态新增 `draft` 并在统计/看板中体现；HTML 看板新增「草稿箱」统计卡与筛选；`存进邮箱草稿箱` 选项同步至对话式智能流程、dist 打包 SKILL.md、智能体 agents.md 与设计方案.md |
| v0.8.0 | 2026-07-14 | 场景重排（A=对话式智能/B=搜到的名单/C=手动导入）；新增发件方画像（公司名+业务类型+发送目的四选一）；新增四种邮件模板来源（预设/自定义/沿用导入文件/AI生成）；新增对话看板（蓝白灰、对话内渲染）；`user_profile` 增 `purpose`/`template_choice`；新增 `/api/templates`、`/api/conversation-board`；**跨 skill 索引定位修复（v0.8.0 补丁）**：初版「按时间戳取 runs 最新」实测仍返回 0 客户数据（runs 为陈旧子集），补丁改为 `get_data_source` 过滤 `.intermediate`/0 客户记录 + `resolve_data_source` 合并索引与实时扫描（排除自身）取获取日期最新者并自愈索引，场景 B 稳定返回最近一次搜索的真实客户清单 |
| v0.7.0 | 2026-07-13 | SMTP 配置全面优化：三段式引导（邮箱自动识别+授权码分支+端口自动适配）、新增 587-STARTTLS 支持、15 家提供商映射表、新增 `/api/config/detect` 和 `/api/config/auto-test` 后端 API |
| v0.6.0 | 2026-07-09 | 新增场景 C 对话式智能邮件发送（对话引导 + AI 话术生成 + 用户配置持久化 + 发送反馈看板） |
| v0.5.0 | 2026-07-09 | 新增场景 B 手动导入功能（Excel/CSV/粘贴解析、批量话术更新）；新增 AI 话术生成流程 |
| v0.4.0 | 2026-07-06 | 完善跨 skill 索引；优化 SMTP 配置流程；新增四级数据定位策略 |
| v0.3.0 | — | 初始骨架搭建 |

## 安全性

| 风险 | 应对措施 |
|:----|:---------|
| SMTP 密码明文存储 | 仅存本地 smtp_config.json，不离开用户电脑 |
| 发送频率过高被封 | 间隔控制 + 日/月配额双层限制 |
| 退信影响域名信誉 | 退信地址记录在日志，不自动重试 |
| IP 被拉黑 | 依赖用户自有邮箱信誉，本工具不干预 |
| 授权码泄露 | 建议使用时填入，用后清除配置 |

## 交互规范

本 Skill 的所有执行步骤必须使用 `AskUserQuestion` 弹窗征求用户确认，**不得直接代劳决策**。关键弹窗场景：

| 弹窗时机 | 选项 |
|:---------|:-----|
| 选择发送场景 | 对话式智能邮件发送（推荐）/ 使用之前搜到的客户名单 / 手动导入新客户邮箱 |
| 场景 A/C：沿用上次配置 | 沿用 / 重新配置 |
| 场景 A/C：发件方业务类型 | AI 推荐选项 / 手动输入 |
| 场景 A/C：发送目的 | 营销推广 / 问候祝福 / 会议邀约 / 其它 |
| 场景 A/C：邮件模板来源 | 系统预设 / 自定义内容 / 沿用导入文件 / AI 生成 |
| 场景 A/C：发送前确认 | 立即发送 / 暂不发送 / 存进邮箱草稿箱 |
| 选择数据源（场景 B 多结果） | 列出候选 runs / 手动指定路径 |
| SMTP 提供商（已知类型） | 列表由 `quick_provider_list()` 动态返回（QQ / 163 / 126 / Gmail / Outlook / 企业邮 / 新浪 / 139 / 189 / 搜狐 / Yahoo / iCloud / Zoho / Yandex 等 18 家）+ 末位「手工输入邮箱地址」兜选项（直接输入完整邮箱自动识别） |
| SMTP 邮箱识别（不确定） | 输入邮箱地址 → 自动识别提供商 |
| SMTP 授权码 | 我有授权码 / 不知道怎么获取（→ 输出专属图文引导） |
| SMTP 自动配置失败 | 检查授权码 / 手动输入 SMTP / 咨询 IT 部门 |
| 缺少话术 | 生成通用模板 / 手动输入正文 |
| 发送间隔 | 10秒 / 20秒 / 30秒 |
| 发送前确认 | 确认 / 修改 / 仅发 5 封测试 |
| 测试邮件失败 | 重新配置 / 只改授权码 / 取消 |
| 修改邮箱配置（用户说"我要修改邮箱"时） | 切换提供商 / 改授权码 / 改发件人名称 |

## 使用示例

### 场景 A 示例（对话式智能，推荐）

```
用户：帮我发邮件
Agent：
  1. 弹窗选场景 → 用户选「对话式智能邮件发送（推荐）」= 场景 A
  2. 对话导入收件方邮箱（粘贴 50 个）→ 预览确认
  3. 对话输入公司名 → 弹窗确认业务类型（AI 推荐）
  4. 弹窗选发送目的 → 用户选「营销推广」
  5. 弹窗选模板来源 → 用户选「系统预设」
  6. Agent 调 /api/templates 取预设，替换占位，对话渲染蓝白灰看板
  7. 弹窗确认发送 → 用户选「立即发送」
  8. SMTP 三段式配置（若已保存则跳过）
  9. 启动服务 → 自动发送 → 聊天输出结果看板
```

### 场景 B 示例（搜到的名单）

```
用户：发之前搜到的客户
Agent：
  1. 弹窗选场景 → 用户选「使用之前搜到的客户名单」
  2. resolve_data_source 定位最新历史数据（v0.8.0 已修复，秒级返回最新）
  3. 合并客户池 → 弹窗选提供商 → 授权码 → 自动测试
  4. 启动服务 → 打开看板或直接发送 → 结果看板
```

### 场景 C 示例（手动导入）

```
用户：导入一批邮箱发开发信
Agent：
  1. 弹窗选场景 → 用户选「手动导入新客户邮箱」
  2. HTML 看板导入 Excel/CSV/粘贴 → 预览确认
  3. 进入共享主流程：收集画像 → 选目的 → 选模板 → 对话看板确认
  4. SMTP 配置 → 发送 → 结果看板
```

## 参考

- 详细设计方案见 `docs/设计方案.md`
- 跨 skill 索引工具见 `src/cross_skill_index.py`
- 邮件预设模板见 `src/email_templates.py`
