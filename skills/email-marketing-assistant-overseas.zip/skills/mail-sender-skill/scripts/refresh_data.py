"""
refresh_data.py — 一键更新客户数据

用法（任选一种）：
  1. 双击本文件（Windows 自动用 Python 打开）
  2. 在终端输入：python refresh_data.py
  3. 或在聊天中对我说「更新客户数据」
"""

import json
import sys
from pathlib import Path

# ─── 工具函数（彩色输出） ───

def print_step(msg):
    print(f"\n  📦 {msg}")

def print_ok(msg):
    print(f"  ✅ {msg}")

def print_info(msg):
    print(f"  ℹ️  {msg}")

def print_err(msg):
    print(f"  ❌ {msg}")

# ─── 主流程 ───

def main():
    print("=" * 50)
    print("     📥 客户数据一键刷新工具")
    print("=" * 50)

    # Step 1: 加载索引模块
    print_step("正在加载数据扫描模块...")
    script_dir = Path(__file__).parent
    if str(script_dir) not in sys.path:
        sys.path.insert(0, str(script_dir))

    try:
        from cross_skill_index import scan_for_data_source, update_data_source
    except ImportError as e:
        print_err(f"加载 cross_skill_index 模块失败: {e}")
        print_info("请确认本文件与 cross_skill_index.py 在同一目录下")
        input("\n按 Enter 键退出...")
        return

    # Step 2: 扫描数据源
    print_step("正在扫描客户数据源...")
    source = scan_for_data_source("customer-list")

    if not source:
        print_err("未扫描到有效客户数据源")
        print_info("请确认已运行海外地图获客并产出了搜索结果文件")
        input("\n按 Enter 键退出...")
        return

    print_ok(f"找到数据源")
    print_info(f"  生产者: {source.get('producer', '?')}")
    print_info(f"  公司:    {source.get('company', '?')}")
    print_info(f"  国家:    {source.get('country', '?')}")
    print_info(f"  客户数:  {source.get('customer_count', 0)} 家")
    print_info(f"  有邮箱:  {source.get('email_count', 0)} 个")

    # Step 3: 回写索引
    update_data_source("customer-list", source)
    print_ok("已回写索引，下次扫描更快")

    # Step 4: 读取数据文件
    json_file = source.get("json_file", "")
    if json_file.startswith("~/"):
        json_file = str(Path.home() / json_file[2:])
    json_path = Path(json_file)

    if not json_path.exists():
        print_err(f"数据文件不存在: {json_path}")
        input("\n按 Enter 键退出...")
        return

    print_step(f"正在读取数据文件...")
    with open(json_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    customers = data.get("customers", [])
    print_info(f"文件内含 {len(customers)} 条客户数据")

    import_list = []
    today_str = __import__("datetime").datetime.now().strftime("%Y-%m-%d")
    company = source.get("company", "")
    country = source.get("country", "")
    run_name = f"{company}_{country}" if company and country else source.get("producer", "未知")

    for c in customers:
        if not c.get("email"):
            continue
        c["_acquired_date"] = source.get("_acquired_date", today_str)
        c["_run_name"] = run_name
        c.setdefault("status", "unsent")
        c.setdefault("send_count", 0)
        import_list.append(c)

    if not import_list:
        print_err("数据源中没有含邮箱的客户，无需导入")
        input("\n按 Enter 键退出...")
        return

    print_info(f"含邮箱客户: {len(import_list)} 条")

    # Step 5: 通过 API 导入
    print_step("正在导入到邮件发送服务...")
    try:
        import urllib.request
        payload = json.dumps({"customers": import_list}).encode("utf-8")
        req = urllib.request.Request(
            "http://localhost:5678/api/customers/import",
            data=payload,
            headers={"Content-Type": "application/json"},
        )
        resp = urllib.request.urlopen(req)
        result = json.loads(resp.read())

        if result.get("ok"):
            print_ok(f"导入完成！新增 {result.get('added', 0)} 条，更新 {result.get('updated', 0)} 条")
            print_info(f"当前客户池共 {result.get('stats', {}).get('total', '?')} 条")
        else:
            print_err(f"导入失败: {result.get('error', '未知错误')}")
    except urllib.request.URLError:
        print_err("无法连接邮件发送服务（http://localhost:5678）")
        print_info("请先启动服务，或直接在聊天中告诉我「更新客户数据」")
    except Exception as e:
        print_err(f"导入异常: {e}")

    print("\n" + "=" * 50)
    input("按 Enter 键退出...")


if __name__ == "__main__":
    main()
