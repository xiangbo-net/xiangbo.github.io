"""
smtp_test.py — SMTP 邮箱兼容性测试工具

用途：测试各邮箱 SMTP 服务器的 TCP 连接、SSL 握手、SMTP banner，
      验证 mail-sender-skill 的 SMTP 配置是否正确。
      
用法：
  python smtp_test.py              ← 测试所有已知邮箱
  python smtp_test.py --server smtp.qq.com --port 465  ← 测试指定邮箱
  python smtp_test.py --quick      ← 仅测试连接，不验证证书详情

输出：控制台彩色表格，每项测试有 ✅/❌ 标识
"""

import socket
import ssl
import time
import sys
from datetime import datetime

# ─── 测试配置（从共享模块导入） ───

import sys
from pathlib import Path
_this_dir = Path(__file__).parent
if str(_this_dir) not in sys.path:
    sys.path.insert(0, str(_this_dir))
from smtp_providers import get_all_servers

# 转换为测试工具所需的格式（兼容现有 SMTP_PROVIDERS 结构）
SMTP_PROVIDERS = [
    {"name": s["name"], "server": s["server"], "port": s["port"], "ssl": s["ssl"]}
    for s in get_all_servers()
]

TIMEOUT = 8  # 单次测试超时（秒）
COLORS = {
    "green": "\033[92m",
    "red": "\033[91m",
    "yellow": "\033[93m",
    "cyan": "\033[96m",
    "reset": "\033[0m",
    "bold": "\033[1m",
    "dim": "\033[2m",
}


def c(code, text):
    """带颜色的输出。"""
    return f"{COLORS.get(code, '')}{text}{COLORS['reset']}"


def test_smtp_server(server: str, port: int, use_ssl: bool, quick: bool = False) -> dict:
    """测试单个 SMTP 服务器的连通性和 banner。"""
    result = {
        "server": server,
        "port": port,
        "ssl": use_ssl,
        "reachable": False,
        "banner": "",
        "cert_info": "",
        "dns_ok": False,
        "error": "",
        "latency_ms": 0,
    }

    # 1. DNS 解析
    try:
        t0 = time.time()
        addr = socket.getaddrinfo(server, port)
        result["dns_ok"] = True
        result["latency_ms"] = round((time.time() - t0) * 1000)
    except socket.gaierror as e:
        result["error"] = f"DNS 解析失败: {e}"
        return result

    # 2. TCP + SSL 连接
    sock = None
    try:
        t0 = time.time()
        sock = socket.create_connection((server, port), timeout=TIMEOUT)

        if use_ssl:
            context = ssl.create_default_context()
            # 标准端口 465 用 SSL；587 用 STARTTLS
            if port == 465:
                ssock = context.wrap_socket(sock, server_hostname=server)
            else:
                # 587 端口：先发 EHLO，再 STARTTLS
                sock.sendall(b"EHLO test\r\n")
                resp = sock.recv(1024)
                sock.sendall(b"STARTTLS\r\n")
                resp2 = sock.recv(1024)
                ssock = context.wrap_socket(sock, server_hostname=server)
            sock = ssock  # 替换为 ssl socket

        latency = round((time.time() - t0) * 1000)
        result["latency_ms"] = latency

        # 读取 banner
        if use_ssl:
            banner = sock.recv(1024).decode("utf-8", errors="ignore").strip()
        else:
            banner = sock.recv(1024).decode("utf-8", errors="ignore").strip()

        result["reachable"] = True
        result["banner"] = banner[:120]

        # 证书信息（SSL 模式）
        if use_ssl and hasattr(sock, "getpeercert"):
            try:
                cert = sock.getpeercert()
                if cert:
                    issuer = dict(x[0] for x in cert.get("issuer", []) if x)
                    subject = dict(x[0] for x in cert.get("subject", []) if x)
                    result["cert_info"] = (
                        f"颁发者: {issuer.get('organizationName', 'N/A')}, "
                        f"域名: {subject.get('commonName', 'N/A')}"
                    )
                else:
                    result["cert_info"] = "无证书信息"
            except Exception:
                result["cert_info"] = "证书读取失败"

    except socket.timeout:
        result["error"] = f"连接超时（{TIMEOUT}秒）"
    except ConnectionRefusedError:
        result["error"] = "连接被拒绝"
    except ssl.SSLError as e:
        result["error"] = f"SSL 错误: {e}"
    except Exception as e:
        result["error"] = f"未知错误: {e}"
    finally:
        if sock:
            try:
                sock.close()
            except Exception:
                pass

    return result


def run_tests(providers: list, quick: bool = False):
    """运行测试并输出表格。"""
    print("\n" + c("bold", "═" * 70))
    print(c("bold", "  SMTP 邮箱兼容性测试报告"))
    print(c("dim", f"  测试时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"))
    print(c("bold", "═" * 70))

    results = []
    for p in providers:
        label = f"{p['name']} ({p['server']}:{p['port']})"
        print(f"\n  {c('cyan', '▶')} 测试 {c('bold', p['name'])}  ", end="")
        sys.stdout.flush()

        r = test_smtp_server(p["server"], p["port"], p["ssl"], quick)
        results.append({**p, **r})

        if r["reachable"]:
            print(f"{c('green', '✅ 可达')}  ({r['latency_ms']}ms)")
        else:
            print(f"{c('red', '❌ 失败')}  {r['error'][:60]}")

        if not quick and r["reachable"]:
            print(f"     Banner: {c('dim', r['banner'][:100])}")
            if r["cert_info"]:
                print(f"     证书:   {c('dim', r['cert_info'][:100])}")

    # ─── 汇总 ───
    print("\n" + c("bold", "═" * 70))
    print(c("bold", "  测试汇总"))
    print(c("bold", "═" * 70))

    reachable_count = sum(1 for r in results if r["reachable"])
    print(f"\n  总计: {len(results)} 项  |  ✅ 可达: {c('green', str(reachable_count))}  |  ❌ 失败: {c('red', str(len(results) - reachable_count))}")

    print(f"\n  {c('bold', '📌 推荐邮箱（SSL 465 端口，稳定可达）:')}")
    for r in results:
        if r["reachable"] and r["port"] == 465:
            print(f"    {c('green', '✅')} {r['name']:<12}  {r['server']:<22}  {r['latency_ms']}ms")

    print(f"\n  {c('bold', '⚠️ 需要注意的邮箱:')}")
    for r in results:
        if not r["reachable"] and r["port"] == 465:
            print(f"    {c('red', '❌')} {r['name']:<12}  {r['server']:<22}  {r['error'][:50]}")

    # 兼容性结论
    print(f"\n  {c('bold', '📋 兼容性结论:')}")
    for proto in ["Gmail", "QQ 邮箱", "163 邮箱", "Outlook", "腾讯企业邮", "阿里企业邮", "Zoho Mail"]:
        ssl_res = next((r for r in results if r["name"] == proto and r["port"] == 465), None)
        tls_res = next((r for r in results if r["name"] == f"{proto} (TLS)"), None)
        if ssl_res and ssl_res["reachable"]:
            print(f"    {c('green', '✅')} {proto:<12}  SSL 465 端口 {c('green', '可用')}  ({ssl_res['latency_ms']}ms)")
        elif tls_res and tls_res["reachable"]:
            print(f"    {c('yellow', '⚠️')} {proto:<12}  SSL 465 不可用，TLS 587 端口 {c('green', '可用')}")
        else:
            reason = (ssl_res and ssl_res["error"]) or (tls_res and tls_res["error"]) or "未知"
            print(f"    {c('red', '❌')} {proto:<12}  不可用 — {reason[:40]}")


def test_custom(server: str, port: int):
    """测试自定义 SMTP 服务器。"""
    print(f"\n{c('bold', '测试自定义 SMTP:')} {server}:{port}")
    r = test_smtp_server(server, port, port == 465)
    if r["reachable"]:
        print(f"  {c('green', '✅ 可达')} ({r['latency_ms']}ms)")
        print(f"  Banner: {r['banner']}")
        if r["cert_info"]:
            print(f"  证书: {r['cert_info']}")
    else:
        print(f"  {c('red', '❌ 失败')}: {r['error']}")


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="SMTP 邮箱兼容性测试工具")
    parser.add_argument("--server", help="自定义 SMTP 服务器地址")
    parser.add_argument("--port", type=int, default=465, help="自定义端口（默认 465）")
    parser.add_argument("--quick", action="store_true", help="快速模式：仅测试可达性，不输出证书详情")
    args = parser.parse_args()

    if args.server:
        test_custom(args.server, args.port)
    else:
        run_tests(SMTP_PROVIDERS, args.quick)

    print()
