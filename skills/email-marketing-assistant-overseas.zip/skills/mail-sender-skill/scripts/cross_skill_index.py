"""
cross_skill_index.py — 跨 Skill 数据共享索引 v2

核心变更（v1 → v2）：
  v1: 索引键 = skill_name（如 "tavily-customer-miner"）
  v2: 索引键 = data_type（如 "customer-list"），producer 改名不影响查找

架构：
  - 共享索引文件：~/.workbuddy/skill_data_index.json
  - 路径存储：home 目录下使用 ~/ 相对路径，home 外保持绝对路径
  - 自愈机制：索引失效时自动扫描 + 回写

数据源识别策略（多线索评分）：
  不依赖单一文件名或字段名，组合多项线索评分，总分 ≥ 0.6 即视为有效。
  详见 score_customer_source() 函数。

v1 → v2 自动迁移：
  首次加载旧索引时自动转换 data_sources 格式，保留原 skills 块不动。
"""

import json
import os
import re
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

INDEX_PATH = Path.home() / ".workbuddy" / "skill_data_index.json"
MAX_HISTORY = 20

CURRENT_VERSION = 2

# ─── 路径工具 ───


def _to_relative(path_str: str) -> str:
    """将路径转换为 ~/ 相对形式（仅在 home 目录下时）。"""
    if not path_str:
        return path_str
    p = Path(path_str)
    try:
        rel = p.relative_to(Path.home())
        return "~/" + rel.as_posix()
    except ValueError:
        return path_str


def _to_absolute(path_str: str) -> str:
    """将 ~/ 路径解析为绝对路径。"""
    if not path_str:
        return path_str
    if path_str.startswith("~/"):
        return str((Path.home() / path_str[2:]).resolve())
    return path_str


def _resolve_path(path_str: str) -> Path | None:
    """解析路径字符串为 Path 对象，验证存在性。"""
    if not path_str:
        return None
    p = Path(_to_absolute(path_str))
    return p if p.exists() else None


# ─── 索引存储 ───


def _load() -> dict:
    """加载索引文件，自动执行 v1→v2 迁移。"""
    if not INDEX_PATH.exists():
        return {"version": CURRENT_VERSION, "data_sources": {}}
    try:
        with open(INDEX_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return {"version": CURRENT_VERSION, "data_sources": {}}

    if data.get("version", 1) < 2:
        data = _migrate_v1_to_v2(data)
    return data


def _save(data: dict):
    """原子化写入索引文件。"""
    INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = INDEX_PATH.with_suffix(".tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(INDEX_PATH)


def _migrate_v1_to_v2(v1_data: dict) -> dict:
    """将 v1 索引（skills/{name}/runs）迁移为 v2（data_sources/{type}/runs）。"""
    v2 = {"version": 2, "data_sources": {}}
    v2["_migrated_from_v1_at"] = datetime.now(timezone.utc).astimezone().isoformat()

    old_skills = v1_data.get("skills", {})
    if old_skills:
        # 将所有旧 skill 的 runs 合并到 customer-list 下
        all_runs = []
        for skill_name, skill_data in old_skills.items():
            for run in skill_data.get("runs", []):
                run["_producer"] = skill_name
                # 路径转换
                if "json_file" in run:
                    run["json_file"] = _to_relative(run["json_file"])
                if "output_dir" in run:
                    run["output_dir"] = _to_relative(run["output_dir"])
                all_runs.append(run)

        # 按时间降序排列
        all_runs.sort(key=lambda r: r.get("timestamp", ""), reverse=True)

        if all_runs:
            v2["data_sources"]["customer-list"] = {
                "latest": all_runs[0],
                "runs": all_runs,
            }

    # 保留原始 v1 数据备查
    v2["_v1_legacy"] = v1_data

    _save(v2)
    return v2


# ─── 数据源评分（内容扫描核心） ───


def score_customer_source(file_path: Path) -> float:
    """
    对候选 JSON 文件进行多线索评分，返回 0.0 ~ 1.0 的置信度。

    阈值建议：≥ 0.6 视为有效客户数据源。
    """
    score = 0.0

    # ── 目录线索（最高 0.25） ──
    if "output" in file_path.parent.name:
        score += 0.15
    if "wxskill" in file_path.parts:
        score += 0.10

    # ── 文件名线索（最高 0.20） ──
    name = file_path.stem
    # 匹配 YYYY-MM-DD、YYYYMMDD、YYYY年MM月DD日 等日期格式
    if re.search(r'\d{4}[-年]\d{1,2}[-月]\d{1,2}', name) or re.search(r'\d{8}', name):
        score += 0.10
    if any(kw in name.lower() for kw in ["搜索", "结果", "客户", "list", "result",
                                          "customer", "search", "output", "客户清单"]):
        score += 0.10

    # ── 内容线索（最高 0.45） ──
    try:
        ext = file_path.suffix.lower()
        items = []

        if ext == ".json":
            raw = file_path.read_text(encoding="utf-8", errors="replace")
            data = json.loads(raw)
            items = data if isinstance(data, list) else data.get("customers", [data])
        elif ext == ".xlsx":
            # 使用 openpyxl 解析 Excel 文件
            try:
                import openpyxl
                wb = openpyxl.load_workbook(file_path, read_only=True, data_only=True)
                ws = wb.active
                if ws and ws.max_row and ws.max_row > 1:
                    headers = [str(c.value or "").strip().lower() for c in next(ws.iter_rows(min_row=1, max_row=1))]
                    for row in ws.iter_rows(min_row=2, values_only=True):
                        item = {}
                        for i, h in enumerate(headers):
                            if i < len(row):
                                item[h] = row[i]
                        items.append(item)
                if ws:
                    wb.close()
            except ImportError:
                pass  # openpyxl 未安装，跳过内容评分

        if items:
            score += 0.15  # 有客户数据
            # 扫描全部客户，只要有一个有邮箱/公司名/国家/网站即得分（支持中英文列名）
            def _v(item, *keys):
                """从 item 中按多个 key 依次取值，返回第一个非空值"""
                for k in keys:
                    val = item.get(k) if isinstance(item, dict) else None
                    if val:
                        return val
                return None

            has_company = any(_v(item, "company_name", "公司名称", "公司名") for item in items)
            has_email = any(_v(item, "email", "邮箱", "邮箱地址", "e-mail", "mail") for item in items)
            has_country = any(_v(item, "country", "国家") for item in items)
            has_website_or_phone = any(
                _v(item, "website", "官网", "web") or _v(item, "phone", "联系电话", "电话")
                for item in items
            )
            if has_company:
                score += 0.10
            if has_email:
                score += 0.10
            if has_country:
                score += 0.05
            if has_website_or_phone:
                score += 0.05
    except Exception:
        pass

    # ── 伴生文件线索（最高 0.10） ──
    companion_count = 0
    for ext in [".md", ".xlsx", ".html"]:
        if file_path.with_suffix(ext).exists():
            companion_count += 1
    score += min(companion_count * 0.04, 0.10)

    return min(score, 1.0)


def find_best_source(directory: Path) -> Optional[dict]:
    """
    在指定目录下递归查找得分最高的客户数据文件（支持 JSON 和 XLSX）。

    返回：{"json_file": str, "score": float, "metadata": dict} 或 None
    同分时按邮箱数 > 客户数择优。
    """
    best = {"score": 0.0, "json_file": None, "metadata": {}}

    def _extract_metadata(data_path: Path, ext_f: str) -> dict:
        """提取文件元数据（客户数、邮箱数、公司名、国家）"""
        meta = {"company": "", "country": "", "customer_count": 0, "email_count": 0,
                "timestamp": datetime.fromtimestamp(data_path.stat().st_mtime).isoformat()}
        if ext_f == ".json":
            raw = data_path.read_text(encoding="utf-8", errors="replace")
            data = json.loads(raw)
            items = data if isinstance(data, list) else data.get("customers", [])
            meta["customer_count"] = len(items) if isinstance(items, list) else 0
            meta["email_count"] = sum(1 for c in items if isinstance(c, dict) and (
                c.get("email") or c.get("邮箱") or c.get("邮箱地址")))
            if items and isinstance(items[0], dict):
                meta["company"] = items[0].get("company_name", "") or items[0].get("公司名称", "")
                meta["country"] = items[0].get("country", "") or items[0].get("国家", "")
        elif ext_f == ".xlsx":
            try:
                import openpyxl
                wb = openpyxl.load_workbook(data_path, read_only=True, data_only=True)
                ws = wb.active
                if ws and ws.max_row and ws.max_row > 1:
                    headers = [str(c.value or "").strip().lower() for c in next(ws.iter_rows(min_row=1, max_row=1))]
                    email_idx = next((i for i, h in enumerate(headers) if h in ("email", "邮箱", "邮箱地址", "e-mail", "mail")), -1)
                    company_idx = next((i for i, h in enumerate(headers) if h in ("company_name", "公司名称", "公司名")), -1)
                    country_idx = next((i for i, h in enumerate(headers) if h in ("country", "国家")), -1)
                    total_rows = 0; email_count = 0
                    first_company = ""; first_country = ""
                    for row in ws.iter_rows(min_row=2, values_only=True):
                        total_rows += 1
                        if email_idx >= 0 and email_idx < len(row) and row[email_idx]:
                            email_count += 1
                        if not first_company and company_idx >= 0 and company_idx < len(row) and row[company_idx]:
                            first_company = str(row[company_idx] or "")
                        if not first_country and country_idx >= 0 and country_idx < len(row) and row[country_idx]:
                            first_country = str(row[country_idx] or "")
                    meta["customer_count"] = total_rows
                    meta["email_count"] = email_count
                    meta["company"] = first_company
                    meta["country"] = first_country
                if ws: wb.close()
            except ImportError:
                pass
        return meta

    for ext in ("*.json", "*.xlsx"):
        for data_path in sorted(directory.rglob(ext), key=lambda p: p.stat().st_mtime, reverse=True):
            score = score_customer_source(data_path)
            if not (score > 0.6):
                continue

            # 提取 metadata 后判断是否替换 best
            meta = _extract_metadata(data_path, data_path.suffix.lower())

            should_replace = False
            if best["json_file"] is None:
                should_replace = True
            elif score > best["score"]:
                should_replace = True
            elif score == best["score"]:
                # 同分：按邮箱数 > 客户数择优
                if meta["email_count"] > best["metadata"]["email_count"]:
                    should_replace = True
                elif meta["email_count"] == best["metadata"]["email_count"] and meta["customer_count"] > best["metadata"]["customer_count"]:
                    should_replace = True

            if should_replace:
                best = {"score": score, "json_file": str(data_path), "metadata": meta}
                break  # 每个目录找到最优即退出（已按 mtime 降序，最先找到的是最新的）

    return best if best["json_file"] else None


# ─── 自动扫描路径 ───


DEFAULT_SCAN_PATHS = [
    Path.home() / ".workbuddy" / "userdata" / "wxskill",
    Path.home() / ".workbuddy" / "skills",
    Path.home() / "workbuddyproject",
]


def scan_for_data_source(
    data_type: str = "customer-list",
    scan_paths: list[Path] = None,
    exclude_producers: list[str] = None,
    return_all: bool = False,
) -> Optional[dict]:
    """
    在指定路径集合中扫描数据源。

    返回格式：
        {
            "json_file": "~/.../搜索结果.json",
            "output_dir": "~/.../output",
            "producer": str,         # 文件夹名称
            "_acquired_date": str,   # 取自文件名或文件 mtime
            "company": str,
            "country": str,
            "customer_count": int,
            "email_count": int,
            "timestamp": str,        # ISO 格式
            "score": float,
        }
    """
    scan_paths = scan_paths or DEFAULT_SCAN_PATHS
    exclude_producers = set(exclude_producers or [])
    candidates = []

    for base_dir in scan_paths:
        if not base_dir.exists():
            continue
        # 扫描 output/ 目录（wxskill 下每个 skill 的 output）
        if base_dir.name == "wxskill" or "wxskill" in base_dir.parts:
            for skill_dir in base_dir.iterdir():
                if not skill_dir.is_dir():
                    continue
                # 排除消费者自身目录，避免自引用
                if skill_dir.name in exclude_producers:
                    continue
                output_dir = skill_dir / "output"
                if output_dir.exists():
                    if return_all:
                        # 收集该 skill 所有合格的数据文件
                        for ext in ("*.json", "*.xlsx"):
                            for data_path in output_dir.rglob(ext):
                                s = score_customer_source(data_path)
                                if s > 0.6:
                                    # 提取简单的元数据（仅用于候选列表）
                                    meta = {"customer_count": 0, "email_count": 0}
                                    try:
                                        if data_path.suffix.lower() == ".xlsx":
                                            import openpyxl
                                            wb = openpyxl.load_workbook(data_path, read_only=True, data_only=True)
                                            ws = wb.active
                                            if ws and ws.max_row and ws.max_row > 1:
                                                headers = [str(c.value or "").strip().lower() for c in next(ws.iter_rows(min_row=1, max_row=1))]
                                                ei = next((i for i, h in enumerate(headers) if h in ("email","邮箱","邮箱地址","e-mail","mail")), -1)
                                                rr = 0; ec = 0
                                                for row in ws.iter_rows(min_row=2, values_only=True):
                                                    rr += 1
                                                    if ei >= 0 and ei < len(row) and row[ei]:
                                                        ec += 1
                                                meta = {"customer_count": rr, "email_count": ec}
                                            if ws: wb.close()
                                    except ImportError:
                                        pass
                                    candidates.append({
                                        "json_file": str(data_path),
                                        "output_dir": str(output_dir),
                                        "producer": skill_dir.name,
                                        "score": s,
                                        "metadata": meta,
                                    })
                    else:
                        result = find_best_source(output_dir)
                        if result:
                            result["output_dir"] = str(output_dir)
                            result["producer"] = skill_dir.name
                            candidates.append(result)
        else:
            # 直接扫描当前目录
            result = find_best_source(base_dir)
            if result:
                result["output_dir"] = str(base_dir)
                result["producer"] = base_dir.name
                candidates.append(result)

    if not candidates:
        return None

    # 按得分降序，同分按邮箱数降序
    candidates.sort(key=lambda c: (c["score"], c["metadata"]["email_count"]), reverse=True)

    # return_all 模式：返回所有合格候选
    if return_all:
        results = []
        seen_files = set()
        for cand in candidates:
            jf = cand.get("json_file", "")
            if jf in seen_files:
                continue
            seen_files.add(jf)
            name = Path(jf).stem
            m = re.search(r'(\d{4}[-年]\d{1,2}[-月]\d{1,2})', name) or re.search(r'(\d{8})', name)
            acq_date = ""
            if m:
                acq_date = m.group(1).replace("年", "-").replace("月", "-").replace("日", "")
                if len(acq_date) == 8:
                    acq_date = f"{acq_date[:4]}-{acq_date[4:6]}-{acq_date[6:]}"
            else:
                try:
                    ts = os.path.getmtime(jf)
                    acq_date = datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
                except Exception:
                    acq_date = datetime.now().strftime("%Y-%m-%d")
            results.append({
                "json_file": _to_relative(jf),
                "output_dir": _to_relative(cand.get("output_dir", "")),
                "producer": cand.get("producer", ""),
                "_acquired_date": acq_date,
                "company": cand["metadata"].get("company", ""),
                "country": cand["metadata"].get("country", ""),
                "customer_count": cand["metadata"].get("customer_count", 0),
                "email_count": cand["metadata"].get("email_count", 0),
                "score": round(cand["score"], 2),
            })
        return results

    # 单源模式：返回最佳结果（兼容旧行为）
    best = candidates[0]

    # 提取获取日期（优先从文件名，其次文件 mtime）
    acq_date = ""
    name = Path(best["json_file"]).stem
    m = re.search(r'(\d{4}[-年]\d{1,2}[-月]\d{1,2})', name)
    if m:
        acq_date = m.group(1).replace("年", "-").replace("月", "-").replace("日", "")
    else:
        try:
            ts = os.path.getmtime(best["json_file"])
            acq_date = datetime.fromtimestamp(ts).strftime("%Y-%m-%d")
        except Exception:
            acq_date = datetime.now().strftime("%Y-%m-%d")

    return {
        "json_file": _to_relative(best["json_file"]),
        "output_dir": _to_relative(best["output_dir"]),
        "producer": best.get("producer", ""),
        "_acquired_date": acq_date,
        "company": best["metadata"].get("company", ""),
        "country": best["metadata"].get("country", ""),
        "customer_count": best["metadata"].get("customer_count", 0),
        "email_count": best["metadata"].get("email_count", 0),
        "timestamp": best["metadata"].get("timestamp", datetime.now().isoformat()),
        "score": round(best["score"], 2),
    }


# ─── 数据类型索引（v2 核心 API） ───


def update_data_source(data_type: str, source_info: dict):
    """
    向索引写入一条数据源记录。

    参数：
        data_type — 数据类型，如 "customer-list"
        source_info — 包含 json_file、output_dir、company 等字段

    使用示例：
        update_data_source("customer-list", {
            "json_file": "~/userdata/wxskill/.../搜索结果.json",
            "output_dir": "~/userdata/wxskill/.../output",
            "company": "湖南五金制品厂",
            "country": "德国",
            "customer_count": 54,
            "email_count": 3,
            "producer": "overseas-customer-miner",
        })
    """
    record = {
        "timestamp": source_info.get("timestamp", datetime.now(timezone.utc).astimezone().isoformat()),
        **source_info,
    }

    data = _load()
    ds_data = data.setdefault("data_sources", {}).setdefault(data_type, {"runs": []})
    runs = ds_data.setdefault("runs", [])

    # 路径统一为相对形式
    if record.get("json_file"):
        record["json_file"] = _to_relative(record["json_file"])
    if record.get("output_dir"):
        record["output_dir"] = _to_relative(record["output_dir"])

    # 去重：如果相同 json_file 已存在，只更新时间戳
    for i, r in enumerate(runs):
        if r.get("json_file") == record.get("json_file"):
            runs[i] = record
            break
    else:
        runs.insert(0, record)

    # 保留上限
    if len(runs) > MAX_HISTORY:
        runs[:] = runs[:MAX_HISTORY]

    ds_data["latest"] = record
    data["_updated_at"] = record["timestamp"]

    _save(data)


def get_data_source(data_type: str) -> Optional[dict]:
    """
    获取指定数据类型的最新数据源记录。

    返回 dict 或 None。路径已解析为绝对路径。

    v0.8.0 修复（before/after）：
      - before: 直接返回 ds["latest"]，该字段在 v2 迁移后长期指向 2026-07-09 的陈旧记录，
                导致 Tier0 快路径返回非最新数据。
      - after (v0.8.0 初版): 不再信任 ds["latest"]，改为在 runs 中按时间戳取"文件仍存在"的最新记录。
      - after (v0.8.0 补丁): 初版修复不彻底——runs 本身是 v2 迁移后的陈旧子集（仅含桂林 .intermediate
                一条），按时间戳取仍取到该陈旧记录。现额外过滤两类无效记录：
                (1) 路径含 ".intermediate" 的临时文件（非真实客户导出）；
                (2) customer/email 计数为 0 或缺失的记录（无实际数据）。
                仅剩陈旧垃圾时 valid 为空 → 返回 None，迫使 resolve_data_source 走实时扫描兜底。
    """
    data = _load()
    ds = data.get("data_sources", {}).get(data_type)
    if not ds:
        return None
    runs = ds.get("runs", [])
    if not runs:
        return None

    # v0.8.0 补丁：过滤掉「文件不存在 / 临时中间文件 / 无客户数据」的无效记录
    valid = []
    for r in runs:
        jf = r.get("json_file")
        if not jf:
            continue
        abs_path = _resolve_path(jf)
        if not abs_path:
            continue  # 文件已不存在
        if ".intermediate" in str(abs_path):
            continue  # 排除 .intermediate 临时文件（非真实客户导出）
        # 排除无客户/邮箱数据的无效记录（兼容 customers/customer_count、emails/email_count 两种字段名）
        has_data = any(r.get(k) for k in ("customers", "customer_count", "emails", "email_count"))
        if not has_data:
            continue
        valid.append(r)
    if not valid:
        return None
    latest = max(valid, key=lambda r: r.get("timestamp", ""))

    # 返回副本，路径解析为绝对
    result = dict(latest)
    if result.get("json_file"):
        result["json_file"] = _to_absolute(result["json_file"])
    if result.get("output_dir"):
        result["output_dir"] = _to_absolute(result["output_dir"])
    return result


def list_data_sources(data_type: str, limit: int = 5) -> list[dict]:
    """列出指定数据类型的历史记录。"""
    data = _load()
    runs = data.get("data_sources", {}).get(data_type, {}).get("runs", [])
    result = []
    for r in runs[:limit]:
        r_copy = dict(r)
        if r_copy.get("json_file"):
            r_copy["json_file"] = _to_absolute(r_copy["json_file"])
        if r_copy.get("output_dir"):
            r_copy["output_dir"] = _to_absolute(r_copy["output_dir"])
        result.append(r_copy)
    return result


def resolve_data_source(data_type: str = "customer-list", self_producer: str = "mail-sender-skill") -> Optional[dict]:
    """
    综合查找数据源：合并「索引记录 + 实时扫描」→ 取获取日期最新者 → 回写索引。

    这是消费者侧（mail-sender）推荐使用的入口。

    v0.8.0 补丁（before/after）：
      - before: Step 1 命中陈旧 .intermediate 文件（磁盘存在）即直接返回，Step 2 扫描被短路；
                且 Step 2 的 scan_for_data_source 未排除消费者自身，可能误选自身不存在的 customers.json。
      - after : 不再盲信索引返回。将「get_data_source 已过滤的索引记录」与「实时扫描全部候选（排除自身）」
                合并为候选集，统一按「获取日期最新（同日期按邮箱数降序）」选取，校验文件存在后回写索引；
                保证场景 B 始终返回最近一次搜索的真实客户清单。
    """
    candidates: list[dict] = []

    def _norm(rec: dict) -> dict:
        """统一候选记录字段，便于跨来源比较。"""
        rec = dict(rec)
        jf = rec.get("json_file")
        if jf:
            rec["json_file"] = _to_absolute(jf)
        if rec.get("output_dir"):
            rec["output_dir"] = _to_absolute(rec["output_dir"])
        # 统一日期：索引记录用 timestamp[:10]，扫描记录用 _acquired_date
        if rec.get("_acquired_date"):
            rec["_date"] = rec["_acquired_date"]
        elif rec.get("timestamp"):
            rec["_date"] = str(rec["timestamp"])[:10]
        else:
            rec["_date"] = ""
        # 统一邮箱数（兼容 email_count / emails 两种字段名）
        rec["_emails"] = rec.get("email_count") or rec.get("emails") or 0
        return rec

    # 1) 索引记录（get_data_source 已过滤 .intermediate / 无数据记录）
    idx = get_data_source(data_type)
    if idx and idx.get("json_file") and Path(idx["json_file"]).exists():
        candidates.append(_norm(idx))

    # 2) 实时扫描全部候选（排除消费者自身，避免自引用）
    scan_all = scan_for_data_source(data_type, return_all=True, exclude_producers=[self_producer])
    for c in (scan_all or []):
        abs_jf = _to_absolute(c.get("json_file", ""))
        if abs_jf and Path(abs_jf).exists():
            candidates.append(_norm({**c, "json_file": abs_jf, "output_dir": c.get("output_dir", "")}))

    if not candidates:
        # 3) 兜底——单源扫描（兼容旧行为，排除自身）
        found = scan_for_data_source(data_type, exclude_producers=[self_producer])
        if found:
            abs_jf = _to_absolute(found.get("json_file", ""))
            if abs_jf and Path(abs_jf).exists():
                best = _norm(found)
                _write = {k: v for k, v in best.items() if k not in ("_date", "_emails")}
                update_data_source(data_type, _write)
                return best
        return None

    # 选「获取日期最新」，同日期按邮箱数降序
    best = max(candidates, key=lambda c: (c.get("_date", ""), c.get("_emails", 0)))
    _write = {k: v for k, v in best.items() if k not in ("_date", "_emails")}
    update_data_source(data_type, _write)  # 回写索引，自愈 runs
    return best


# ─── 向后兼容（v1 API 包装） ───


def update_index(skill_name: str, run_info: dict):
    """[v1 兼容] 委托给 v2 的 update_data_source。"""
    source = {
        "producer": skill_name,
        **run_info,
    }
    update_data_source("customer-list", source)


def list_runs(skill_name: str, limit: int = 5) -> list[dict]:
    """[v1 兼容] 从 data_sources 中按 producer 过滤。"""
    all_runs = list_data_sources("customer-list", limit=MAX_HISTORY)
    filtered = [r for r in all_runs if r.get("producer") == skill_name]
    return filtered[:limit]


def get_latest_run(skill_name: str) -> Optional[dict]:
    """[v1 兼容]"""
    runs = list_runs(skill_name, limit=1)
    return runs[0] if runs else None


def has_recent_run(skill_name: str, max_hours: int = 72) -> bool:
    """[v1 兼容]"""
    run = get_latest_run(skill_name)
    if not run:
        return False
    try:
        run_time = datetime.fromisoformat(run["timestamp"])
        now = datetime.now(timezone.utc).astimezone()
        return (now - run_time).total_seconds() / 3600 <= max_hours
    except (ValueError, KeyError):
        return False


def remove_orphaned(skill_name: str) -> int:
    """[v1 兼容] 清理索引中路径不存在的记录。"""
    data = _load()
    ds = data.get("data_sources", {}).get("customer-list", {})
    runs = ds.get("runs", [])
    before = len(runs)
    runs[:] = [
        r for r in runs
        if r.get("producer") != skill_name or (r.get("json_file") and Path(_to_absolute(r["json_file"])).exists())
    ]
    removed = before - len(runs)
    if removed > 0:
        ds["runs"] = runs
        if runs:
            ds["latest"] = runs[0]
        elif "latest" in ds:
            del ds["latest"]
        _save(data)
    return removed


def get_index() -> dict:
    """返回完整索引内容（供查看用）。"""
    return _load()


# ─── 脚本入口 ───

if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "scan":
        print("🔍 正在扫描客户数据源...")
        result = scan_for_data_source("customer-list")
        if result:
            print(f"\n✅ 找到数据源")
            print(f"   文件: {_to_absolute(result['json_file'])}")
            print(f"   目录: {_to_absolute(result['output_dir'])}")
            print(f"   生产者: {result.get('producer', '?')}")
            print(f"   公司: {result.get('company', '?')}")
            print(f"   国家: {result.get('country', '?')}")
            print(f"   客户数: {result.get('customer_count', 0)}")
            print(f"   有邮箱: {result.get('email_count', 0)}")
            print(f"   获取日期: {result.get('_acquired_date', '?')}")
            print(f"   评分: {result.get('score', 0)}")
        else:
            print("❌ 未找到匹配的客户数据源。")
        sys.exit(0)

    # 查看索引
    data = _load()
    ds = data.get("data_sources", {})

    if not ds:
        print(f"📭 v2 索引中暂无 data_sources。")
    else:
        print(f"\n📦 数据源索引 (v{data.get('version', '?')}):")
        for data_type, ds_data in ds.items():
            if data_type.startswith("_"):
                continue
            latest = ds_data.get("latest")
            if latest:
                print(f"\n  [{data_type}]")
                print(f"    生产者: {latest.get('producer', '?')}")
                print(f"    文件: {latest.get('json_file', '?')}")
                print(f"    公司: {latest.get('company', '?')}")
                print(f"    国家: {latest.get('country', '?')}")
                print(f"    客户数: {latest.get('customer_count', '?')}")
                print(f"    有邮箱: {latest.get('email_count', '?')}")
                print(f"    时间: {latest.get('timestamp', '?')}")
            runs = ds_data.get("runs", [])
            if len(runs) > 1:
                print(f"    历史: {len(runs)} 条记录")

    v1 = data.get("_v1_legacy", {}).get("skills", {})
    if v1:
        print(f"\n📦 已迁移的 v1 遗留数据:")
        for skill_name in v1:
            print(f"  - {skill_name}")
