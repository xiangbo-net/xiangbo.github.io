"""
mail_server.py — 邮件批量发送本地 HTTP 服务

架构：Flask HTTP 服务 + smtplib 邮件发送
端口：5678
依赖：pip install flask openpyxl

数据流：
  HTML 看板（浏览器）  ←HTTP→  mail_server.py  ←SMTP→  邮箱服务器

API 端点：
  GET    /                         → 返回 HTML 看板
  GET    /api/status               → 服务状态 + 配额
  GET    /api/customers            → 客户列表 + 统计
  GET    /api/config               → 读取 SMTP 配置
  POST   /api/config               → 保存 SMTP 配置
  POST   /api/config/detect        → 自动识别邮箱提供商+SMTP 参数（新增 v0.7.0）
  POST   /api/config/auto-test     → 自动试连 465/587+落库+发测试邮件（新增 v0.7.0）
  GET    /api/config/user-profile  → 读取场景 A/C 用户配置（公司名、业务类型、语言、发送目的、模板选择）
  POST   /api/config/user-profile  → 保存/覆盖场景 A/C 用户配置
  POST   /api/templates            → 按发送目的返回预设邮件模板（新增 v0.8.0）
  GET    /api/conversation-board   → 返回对话看板数据：画像+收件人预览+模板（新增 v0.8.0）
  POST   /api/test-email           → 发送测试邮件
  POST   /api/send                 → 批量发送
  POST   /api/pause                → 暂停发送
  POST   /api/resume               → 恢复发送
  POST   /api/stop                 → 停止发送
  GET    /api/logs                 → 发送日志（支持 ?status= 过滤）
  POST   /api/quota                → 调整配额

场景 B —— 手动导入：
  POST   /api/customers/import     → 导入客户池（已存在）
  POST   /api/customers/parse-file → 解析 Excel/CSV 文件（只解析不导入）
  POST   /api/customers/parse-paste→ 解析纯文本粘贴（只解析不导入）
  POST   /api/customers/batch-update-pitch → 批量更新话术
"""

import json
import os
import csv
import re
import smtplib
import ssl
import imaplib  # v0.9.0 新增：存进邮箱草稿箱（IMAP APPEND）
import time
import logging
import shutil
import uuid
from datetime import datetime, date
from email.mime.text import MIMEText
from email.utils import formataddr, formatdate  # formatdate 用于草稿邮件的 Date 头
from pathlib import Path

try:
    from flask import Flask, request, jsonify, send_file
except ImportError:
    print("错误：请先安装 Flask（pip install flask）")
    exit(1)

# ─── 跨 skill 数据索引 ───
import sys
_skill_dir = Path(__file__).parent
if str(_skill_dir) not in sys.path:
    sys.path.insert(0, str(_skill_dir))
try:
    from cross_skill_index import scan_for_data_source, update_data_source
    HAS_INDEX = True
except ImportError:
    HAS_INDEX = False

# ─── SMTP 提供商映射 ───
try:
    from smtp_providers import detect_by_email, get_auth_guide, get_imap_server
    HAS_PROVIDERS = True
except ImportError:
    HAS_PROVIDERS = False

# ─── 邮件预设模板（v0.8.0 新增） ───
try:
    from email_templates import list_purposes, get_template
    HAS_TEMPLATES = True
except ImportError:
    HAS_TEMPLATES = False

# ──────────────────── 配置 ────────────────────

DEFAULT_HOST = "0.0.0.0"
DEFAULT_PORT = 5678

SEND_INTERVAL_DEFAULT = 10
DAILY_LIMIT_DEFAULT = 100
MONTHLY_LIMIT_DEFAULT = 1000
BATCH_SIZE_MAX = 50

# 主数据目录（用户级别，跨工作目录持久保留）
MAIL_SENDER_DIR = Path.home() / ".workbuddy" / "userdata" / "wxskill" / "mail-sender-skill" / "output"

# 工作区同步目录（自动检测，不限盘符）
WORKSPACE_OUTPUT_DIR = Path(__file__).parent.parent / "output"

# 旧数据目录（v0.4 及之前版本）
LEGACY_DATA_DIR = Path.home() / ".workbuddy" / "skills" / "mail-sender"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S"
)
logger = logging.getLogger("mail-server")

# ─── 目录迁移与同步 ───


def migrate_legacy_data():
    """从旧目录 (~/.workbuddy/skills/mail-sender/) 迁移数据到新目录。"""
    if not LEGACY_DATA_DIR.exists():
        return
    MAIL_SENDER_DIR.mkdir(parents=True, exist_ok=True)
    migrated = 0
    for f in ["customers.json", "send_stats.json", "send_log.json", "smtp_config.json", "user_profile.json"]:
        src = LEGACY_DATA_DIR / f
        dst = MAIL_SENDER_DIR / f
        if src.exists() and not dst.exists():
            shutil.copy2(str(src), str(dst))
            migrated += 1
            logger.info("已迁移 %s → %s", src, dst)
    if migrated > 0:
        logger.info("旧数据迁移完成（%d 个文件从 %s 迁移到 %s）",
                     migrated, LEGACY_DATA_DIR, MAIL_SENDER_DIR)


def sync_to_workspace(data_dir: os.PathLike):
    """同步数据文件到工作区目录（用于查看和备份）。"""
    try:
        target = WORKSPACE_OUTPUT_DIR
        target.mkdir(parents=True, exist_ok=True)
        src_dir = Path(data_dir)
        synced = 0
        for f in ["customers.json", "send_stats.json", "send_log.json", "smtp_config.json", "user_profile.json"]:
            src = src_dir / f
            dst = target / f
            if src.exists():
                shutil.copy2(str(src), str(dst))
                synced += 1
        if synced > 0:
            logger.debug("数据已同步到工作区: %s（%d 个文件）", target, synced)
    except Exception as e:
        logger.warning("工作区同步失败（不影响主存储）: %s", e)


# ──────────────────── 状态管理 ────────────────────

class SendState:
    """发送状态管理：客户池 + 配额统计 + 发送日志 + 队列控制"""

    def __init__(self, data_dir: str):
        self.data_dir = Path(data_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self._customers_path = self.data_dir / "customers.json"
        self._stats_path = self.data_dir / "send_stats.json"
        self._log_path = self.data_dir / "send_log.json"
        self._config_path = self.data_dir / "smtp_config.json"
        self._profile_path = self.data_dir / "user_profile.json"
        self._runs_dir = self.data_dir / "runs"

        self.config = self._load_config()
        self.profile = self._load_profile()
        self.customers = self._load_customers()
        self.stats = self._load_stats()
        self.logs = self._load_logs()

        self._paused = False
        self._stopped = False
        self._sending = False
        self._drafting = False  # v0.9.3 草稿箱在途守卫，防并发/重复触发

    # ─── 客户池 ───

    def _load_customers(self) -> list:
        if self._customers_path.exists():
            with open(self._customers_path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data.get("customers", [])
        return []

    def save_customers(self):
        sent = sum(1 for c in self.customers if c.get("status") == "sent")
        bounced = sum(1 for c in self.customers if c.get("status") == "bounced")
        failed = sum(1 for c in self.customers if c.get("status") == "failed")
        # v0.9.0 新增：draft = 已存入发件方邮箱草稿箱，待用户在邮件客户端手动发送
        draft = sum(1 for c in self.customers if c.get("status") == "draft")
        unsent = sum(1 for c in self.customers if c.get("status") in ("unsent", None, ""))
        stats = {"total": len(self.customers), "unsent": unsent, "sent": sent,
                 "bounced": bounced, "failed": failed, "draft": draft}
        data = {"version": 2, "updated_at": datetime.now().isoformat(), "stats": stats, "customers": self.customers}
        with open(self._customers_path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        sync_to_workspace(self.data_dir)
        return stats

    def import_customers(self, new_customers: list) -> dict:
        """导入客户数据，自动去重。返回新增/更新统计。"""
        existing = {c.get("email", ""): c for c in self.customers if c.get("email")}
        added = 0
        updated = 0
        for nc in new_customers:
            email = nc.get("email", "")
            if not email:
                continue
            if email in existing:
                # 更新话术（取最新）
                ec = existing[email]
                if nc.get("pitch_email") and nc["pitch_email"] != ec.get("pitch_email"):
                    ec["pitch_email"] = nc["pitch_email"]
                    ec["pitch_updated_at"] = datetime.now().isoformat()
                    # 如果原本是 unsent，保留状态；已发送的不改
                    if ec.get("status") not in ("sent", "bounced", "failed"):
                        ec["status"] = "unsent"
                    updated += 1
                # 记录来源 run
                run_name = nc.get("_run_name", "")
                if run_name and run_name not in ec.get("source_runs", []):
                    ec.setdefault("source_runs", []).append(run_name)
                # 补全获取日期（不覆盖已有值）
                if "_acquired_date" in nc and not ec.get("_acquired_date"):
                    ec["_acquired_date"] = nc["_acquired_date"]
            else:
                nc.setdefault("status", "unsent")
                nc.setdefault("send_count", 0)
                nc["created_at"] = datetime.now().isoformat()
                nc["updated_at"] = datetime.now().isoformat()
                self.customers.append(nc)
                added += 1
        stats = self.save_customers()
        return {"added": added, "updated": updated, "stats": stats}

    def update_status(self, email: str, status: str, error: str = ""):
        for c in self.customers:
            if c.get("email") == email:
                c["status"] = status
                c["updated_at"] = datetime.now().isoformat()
                if status == "sent":
                    c["sent_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    c["send_count"] = c.get("send_count", 0) + 1
                if error:
                    c["last_error"] = error
                break

    # ─── 配置 ───

    def _load_config(self) -> dict:
        if self._config_path.exists():
            with open(self._config_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}

    def save_config(self, config: dict):
        self.config.update(config)
        with open(self._config_path, "w", encoding="utf-8") as f:
            json.dump(self.config, f, ensure_ascii=False, indent=2)
        sync_to_workspace(self.data_dir)
        logger.info("SMTP 配置已保存")

    # ─── 用户配置（场景 C） ───

    def _load_profile(self) -> dict:
        if self._profile_path.exists():
            with open(self._profile_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return {}

    def save_profile(self, profile: dict):
        """保存场景 C 用户配置（公司名、业务类型、语言偏好等），不做增量合并，直接覆盖。"""
        profile["updated_at"] = datetime.now().isoformat()
        profile["version"] = profile.get("version", 1)
        self.profile = profile
        with open(self._profile_path, "w", encoding="utf-8") as f:
            json.dump(self.profile, f, ensure_ascii=False, indent=2)
        sync_to_workspace(self.data_dir)
        logger.info("用户配置（场景 C）已保存: company=%s", profile.get("company_name", ""))

    def get_profile_safe(self) -> dict:
        """返回脱敏后的配置（不包含敏感字段，当前无密码等敏感信息，预留扩展）。"""
        return dict(self.profile)

    # ─── 配额 ───

    def _load_stats(self) -> dict:
        if self._stats_path.exists():
            with open(self._stats_path, "r", encoding="utf-8") as f:
                stats = json.load(f)
            # 强制使用最新配额默认值（覆盖旧文件中的历史值）
            stats.setdefault("daily", {})["limit"] = DAILY_LIMIT_DEFAULT
            stats.setdefault("monthly", {})["limit"] = MONTHLY_LIMIT_DEFAULT
            return stats
        return self._fresh_stats()

    def _fresh_stats(self) -> dict:
        today = date.today().isoformat()
        this_month = date.today().strftime("%Y-%m")
        return {
            "daily": {"date": today, "sent": 0, "limit": DAILY_LIMIT_DEFAULT},
            "monthly": {"year_month": this_month, "sent": 0, "limit": MONTHLY_LIMIT_DEFAULT},
        }

    def _persist_stats(self):
        with open(self._stats_path, "w", encoding="utf-8") as f:
            json.dump(self.stats, f, ensure_ascii=False, indent=2)
        sync_to_workspace(self.data_dir)

    def check_quota(self) -> dict:
        today = date.today().isoformat()
        this_month = date.today().strftime("%Y-%m")
        if self.stats["daily"]["date"] != today:
            self.stats["daily"]["date"] = today
            self.stats["daily"]["sent"] = 0
        if self.stats["monthly"]["year_month"] != this_month:
            self.stats["monthly"]["year_month"] = this_month
            self.stats["monthly"]["sent"] = 0
        daily_ok = self.stats["daily"]["sent"] < self.stats["daily"]["limit"]
        monthly_ok = self.stats["monthly"]["sent"] < self.stats["monthly"]["limit"]
        return {"daily": self.stats["daily"], "monthly": self.stats["monthly"], "can_send": daily_ok and monthly_ok}

    def increment_quota(self):
        self.stats["daily"]["sent"] += 1
        self.stats["monthly"]["sent"] += 1
        self._persist_stats()

    # ─── 日志 ───

    def _load_logs(self) -> list:
        if self._log_path.exists():
            with open(self._log_path, "r", encoding="utf-8") as f:
                return json.load(f)
        return []

    def add_log(self, company: str, email: str, status: str, reason: str = ""):
        entry = {
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "company": company,
            "email": email,
            "status": status,
            "reason": reason,
        }
        self.logs.append(entry)
        with open(self._log_path, "w", encoding="utf-8") as f:
            json.dump(self.logs, f, ensure_ascii=False, indent=2)
        sync_to_workspace(self.data_dir)

    def get_logs(self, status_filter: str = None) -> list:
        if status_filter:
            return [e for e in self.logs if e["status"] == status_filter]
        return self.logs

    # ─── 队列控制 ───

    @property
    def is_paused(self): return self._paused
    @property
    def is_stopped(self): return self._stopped
    @property
    def is_sending(self): return self._sending

    def pause(self):
        self._paused = True
        logger.info("发送已暂停")

    def resume(self):
        self._paused = False
        logger.info("发送已恢复")

    def stop(self):
        self._stopped = True
        self._paused = False
        self._sending = False
        logger.info("发送已停止")


# ──────────────────── DNS 预校验 ────────────────────

def has_valid_domain(email: str) -> tuple[bool, str]:
    """
    发送前 DNS 预校验：验证目标邮箱域名是否存在。
    
    检查顺序：MX 记录 → A/AAAA 记录。
    MX 记录是邮件投递的直接依据，若存在说明域名可收信；
    若没有 MX 但有 A 记录，可能托管了网站但没有邮件服务器；
    若两者都没有，域名肯定无效。
    
    返回：(是否有效, 提示信息)
    """
    import socket
    domain = email.split("@")[-1] if "@" in email else ""
    if not domain:
        return (False, "邮箱格式无效，缺少域名")

    # 检查保留域名 / 本地域名
    reserved = {"localhost", "local", "example.com", "example.org", "example.net",
                 "test.com", "test.org", "test.net", "mailinator.com"}
    if domain.lower() in reserved:
        return (False, f"域名 {domain} 为保留或测试域名")

    # 优先检查 MX 记录（使用 dnspython，精确判断邮件投递能力）
    mx_ok = False
    try:
        import dns.resolver
        mx_records = dns.resolver.resolve(domain, "MX", lifetime=5)
        if mx_records:
            mx_ok = True
    except ImportError:
        pass  # dnspython 未安装，回退到 A 记录
    except (dns.resolver.NoAnswer, dns.resolver.NXDOMAIN,
            dns.resolver.LifetimeTimeout, dns.exception.DNSException):
        pass

    if mx_ok:
        return (True, "")

    # 回退检查 A/AAAA 记录（域名是否存在的基本判断）
    try:
        socket.getaddrinfo(domain, 25, socket.AF_UNSPEC, socket.SOCK_STREAM)
        return (True, "⚠️ 仅有 A 记录（网站存在），无 MX 记录，邮件可能无法到达")
    except socket.gaierror:
        return (False, f"域名 {domain} 不存在或无法解析，无法投递邮件")


# ──────────────────── SMTP 发送 ────────────────────

def smtp_send(sender: dict, to_email: str, subject: str, body: str) -> tuple[bool, str]:
    try:
        msg = MIMEText(body, "plain", "utf-8")
        msg["From"] = formataddr((sender.get("display_name", ""), sender["email"]))
        msg["To"] = to_email
        msg["Subject"] = subject
        context = ssl.create_default_context()
        port = int(sender.get("smtp_port", 465))
        # 587 → STARTTLS；465 → SSL
        if port == 587:
            with smtplib.SMTP(sender["smtp_server"], port, timeout=10) as server:
                server.starttls(context=context)
                server.login(sender["email"], sender["password"])
                server.sendmail(sender["email"], [to_email], msg.as_string())
        else:
            with smtplib.SMTP_SSL(sender["smtp_server"], port, context=context, timeout=10) as server:
                server.login(sender["email"], sender["password"])
                server.sendmail(sender["email"], [to_email], msg.as_string())
        return (True, "250 OK")
    except smtplib.SMTPRecipientsRefused as e:
        return (False, "550 Mailbox not found")
    except smtplib.SMTPSenderRefused:
        return (False, "553 Sender refused")
    except smtplib.SMTPDataError:
        return (False, "552 Data error")
    except smtplib.SMTPAuthenticationError:
        return (False, "535 Authentication failed — 请检查授权码")
    except (smtplib.SMTPException, OSError, TimeoutError) as e:
        return (False, f"Connection error: {str(e)[:80]}")


# ──────────────────── 存进邮箱草稿箱（v0.9.0 新增） ────────────────────

def _detect_drafts_folder(imap: "imaplib.IMAP4") -> str:
    """
    探测邮箱中的草稿文件夹名称。

    返回首个名称含 "draft"（忽略大小写）或「草稿」的文件夹，
    例如 Gmail 的 "[Gmail]/Drafts"、QQ 的 "Drafts"、部分中文邮箱的「草稿」。
    都探测不到时回退 "Drafts"。
    """
    try:
        typ, raw = imap.list()
    except Exception:
        return "Drafts"
    if not raw:
        return "Drafts"
    candidates = []
    for line in raw:
        if not line:
            continue
        text = line.decode("utf-8", "ignore")
        # LIST 响应形如：(\HasNoChildren) "/" "Drafts"
        # 取最后一段被双引号包裹的内容作为文件夹名
        m = re.search(r'"([^"]+)"\s*$', text)
        name = m.group(1) if m else text.strip()
        low = name.lower()
        if "draft" in low or "草稿" in name:
            candidates.append(name)
    if not candidates:
        return "Drafts"
    # 优先返回含 "draft" 的（与中文「草稿」二选一时取 draft，更通用）
    for c in candidates:
        if "draft" in c.lower():
            return c
    return candidates[0]


def imap_save_draft(sender: dict, to_email: str, subject: str, body: str,
                    imap_server: str, imap_port: int = 993) -> tuple[bool, str]:
    """
    通过 IMAP 将单封邮件写入发件方邮箱的草稿（Drafts）文件夹。

    参数：
      sender       — 含 email / password / display_name 的发送方配置
      to_email     — 收件人地址（草稿的 To）
      subject/body — 邮件主题与正文
      imap_server  — IMAP 服务器地址（由 get_imap_server 解析）
      imap_port    — IMAP 端口，默认 993（SSL）

    返回：
      (success, reason) — success=True 表示已写入草稿箱

    说明：
      - 复用与 SMTP 相同的授权码（邮箱 + 授权码）登录 IMAP
      - 自动探测草稿文件夹（见 _detect_drafts_folder）
      - 写入时打上 \\Draft 标志，邮件停留在草稿箱而非已发送
      - 不消耗任何发送配额
    """
    try:
        msg = MIMEText(body, "plain", "utf-8")
        msg["From"] = formataddr((sender.get("display_name", ""), sender["email"]))
        msg["To"] = to_email
        msg["Subject"] = subject
        msg["Date"] = formatdate(localtime=True)
        with imaplib.IMAP4_SSL(imap_server, imap_port, timeout=15) as imap:
            imap.login(sender["email"], sender["password"])
            folder = _detect_drafts_folder(imap)
            # APPEND：\\Draft 标志让邮件留在草稿箱；内部日期传 None 由服务器生成
            imap.append(folder, "\\Draft", None, msg.as_bytes())
        return (True, f"已存入草稿箱（{folder}）")
    except imaplib.IMAP4.error as e:
        return (False, f"IMAP 认证/操作失败: {str(e)[:120]}")
    except Exception as e:  # 网络/超时/DNS 解析等
        return (False, f"IMAP 连接错误: {str(e)[:120]}")


# ──────────────────── 首页 HTML ────────────────────

def find_html() -> str | None:
    """查找可用的 HTML 看板文件"""
    candidates = [
        Path(__file__).parent.parent / "web" / "send_panel_template.html",
        Path.cwd() / "web" / "send_panel_template.html",
        MAIL_SENDER_DIR / "index.html",
    ]
    for p in candidates:
        if p.exists():
            return str(p)
    return None


# ──────────────────── Flask 应用 ────────────────────

def create_app(work_dir: str) -> Flask:
    static_dir = str(Path(__file__).parent.parent / "web" / "assets")
    app = Flask(__name__, static_folder=static_dir, static_url_path="/assets")
    state = SendState(work_dir)

    @app.after_request
    def cors(response):
        response.headers["Access-Control-Allow-Origin"] = "*"
        response.headers["Access-Control-Allow-Headers"] = "Content-Type"
        response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
        return response

    # ─── 静态文件回退（支持从当前工作目录加载） ───

    @app.route("/assets/<path:filename>")
    def custom_assets(filename):
        candidates = [
            Path(__file__).parent.parent / "web" / "assets" / filename,
            Path.cwd() / "web" / "assets" / filename,
        ]
        for p in candidates:
            if p.exists():
                return send_file(str(p))
        return jsonify({"error": "文件不存在"}), 404

    # ─── 首页 ───

    @app.route("/")
    def index():
        html_path = find_html()
        if html_path:
            return send_file(html_path)
        return "<h1>mail-sender 服务已启动</h1><p>HTML 看板文件未找到</p>"

    # ─── 状态 ───

    @app.route("/api/status", methods=["GET"])
    def get_status():
        quota = state.check_quota()
        return jsonify({
            "sending": state.is_sending,
            "paused": state.is_paused,
            "stopped": state.is_stopped,
            "quota": quota,
            "config_ready": bool(state.config.get("smtp_server")),
        })

    # ─── 客户 ───

    @app.route("/api/customers", methods=["GET"])
    def get_customers():
        stats = state.save_customers()  # refresh
        return jsonify({"customers": state.customers, "stats": stats})

    @app.route("/api/customers/import", methods=["POST"])
    def import_customers():
        data = request.get_json(force=True)
        new_list = data.get("customers", [])
        result = state.import_customers(new_list)
        return jsonify({"ok": True, **result})

    @app.route("/api/customers/refresh", methods=["POST"])
    def refresh_customers():
        """自动扫描所有数据源并导入新客户（一键刷新）。"""
        if not HAS_INDEX:
            return jsonify({"ok": False, "error": "cross_skill_index 模块未加载"}), 500
        try:
            sources = scan_for_data_source("customer-list", exclude_producers=["mail-sender-skill"], return_all=True)
            if not sources:
                return jsonify({"ok": False, "error": "未扫描到有效客户数据源"}), 404

            if not isinstance(sources, list):
                sources = [sources]

            today_str = datetime.now().strftime("%Y-%m-%d")
            total_added = 0
            total_updated = 0
            last_source = None

            for source in sources:
                json_file = source.get("json_file", "")
                if not json_file:
                    continue
                if json_file.startswith("~/"):
                    json_file = str(Path.home() / json_file[2:])
                json_path = Path(json_file)
                if not json_path.exists():
                    logger.warning("数据文件不存在，跳过: %s", json_path)
                    continue

                ext = json_path.suffix.lower()
                customers = []

                if ext == ".json":
                    with open(json_path, "r", encoding="utf-8") as f:
                        data = json.load(f)
                    customers = data.get("customers", [])
                    if not customers and isinstance(data, list):
                        customers = data
                elif ext == ".xlsx":
                    try:
                        import openpyxl
                    except ImportError:
                        logger.warning("openpyxl 未安装，跳过: %s", json_path)
                        continue
                    wb = openpyxl.load_workbook(json_path, read_only=True, data_only=True)
                    ws = wb.active
                    if ws is None or ws.max_row is None or ws.max_row < 2:
                        wb.close(); continue
                    headers = [str(c.value or "").strip().lower() for c in next(ws.iter_rows(min_row=1, max_row=1))]
                    email_idx = next((i for i, h in enumerate(headers) if h in ("email","邮箱","邮箱地址","e-mail","mail")), -1)
                    company_idx = next((i for i, h in enumerate(headers) if h in ("company_name","公司名称","公司名")), -1)
                    pitch_idx = next((i for i, h in enumerate(headers) if "话术" in h or "pitch" in h), -1)
                    country_idx = next((i for i, h in enumerate(headers) if h in ("country","国家")), -1)
                    if email_idx < 0:
                        wb.close(); continue
                    for row in ws.iter_rows(min_row=2, values_only=True):
                        ev = str(row[email_idx] or "").strip() if email_idx < len(row) else ""
                        if not ev or "@" not in ev:
                            continue
                        c = {"email": ev}
                        if company_idx >= 0 and company_idx < len(row) and row[company_idx]:
                            c["company_name"] = str(row[company_idx]).strip()
                        c.setdefault("company_name", "")
                        if pitch_idx >= 0 and pitch_idx < len(row) and row[pitch_idx]:
                            c["pitch_email"] = str(row[pitch_idx]).strip()
                        if country_idx >= 0 and country_idx < len(row) and row[country_idx]:
                            c["country"] = str(row[country_idx]).strip()
                        customers.append(c)
                    wb.close()
                else:
                    continue

                company = source.get("company", "")
                country = source.get("country", "")
                run_name = f"{company}_{country}" if company and country else source.get("producer", "未知")

                import_list = []
                for c in customers:
                    if not c.get("email"):
                        continue
                    c["_acquired_date"] = source.get("_acquired_date", today_str)
                    c["_run_name"] = run_name
                    c.setdefault("status", "unsent")
                    c.setdefault("send_count", 0)
                    import_list.append(c)
                if not import_list:
                    continue

                result = state.import_customers(import_list)
                total_added += result.get("added", 0)
                total_updated += result.get("updated", 0)
                last_source = source
                source["_acquired_date"] = today_str
                update_data_source("customer-list", source)
                logger.info("已导入: %s → +%d 新增, %d 更新",
                            json_path.name, result.get("added",0), result.get("updated",0))

            stats = state.save_customers()
            return jsonify({
                "ok": True,
                "added": total_added,
                "updated": total_updated,
                "source": {"company": last_source.get("company","") if last_source else "",
                           "country": last_source.get("country","") if last_source else "",
                           "customer_count": sum(s.get("customer_count",0) for s in sources),
                           "email_count": sum(s.get("email_count",0) for s in sources)} if last_source else {},
                "stats": stats,
            })
        except Exception as e:
            logger.error(f"刷新客户数据失败: {e}")
            return jsonify({"ok": False, "error": str(e)}), 500

    @app.route("/api/customers/update", methods=["POST"])
    def update_customer():
        data = request.get_json(force=True)
        email = data.get("email", "")
        if not email:
            return jsonify({"error": "缺少 email"}), 400
        for c in state.customers:
            if c.get("email") == email:
                # 如果邮箱变更，需要同步更新主键（email 本身）
                new_email = data.get("new_email", "").strip()
                if new_email and new_email != email:
                    # 检查新邮箱是否已存在（避免覆盖其他客户）
                    if any(x.get("email") == new_email for x in state.customers):
                        return jsonify({"error": "新邮箱已存在"}), 409
                    c["email"] = new_email
                    c["id"] = new_email
                if "subject" in data:
                    c["_subject"] = data["subject"]
                if "body" in data:
                    c["pitch_email"] = data["body"]
                if "_acquired_date" in data:
                    c["_acquired_date"] = data["_acquired_date"]
                if "status" in data:
                    c["status"] = data["status"]
                    if data["status"] == "bounced":
                        c["_bounced_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                c["updated_at"] = datetime.now().isoformat()
                state.save_customers()
                return jsonify({"ok": True, "email": c.get("email")})
        return jsonify({"error": "客户不存在"}), 404

    # ─── 场景 B：手动导入（解析/导入/话术批量更新） ───

    @app.route("/api/customers/parse-file", methods=["POST"])
    def parse_file():
        """解析 Excel/CSV 文件路径，返回结构化客户列表（不导入池）。"""
        data = request.get_json(force=True)
        file_path = data.get("file_path", "").strip()
        email_col = data.get("email_column", "email")
        company_col = data.get("company_column", "company_name")

        if not file_path:
            return jsonify({"error": "请提供文件路径"}), 400

        p = Path(file_path)
        if not p.exists():
            return jsonify({"error": f"文件不存在: {file_path}"}), 404

        ext = p.suffix.lower()
        parsed = []

        try:
            if ext in (".xlsx", ".xls"):
                # 使用 openpyxl 解析
                try:
                    import openpyxl
                except ImportError:
                    return jsonify({"error": "需要安装 openpyxl：pip install openpyxl"}), 500

                wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
                ws = wb.active
                if ws is None or ws.max_row is None or ws.max_row < 2:
                    return jsonify({"error": "Excel 文件为空或只有表头"}), 400

                headers = [str(c.value or "").strip().lower() for c in next(ws.iter_rows(min_row=1, max_row=1))]
                email_idx = next((i for i, h in enumerate(headers) if h == email_col.lower()), -1)
                company_idx = next((i for i, h in enumerate(headers) if h == company_col.lower()), -1)

                if email_idx < 0:
                    # 尝试查找包含 email/邮箱/邮件 的列
                    email_idx = next((i for i, h in enumerate(headers) if "email" in h or "邮箱" in h or "邮件" in h), -1)
                if email_idx < 0:
                    return jsonify({"error": f"未找到 email 列（表头: {', '.join(headers)}）"}), 400

                for row in ws.iter_rows(min_row=2, values_only=True):
                    email_val = str(row[email_idx] or "").strip()
                    if not email_val or "@" not in email_val:
                        continue
                    customer = {"email": email_val}
                    if company_idx >= 0 and row[company_idx]:
                        customer["company_name"] = str(row[company_idx]).strip()
                    customer.setdefault("company_name", "")
                    parsed.append(customer)
                wb.close()

            elif ext == ".csv":
                with open(p, "r", encoding="utf-8-sig") as f:
                    reader = csv.DictReader(f)
                    if reader.fieldnames is None:
                        return jsonify({"error": "CSV 文件为空"}), 400
                    fn_lower = [h.lower() for h in reader.fieldnames]
                    email_fn = email_col.lower()
                    company_fn = company_col.lower()
                    # 自动匹配
                    if email_fn not in fn_lower:
                        for h in reader.fieldnames:
                            hl = h.lower()
                            if "email" in hl or "邮箱" in hl or "邮件" in hl:
                                email_fn = hl
                                break
                    if email_fn not in fn_lower:
                        return jsonify({"error": f"未找到 email 列（表头: {', '.join(reader.fieldnames)}）"}), 400
                    if company_fn not in fn_lower:
                        company_fn = ""

                    for row in reader:
                        email_val = (row.get(email_fn) or "").strip()
                        if not email_val or "@" not in email_val:
                            continue
                        customer = {"email": email_val}
                        if company_fn:
                            customer["company_name"] = (row.get(company_fn) or "").strip()
                        customer.setdefault("company_name", "")
                        parsed.append(customer)
            else:
                return jsonify({"error": f"不支持的文件格式: {ext}（支持 .xlsx, .xls, .csv）"}), 400

        except Exception as e:
            logger.error(f"文件解析失败: {e}")
            return jsonify({"error": f"文件解析失败: {str(e)[:200]}"}), 500

        return jsonify({
            "ok": True,
            "file_name": p.name,
            "total_parsed": len(parsed),
            "customers": parsed,
        })

    @app.route("/api/customers/parse-paste", methods=["POST"])
    def parse_paste():
        """解析纯文本粘贴内容，提取邮箱列表。"""
        data = request.get_json(force=True)
        content = data.get("content", "").strip()

        if not content:
            return jsonify({"error": "粘贴内容为空"}), 400

        lines = content.strip().split("\n")
        email_pattern = re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}")
        seen = set()
        parsed = []

        for line in lines:
            line = line.strip()
            if not line:
                continue
            emails_found = email_pattern.findall(line)
            if not emails_found:
                continue
            email = emails_found[0].lower()
            if email in seen:
                continue
            seen.add(email)

            # 尝试提取公司名（邮箱前或逗号前的部分）
            parts = re.split(r"[,;\t|]", line)
            company = ""
            for part in parts:
                part = part.strip()
                if "@" not in part and part:
                    company = part
                    break

            parsed.append({
                "email": email,
                "company_name": company,
            })

        return jsonify({
            "ok": True,
            "total_parsed": len(parsed),
            "customers": parsed,
        })

    @app.route("/api/customers/batch-update-pitch", methods=["POST"])
    def batch_update_pitch():
        """批量更新客户话术（由 Agent AI 生成后回写）。"""
        data = request.get_json(force=True)
        updates = data.get("updates", [])

        if not updates:
            return jsonify({"error": "请提供更新数据"}), 400

        updated_count = 0
        not_found = []

        for item in updates:
            email = item.get("email", "").strip().lower()
            pitch = item.get("pitch_email", "").strip()
            if not email or not pitch:
                continue
            found = False
            for c in state.customers:
                if c.get("email", "").strip().lower() == email:
                    c["pitch_email"] = pitch
                    c["pitch_updated_at"] = datetime.now().isoformat()
                    c["updated_at"] = datetime.now().isoformat()
                    # 如果之前是 unsent，保持；否则改为 unsent 待发
                    if c.get("status") not in ("sent", "bounced"):
                        c["status"] = "unsent"
                    updated_count += 1
                    found = True
                    break
            if not found:
                not_found.append(email)

        state.save_customers()
        return jsonify({
            "ok": True,
            "updated_count": updated_count,
            "not_found_count": len(not_found),
            "not_found_emails": not_found if not_found else [],
        })

    # ─── SMTP 配置 ───

    @app.route("/api/config", methods=["GET", "POST"])
    def config():
        if request.method == "GET":
            safe = {k: v for k, v in state.config.items() if k != "password"}
            safe["has_password"] = bool(state.config.get("password"))
            return jsonify(safe)
        data = request.get_json(force=True)
        # 支持部分更新：未提供的字段保留原值
        merged = {**state.config, **data}
        state.save_config(merged)
        return jsonify({"ok": True, "message": "SMTP 配置已保存"})

    # ─── 邮箱自动检测（不带密码，仅返回提供商信息） ───

    @app.route("/api/config/detect", methods=["POST"])
    def detect_smtp():
        """自动识别邮箱的 SMTP 提供商和配置。

        POST 请求体：{"email": "user@qq.com"}
        返回：providers 列表（供 auto-test 试连）、auth_guide 图文指引、提供商名称
        """
        data = request.get_json(force=True)
        email = data.get("email", "").strip().lower()

        if not email or "@" not in email:
            return jsonify({"error": "请输入有效的邮箱地址"}), 400

        if not HAS_PROVIDERS:
            return jsonify({"error": "SMTP 提供商模块未加载"}), 500

        provider = detect_by_email(email)
        if not provider:
            return jsonify({
                "detected": False,
                "message": "未识别到已知邮箱提供商，请尝试 MX 记录查询或手动输入 SMTP 服务器",
                "email": email,
            })

        from smtp_providers import get_all_servers
        servers = [s for s in get_all_servers() if s["name"].startswith(provider["name"])]

        auth_guide = get_auth_guide(provider["auth_key"]) or {}

        return jsonify({
            "detected": True,
            "email": email,
            "provider_name": provider["display_name"],
            "provider_key": provider["name"],
            "server": provider["server"],
            "ports": provider["ports"],
            "use_ssl_default": provider["use_ssl_default"],
            "auth_key": provider["auth_key"],
            "servers_for_test": [
                {"server": s["server"], "port": s["port"], "ssl": s["ssl"]}
                for s in servers
            ],
            "auth_guide": {
                "title": auth_guide.get("title", ""),
                "note": auth_guide.get("note", ""),
                "steps": auth_guide.get("steps", []),
                "url": auth_guide.get("url", ""),
                "important": auth_guide.get("important", ""),
            },
        })

    # ─── 邮箱自动试连 + 配置落库 ───

    @app.route("/api/config/auto-test", methods=["POST"])
    def auto_test_config():
        """自动尝试 465-SSL / 587-STARTTLS，成功后保存配置并发测试邮件。

        POST 请求体：
        {
            "email": "user@qq.com",
            "password": "授权码",
            "display_name": "张三"         // 可选，发件人显示名
        }

        流程：
        1. detect → 获取提供商信息
        2. 按 use_ssl_default 优先试连，失败自动试另一端口
        3. 成功 → 保存 smtp_config.json → 发测试邮件
        4. 返回结果
        """
        data = request.get_json(force=True)
        email = data.get("email", "").strip().lower()
        password = data.get("password", "").strip()
        display_name = data.get("display_name", "").strip() or email.split("@")[0]

        if not email or "@" not in email:
            return jsonify({"error": "请输入有效的邮箱地址"}), 400
        if not password:
            return jsonify({"error": "请输入授权码或密码"}), 400

        if not HAS_PROVIDERS:
            return jsonify({"error": "SMTP 提供商模块未加载"}), 500

        provider = detect_by_email(email)
        if not provider:
            return jsonify({
                "ok": False,
                "error": "未识别到邮箱提供商，无法自动配置",
                "email": email,
            })

        # 准备试连接列表
        ports = list(provider["ports"])  # e.g., [465, 587]
        default_ssl = provider["use_ssl_default"]  # True=465优先, False=587优先

        # 按优先级排序
        if default_ssl:
            try_order = [(p, p == 465) for p in sorted(ports, key=lambda x: 0 if x == 465 else 1)]
        else:
            try_order = [(p, p == 465) for p in sorted(ports, key=lambda x: 0 if x == 587 else 1)]

        last_error = ""
        success_config = None

        for port, use_ssl in try_order:
            tester = {
                "smtp_server": provider["server"],
                "smtp_port": port,
                "email": email,
                "password": password,
                "display_name": display_name,
            }
            ok, reason = smtp_send(tester, email, "邮箱配置测试",
                                   "这是一封自动配置测试邮件，如果您收到说明邮箱已成功配置！")
            if ok:
                success_config = tester
                break
            last_error = reason

        if not success_config:
            return jsonify({
                "ok": False,
                "error": f"所有端口均连接失败: {last_error}",
                "email": email,
                "provider": provider["name"],
                "server": provider["server"],
                "attempted_ports": [p for p, _ in try_order],
            }), 400

        # 保存配置
        state.save_config({
            "email": email,
            "password": password,
            "smtp_server": success_config["smtp_server"],
            "smtp_port": success_config["smtp_port"],
            "display_name": display_name,
        })

        # 再发一次正式测试邮件（保存配置后的路径）
        ok2, reason2 = smtp_send(success_config, email,
                                 "✅ 邮箱配置成功",
                                 f"您已成功完成 SMTP 邮箱配置！\n\n"
                                 f"• 邮箱：{email}\n"
                                 f"• SMTP 服务器：{provider['server']}\n"
                                 f"• 端口：{success_config['smtp_port']}\n"
                                 f"• 协议：{'SSL' if port == 465 else 'STARTTLS'}\n\n"
                                 f"现在您可以使用 mail-sender-skill 向海外客户批量发送开发信了。")

        return jsonify({
            "ok": True,
            "message": "SMTP 配置成功并已保存",
            "email": email,
            "provider": provider["name"],
            "server": provider["server"],
            "port": success_config["smtp_port"],
            "protocol": "SSL" if success_config["smtp_port"] == 465 else "STARTTLS",
            "test_email_sent": ok2,
        })

    # ─── 场景 C：用户配置（公司名、业务类型、语言偏好） ───

    @app.route("/api/config/user-profile", methods=["GET", "POST"])
    def user_profile():
        """读写场景 A/C 的用户基础配置（发件方公司名、业务类型、语言、内容策略、占位变量、发送目的、模板选择）。

        GET → 返回当前配置（无敏感字段）
        POST → 保存/覆盖用户配置
        """
        if request.method == "GET":
            return jsonify(state.get_profile_safe())

        data = request.get_json(force=True)
        if not data:
            return jsonify({"error": "请求体为空"}), 400

        # 校验必填字段
        # v0.8.0 新增：purpose（发送目的）与 template_choice（模板选择）
        profile_data = {
            "company_name": data.get("company_name", "").strip(),
            "business_type": data.get("business_type", "").strip(),
            "email_language": data.get("email_language", "English"),
            "content_strategy": data.get("content_strategy", "unified_template"),
            "placeholder_variable": data.get("placeholder_variable", "{{company}}"),
            "purpose": data.get("purpose", "").strip(),
            "template_choice": data.get("template_choice", "").strip(),
        }
        if not profile_data["company_name"]:
            return jsonify({"error": "请提供公司名称（company_name）"}), 400
        
        state.save_profile(profile_data)
        return jsonify({"ok": True, "profile": state.get_profile_safe()})

    # ─── 邮件预设模板（v0.8.0 新增） ───

    @app.route("/api/templates", methods=["POST"])
    def templates():
        """按发送目的返回预设邮件模板。

        POST 请求体：{"purpose": "marketing", "language": "English"}
        特殊：purpose="list" 或为空 -> 返回所有目的枚举（供 Agent 弹窗）。
        """
        if not HAS_TEMPLATES:
            return jsonify({"error": "email_templates 模块未加载"}), 500
        data = request.get_json(force=True)
        purpose = (data.get("purpose", "") or "").strip()
        language = (data.get("language", "English") or "English").strip() or "English"
        if purpose in ("", "list"):
            return jsonify({"purposes": list_purposes()})
        tpl = get_template(purpose, language)
        if not tpl:
            return jsonify({"error": f"未找到发送目的 '{purpose}' 的模板"}), 404
        return jsonify({"ok": True, **tpl})

    # ─── 对话看板数据（v0.8.0 新增） ───

    @app.route("/api/conversation-board", methods=["GET"])
    def conversation_board():
        """返回对话看板所需数据：发件方画像 + 收件人预览 + 选定模板预览。

        看板本身由 Agent 在对话中按蓝/白/灰视觉语言渲染，本接口仅提供结构化数据。
        """
        profile = state.get_profile_safe()
        recipients = state.customers
        preview = [
            {"email": c.get("email", ""), "company_name": c.get("company_name", "")}
            for c in recipients[:5]
        ]
        board = {
            "profile": profile,
            "recipient_count": len(recipients),
            "recipient_preview": preview,
        }
        purpose = profile.get("purpose", "")
        if purpose and HAS_TEMPLATES:
            tpl = get_template(purpose, profile.get("email_language", "English"))
            if tpl:
                board["template"] = tpl
        return jsonify(board)

    # ─── 测试邮件 ───

    @app.route("/api/test-email", methods=["POST"])
    def test_email():
        sender = state.config
        if not sender.get("smtp_server") or not sender.get("email"):
            return jsonify({"error": "请先保存 SMTP 配置"}), 400
        success, reason = smtp_send(
            sender, sender["email"],
            "邮箱配置测试",
            "这是一封测试邮件，您能收到说明邮件发送通道已经配置成功啦！"
        )
        if success:
            return jsonify({"ok": True, "message": "测试邮件发送成功"})
        return jsonify({"ok": False, "error": reason}), 400

    # ─── 发送 ───

    @app.route("/api/send", methods=["POST"])
    def send():
        if state.is_sending:
            return jsonify({"error": "正在发送中，请等待完成"}), 409

        data = request.get_json(force=True)
        customers = data.get("customers", [])
        interval = data.get("interval", SEND_INTERVAL_DEFAULT)
        batch = data.get("batch", BATCH_SIZE_MAX)

        if not customers:
            return jsonify({"error": "未选择客户"}), 400

        if len(customers) > batch:
            customers = customers[:batch]

        if not state.check_quota()["can_send"]:
            return jsonify({"error": "已超出发送配额"}), 429

        sender = state.config
        if not sender.get("smtp_server"):
            return jsonify({"error": "请先配置 SMTP"}), 400

        state._sending = True
        state._paused = False
        state._stopped = False

        results = []
        for i, customer in enumerate(customers):
            if state.is_stopped:
                break
            while state.is_paused and not state.is_stopped:
                time.sleep(0.5)
            if state.is_stopped:
                break

            quota = state.check_quota()
            if not quota["can_send"]:
                results.append({
                    "company": customer.get("company_name", ""),
                    "email": customer.get("email", ""),
                    "status": "skipped",
                    "reason": "配额超限",
                })
                break

            to_email = customer.get("email", "")
            company = customer.get("company_name", "")

            # 检查发送状态：已发送的客户不再发送
            _existing = next((c for c in state.customers if c.get("email") == to_email), None)
            if _existing and _existing.get("status") == "sent":
                results.append({
                    "company": company,
                    "email": to_email,
                    "status": "skipped",
                    "reason": "该客户已发送过",
                })
                continue

            # DNS 预校验：目标域名无效时直接标记退信，不消耗配额
            dns_valid, dns_msg = has_valid_domain(to_email)
            if not dns_valid:
                status = "bounced"
                logger.warning("DNS 预校验失败: %s — %s", to_email, dns_msg)
                state.add_log(company, to_email, status, dns_msg)
                # 同步导入/更新客户池，确保顶部统计与日志一致
                state.import_customers([{
                    "email": to_email,
                    "company_name": company,
                    "status": status,
                    "pitch_email": customer.get("pitch_email", ""),
                    "_dns_bounce_reason": dns_msg,
                }])
                results.append({
                    "company": company,
                    "email": to_email,
                    "status": status,
                    "reason": dns_msg,
                })
                continue

            if customer.get("_subject"):
                subject = customer["_subject"]
            else:
                subject = f"Inquiry — {company[:30]}" if company else "Inquiry"
            body = customer.get("pitch_email", "")

            success, reason = smtp_send(sender, to_email, subject, body)
            status = "sent" if success else "bounced" if "550" in reason else "failed"

            state.add_log(company, to_email, status, reason if not success else "")
            state.update_status(to_email, status, reason if not success else "")

            if success:
                state.increment_quota()

            results.append({
                "company": company,
                "email": to_email,
                "status": status,
                "reason": reason if not success else "",
            })

            if i < len(customers) - 1 and not state.is_stopped:
                time.sleep(interval)

        state._sending = False
        state.save_customers()

        return jsonify({
            "results": results,
            "sent_count": sum(1 for r in results if r["status"] == "sent"),
        })

    # ─── 存进邮箱草稿箱（v0.9.0 新增） ───

    @app.route("/api/drafts/save", methods=["POST"])
    def drafts_save():
        """
        将编排好的邮件写入发件方邮箱的草稿（Drafts）文件夹，不消耗发送配额。

        POST 请求体：{"customers": [ {email, company_name, pitch_email, _subject?}, ... ],
                      "draft_task_id": "<可选，任务级幂等标识>"}
        若省略 customers，则对全部客户池执行（与 /api/send 一致，受 batch 上限约束）。
        若省略 draft_task_id，则本次调用自动生成（此时仅保证单次调用内不重复，跨调用无幂等保护）。

        幂等策略（v0.9.3）：
          - 任务级幂等：同一 draft_task_id 内，同一收件人只写入草稿箱一次。
            调用方对「同一次发送任务」传相同 id、对「不同场景/新任务」传新 id；
            新 id（不同场景）允许给同一收件人重存，满足多场景诉求。
          - 入参去重：单次调用内同一收件人只处理一次（防合并名单重复）。
          - 在途守卫：并发/重复触发返回 409，防止同一任务被写两次（20→40）。

        流程：
          1. 校验 SMTP 配置（草稿箱复用同一邮箱 + 授权码登录 IMAP）
          2. 解析 IMAP 服务器（get_imap_server）
          3. 逐封组装 subject/body（与 /api/send 相同规则），IMAP APPEND 到草稿箱
          4. 成功标记客户 status="draft"、记录 drafted_in_tasks 与 draft_saved_at；返回结果看板
        """
        if not HAS_PROVIDERS:
            return jsonify({"error": "SMTP 提供商模块未加载"}), 500

        data = request.get_json(force=True) or {}
        customers = data.get("customers", [])

        # ── 任务级幂等：draft_task_id ──
        # 调用方对「同一次发送任务」传相同 id，对「不同场景/新任务」传新 id。
        # 同 id 内同一收件人只存一次草稿；不同 id（新场景）允许给同一收件人重存。
        # 不传则自动生成（此时跨调用无幂等保护，仅保证单次调用内不重复）。
        draft_task_id = data.get("draft_task_id") or (
            datetime.now().strftime("%Y%m%d%H%M%S") + "-" + uuid.uuid4().hex[:8]
        )

        # 在途守卫：防止并发/重复触发导致同一任务被写两次（与 /api/send 的 is_sending 对齐）
        if state._drafting:
            return jsonify({"error": "正在存入草稿箱，请等待当前任务完成"}), 409
        state._drafting = True
        try:
            # 未指定客户时，默认对全部客户池执行（与 /api/send 行为对齐）
            if not customers:
                customers = state.customers

            if not customers:
                return jsonify({"error": "未选择客户"}), 400

            batch = data.get("batch", BATCH_SIZE_MAX)
            if len(customers) > batch:
                customers = customers[:batch]

            sender = state.config
            if not sender.get("smtp_server") or not sender.get("email") or not sender.get("password"):
                return jsonify({
                    "error": "请先完成 SMTP 配置（草稿箱复用同一邮箱与授权码登录 IMAP）",
                    "need_config": True,
                }), 400

            imap_server, imap_port = get_imap_server(sender["email"])
            if not imap_server:
                return jsonify({
                    "error": f"未识别到邮箱 {sender['email']} 的 IMAP 服务器，无法存入草稿箱",
                    "email": sender["email"],
                }), 400

            results = []
            # 预置：确保待存草稿的客户都在客户池中（兜底 + 支持 Agent 直接传客户列表）
            _present = {c.get("email") for c in state.customers}
            for _c in customers:
                _em = _c.get("email", "")
                if _em and _em not in _present:
                    state.customers.append({
                        "email": _em,
                        "company_name": _c.get("company_name", ""),
                        "pitch_email": _c.get("pitch_email", ""),
                        "status": "unsent",
                        "created_at": datetime.now().isoformat(),
                    })
                    _present.add(_em)

            # 本次调用内去重：同一收件人只处理一次（防入参列表/合并名单重复）
            _seen_in_task = set()

            for customer in customers:
                to_email = customer.get("email", "")
                company = customer.get("company_name", "")
                if not to_email:
                    results.append({"company": company, "email": to_email, "status": "skipped", "reason": "无邮箱"})
                    continue

                if to_email in _seen_in_task:
                    results.append({"company": company, "email": to_email, "status": "skipped", "reason": "本次任务重复收件人"})
                    continue
                _seen_in_task.add(to_email)

                _existing = next((c for c in state.customers if c.get("email") == to_email), None)

                # 已发送的客户不存草稿
                if _existing and _existing.get("status") == "sent":
                    results.append({"company": company, "email": to_email, "status": "skipped", "reason": "该客户已发送过"})
                    continue

                # 任务级幂等：本次 draft_task_id 已给该收件人存过草稿 → 跳过（防重触发 20→40）
                _done_tasks = _existing.get("drafted_in_tasks", []) if _existing else []
                if draft_task_id in _done_tasks:
                    results.append({"company": company, "email": to_email, "status": "skipped", "reason": "本次任务已存入草稿箱"})
                    continue

                subject = customer.get("_subject") or (f"Inquiry — {company[:30]}" if company else "Inquiry")
                body = customer.get("pitch_email", "")
                if not body.strip():
                    results.append({"company": company, "email": to_email, "status": "skipped", "reason": "无邮件正文"})
                    continue

                ok, reason = imap_save_draft(sender, to_email, subject, body, imap_server, imap_port)
                if ok:
                    state.update_status(to_email, "draft", "")
                    # 记录草稿保存时间 + 本任务已存标记（任务级幂等）
                    for c in state.customers:
                        if c.get("email") == to_email:
                            c.setdefault("drafted_in_tasks", [])
                            if draft_task_id not in c["drafted_in_tasks"]:
                                c["drafted_in_tasks"].append(draft_task_id)
                            c["draft_saved_at"] = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                            break
                    results.append({"company": company, "email": to_email, "status": "draft", "reason": ""})
                else:
                    state.update_status(to_email, "failed", reason)
                    results.append({"company": company, "email": to_email, "status": "failed", "reason": reason})

            state.save_customers()
            draft_count = sum(1 for r in results if r["status"] == "draft")
            failed_count = sum(1 for r in results if r["status"] == "failed")
            skipped_count = sum(1 for r in results if r["status"] == "skipped")
            return jsonify({
                "ok": True,
                "draft_task_id": draft_task_id,
                "results": results,
                "draft_count": draft_count,
                "failed_count": failed_count,
                "skipped_count": skipped_count,
            })
        finally:
            state._drafting = False

    # ─── 控制 ───

    @app.route("/api/pause", methods=["POST"])
    def pause():
        state.pause()
        return jsonify({"ok": True})

    @app.route("/api/resume", methods=["POST"])
    def resume():
        state.resume()
        return jsonify({"ok": True})

    @app.route("/api/stop", methods=["POST"])
    def stop():
        state.stop()
        return jsonify({"ok": True})

    # ─── 日志 ───

    @app.route("/api/logs", methods=["GET"])
    def logs():
        status_filter = request.args.get("status")
        return jsonify(state.get_logs(status_filter))

    # ─── 配额 ───

    @app.route("/api/quota", methods=["POST"])
    def update_quota():
        data = request.get_json(force=True)
        if "daily_limit" in data:
            state.stats["daily"]["limit"] = int(data["daily_limit"])
        if "monthly_limit" in data:
            state.stats["monthly"]["limit"] = int(data["monthly_limit"])
        state._persist_stats()
        return jsonify({"ok": True, "quota": state.check_quota()})

    return app


# ──────────────────── 入口 ────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="邮件批量发送本地服务")
    parser.add_argument("--work-dir", default=str(MAIL_SENDER_DIR),
                        help=f"数据目录（默认 {MAIL_SENDER_DIR}）")
    parser.add_argument("--host", default=DEFAULT_HOST)
    parser.add_argument("--port", type=int, default=DEFAULT_PORT)
    args = parser.parse_args()

    # 迁移旧数据（如有）
    migrate_legacy_data()
    # 启动时同步现有数据到工作区
    if Path(args.work_dir).exists():
        sync_to_workspace(args.work_dir)

    print(f"""
╔══════════════════════════════════════════════════════╗
║          海外客户邮件开发信 — 发送服务已启动           ║
╠══════════════════════════════════════════════════════╣
║  看板地址：http://localhost:{args.port}                     ║
║  数据目录：{args.work_dir}                ║
║  说明：在浏览器中打开看板地址操作                      ║
║  关闭：按 Ctrl+C 停止服务                             ║
╚══════════════════════════════════════════════════════╝
""")

    app = create_app(args.work_dir)
    app.run(host=args.host, port=args.port, debug=False)
