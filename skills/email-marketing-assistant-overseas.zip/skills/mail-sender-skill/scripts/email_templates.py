"""
email_templates.py — 按发送目的分类的邮件预设模板（v0.8.0 新增）

背景：
    场景 A（对话式智能）与场景 C（手动导入）在收集发件方画像后，需按"发送目的"
    匹配对应邮件模板。模板中保留两类占位符：
      - {{company}}      ：发送时由 mail_server 替换为【收件方】公司名
      - [发件方公司名] / [主营业务] / [城市或国家] / [价值点] / [发件人]
                         ：由 Agent 在生成阶段替换为【发件方】画像信息
    这样模板既能个性化称呼收件人，又能复用发件方画像。

发送目的（purpose）：
    marketing : 营销推广
    blessing  : 问候祝福
    meeting   : 会议邀约
    other     : 其它

语言：默认 English；支持 简体中文。每类目每语言各一套预设。

对外 API：
    list_purposes()            -> 返回目的枚举与中文标签
    get_template(purpose, language="English") -> {"subject", "body"} 或 None
"""

# ─── 预设模板库 ───
# 结构：{ purpose: { "label_zh": 中文标签, "en": {subject, body}, "zh": {subject, body} } }
TEMPLATES = {
    "marketing": {
        "label_zh": "营销推广",
        "en": {
            "subject": "Partnership Inquiry — {{company}}",
            "body": (
                "Dear {{company}},\n\n"
                "I hope this email finds you well. This is [发件人] from [发件方公司名], "
                "based in [城市或国家], specializing in [主营业务].\n\n"
                "We have helped companies in your industry improve [价值点], and I believe "
                "there may be a fit for {{company}} as well. I would love to share a brief "
                "overview tailored to your business.\n\n"
                "Would you be open to a short introduction? Happy to send more details at your convenience.\n\n"
                "Best regards,\n[发件人]\n[发件方公司名]"
            ),
        },
        "zh": {
            "subject": "合作咨询 — {{company}}",
            "body": (
                "尊敬的 {{company}}：\n\n"
                "您好！我是[发件方公司名]的[发件人]，我们位于[城市或国家]，专注于[主营业务]。\n\n"
                "我们曾协助业内多家企业提升[价值点]，相信也能为{{company}}带来价值。"
                "希望能向您简要介绍针对贵司业务的方案。\n\n"
                "如方便，我可将更详细的资料发给您参考。期待您的回复。\n\n"
                "顺祝商祺，\n[发件人]\n[发件方公司名]"
            ),
        },
    },
    "blessing": {
        "label_zh": "问候祝福",
        "en": {
            "subject": "Warm Greetings to {{company}}",
            "body": (
                "Dear {{company}},\n\n"
                "I hope this message finds you and your team doing well.\n\n"
                "I'm [发件人] from [发件方公司名] ([主营业务]). We've been following your "
                "company's progress with great interest, and would like to take this opportunity "
                "to send our best wishes to you and your team.\n\n"
                "If there is ever a chance to connect or explore collaboration in the future, "
                "we would be delighted. Wishing {{company}} continued success.\n\n"
                "Warm regards,\n[发件人]\n[发件方公司名]"
            ),
        },
        "zh": {
            "subject": "致 {{company}} 的诚挚问候",
            "body": (
                "尊敬的 {{company}}：\n\n"
                "您好！我是[发件方公司名]的[发件人]（[主营业务]）。\n\n"
                "一直关注贵司的发展，借此机会向您和团队致以诚挚的问候。"
                "若未来有机会交流或合作，我们将非常荣幸。祝愿{{company}}生意兴隆、蒸蒸日上。\n\n"
                "此致，\n[发件人]\n[发件方公司名]"
            ),
        },
    },
    "meeting": {
        "label_zh": "会议邀约",
        "en": {
            "subject": "Meeting Invitation — {{company}}",
            "body": (
                "Dear {{company}},\n\n"
                "I'm [发件人] from [发件方公司名], specializing in [主营业务].\n\n"
                "We are organizing a brief online session to introduce our latest solutions, "
                "and I would like to invite {{company}} to join a 20-minute call at your convenience. "
                "The session will focus on [价值点] relevant to your industry.\n\n"
                "Could you let me know a time that works for you? I'm happy to adapt to your timezone.\n\n"
                "Best regards,\n[发件人]\n[发件方公司名]"
            ),
        },
        "zh": {
            "subject": "会议邀约 — {{company}}",
            "body": (
                "尊敬的 {{company}}：\n\n"
                "我是[发件方公司名]的[发件人]，我们专注于[主营业务]。\n\n"
                "我们计划举办一场简短的线上交流，介绍最新方案，诚邀{{company}}参与约 20 分钟的沟通，"
                "内容将围绕贵行业关注的[价值点]展开。\n\n"
                "请问您何时有空？我可配合您的时间与时区安排。\n\n"
                "此致，\n[发件人]\n[发件方公司名]"
            ),
        },
    },
    "other": {
        "label_zh": "其它",
        "en": {
            "subject": "Hello from [发件方公司名] — {{company}}",
            "body": (
                "Dear {{company}},\n\n"
                "I'm [发件人] from [发件方公司名] ([主营业务]).\n\n"
                "I'm reaching out to introduce our company and explore whether there might be "
                "an opportunity to work together. If this isn't a priority right now, no worries — "
                "I'll keep it brief.\n\n"
                "Happy to share more details whenever it suits you.\n\n"
                "Best regards,\n[发件人]\n[发件方公司名]"
            ),
        },
        "zh": {
            "subject": "[发件方公司名] 致 {{company}}",
            "body": (
                "尊敬的 {{company}}：\n\n"
                "我是[发件方公司名]的[发件人]（[主营业务]）。\n\n"
                "致信是想向贵司简要介绍我们，并探讨是否存在合作机会。"
                "若暂时不便，也完全理解。\n\n"
                "如需了解更多，随时与我联系。\n\n"
                "顺祝商祺，\n[发件人]\n[发件方公司名]"
            ),
        },
    },
}

# 目的键 -> 中文标签（供 UI / Agent 弹窗使用）
PURPOSE_LABELS = {k: v["label_zh"] for k, v in TEMPLATES.items()}


def list_purposes() -> list:
    """返回所有发送目的枚举及中文标签。"""
    return [{"key": k, "label_zh": v["label_zh"]} for k, v in TEMPLATES.items()]


def get_template(purpose: str, language: str = "English") -> dict | None:
    """
    按发送目的与语言返回预设模板。

    参数：
        purpose  — marketing / blessing / meeting / other
        language — English / 简体中文 / 其它（非中文一律按 English）
    返回：
        {"purpose", "language", "subject", "body"} 或 None（purpose 不存在时）
    """
    block = TEMPLATES.get(purpose)
    if not block:
        return None
    lang = "zh" if language in ("简体中文", "中文", "zh-CN", "Chinese", "chinese") else "en"
    tpl = block.get(lang, block.get("en"))
    return {
        "purpose": purpose,
        "language": language,
        "subject": tpl["subject"],
        "body": tpl["body"],
    }
