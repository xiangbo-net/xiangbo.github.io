"""
smtp_providers.py — SMTP 邮箱提供商映射与自动检测共享模块

用途：
  1. 通过邮箱域名自动匹配 SMTP 服务器/端口/协议
  2. 提供自动试连接列表（SSL 465 + TLS 587 双端口探测）
  3. 提供各提供商授权码获取引导图文
  4. 统一映射，供 mail_server.py / smtp_test.py / Agent 共享

数据源：
  - PROVIDER_MAP：域名 → 提供商信息
  - SMTP_SERVERS：所有服务端的 SSL/TLS 变体列表（试连接用）
  - AUTH_GUIDES：授权码获取图文步骤
"""

from __future__ import annotations
import re
from typing import Any

# ──────────────────── 域名 → 提供商映射 ────────────────────

DOMAIN_MAP: dict[str, dict[str, Any]] = {
    # ── 国际邮箱 ──
    "gmail.com": {
        "name": "Gmail",
        "display_name": "Gmail（谷歌邮箱）",
        "server": "smtp.gmail.com",
        "ports": [465, 587],
        "use_ssl_default": True,  # 465 SSL 优先
        "auth_key": "gmail",
        "aliases": ["googlemail.com"],
    },
    "outlook.com": {
        "name": "Outlook",
        "display_name": "Outlook（微软邮箱）",
        "server": "smtp-mail.outlook.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "outlook",
        "aliases": ["hotmail.com", "live.com", "msn.com"],
    },
    "yahoo.com": {
        "name": "Yahoo Mail",
        "display_name": "Yahoo 邮箱",
        "server": "smtp.mail.yahoo.com",
        "ports": [465, 587],
        "use_ssl_default": False,  # 587 STARTTLS 优先
        "auth_key": "yahoo",
        "aliases": ["yahoo.co.jp", "yahoo.co.uk", "ymail.com", "rocketmail.com"],
    },
    "icloud.com": {
        "name": "iCloud Mail",
        "display_name": "iCloud 邮箱",
        "server": "smtp.mail.me.com",
        "ports": [587],
        "use_ssl_default": False,
        "auth_key": "icloud",
        "aliases": ["me.com", "mac.com"],
    },
    "zoho.com": {
        "name": "Zoho Mail",
        "display_name": "Zoho Mail",
        "server": "smtp.zoho.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "zoho",
        "aliases": [],
    },
    "yandex.com": {
        "name": "Yandex Mail",
        "display_name": "Yandex 邮箱",
        "server": "smtp.yandex.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "yandex",
        "aliases": ["yandex.ru", "ya.ru"],
    },
    "gmx.com": {
        "name": "GMX Mail",
        "display_name": "GMX 邮箱",
        "server": "smtp.gmx.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "gmx",
        "aliases": ["gmx.net", "gmx.de", "gmx.at", "gmx.ch"],
    },
    "aol.com": {
        "name": "AOL Mail",
        "display_name": "AOL 邮箱",
        "server": "smtp.aol.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "aol",
        "aliases": ["aim.com"],
    },
    # ── 国内邮箱 ──
    "qq.com": {
        "name": "QQ邮箱",
        "display_name": "QQ 邮箱",
        "server": "smtp.qq.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "qq",
        "aliases": ["vip.qq.com", "foxmail.com"],
    },
    "163.com": {
        "name": "163邮箱",
        "display_name": "网易 163 邮箱",
        "server": "smtp.163.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "163",
        "aliases": ["vip.163.com", "188.com"],
    },
    "126.com": {
        "name": "126邮箱",
        "display_name": "网易 126 邮箱",
        "server": "smtp.126.com",
        "ports": [465, 587],
        "use_ssl_default": False,  # 126 通常推荐 587
        "auth_key": "126",
        "aliases": [],
    },
    "88.com": {
        "name": "88邮箱",
        "display_name": "网易 88 邮箱",
        "server": "smtp.88.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "mail88",
        "aliases": ["yeah.net"],
    },
    "sina.com": {
        "name": "新浪邮箱",
        "display_name": "新浪邮箱",
        "server": "smtp.sina.com.cn",
        "ports": [465, 587],
        "use_ssl_default": False,
        "auth_key": "sina",
        "aliases": ["vip.sina.com", "sina.cn"],
    },
    "sohu.com": {
        "name": "搜狐邮箱",
        "display_name": "搜狐邮箱",
        "server": "smtp.sohu.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "sohu",
        "aliases": [],
    },
    "139.com": {
        "name": "139邮箱",
        "display_name": "139 邮箱（中国移动）",
        "server": "smtp.139.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "139",
        "aliases": [],
    },
    "189.cn": {
        "name": "189邮箱",
        "display_name": "189 邮箱（中国电信）",
        "server": "smtp.189.cn",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "189",
        "aliases": [],
    },
    # ── 企业邮箱 ──
    "exmail.qq.com": {
        "name": "腾讯企业邮",
        "display_name": "腾讯企业邮",
        "server": "smtp.exmail.qq.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "tencent_enterprise",
        "aliases": [],
    },
    "aliyun.com": {
        "name": "阿里企业邮",
        "display_name": "阿里企业邮",
        "server": "smtp.mxhichina.com",
        "ports": [465, 587],
        "use_ssl_default": True,
        "auth_key": "aliyun_enterprise",
        "aliases": ["hichina.com", "alibaba-inc.com"],
    },
}


# ──────────────────── SMTP 试连接列表 ────────────────────

_all_servers_cache: list[dict[str, Any]] | None = None


def get_all_servers() -> list[dict[str, Any]]:
    """
    返回所有 SMTP 服务端的 SSL/TLS 变体列表。
    每个条目格式：{"name", "server", "port", "ssl"}
    用途：smtp_test.py 的批量测试 + mail_server auto-test 遍历
    """
    global _all_servers_cache
    if _all_servers_cache is not None:
        return _all_servers_cache

    result: list[dict[str, Any]] = []
    for domain, info in DOMAIN_MAP.items():
        for port in info["ports"]:
            use_ssl = port == 465  # 465=SSL, 587=STARTTLS
            suffix = " (SSL)" if use_ssl else " (TLS)"
            result.append({
                "name": info["name"] + suffix,
                "display_name": info["display_name"],
                "server": info["server"],
                "port": port,
                "ssl": use_ssl,
                "auth_key": info["auth_key"],
            })
    _all_servers_cache = result
    return result


def get_servers_for_provider(provider_name: str) -> list[dict[str, Any]]:
    """根据提供商名称获取所有可用 SMTP 变体。"""
    return [
        s for s in get_all_servers()
        if s["name"].startswith(provider_name)
    ]


# ──────────────────── 邮箱检测函数 ────────────────────


def detect_by_email(email: str) -> dict[str, Any] | None:
    """
    通过邮箱地址自动匹配 SMTP 提供商。

    参数：
      email — 完整的邮箱地址，如 "user@qq.com"

    返回：
      匹配到的 provider 信息字典，包含：
        name, display_name, server, ports, use_ssl_default,
        auth_key, aliases, matched_domain
      未匹配返回 None。
    """
    m = re.match(r".+@(.+)$", email.strip().lower())
    if not m:
        return None
    domain = m.group(1)

    # 精确匹配
    if domain in DOMAIN_MAP:
        result = dict(DOMAIN_MAP[domain])
        result["matched_domain"] = domain
        return result

    # 别名匹配
    for prim_domain, info in DOMAIN_MAP.items():
        if domain in info.get("aliases", []):
            result = dict(info)
            result["matched_domain"] = domain
            return result

    # 后缀匹配（如 mycompany.exmail.qq.com → 腾讯企业邮）
    # 按域名长度降序排列，优先匹配更具体的域名
    sorted_domains = sorted(DOMAIN_MAP.keys(), key=lambda d: -len(d))
    for prim_domain in sorted_domains:
        if domain.endswith("." + prim_domain):
            result = dict(DOMAIN_MAP[prim_domain])
            result["matched_domain"] = domain
            return result

    return None


EXTRA_SMTP_DOMAINS: dict[str, dict[str, Any]] = {
    # 一些使用常见 SMTP 服务但无提供旗下所有域名的场景
    "aliyun.com": {"server": "smtp.mxhichina.com", "display_name": "阿里企业邮"},
    "exmail.qq.com": {"server": "smtp.exmail.qq.com", "display_name": "腾讯企业邮"},
}


# ──────────────────── 授权码获取引导 ────────────────────

AUTH_GUIDES: dict[str, dict[str, Any]] = {
    "gmail": {
        "title": "Gmail 授权码（应用专用密码）",
        "note": "注意：授权码 ≠ 您的 Gmail 登录密码！",
        "steps": [
            "1. 登录您的 Gmail 账号（网页版）",
            "2. 点击右上角头像 → 「管理您的 Google 账号」",
            "3. 左侧导航 → 「安全性」",
            "4. 确保「两步验证」已开启 → 如果未开启，请先开启",
            "5. 在「两步验证」下方点击「应用专用密码」",
            "6. 应用选择「邮件」，设备选择「其他」→ 输入「WorkBuddy」",
            "7. 点击「生成」→ 您将得到一串 16 位字母密码",
            "8. 复制这串密码（中间有空格没关系），粘贴到下方输入框",
        ],
        "url": "https://myaccount.google.com/apppasswords",
        "important": "⚠️ 必须开启两步验证才能生成应用专用密码！",
    },
    "outlook": {
        "title": "Outlook/Hotmail 授权码（应用密码）",
        "note": "注意：授权码 ≠ 您的 Outlook 登录密码！",
        "steps": [
            "1. 登录您的 Outlook 账号（网页版）",
            "2. 点击右上角头像 → 「查看账户」→「安全性」",
            "3. 确保「双重验证」已开启",
            "4. 在「双重验证」页面底部 →「创建新的应用密码」",
            "5. 会生成一串随机密码，复制它",
            "6. 将这串密码粘贴到下方输入框",
        ],
        "url": "https://account.microsoft.com/security",
        "important": "⚠️ 需要开启双重验证才能生成应用密码！如果您的 Outlook 没有这项设置，可直接使用登录密码尝试。",
    },
    "qq": {
        "title": "QQ 邮箱授权码",
        "note": "注意：授权码 ≠ QQ 密码！",
        "steps": [
            "1. 登录 QQ 邮箱（mail.qq.com）",
            "2. 点击顶部「设置」→「账户」",
            "3. 向下滚动到「POP3/IMAP/SMTP 服务」",
            "4. 点击「开启 POP3/SMTP 服务」",
            "5. 系统会提示发送短信验证 → 按提示用绑定手机发送短信",
            "6. 验证通过后，系统会生成一串授权码（16 位字母密码）",
            "7. 复制这串授权码，粘贴到下方输入框中",
            "8. ⚠️ 提醒：授权码只会显示一次，请立即复制保存",
        ],
        "url": "https://mail.qq.com/",
        "important": "⚠️ 授权码只会显示一次，务必复制保存！如丢失需重新生成。",
    },
    "163": {
        "title": "163 邮箱授权码",
        "note": "注意：授权码 ≠ 163 邮箱登录密码！",
        "steps": [
            "1. 登录 163 邮箱（mail.163.com）",
            "2. 点击顶部「设置」→「POP3/SMTP/IMAP」",
            "3. 在「客户端密码」旁点击「新增授权密码」",
            "4. 填写备注（如 WorkBuddy），点击「确定」",
            "5. 系统会生成一串授权码，复制它",
            "6. 将授权码粘贴到下方输入框",
        ],
        "url": "https://mail.163.com/",
        "important": "⚠️ 部分 163 邮箱需先开启 POP3/SMTP 服务才能看到新增授权密码按钮。",
    },
    "126": {
        "title": "126 邮箱授权码",
        "note": "注意：授权码 ≠ 126 邮箱登录密码！",
        "steps": [
            "1. 登录 126 邮箱（mail.126.com）",
            "2. 点击顶部「设置」→「POP3/SMTP/IMAP」",
            "3. 开启「POP3/SMTP 服务」",
            "4. 点击「新增授权密码」，填写备注",
            "5. 系统生成授权码，复制它",
            "6. 将授权码粘贴到下方输入框",
        ],
        "url": "https://mail.126.com/",
        "important": "",
    },
    "mail88": {
        "title": "88 邮箱授权码",
        "note": "注意：授权码 ≠ 88 邮箱登录密码！",
        "steps": [
            "1. 登录 88 邮箱（mail.88.com）",
            "2. 点击顶部「设置」→「POP3/SMTP/IMAP」",
            "3. 开启「POP3/SMTP 服务」",
            "4. 点击「新增授权密码」，填写备注（如 WorkBuddy）",
            "5. 系统生成授权码，复制它",
            "6. 将授权码粘贴到下方输入框",
        ],
        "url": "https://mail.88.com/",
        "important": "",
    },
    "sina": {
        "title": "新浪邮箱授权码",
        "note": "注意：授权码 ≠ 新浪邮箱登录密码！",
        "steps": [
            "1. 登录新浪邮箱（mail.sina.com.cn）",
            "2. 点击「设置」→「账户安全」",
            "3. 开启「POP3/SMTP 服务」",
            "4. 生成授权码并复制",
            "5. 将授权码粘贴到下方输入框",
        ],
        "url": "https://mail.sina.com.cn/",
        "important": "",
    },
    "sohu": {
        "title": "搜狐邮箱授权码",
        "note": "注意：授权码 ≠ 搜狐邮箱登录密码！",
        "steps": [
            "1. 登录搜狐邮箱（mail.sohu.com）",
            "2. 点击「设置」→「POP3/SMTP 设置」",
            "3. 开启 SMTP 服务",
            "4. 按页面提示进行手机验证",
            "5. 验证通过后获得授权码，复制它",
            "6. 将授权码粘贴到下方输入框",
        ],
        "url": "https://mail.sohu.com/",
        "important": "",
    },
    "139": {
        "title": "139 邮箱授权码",
        "note": "注意：授权码 ≠ 139 邮箱登录密码！",
        "steps": [
            "1. 登录 139 邮箱（mail.139.com）",
            "2. 点击「设置」→「账户安全」→「客户端密码」",
            "3. 点击「新增客户端密码」",
            "4. 备注填写 WorkBuddy，点击确定",
            "5. 系统生成授权码，复制它",
            "6. 将授权码粘贴到下方输入框",
        ],
        "url": "https://mail.139.com/",
        "important": "中国移动手机号可直接作为 139 邮箱使用。",
    },
    "189": {
        "title": "189 邮箱授权码",
        "note": "注意：授权码 ≠ 189 邮箱登录密码！",
        "steps": [
            "1. 登录 189 邮箱（mail.189.cn）",
            "2. 点击「设置」→「客户端密码」",
            "3. 点击「生成授权码」",
            "4. 系统生成授权码，复制它",
            "5. 将授权码粘贴到下方输入框",
        ],
        "url": "https://mail.189.cn/",
        "important": "中国电信手机号可直接作为 189 邮箱使用。",
    },
    "yahoo": {
        "title": "Yahoo 邮箱授权码（应用专用密码）",
        "note": "注意：授权码 ≠ Yahoo 登录密码！",
        "steps": [
            "1. 登录 Yahoo 账号",
            "2. 进入「账户安全」页面",
            "3. 开启「两步验证」（Two-step verification）",
            "4. 完成后进入「应用密码」（App passwords）",
            "5. 选择应用类型「其他应用」，命名后生成密码",
            "6. 复制这串密码，粘贴到下方输入框",
        ],
        "url": "https://login.yahoo.com/account/security",
        "important": "⚠️ 需开启两步验证才能生成应用专用密码。",
    },
    "icloud": {
        "title": "iCloud 邮箱专用密码",
        "note": "注意：授权码 ≠ Apple ID 密码！",
        "steps": [
            "1. 登录 appleid.apple.com",
            "2. 进入「安全性」→「应用专用密码」",
            "3. 点击「生成密码」，备注填写 WorkBuddy",
            "4. 系统生成一串专用密码，复制它",
            "5. 将密码粘贴到下方输入框",
        ],
        "url": "https://appleid.apple.com/",
        "important": "⚠️ 需开启 Apple ID 双重认证才能使用。",
    },
    "zoho": {
        "title": "Zoho Mail 应用专用密码",
        "note": "注意：授权码 ≠ Zoho 登录密码！",
        "steps": [
            "1. 登录 Zoho Mail 账号",
            "2. 点击右上角头像 →「我的账户」→「安全性」",
            "3. 在「应用专用密码」旁点击「生成」",
            "4. 选择应用类型「邮件」，设备「其他」",
            "5. 系统生成密码，复制它",
            "6. 将密码粘贴到下方输入框",
        ],
        "url": "https://accounts.zoho.com/",
        "important": "",
    },
    "yandex": {
        "title": "Yandex 邮箱应用专用密码",
        "note": "注意：授权码 ≠ Yandex 登录密码！",
        "steps": [
            "1. 登录 Yandex 账号",
            "2. 进入「安全性」→「应用密码」",
            "3. 点击「创建密码」，选择「邮件」应用",
            "4. 系统生成 16 位密码，复制它",
            "5. 将密码粘贴到下方输入框",
        ],
        "url": "https://id.yandex.com/security/",
        "important": "",
    },
    "gmx": {
        "title": "GMX 邮箱授权码",
        "note": "⚠️ GMX 免费邮箱可能不支持 SMTP 授权码模式，可直接使用登录密码尝试。",
        "steps": [
            "1. 登录 GMX 邮箱（gmx.com）",
            "2. 进入「设置」→「POP3 & IMAP」",
            "3. 确保 SMTP 访问已启用",
            "4. 尝试直接使用您的 GMX 登录密码",
        ],
        "url": "https://www.gmx.com/",
        "important": "如果登录密码无法使用，请考虑更换其他邮箱（推荐 QQ/163/Outlook）。",
    },
    "aol": {
        "title": "AOL 邮箱应用专用密码",
        "note": "注意：授权码 ≠ AOL 登录密码！",
        "steps": [
            "1. 登录 AOL 账号",
            "2. 进入「安全设置」",
            "3. 开启「双重认证」",
            "4. 进入「应用密码」页面，生成密码",
            "5. 复制密码，粘贴到下方输入框",
        ],
        "url": "https://login.aol.com/",
        "important": "",
    },
    "tencent_enterprise": {
        "title": "腾讯企业邮授权码",
        "note": "注意：授权码 ≠ 企业邮箱登录密码！",
        "steps": [
            "1. 以管理员或成员身份登录腾讯企业邮",
            "2. 点击「设置」→「邮箱设置」→「客户端设置」",
            "3. 确保「SMTP 服务」已开启",
            "4. 点击「生成授权码」或「客户端专用密码」",
            "5. 系统生成授权码，复制它",
            "6. 将授权码粘贴到下方输入框",
        ],
        "url": "https://exmail.qq.com/",
        "important": "企业邮管理员可能需要为企业成员开启 SMTP 服务权限。",
    },
    "aliyun_enterprise": {
        "title": "阿里企业邮客户端密码",
        "note": "注意：客户端密码 ≠ 您的登录密码！",
        "steps": [
            "1. 登录阿里企业邮箱网页版",
            "2. 点击「设置」→「客户端密码」",
            "3. 点击「新增客户端密码」",
            "4. 填写备注（如 WorkBuddy），点击确定",
            "5. 系统生成密码，复制它",
            "6. 将密码粘贴到下方输入框",
        ],
        "url": "https://qiye.aliyun.com/",
        "important": "部分阿里企业邮在「安全设置」→「客户端密码」中设置。",
    },
}


def get_auth_guide(auth_key: str) -> dict[str, Any] | None:
    """根据授权码 key 获取引导图文。"""
    return AUTH_GUIDES.get(auth_key)


def get_provider_names() -> list[str]:
    """返回所有提供商显示名列表（按类别分组含分隔标识），供弹窗选择。"""
    providers = sorted(set(
        info["display_name"] for info in DOMAIN_MAP.values()
    ), key=lambda x: (
        0 if x in ("QQ 邮箱", "163 邮箱", "126 邮箱", "139 邮箱（中国移动）",
                    "189 邮箱（中国电信）", "新浪邮箱", "搜狐邮箱") else
        1 if x in ("腾讯企业邮", "阿里企业邮") else
        2 if x in ("Gmail（谷歌邮箱）", "Outlook（微软邮箱）") else
        3
    ))
    return providers


# ──────────────────── 快速检测函数 ────────────────────


def quick_provider_list() -> list[dict[str, str]]:
    """
    返回弹窗用的提供商选项列表。
    每个选项包含 label 和 description（邮箱域名示例）。
    """
    options = []
    for domain, info in DOMAIN_MAP.items():
        # 只取每个提供商的前一个域名做示例
        if domain not in set().union(*[set(v["aliases"]) for v in DOMAIN_MAP.values()]):
            example_domains = [domain] + info.get("aliases", [])
            desc = f"使用 @{domain} 等邮箱"
            options.append({
                "name": info["name"],
                "label": info["display_name"],
                "description": desc,
                "domains": example_domains,
            })
    # 去重：同名的合并
    seen = set()
    merged = []
    for opt in options:
        key = opt["name"]
        if key not in seen:
            seen.add(key)
            merged.append(opt)
    # v0.9.2 新增：追加「手工输入邮箱地址」兜选项
    # 用途：覆盖"已知邮箱类型但服务商不在上述 15 家列表内"的情况
    #       （如企业自建邮箱、学校邮箱、小众服务商等）。
    # 选中后 Agent 提示用户输入完整邮箱地址，并调用 /api/config/detect
    # 自动识别服务商（与分支 B「我不确定」同源），保证入口一致。
    # name="manual" 用于 Agent 区分该特殊项，不对应任何具体 DOMAIN_MAP 条目。
    merged.append({
        "name": "manual",
        "label": "手工输入邮箱地址",
        "description": "直接输入完整邮箱地址（如 you@company.com），系统自动识别服务商",
        "domains": [],
    })
    return merged


# ──────────────────── IMAP 草稿箱支持（v0.9.0 新增） ────────────────────
#
# 「存进邮箱草稿箱」功能通过 IMAP（993/SSL）将编排好的邮件写入发件方邮箱的
# 草稿（Drafts）文件夹，用户随后可在自己的邮件客户端中查看草稿并手动发送。
# 各提供商的 IMAP 服务器与 SMTP 不同，下表按 DOMAIN_MAP 中的 provider name
# 映射（别名/后缀命中同一 name，因此可统一解析，无需为每个别名单独维护）。

IMAP_BY_PROVIDER: dict[str, dict[str, Any]] = {
    "Gmail":        {"server": "imap.gmail.com",       "port": 993},
    "Outlook":      {"server": "imap.outlook.com",     "port": 993},
    "Yahoo Mail":   {"server": "imap.mail.yahoo.com",  "port": 993},
    "iCloud Mail":  {"server": "imap.mail.me.com",     "port": 993},
    "Zoho Mail":    {"server": "imap.zoho.com",        "port": 993},
    "Yandex Mail":  {"server": "imap.yandex.com",      "port": 993},
    "GMX Mail":     {"server": "imap.gmx.com",         "port": 993},
    "AOL Mail":     {"server": "imap.aol.com",         "port": 993},
    "QQ邮箱":        {"server": "imap.qq.com",          "port": 993},
    "163邮箱":       {"server": "imap.163.com",         "port": 993},
    "126邮箱":       {"server": "imap.126.com",         "port": 993},
    "88邮箱":        {"server": "imap.88.com",          "port": 993},
    "新浪邮箱":      {"server": "imap.sina.com",        "port": 993},
    "搜狐邮箱":      {"server": "imap.sohu.com",        "port": 993},
    "139邮箱":       {"server": "imap.139.com",         "port": 993},
    "189邮箱":       {"server": "imap.189.cn",          "port": 993},
    "腾讯企业邮":    {"server": "imap.exmail.qq.com",   "port": 993},
    "阿里企业邮":    {"server": "imap.mxhichina.com",   "port": 993},
}


def get_imap_server(email: str) -> tuple[str | None, int]:
    """
    根据邮箱地址返回其 IMAP 服务器与端口，用于「存进邮箱草稿箱」功能。

    参数：
      email — 完整邮箱地址，如 "user@qq.com"

    返回：
      (imap_server, port) — 解析成功返回服务器地址与 993；
      未匹配到已知提供商返回 (None, 993)，调用方据此提示用户 IMAP 不可用。
    """
    if not email or "@" not in email:
        return (None, 993)
    provider = detect_by_email(email)
    if not provider:
        return (None, 993)
    info = IMAP_BY_PROVIDER.get(provider.get("name", ""))
    if not info:
        return (None, 993)
    return (info["server"], info.get("port", 993))
